import { Body as o } from "caido:utils";
function n(e, r, t) {
  return e.console.log(new o("test")), Math.floor(Math.random() * (t - r + 1) + r);
}
function i(e) {
  e.api.register("generateNumber", n);
}
export {
  i as init
};
