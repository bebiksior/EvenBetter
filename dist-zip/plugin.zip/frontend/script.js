var Ve = Object.defineProperty;
var Ge = (n, e, t) => e in n ? Ve(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t;
var _ = (n, e, t) => (Ge(n, typeof e != "symbol" ? e + "" : e, t), t);
let Q = null;
const ze = (n) => {
  Q = n;
}, p = () => {
  if (!Q)
    throw new Error("CaidoAPI is not set yet!");
  return Q;
}, N = "v2.5", Ke = "https://raw.githubusercontent.com/bebiksior/EvenBetter/main/version.txt", Qe = {
  ssrfInstancePlaceholder: "$ssrfinstance",
  ssrfInstanceFunctionality: "true",
  sidebarHideGroups: "true",
  sidebarRearrangeGroups: "true",
  showOutdatedVersionWarning: "true",
  highlightRowsFunctionality: "true",
  quickDecode: "true",
  ssrfInstanceTool: "ssrf.cvssadvisor.com"
}, E = (n) => {
  if (localStorage.getItem(`evenbetter_${n}`) === null) {
    const e = Qe[n];
    e !== void 0 && localStorage.setItem(`evenbetter_${n}`, e);
  }
  return localStorage.getItem(`evenbetter_${n}`) || "";
}, I = (n, e) => {
  localStorage.setItem(`evenbetter_${n}`, e);
}, Ye = async () => {
  try {
    const e = await (await fetch(Ke, {
      cache: "no-store"
    })).text(), t = parseFloat(e.replace("v", ""));
    return parseFloat(
      N.replace("v", "")
    ) > t ? {
      isLatest: !0,
      message: `You are using a development version: ${N}.`
    } : e.trim() === N ? {
      isLatest: !0,
      message: "You are using the latest version! 🎉"
    } : {
      isLatest: !1,
      message: `New EvenBetter version available: ${e}.`
    };
  } catch {
    return {
      isLatest: !0,
      message: "Failed to check for updates"
    };
  }
}, Ie = {
  gray: {
    name: "Gray",
    "--c-header-cell-border": "#101010",
    "--c-bg-default": "#202020",
    "--c-bg-subtle": "#252525",
    "--c-table-item-row": "#252525",
    "--c-table-item-row-hover": "#303030",
    "--header-cell-width": "1px",
    "--c-table-even-item-row": "#282828",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#222222"
  },
  evendarker: {
    name: "Even Darker",
    "--c-header-cell-border": "#101010",
    "--c-bg-default": "#050607",
    "--c-bg-subtle": "#090a0c",
    "--c-table-item-row": "#08090a",
    "--c-table-item-row-hover": "#0f1012",
    "--header-cell-width": "1px",
    "--c-table-even-item-row": "#08090a",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#0b0b0b"
  },
  caido: {
    name: "Caido Default",
    "--c-header-cell-border": "#101010",
    "--c-bg-default": "#25272d",
    "--c-bg-subtle": "var(--c-gray-800)",
    "--c-table-item-row": "#353942",
    "--c-table-item-row-hover": "#25272d",
    "--header-cell-width": "0px",
    "--c-table-even-item-row": "#353942",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "rgb(43, 46, 53)"
  },
  oceanblue: {
    name: "Ocean Blue",
    "--c-header-cell-border": "#116699",
    "--c-bg-default": "#1a2b3c",
    "--c-bg-subtle": "#2a3b4c",
    "--c-table-item-row": "#1c2d3e",
    "--c-table-item-row-hover": "#2a3b4c",
    "--header-cell-width": "0px",
    "--c-table-even-item-row": "#2c3d4e",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#213345"
  },
  solarized: {
    name: "Solarized",
    "--c-header-cell-border": "#93a1a1",
    "--c-bg-default": "#002b36",
    "--c-bg-subtle": "#073642",
    "--c-table-item-row": "#073642",
    "--c-table-item-row-hover": "#586e75",
    "--header-cell-width": "1px",
    "--c-table-even-item-row": "#073642",
    "--c-fg-default": "#e3e3e3",
    "--c-fg-subtle": "#657b83",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "#073642",
    "--c-table-background": "#03303c"
  },
  black: {
    name: "Black",
    "--c-header-cell-border": "#070707",
    "--c-bg-default": "#000000",
    "--c-bg-subtle": "#000000",
    "--c-table-item-row": "#050505",
    "--c-table-item-row-hover": "#222222",
    "--header-cell-width": "0px",
    "--c-table-even-item-row": "#111111",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#000000"
  },
  /*light: {
      name: "Light",
      customCSS: `
        .toggle-features,
        .settings-box {
          border: 1px solid var(--c-gray-400);
        }
  
        .c-table-item__key {
          background-color: #d3d3d3 !important;
        }
      `,
      "--c-bg-inset": "#ffffff",
      "--c-header-cell-border": "#e1e4e8",
      "--c-bg-default": "#f6f8fa",
      "--c-bg-subtle": "#f6f8fa",
      "--c-table-item-row": "#f1f1f1",
      "--c-table-item-row-hover": "#e7e7e7",
      "--header-cell-width": "1px",
      "--c-table-even-item-row": "#ffffff",
      "--c-fg-default": "var(--c-black-100)",
      "--c-fg-subtle": "var(--c-gray-400)",
      "--selection-background": "rgba(0, 0, 0, 0.15)",
      "--selected-row-background": "var(--c-bg-default)",
    },*/
  neon: {
    name: "Neon",
    "--c-header-cell-border": "#ff6ac1",
    "--c-bg-default": "#2b213a",
    "--c-bg-subtle": "#30263e",
    "--c-table-item-row": "#2b213a",
    "--c-table-item-row-hover": "#3c2e52",
    "--header-cell-width": "1px",
    "--c-table-even-item-row": "#372e45",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#2b213a"
  },
  deepdark: {
    name: "Deep Dark",
    "--c-header-cell-border": "#101010",
    "--c-bg-default": "#0b0b0b",
    "--c-bg-subtle": "#050505",
    "--c-table-item-row": "#0f0f0f",
    "--c-table-item-row-hover": "#1a1a1a",
    "--header-cell-width": "1px",
    "--c-table-even-item-row": "#0e0e0e",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#0b0b0b"
  }
}, Le = (n) => {
  var t;
  const e = Ie[n];
  if (e && ((t = document.getElementById("evenbetter-custom-theme")) == null || t.remove(), Object.keys(e).forEach((s) => {
    if (!s.startsWith("--"))
      return;
    const o = e[s];
    o && document.documentElement.style.setProperty(s, o, "important");
  }), e.customCSS)) {
    const s = document.createElement("style");
    s.id = "evenbetter-custom-theme", s.innerHTML = e.customCSS, document.head.appendChild(s);
  }
}, Y = {
  defaultCaido: {
    name: "Caido Default"
  },
  jetbrainsMono: {
    name: "Jetbrains Mono",
    url: "https://fonts.cdnfonts.com/css/jetbrains-mono"
  },
  comicSans: {
    name: "Comic Sans MS",
    url: "https://fonts.googleapis.com/css2?family=Comic+Sans+MS"
  },
  firaCode: {
    name: "Fira Code",
    url: "https://fonts.googleapis.com/css2?family=Fira+Code:wght@300..600&display=swap"
  }
}, Ae = (n) => {
  var s;
  const e = Y[n];
  if (!e || (document.getElementById("evenbetter-custom-font") && ((s = document.getElementById("evenbetter-custom-font")) == null || s.remove()), !e.url))
    return;
  const t = document.createElement("style");
  t.id = "evenbetter-custom-font", t.innerHTML = `@import url('${e.url}'); body { font-family: '${e.name}', sans-serif; }`, document.head.appendChild(t);
};
let J = null;
const Je = (n) => {
  J = n;
}, h = () => {
  if (!J)
    throw new Error("EvenBetterAPI is not set yet!");
  return J;
}, Ze = () => {
  const n = E("theme"), e = document.createElement("div");
  e.innerHTML = Xe(Ie, n), e.classList.add("evenbetter-custom-tab"), e.querySelector(
    "#theme-select"
  ).addEventListener("change", (l) => {
    const m = l.target.value;
    I("theme", m), Le(m);
  }), e.querySelector(
    "#font-select"
  ).addEventListener("change", (l) => {
    const m = l.target.value;
    I("font", m), Ae(m);
  });
  const o = [];
  let r = !1;
  e.querySelectorAll("input[type=checkbox]").forEach((l) => {
    l.addEventListener("change", (d) => {
      const m = d.target, f = m.name, b = m.checked, g = o.findIndex(
        (w) => w.name === f
      );
      g !== -1 ? o.splice(g, 1) : o.push({ name: f, value: b }), r = o.length > 0;
      const v = e.querySelector(
        ".toggle-features__content button"
      );
      v && (r ? v.removeAttribute("disabled") : v.setAttribute("disabled", "true"));
    });
  });
  const i = e.querySelector(
    ".toggle-features__content button"
  );
  if (!i)
    return;
  i.addEventListener("click", () => {
    o.forEach((l) => {
      I(l.name, l.value);
    }), localStorage.setItem("previousPath", "#/settings/evenbetter"), location.reload();
  });
  const c = e.querySelector(
    ".ssrfInstanceFunctionality"
  );
  if (c) {
    const l = [], d = c.querySelector("input");
    if (!d)
      return;
    d.value = E(
      "ssrfInstancePlaceholder"
    ), d.addEventListener("input", (f) => {
      const g = f.target.value;
      l.push({
        name: "ssrfInstancePlaceholder",
        value: g
      });
      const v = c.querySelector("button");
      v && v.removeAttribute("disabled");
    });
    const m = c.querySelector("button");
    if (!m)
      return;
    m.addEventListener("click", () => {
      l.forEach((f) => {
        I(f.name, f.value), localStorage.setItem("previousPath", window.location.hash), location.reload();
      });
    });
  }
  const u = e.querySelector(".useopenai");
  if (u) {
    const l = u.querySelector("button");
    if (!l)
      return;
    const d = u.querySelector("input");
    d.value = E("openaiApiKey") || "";
    let m = d.value;
    d.addEventListener("input", (f) => {
      const g = f.target.value;
      l && (g === m ? l.setAttribute("disabled", "true") : l.removeAttribute("disabled"));
    }), l.addEventListener("click", (f) => {
      const b = d.value;
      I("openaiApiKey", b), m = b, l.setAttribute("disabled", "true"), h().toast.showToast({
        message: "OpenAI API key saved!",
        duration: 2e3,
        position: "bottom",
        type: "success"
      });
    });
  }
  return Ye().then(({ isLatest: l, message: d }) => {
    if (!l) {
      const m = e.querySelector(
        ".header-outdated"
      );
      m.style.display = "block";
    }
  }), e;
}, Xe = (n, e) => {
  const t = [
    {
      name: "sidebarTweaks",
      title: "Sidebar tweaks",
      items: [
        {
          name: "sidebarRearrangeGroups",
          title: "Groups Rearrange",
          description: "Show move buttons next to sidebar groups."
        },
        {
          name: "sidebarHideGroups",
          title: "Groups Collapse",
          description: "This allows you to collapse groups in the sidebar."
        }
      ]
    },
    {
      name: "ssrfInstanceFunctionality",
      title: "Quick SSRF Instance",
      items: [
        {
          name: "ssrfInstanceFunctionality",
          title: "Quick SSRF Instance",
          description: "Adds a Quick SSRF sidebar page and allows you to quickly create new SSRF instance by typing the placeholder."
        }
      ]
    },
    {
      name: "quickDecode",
      title: "Quick Decode",
      items: [
        {
          name: "quickDecode",
          title: "Quick Decode",
          description: "Selecting text on the Replay page will attempt to decode it and show the result at the left bottom corner."
        }
      ]
    },
    {
      name: "versionCheckWarning",
      title: "Version Check Warning",
      items: [
        {
          name: "showOutdatedVersionWarning",
          title: "Version Check Warning",
          description: "Choose if you want to see warning on startup if you are using outdated EvenBetter version."
        }
      ]
    }
  ], s = (o) => {
    const r = h().components.createCheckbox(), a = r.querySelector(
      ".eb-checkbox__input"
    );
    return a.name = o, a.id = o, E(o) === "true" && a.setAttribute("checked", "true"), r;
  };
  return `
  <div class="even-better__settings" id="evenbetter-settings-content">
    <header>
      <div class="header-title">
        <h1>EvenBetter ${N} - Settings</h1>
        <div class="header-outdated" style="display:none;">You are using outdated version!</div>
      </div>
      <div class="header-description">
        Customize EvenBetter plugin here and make your Caido even better :D
      </div>
    </header>

    <main>
      <div class="left">
        <div class="settings-box">
          <!-- Settings header -->
          <div class="settings-box__header">
            <div class="settings-box__header-title">Appearance</div>
            <div class="settings-box__header-description">
              Change the appearance of your Caido
            </div>
          </div>

          <!-- Settings content -->
          <div class="settings-box__content">
            <div class="settings-box__content-item">
              <div class="settings-box__content-item-title">Theme</div>
              <select id="theme-select">
                ${Object.keys(n).map(
    (o) => {
      var r;
      return `<option value="${o}" ${o === e ? "selected" : ""}>${(r = n[o]) == null ? void 0 : r.name}</option>`;
    }
  ).join("")}
              </select>
            </div>
            <div class="settings-box__content-item">
              <div class="settings-box__content-item-title">Font</div>
              <select id="font-select">
                ${Object.keys(Y).map(
    (o) => {
      var r;
      return `<option value="${o}" ${o === E("font") ? "selected" : ""}>${(r = Y[o]) == null ? void 0 : r.name}</option>`;
    }
  ).join("")}
              </select>
            </div>
          </div>
        </div>
        ${E("ssrfInstanceFunctionality") == "true" ? `
        <div class="settings-box ssrfInstanceFunctionality">
          <!-- Settings header -->
          <div class="settings-box__header">
            <div class="settings-box__header-title">Quick SSRF placeholder</div>
            <div class="settings-box__header-description">
              Set the placeholder that will be used to create new SSRF instance
            </div>
          </div>

          <!-- Settings content -->
          <div class="settings-box__content">
            <div class="c-text-input">
              <div class="c-text-input__outer">
                <div class="c-text-input__inner">
                  <input
                    placeholder="$ssrfinstance"
                    spellcheck="false"
                    class="c-text-input__input"
                  />
                </div>
              </div>
            </div>

            <button disabled>Save</button>
          </div>
        </div>` : ""}
        <div class="settings-box useopenai">
          <!-- Settings header -->
          <div class="settings-box__header">
            <div class="settings-box__header-title">Use OpenAI API</div>
            <div class="settings-box__header-description">
              Use the OpenAI API instead of Caido default assistant API.
            </div>
          </div>

          <!-- Settings content -->
          <div class="settings-box__content">
            <div class="c-text-input">
              <div class="c-text-input__outer">
                <div class="c-text-input__inner">
                  <input
                    placeholder="sk-xxxxxxx"
                    spellcheck="false"
                    class="c-text-input__input"
                    type="password"
                  />
                </div>
              </div>
            </div>

            <button disabled>Save</button>
          </div>
        </div>
      </div>

      <div class="right">
        <div class="toggle-features">
          <div class="toggle-features__header">
            <div class="toggle-features__header-title">Toggle features</div>
            <div class="toggle-features__header-description">
              Enable or disable features of the EvenBetter plugin. Note that there are some smaller features that can't be turned off.
            </div>
          </div>
          <hr />
          <div class="toggle-features__content">
            ${t.map(
    (o) => `
              <div class="toggle-features__content-item">
                <div class="toggle-features__content-item-title">
                  ${o.title}
                </div>

                ${o.items.map(
      (r) => `
                  <div class="toggle-features__content-item-toggle">
                    <div class="toggle-features__content-item-description">
                      <b>${r.title}:</b> ${r.description}
                    </div>
                    <div>
                      ${s(r.name).innerHTML}
                    </div>
                  </div>`
    ).join("")}

              </div>

              <hr />`
  ).join("")}

            <button disabled>Save</button>
          </div>
        </div>
      </div>
    </main>
  </div>`;
}, et = () => {
  const n = Ze();
  n && (p().navigation.addPage("/settings/evenbetter", {
    body: n
  }), p().menu.registerItem({
    type: "Settings",
    label: "EvenBetter",
    path: "/settings/evenbetter",
    leadingIcon: "fas fa-cogs"
  }), p().commands.register("evenbetter:settings", {
    name: "Go to EvenBetter: Settings",
    group: "EvenBetter: Navigation",
    run: () => {
      p().navigation.goTo("/settings/evenbetter");
    }
  }), p().commandPalette.register("evenbetter:settings"), p().commands.register("evenbetter:library", {
    name: "Go to EvenBetter: Library",
    group: "EvenBetter: Navigation",
    run: () => {
      p().navigation.goTo("/workflows/library");
    }
  }), p().commandPalette.register("evenbetter:library"));
}, tt = new Map(
  Object.entries({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
    "/": "&#x2F;"
  })
);
function se(n) {
  return String(n).replace(/[&<>"'\/]/g, (e) => tt.get(e));
}
const oe = "https://api.cvssadvisor.com/ssrf/api/instance", Te = async (n, e, t, s) => fetch(`https://api.cvssadvisor.com/ssrf/api/instance/${n}`, {
  method: "POST",
  body: JSON.stringify({
    statusCode: e,
    body: t,
    headers: s
  })
}).then((o) => o.ok), nt = async (n) => fetch(
  `https://api.cvssadvisor.com/ssrf/api/instance/${n}`
).then((e) => e.json()), st = {}, ot = "oast.fun", qe = () => {
  const n = localStorage.getItem("eb-interactsh-enable"), e = localStorage.getItem("eb-interactsh-host");
  let t = n && n === "true" && e ? e : ot;
  return !t.startsWith("http://") && !t.startsWith("https://") && (t = "https://" + t), {
    hostname: new URL(t).hostname,
    url: t
  };
};
class rt {
  constructor() {
    _(this, "publicKey", null);
    _(this, "privateKey", null);
  }
  async generateKeys() {
    const { publicKey: e, privateKey: t } = await window.crypto.subtle.generateKey(
      {
        name: "RSA-OAEP",
        modulusLength: 2048,
        publicExponent: new Uint8Array([1, 0, 1]),
        hash: { name: "SHA-256" }
      },
      !0,
      ["encrypt", "decrypt"]
    );
    this.publicKey = e, this.privateKey = t;
  }
  async getPublicKey() {
    if (!this.publicKey)
      throw new Error("Public key not generated yet.");
    const e = await window.crypto.subtle.exportKey("spki", this.publicKey), t = String.fromCharCode.apply(
      null,
      Array.from(new Uint8Array(e))
    ), s = btoa(t), o = this.splitStringEveryN(s, 64);
    let r = `-----BEGIN PUBLIC KEY-----
`;
    for (const a of o)
      r += a + `
`;
    return r += `-----END PUBLIC KEY-----
`, r;
  }
  splitStringEveryN(e, t) {
    const s = [];
    for (let o = 0; o < e.length; o += t)
      s.push(e.substr(o, t));
    return s;
  }
}
const de = (n) => {
  const e = "abcdefghijklmnopqrstuvwxyz0123456789";
  let t = "";
  for (let s = 0; s < n; s++)
    t += e.charAt(Math.floor(Math.random() * e.length));
  return t;
}, at = async () => {
  const n = new rt();
  await n.generateKeys();
  const e = await n.getPublicKey(), t = n.privateKey, s = window.crypto.randomUUID(), o = de(20), r = {
    "public-key": btoa(e),
    "secret-key": s,
    "correlation-id": o
  }, a = qe(), i = localStorage.getItem("eb-interactsh-token"), c = {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(r)
  }, u = localStorage.getItem("eb-interactsh-enable");
  return i && u && u === "true" && Object.assign(c, {
    headers: {
      ...c.headers,
      Authorization: i
    }
  }), fetch(`${a.url}/register`, c).then((l) => ({
    secretKey: s,
    correlationId: o,
    privateKey: t,
    responseStatusCode: l.status,
    hostname: o + de(13) + "." + a.hostname
  })).catch((l) => (h().toast.showToast({
    message: "Failed to create interactsh instance",
    type: "error",
    position: "bottom",
    duration: 3e3
  }), Promise.reject(l)));
}, it = async (n, e, t) => {
  const s = qe(), o = localStorage.getItem("eb-interactsh-token"), r = localStorage.getItem("eb-interactsh-enable"), a = {};
  return o && r && r === "true" && Object.assign(a, {
    headers: {
      Authorization: o
    }
  }), fetch(
    `${s.url}/poll?id=${e}&secret=${n}`,
    a
  ).then((i) => i.json()).then(async (i) => {
    if (i.data == null)
      return;
    const c = i.aes_key, u = await ct(c, t), l = i.data;
    let d = [];
    return l.forEach((m) => {
      const f = JSON.parse(
        lt(m, btoa(u))
      );
      d.push({
        protocol: f.protocol,
        uniqueId: f["unique-id"],
        rawRequest: f["raw-request"],
        timestamp: f.timestamp,
        remoteAddress: f["remote-address"]
      });
    }), {
      decodedData: d
    };
  });
}, ct = (n, e) => {
  const t = Uint8Array.from(
    atob(n),
    (s) => s.charCodeAt(0)
  );
  return window.crypto.subtle.decrypt(
    {
      name: "RSA-OAEP"
    },
    e,
    t
  ).then((s) => new TextDecoder().decode(s));
}, lt = (n, e) => {
  const t = Buffer.from(n, "base64").slice(0, 16), s = Buffer.from(e, "base64"), o = st.createDecipheriv(
    "aes-256-cfb",
    s,
    t
  );
  let r = o.update(Buffer.from(n, "base64").slice(16));
  return r += o.final("utf8"), r.toString();
};
var W = /* @__PURE__ */ ((n) => (n.CVSSADVISOR = "ssrf.cvssadvisor.com", n.INTERACTSH = "interactsh.com", n))(W || {}), Me = /* @__PURE__ */ ((n) => (n.ACTIVE = "ACTIVE", n.CREATING = "CREATING", n))(Me || {});
let y = null, Z = [];
const dt = () => {
  if (y)
    switch (y.type) {
      case "ssrf.cvssadvisor.com":
        fetch(oe + "/" + y.id).then((e) => e.json()).then((e) => {
          const t = e.requests_history;
          !t || (t == null ? void 0 : t.length) === 0 || t.forEach((s) => {
            Z.includes(s.id) || (s.timestamp = s.timestamp * 1e3, h().eventManager.triggerEvent("onSSRFHit", s), Z.push(s.id));
          });
        }).catch(() => {
          Re(
            "ssrf.cvssadvisor.com"
            /* CVSSADVISOR */
          ).then(
            () => Pe()
          );
        });
        break;
      case "interactsh.com":
        if (y.secretKey == null)
          return;
        const n = y.privateKey;
        if (!n)
          return;
        it(
          y.secretKey,
          y.id,
          n
        ).then((e) => {
          !e || !e.decodedData || e.decodedData.forEach((t) => {
            const s = {
              id: t.uniqueId,
              protocol: t.protocol.toUpperCase(),
              dump: t.rawRequest,
              ip: t.remoteAddress,
              timestamp: new Date(t.timestamp).getTime()
            };
            h().eventManager.triggerEvent("onSSRFHit", s);
          });
        });
        break;
    }
}, Re = async (n) => {
  if (!(y && y.state === "CREATING"))
    switch (n) {
      case "ssrf.cvssadvisor.com":
        return fetch(oe, {
          method: "POST"
        }).then((e) => e.json()).then((e) => {
          y = {
            id: e,
            url: e + ".c5.rs",
            type: "ssrf.cvssadvisor.com",
            state: "ACTIVE"
            /* ACTIVE */
          }, Z = [], h().toast.showToast({
            message: "Successfully created SSRF instance",
            type: "success",
            position: "bottom",
            duration: 3e3
          }), I("ssrfInstanceTool", n), I("ssrfInstanceHostname", y.url), h().eventManager.triggerEvent("onSSRFInstanceChange");
        }).catch((e) => {
          console.error(e);
        });
      case "interactsh.com":
        return at().then((e) => {
          if (e.responseStatusCode !== 200) {
            h().modal.openModal({
              title: "Error",
              content: "Failed to create interactsh instance"
            });
            return;
          }
          h().toast.showToast({
            message: "Successfully created SSRF instance",
            type: "success",
            position: "bottom",
            duration: 3e3
          });
          const t = e.privateKey;
          t && (y = {
            id: e.correlationId,
            url: e.hostname,
            secretKey: e.secretKey,
            privateKey: t,
            type: "interactsh.com",
            state: "ACTIVE"
            /* ACTIVE */
          }, I("ssrfInstanceTool", n), I("ssrfInstanceHostname", y.url), h().eventManager.triggerEvent("onSSRFInstanceChange"));
        }).catch((e) => {
          console.error(e), e.message.includes("crypto.subtle") && window.location.href === "#/evenbetter/quick-ssrf" && h().modal.openModal({
            title: "Error",
            content: "Interactsh.com isn't supported yet on non-local Caido instances :("
          });
        });
    }
};
let re = W.CVSSADVISOR;
const ue = (n) => {
  const e = n.querySelector("select");
  if (!e)
    return;
  const t = n.querySelector(
    ".ssrf-instance-url"
  );
  y && (t.value = y.url), e.value = re, Be();
}, Ne = () => {
  var r, a;
  const n = h().components.createTextInput(
    "13em",
    "N/A",
    !0
  ), e = p().ui.button({
    label: "Clear Logs",
    variant: "primary",
    leadingIcon: "fas fa-trash",
    size: "small"
  });
  e.addEventListener("click", () => j.clearRows());
  const t = h().components.createNavigationBar({
    title: "Quick SSRF",
    items: [
      {
        title: "Requests History",
        url: "#/evenbetter/quick-ssrf",
        icon: "fa-history",
        onOpen: () => ue(t)
      },
      {
        title: "Settings",
        url: "#/evenbetter/quick-ssrf/settings",
        icon: "fa-cog",
        onOpen: () => ue(t)
      }
    ],
    customButtons: [e, ut(), n]
  }), s = n.querySelector("input");
  if (!s)
    return t;
  s.disabled = !0, s.classList.add("ssrf-instance-url"), h().eventManager.on("onSSRFInstanceChange", () => {
    y && (s.value = y.url);
  });
  const o = t.querySelector(
    ".evenbetter_quick-ssrf_switch select"
  );
  return (r = t.querySelector("select")) == null || r.addEventListener(
    "change",
    () => re = o.value
  ), (a = t.querySelector(".evenbetter_quick-ssrf_button")) == null || a.addEventListener("click", Pe), t;
}, Pe = () => {
  Re(re).then(() => {
    j.clearRows(), Be();
  });
}, Be = () => {
  const n = document.querySelector(".evenbetter_quick-ssrf_switch i");
  n && (n.className = y ? "fas fa-sync" : "fas fa-plus");
}, ut = () => {
  const n = document.createElement("div");
  return n.className = "evenbetter_quick-ssrf_switch", n.innerHTML = `<select>
      <option value="ssrf.cvssadvisor.com">ssrf.cvssadvisor.com</option>
      <option value="interactsh.com">interactsh.com</option>
    </select>
    <div class="evenbetter_quick-ssrf_button">
      <i class="fas fa-plus"></i>
    </div>`, n;
};
let j;
const pt = () => {
  const n = document.createElement("div");
  n.className = "c-evenbetter_quick-ssrf";
  const e = document.createElement("div");
  e.className = "c-evenbetter_quick-ssrf__content";
  const t = Ne();
  n.appendChild(t);
  const s = [
    { name: "ID", width: "9em" },
    { name: "Time", width: "10em" },
    { name: "Type", width: "4em" },
    { name: "Request", width: "40em" },
    { name: "Source IP", width: "11em" }
  ], o = h().components.createTable({
    columns: s
  });
  return j = o, h().eventManager.on("onSSRFHit", (r) => {
    window.location.hash.startsWith("#/evenbetter/quick-ssrf") || mt(), j.addRow(
      [
        { columnName: "ID", value: P(r.id) },
        {
          columnName: "Time",
          value: P(new Date(r.timestamp).toLocaleString())
        },
        { columnName: "Type", value: P(r.protocol) },
        { columnName: "Request", value: P(r.dump) },
        { columnName: "Source IP", value: P(r.ip) }
      ],
      () => {
        h().modal.openModal({
          title: "Request",
          content: ht(r)
        });
      }
    );
  }), e.appendChild(o.getHTMLElement()), n.appendChild(e), n;
}, mt = () => {
  document.querySelectorAll(".c-sidebar-item__content").forEach((n) => {
    var s;
    if (n.textContent != "Quick SSRF")
      return;
    let e = (s = n.parentNode) == null ? void 0 : s.querySelector(
      ".c-sidebar-item__count"
    );
    if (!e)
      return;
    let t = e.querySelector(
      ".c-sidebar-item__count-label"
    );
    if (t)
      if (t) {
        const o = t.textContent;
        if (!o)
          return;
        const r = parseInt(o);
        if (isNaN(r))
          return;
        t.textContent = String(r + 1);
      } else {
        let o = document.createElement("div");
        o.classList.add("c-sidebar-item__count-label"), o.textContent = "1", e.appendChild(o);
      }
  });
}, P = (n) => {
  const e = document.createElement("div");
  return e.style.overflow = "hidden", e.innerHTML = se(n), e;
}, ht = (n) => {
  const e = se(n.dump);
  if (n.protocol !== "HTTP")
    return e.split(`
`).join("<br>");
  const t = e.split(`
`), s = document.createElement("div");
  let o = !0;
  return t.forEach((r, a) => {
    const i = document.createElement("div");
    if (o && r.trim() === "" && (o = !1), a === 0) {
      const c = r.split(" ")[0], u = r.split(" ")[1], l = r.split(" ")[2];
      if (!c || !u || !l)
        return;
      const d = document.createElement("span");
      d.classList.add("http_method"), d.innerHTML = c + " ";
      const m = document.createElement("span");
      m.classList.add("http_url"), m.innerHTML = u + " ";
      const f = document.createElement("span");
      f.classList.add("http_version"), f.innerHTML = l, i.appendChild(d), i.appendChild(m), i.appendChild(f);
    }
    if (o) {
      if (r.includes(":")) {
        const c = r.split(":"), u = c[0], l = c.slice(1).join(":"), d = document.createElement("span");
        d.classList.add("http_header-key"), d.innerHTML = u + ":";
        const m = document.createElement("span");
        m.classList.add("http_header-value"), m.innerHTML = l, i.appendChild(d), i.appendChild(m);
      }
    } else
      i.innerHTML = r.split("\\n").join("<br>"), i.classList.add("http_body"), (i.textContent == "\r" || i.textContent == "" || i.textContent == `
`) && (i.style.margin = "5px");
    s.appendChild(i);
  }), s.outerHTML;
}, ft = (n) => !isNaN(Number(n)), bt = (n) => {
  const e = n.split(`
`);
  for (const t of e)
    if (!t.includes(":"))
      return !1;
  for (const t of e) {
    const s = t.indexOf(":");
    if (t[s + 1] !== " ")
      return !1;
  }
  return !0;
}, gt = () => {
  const n = document.createElement("div");
  n.className = "c-evenbetter_quick-ssrf";
  const e = document.createElement("div");
  e.className = "c-evenbetter_quick-ssrf__content";
  const t = Ne();
  n.appendChild(t);
  const s = vt();
  if (s)
    return e.appendChild(s), n.appendChild(e), n;
};
let D;
const vt = () => {
  var b, g;
  const n = document.createElement("div");
  n.classList.add("eb-quickssrf__settings"), n.innerHTML = `
<div class="eb-quickssrf__settings-header">
  <div style="font-weight: 600; font-size: 17px;">
     EvenBetter: Quick SSRF - Settings
  </div>
  <div style="color: var(--c-fg-subtle); font-size: 15px;">
     Configure EvenBetter: Quick SSRF settings.
  </div>
</div>
<div class="eb-quickssrf__settings-content">
  <div class="eb-quickssrf__settings--group">
     <div class="eb-quickssrf__setting-title">Customize HTTP response</div>
     <div class="eb-quickssrf__setting" data-key="customResponse">
        <div class="eb-quickssrf__setting-warning" style="display:none">
           Custom responses are only supported by <b>ssrf.cvssadvisor.com</b>
        </div>
        <!-- Status Code / Body / Headers inputs -->
        <div id="customhttpresponse_input" class="eb-quickssrf__setting-input" data-placeholder="200" data-key="customStatusCode">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Status Code</div>
              <div class="eb-quickssrf__setting-input-description">
                 This is the HTTP status code of the response. You can try to use the redirect status codes to bypass SSRF protection.
              </div>
           </div>
        </div>
        <div id="customhttpresponse_input" class="eb-quickssrf__setting-input" data-placeholder="Hello, World!" data-key="customBody">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Body</div>
              <div class="eb-quickssrf__setting-input-description">
                 This is the body of the HTTP response.
              </div>
           </div>
        </div>
        <div id="customhttpresponse_input" class="eb-quickssrf__setting-input" data-placeholder="Content-Type: text/html" data-key="customHeaders">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Headers</div>
              <div class="eb-quickssrf__setting-input-description">
                 Headers are in the format of key: value. You can add multiple headers in new lines.
              </div>
           </div>
        </div>
     </div>
  </div>
  <!-- Private Interactsh instance, fields: enable, host, token -->
  <div class="eb-quickssrf__settings--group">
     <div class="eb-quickssrf__setting-title">Self-hosted interactsh instance</div>
     <div class="eb-quickssrf__setting" data-key="interactsh">
        <div class="eb-quickssrf__setting-checkbox" data-key="interactsh-enable">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Enable</div>
              <div class="eb-quickssrf__setting-input-description">
                 Enable the self-hosted interactsh instance.
              </div>
           </div>
        </div>
        <div class="eb-quickssrf__setting-input" data-placeholder="https://interactsh.com" data-key="interactsh-host">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Host</div>
              <div class="eb-quickssrf__setting-input-description">
                 The host of your self-hosted interactsh instance.
              </div>
           </div>
        </div>
        <div class="eb-quickssrf__setting-input" data-placeholder="your-token" data-input-type="password" data-key="interactsh-token">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Token</div>
              <div class="eb-quickssrf__setting-input-description">
                 The token of your self-hosted interactsh instance.
              </div>
           </div>
        </div>
     </div>
  </div>
</div>
  `, D = n, n.querySelectorAll(".eb-quickssrf__setting-input").forEach((v) => {
    const w = v.getAttribute("data-placeholder");
    if (!w)
      return;
    const C = h().components.createTextInput(
      "100%",
      w
    ), S = v.getAttribute("data-input-type");
    if (S) {
      const L = C.querySelector("input");
      L && (L.type = S);
    }
    v.appendChild(C);
  }), n.querySelectorAll(".eb-quickssrf__setting-checkbox").forEach((v) => {
    const w = v.getAttribute("data-key"), C = localStorage.getItem(`eb-${w}`) === "true", S = h().components.createCheckbox(), L = S.querySelector(
      'input[type="checkbox"]'
    );
    L.checked = C, v.appendChild(S), v.addEventListener("change", () => {
      localStorage.setItem(`eb-${w}`, L.checked ? "true" : "false");
    });
  });
  const e = n.querySelector(
    "[data-key='interactsh-enable']"
  ), t = n.querySelector(
    "[data-key='interactsh-host']"
  ), s = n.querySelector(
    "[data-key='interactsh-token']"
  );
  if (!e || !t || !s)
    return;
  const o = e.querySelector(
    "input"
  ), r = t.querySelector(
    "input"
  ), a = s.querySelector(
    "input"
  );
  if (!o || !r || !a)
    return;
  e.addEventListener("change", () => {
    localStorage.setItem(
      "eb-interactsh-enable",
      o.checked.toString()
    );
  }), (b = t.querySelector("input")) == null || b.addEventListener("input", (v) => {
    localStorage.setItem(
      "eb-interactsh-host",
      v.target.value
    );
  }), (g = s.querySelector("input")) == null || g.addEventListener("input", (v) => {
    localStorage.setItem(
      "eb-interactsh-token",
      v.target.value
    );
  });
  const i = localStorage.getItem("eb-interactsh-enable"), c = localStorage.getItem("eb-interactsh-host"), u = localStorage.getItem("eb-interactsh-token");
  i && (o.checked = i === "true"), c && (r.value = c), u && (a.value = u);
  let l = n.querySelector(
    "[data-key='customHeaders'] input"
  );
  l.outerHTML = l.outerHTML.replace(
    "<input",
    "<textarea"
  ), l = n.querySelector(
    "[data-key='customHeaders'] textarea"
  ), l.style.height = "100px";
  let d = n.querySelector(
    "[data-key='customBody'] input"
  );
  d.outerHTML = d.outerHTML.replace("<input", "<textarea"), d = n.querySelector(
    "[data-key='customBody'] textarea"
  ), d.style.height = "100px";
  const m = n.querySelector(
    "[data-key='customResponse']"
  );
  if (!m)
    return;
  const f = p().ui.button({
    label: "Save",
    variant: "primary",
    size: "small",
    leadingIcon: "fas fa-save"
  });
  return f.addEventListener("click", async () => {
    if (f.ariaDisabled === "true")
      return;
    const v = document.querySelector(
      "[data-key='customStatusCode'] input"
    );
    if (!ft(v.value)) {
      h().toast.showToast({
        message: "Status code must be a number.",
        type: "error",
        duration: 2e3,
        position: "bottom"
      });
      return;
    }
    const w = document.querySelector(
      "[data-key='customBody'] textarea"
    ), C = document.querySelector(
      "[data-key='customHeaders'] textarea"
    );
    if (!bt(C.value)) {
      h().toast.showToast({
        message: "Headers must be in the format of `key: value`. Make sure you have a space after the colon.",
        type: "error",
        duration: 2e3,
        position: "bottom"
      });
      return;
    }
    y && Te(
      y.id,
      parseInt(v.value),
      w.value,
      C.value
    ).then((S) => {
      h().toast.showToast({
        message: "HTTP response customized successfully!",
        type: "success",
        duration: 2e3,
        position: "bottom"
      });
    }).catch((S) => {
      h().toast.showToast({
        message: "Failed to customize HTTP response.",
        type: "error",
        duration: 2e3,
        position: "bottom"
      }), console.error(S);
    });
  }), f.id = "eb-quickssrf-save-button", f.ariaDisabled = "true", m.appendChild(f), h().eventManager.on("onSSRFInstanceChange", () => {
    f.ariaDisabled = "false";
    const v = n.querySelector(
      ".eb-quickssrf__setting-warning"
    ), w = n.querySelectorAll("#customhttpresponse_input");
    (y == null ? void 0 : y.type) === W.CVSSADVISOR ? (v.style.display = "none", w.forEach((C) => {
      const S = C;
      S.style.display = "flex";
    }), f.style.display = "block", yt()) : (v.style.display = "block", w.forEach((C) => {
      const S = C;
      S.style.display = "none";
    }), f.style.display = "none");
  }), n;
}, yt = async () => {
  if (!y || y.type !== W.CVSSADVISOR || !D)
    return;
  const n = await nt(y.id), e = D.querySelector(
    "[data-key='customStatusCode'] input"
  ), t = D.querySelector(
    "[data-key='customBody'] textarea"
  ), s = D.querySelector(
    "[data-key='customHeaders'] textarea"
  );
  e.value = n.response_data.status_code.toString(), t.value = n.response_data.body, s.value = Object.entries(n.response_data.headers).map(([o, r]) => `${o}: ${r}`).join(`
`);
}, Oe = (n, e) => {
  const t = Array.from(
    document.querySelectorAll(".c-sidebar-item")
  ).filter((o) => o.textContent == n);
  if (t.length == 0)
    return;
  t[0].setAttribute("data-is-active", e);
}, wt = () => {
  h().eventManager.on("onPageOpen", (t) => {
    t.newUrl == "#/replay" && E("ssrfInstanceFunctionality") === "true" && setTimeout(() => Et(), 1e3);
  });
  const n = pt(), e = gt();
  !n || !e || (p().navigation.addPage("/evenbetter/quick-ssrf", {
    body: n
  }), p().navigation.addPage("/evenbetter/quick-ssrf/settings", {
    body: e
  }), p().sidebar.registerItem("Quick SSRF", "/evenbetter/quick-ssrf", {
    icon: "fas fa-compass",
    group: "EvenBetter"
  }), h().eventManager.on("onPageOpen", (t) => {
    Oe(
      "Quick SSRF",
      t.newUrl.startsWith("#/evenbetter/quick-ssrf") ? "true" : "false"
    );
  }), De());
}, De = () => {
  const n = window.location.hash === "#/evenbetter/quick-ssrf" ? 1250 : 8e3;
  y && y.state === Me.ACTIVE && dt(), setTimeout(() => {
    De();
  }, n);
};
let B = null;
const Et = () => {
  const n = document.querySelector(".c-replay-entry .cm-content");
  if (!n)
    return;
  B && (B.disconnect(), B = null);
  const e = E("ssrfInstancePlaceholder");
  B = new MutationObserver((s) => {
    s.forEach((o) => {
      const r = o.target.textContent;
      if (r && r.includes(e)) {
        if (!y) {
          h().modal.openModal({
            title: "SSRF Instance not found",
            content: "Please create an SSRF instance from the sidebar Quick SSRF page before using this functionality."
          });
          return;
        }
        const a = window.getSelection();
        if (!a)
          return;
        const i = a.focusNode;
        if (!i)
          return;
        const c = a.focusOffset, u = He(o.target, i, c, {
          pos: 0,
          done: !1
        });
        c === 0 && (u.pos += 0.5);
        const l = r.replace(
          E("ssrfInstancePlaceholder"),
          y.url
        );
        o.target.textContent = l, a.removeAllRanges();
        const d = Fe(
          o.target,
          document.createRange(),
          {
            pos: u.pos,
            done: !1
          }
        );
        d.collapse(!0), a.addRange(d);
      }
    });
  });
  const t = {
    characterData: !0,
    subtree: !0
  };
  B.observe(n, t);
};
function He(n, e, t, s) {
  if (s.done)
    return s;
  let o = null;
  if (n.childNodes.length == 0) {
    if (!n.textContent)
      return s;
    s.pos += n.textContent.length;
  } else
    for (let r = 0; r < n.childNodes.length && !s.done; r++)
      if (o = n.childNodes[r], !!o) {
        if (o === e)
          return s.pos += t, s.done = !0, s;
        He(o, e, t, s);
      }
  return s;
}
function Fe(n, e, t) {
  if (t.done)
    return e;
  if (n.childNodes.length == 0) {
    if (!n.textContent)
      return e;
    n.textContent.length >= t.pos ? (e.setStart(n, t.pos), t.done = !0) : t.pos = t.pos - n.textContent.length;
  } else
    for (let s = 0; s < n.childNodes.length && !t.done; s++) {
      let o = n.childNodes[s];
      o && Fe(o, e, t);
    }
  return e;
}
const Ct = () => typeof __TAURI_INVOKE__ < "u", St = async (n, e) => await __TAURI_INVOKE__(n, e), ae = async (n, e) => {
  if (Ct())
    return St("download", { filename: n, data: e });
  {
    const t = new Blob([e], { type: "text/plain" }), s = URL.createObjectURL(t), o = document.createElement("a");
    o.href = s, o.download = n, o.click();
  }
}, _t = () => {
  h().eventManager.on("onPageOpen", (n) => {
    n.newUrl == "#/scope" ? (kt(), xt()) : A && (A.disconnect(), A = null);
  });
}, kt = () => {
  var t;
  const n = document.querySelector(".c-header__actions");
  if (!n)
    return;
  (t = document.querySelector("#scope-presents-import")) == null || t.remove();
  const e = p().ui.button({
    label: "Import",
    leadingIcon: "fas fa-file-upload",
    variant: "primary"
  });
  e.id = "scope-presents-import", e.addEventListener("click", () => {
    const s = document.createElement("input");
    s.type = "file", s.accept = ".json", s.style.display = "none", s.addEventListener("change", (o) => {
      const r = o.target;
      if (!r.files || !r.files.length)
        return;
      const a = r.files[0];
      if (!a)
        return;
      const i = new FileReader();
      i.onload = (c) => {
        const u = c.target, l = JSON.parse(u.result);
        p().scopes.createScope({
          name: l.name,
          allowlist: l.allowlist,
          denylist: l.denylist
        });
      }, i.readAsText(a);
    }), document.body.prepend(s), s.click(), s.remove();
  }), n.style.gap = "0.8rem", n.style.display = "flex", n.appendChild(e);
};
let A = null;
const xt = () => {
  var e;
  const n = (e = document.querySelector(
    ".c-preset-form-create"
  )) == null ? void 0 : e.parentElement;
  n && (A && (A.disconnect(), A = null), A = new MutationObserver((t) => {
    t.some(
      (s) => s.attributeName === "style" || s.target.classList.contains(
        "c-preset-form-create__header"
      )
    ) || It();
  }), A.observe(n, {
    childList: !0,
    attributes: !0,
    subtree: !0
  }));
}, It = () => {
  var s;
  (s = document.querySelector("#scope-presents-download")) == null || s.remove();
  const n = document.querySelector(
    ".c-preset-form-create__header"
  ), e = p().ui.button({
    label: "Download",
    leadingIcon: "fas fa-file-arrow-down",
    variant: "tertiary",
    size: "small"
  });
  e.id = "scope-presents-download";
  const t = e.querySelector("button");
  t && (t.addEventListener("click", () => {
    const o = Lt();
    if (!o)
      return;
    const a = p().scopes.getScopes().find((i) => i.id === o);
    a && (ae("scope-" + a.name + ".json", JSON.stringify(a)), h().toast.showToast({
      message: "Scope preset downloaded successfully",
      duration: 3e3,
      position: "bottom",
      type: "success"
    }));
  }), n == null || n.appendChild(e));
}, Lt = () => {
  var n;
  return (n = document.querySelector('.c-preset[data-is-selected="true"]')) == null ? void 0 : n.getAttribute("data-preset-id");
}, At = () => {
  if (E("sidebarHideGroups") !== "true")
    return;
  document.querySelectorAll(".c-sidebar-group").forEach((t) => {
    t.querySelector(".c-sidebar-group__title") && pe(t);
  });
  const e = document.querySelector(".c-sidebar__body");
  if (e) {
    const t = e, s = { childList: !0, subtree: !0 }, o = (a, i) => {
      for (const c of a)
        c.type === "childList" && c.addedNodes.forEach((u) => {
          var l;
          if (u.nodeType === Node.ELEMENT_NODE && u.classList.contains("c-sidebar-group")) {
            const d = u.querySelector(
              ".c-sidebar-group__title"
            );
            if (!d || u.getAttribute("modified") === "true")
              return;
            pe(u), Mt(((l = d.textContent) == null ? void 0 : l.trim()) || "");
          }
        });
    };
    new MutationObserver(o).observe(t, s);
  }
}, pe = (n) => {
  const e = n.querySelector(".c-sidebar-group__title");
  e && (n.setAttribute("modified", "true"), e.addEventListener("click", () => {
    const t = n.querySelector(".c-sidebar-group__items"), s = n.getAttribute("data-is-group-collapsed");
    t.style.display = s === "true" ? "block" : "none", n.setAttribute(
      "data-is-group-collapsed",
      s === "true" ? "false" : "true"
    ), Tt();
  }));
}, Tt = () => {
  document.querySelectorAll(".c-sidebar-group").forEach((e) => {
    var o, r;
    const t = (r = (o = e.children[0]) == null ? void 0 : o.textContent) == null ? void 0 : r.trim();
    if (!t)
      return;
    const s = e.getAttribute("data-is-group-collapsed");
    s !== null && localStorage.setItem(`evenbetter_${t}_isCollapsed`, s);
  });
}, qt = () => {
  if (E("sidebarHideGroups") !== "true")
    return;
  document.querySelectorAll(".c-sidebar-group").forEach((e) => {
    var o, r;
    const t = (r = (o = e.children[0]) == null ? void 0 : o.textContent) == null ? void 0 : r.trim();
    if (!t)
      return;
    const s = localStorage.getItem(
      `evenbetter_${t}_isCollapsed`
    );
    if (s) {
      e.setAttribute("data-is-group-collapsed", s);
      const a = e.querySelector(".c-sidebar-group__items");
      a.style.display = s === "true" ? "none" : "block";
    }
  });
}, Mt = (n) => {
  if (E("sidebarHideGroups") !== "true")
    return;
  document.querySelectorAll(".c-sidebar-group").forEach((t) => {
    var o, r;
    const s = (r = (o = t.children[0]) == null ? void 0 : o.textContent) == null ? void 0 : r.trim();
    if (s && s === n) {
      const a = localStorage.getItem(
        `evenbetter_${n}_isCollapsed`
      );
      if (a) {
        t.setAttribute("data-is-group-collapsed", a);
        const i = t.querySelector(".c-sidebar-group__items");
        i.style.display = a === "true" ? "none" : "block";
      }
    }
  });
}, Rt = () => {
  if (E("sidebarRearrangeGroups") !== "true")
    return;
  document.querySelectorAll(
    ".c-sidebar-group__title"
  ).forEach((s) => {
    const o = s.textContent;
    o && o !== "..." && he(s, o);
  }), document.querySelectorAll(".c-sidebar-group").forEach((s) => {
    me(s);
  });
  const t = document.querySelector(".c-sidebar__body");
  if (t) {
    const s = t, o = { childList: !0, subtree: !0 }, r = (i, c) => {
      for (const u of i)
        u.type === "childList" && u.addedNodes.forEach((l) => {
          if (l.nodeType === Node.ELEMENT_NODE && l.classList.contains("c-sidebar-group")) {
            if (l.querySelector(".c-sidebar-group__rearrange-arrows"))
              return;
            const d = l.querySelector(
              ".c-sidebar-group__title"
            );
            if (!d)
              return;
            const m = d.textContent;
            if (!m)
              return;
            he(d, m), me(l), Bt(m);
          }
        });
    };
    new MutationObserver(r).observe(s, o);
  }
}, me = (n) => {
  const e = n.querySelector(".c-sidebar-group__move-up"), t = n.querySelector(".c-sidebar-group__move-down");
  !e || !t || (e.addEventListener("click", (s) => {
    fe(n, "up"), s.stopPropagation();
  }), t.addEventListener("click", (s) => {
    fe(n, "down"), s.stopPropagation();
  }));
}, he = (n, e) => {
  n.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;">${e}
          <div class="c-sidebar-group__rearrange-arrows">
              <svg class="c-sidebar-group__move-up" width="15px" height="15px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 5V19M12 5L6 11M12 5L18 11" stroke="#424242" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              <svg class="c-sidebar-group__move-down" width="15px" height="15px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 5V19M12 19L6 13M12 19L18 13" stroke="#424242" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
          </div>
        `;
}, fe = (n, e) => {
  const t = n.parentElement;
  if (!t)
    return;
  const s = Array.from(t.children).indexOf(n);
  if (e === "up" && s > 0 || e === "down" && s < t.children.length - 1) {
    const o = e === "up" ? s - 1 : s + 1;
    let r = t.children[o + (e === "up" ? 0 : 1)];
    if (r && r.classList.contains("c-sidebar__toggle-wrapper")) {
      if (e === "up" && !r.classList.contains("c-sidebar-group") && (r = t.children[o - 1], !r))
        return;
      e === "up" ? t.append(r) : t.insertBefore(n, r.nextSibling);
    } else
      r ? t.insertBefore(n, r) : t.appendChild(n);
    Nt();
  }
}, Nt = () => {
  document.querySelectorAll(".c-sidebar-group").forEach((e) => {
    var r, a;
    const t = e.parentElement;
    if (!t)
      return;
    const s = (a = (r = e.children[0]) == null ? void 0 : r.textContent) == null ? void 0 : a.trim();
    if (!s)
      return;
    const o = Array.from(t.children).indexOf(e);
    localStorage.setItem(`evenbetter_${s}_position`, String(o));
  });
}, Pt = () => {
  if (E("sidebarRearrangeGroups") !== "true")
    return;
  document.querySelectorAll(".c-sidebar-group").forEach((e) => {
    var a, i;
    const t = e.parentElement;
    if (!t)
      return;
    const s = (i = (a = e.children[0]) == null ? void 0 : a.textContent) == null ? void 0 : i.trim();
    if (!s)
      return;
    const o = $e(s);
    if (o == null)
      return;
    const r = t.children[Number(o)];
    r && t.insertBefore(e, r);
  });
}, Bt = (n) => {
  if (E("sidebarRearrangeGroups") !== "true")
    return;
  document.querySelectorAll(".c-sidebar-group").forEach((t) => {
    var r, a;
    const s = t.parentElement;
    if (!s)
      return;
    const o = (a = (r = t.children[0]) == null ? void 0 : r.textContent) == null ? void 0 : a.trim();
    if (o && o === n) {
      const i = $e(n);
      if (i == null)
        return;
      const c = s.children[Number(i)];
      c && s.insertBefore(t, c);
    }
  });
}, $e = (n) => localStorage.getItem(`evenbetter_${n}_position`), Ot = () => {
  qt(), Pt(), Rt(), At();
};
window.global = window;
let Dt = class {
  log(e, t) {
    const o = `${(/* @__PURE__ */ new Date()).toString()} [EvenBetter ${N}]`;
    switch (e) {
      case "info":
        console.log(`${o} [INFO] ${t}`);
        break;
      case "error":
        console.error(`${o} [ERROR] ${t}`);
        break;
      case "warn":
        console.warn(`${o} [WARN] ${t}`);
        break;
      case "debug":
        break;
      default:
        console.log(`${o} [UNKNOWN] ${t}`);
    }
  }
  info(e) {
    this.log("info", e);
  }
  error(e) {
    this.log("error", e);
  }
  warn(e) {
    this.log("warn", e);
  }
  debug(e) {
    this.log("debug", e);
  }
};
const X = new Dt(), Ht = () => {
  p().commands.register("evenbetter:quickmar", {
    name: "Send to Match & Replace",
    run: async (n) => {
      if (n.type == "RequestContext" || n.type == "ResponseContext") {
        const e = n.selection;
        Ft(e);
      }
    }
  }), p().menu.registerItem({
    commandId: "evenbetter:quickmar",
    leadingIcon: "fas fa-wrench",
    type: "Request"
  }), p().menu.registerItem({
    commandId: "evenbetter:quickmar",
    leadingIcon: "fas fa-wrench",
    type: "Response"
  });
}, Ft = async (n) => {
  if (!n)
    return;
  p().navigation.goTo("/tamper"), await Ue();
  const e = document.querySelector(
    ".c-rule-list-header__new button"
  );
  if (!e)
    return;
  e.click(), await je();
  const t = document.querySelector(
    ".c-tamper textarea"
  ), s = document.querySelector(
    ".c-rule-form-update__name input"
  );
  if (!t || !s)
    return;
  let o = n.split(`
`)[0];
  o || (o = n), o.length > 50 && (o = o.substring(0, 50) + "..."), be(t, n), be(s, o);
  const r = document.querySelector(
    ".c-rule-form-update__save button"
  );
  let a = setInterval(() => {
    r.disabled || (clearInterval(a), r.click());
  }, 25);
  setTimeout(() => {
    a && clearInterval(a);
  }, 100);
}, Ue = async () => {
  const n = document.querySelector(".c-rule-form-update"), e = document.querySelector(".c-rule-form-create");
  if (!(n || e))
    return await new Promise((t) => setTimeout(t, 100)), Ue();
}, je = async () => {
  if (await new Promise((e) => setTimeout(e, 100)), !document.querySelector(".c-rule-form-update__body"))
    return je();
}, be = (n, e) => {
  const t = document.activeElement;
  n.focus(), n.value = "";
  for (let o = 0; o < e.length; o++) {
    n.value += e[o];
    let r = new Event("input", {
      bubbles: !0,
      cancelable: !0
    });
    n.dispatchEvent(r);
  }
  let s = new Event("change", {
    bubbles: !0,
    cancelable: !0
  });
  n.dispatchEvent(s), t == null || t.focus();
};
function $t(n) {
  for (var e = "", t = 0; t < n.length; t++) {
    for (var s = n.charCodeAt(t).toString(16); s.length < 4; )
      s = "0" + s;
    e += "\\u" + s;
  }
  return e;
}
class Ut {
  constructor() {
    _(this, "HTMLElement");
    _(this, "textArea");
    _(this, "encodeMethodSelect");
    _(this, "encodeMethod");
    _(this, "activeEditor");
    _(this, "selectionInterval");
    this.HTMLElement = document.createElement("div"), this.HTMLElement.classList.add("evenbetter__qd-body"), this.HTMLElement.id = "evenbetter__qd-body", this.HTMLElement.style.display = "none";
    const e = document.createElement("div");
    e.id = "evenbetter__qd-resizer";
    let t = !1, s;
    const o = (l) => {
      if (!t)
        return;
      const d = s - l.clientY, m = Math.max(10, this.HTMLElement.offsetHeight + d);
      this.HTMLElement.style.height = `${m}px`, s = l.clientY;
    }, r = () => {
      t = !1, document.removeEventListener("mousemove", o), document.removeEventListener("mouseup", r);
    };
    e.addEventListener("mousedown", (l) => {
      t = !0, s = l.clientY, document.addEventListener("mousemove", o), document.addEventListener("mouseup", r);
    }), this.HTMLElement.appendChild(e);
    const a = document.createElement("div");
    a.classList.add("evenbetter__qd-selected-text");
    const i = document.createElement("div");
    i.classList.add("evenbetter__qd-selected-text-top");
    const c = h().components.createSelectInput([
      { value: "none", label: "None" },
      { value: "base64", label: "Base64" },
      { value: "unicode", label: "Unicode" },
      { value: "url", label: "URL" },
      { value: "url+base64", label: "URL + Base64" },
      { value: "base64+url", label: "Base64 + URL" }
    ]);
    c.style.width = "150px", c.style.height = "25px", c.style.borderRadius = "5px !important", c.addEventListener("change", (l) => {
      const d = l.target;
      this.encodeMethod = d.value, this.handleInput();
    }), this.encodeMethodSelect = c;
    const u = document.createElement("i");
    u.classList.add("c-icon", "fas", "fa-copy"), i.appendChild(c), i.appendChild(u), this.textArea = document.createElement("textarea"), this.textArea.classList.add("evenbetter__qd-selected-text-box"), this.textArea.setAttribute("autocomplete", "false"), this.textArea.setAttribute("autocorrect", "off"), this.textArea.setAttribute("autocapitalize", "off"), this.textArea.setAttribute("spellcheck", "false"), a.appendChild(i), a.appendChild(this.textArea), this.HTMLElement.appendChild(a), u.addEventListener("click", this.copyToClipboard.bind(this)), this.textArea.addEventListener("input", this.handleInput.bind(this)), this.encodeMethod = "none", this.startMonitoringSelection();
  }
  copyToClipboard() {
    const e = this.textArea.textContent;
    e && navigator.clipboard.writeText(e);
  }
  handleInput() {
    let e = this.textArea.value;
    if (!(e.length <= 0) && !(!this.activeEditor || this.activeEditor.state.readOnly)) {
      switch (this.encodeMethod) {
        case "base64":
          e = btoa(e);
          break;
        case "unicode":
          e = e.split("").map((t) => $t(t)).join("");
          break;
        case "url":
          e = encodeURIComponent(e);
          break;
        case "url+base64":
          e = encodeURIComponent(btoa(e));
          break;
        case "base64+url":
          e = btoa(encodeURIComponent(e));
          break;
      }
      this.activeEditor.dispatch({
        changes: [
          {
            from: this.activeEditor.state.selection.main.from,
            to: this.activeEditor.state.selection.main.to,
            insert: e
          }
        ]
      });
    }
  }
  updateText(e) {
    this.textArea.textContent = e, this.textArea.value = e;
  }
  updateEncodeMethod(e) {
    this.encodeMethod = e || "none", e ? this.encodeMethodSelect.value = e : this.encodeMethodSelect.value = "none";
  }
  show() {
    this.HTMLElement.style.display = "flex";
  }
  hide() {
    this.HTMLElement.style.display = "none";
  }
  getElement() {
    return this.HTMLElement;
  }
  getActiveEditor() {
    var s;
    const e = document.activeElement;
    if (!e)
      return;
    const t = e.closest(".cm-content");
    if (t)
      return (s = t == null ? void 0 : t.cmView) == null ? void 0 : s.view;
  }
  getCurrentSelection() {
    const e = this.getActiveEditor();
    if (!e)
      return {
        from: 0,
        to: 0,
        text: ""
      };
    const { from: t, to: s } = e.state.selection.main;
    return {
      from: t,
      to: s,
      text: e.state.sliceDoc(t, s)
    };
  }
  startMonitoringSelection() {
    let t = this.getCurrentSelection();
    this.selectionInterval = setInterval(() => {
      const s = this.getCurrentSelection();
      (s.from !== t.from || s.to !== t.to) && (t = s, this.onSelectionChange(s));
    }, 50);
  }
  stopMonitoringSelection() {
    this.selectionInterval && clearInterval(this.selectionInterval);
  }
  isMouseOver(e) {
    if (!e)
      return !1;
    const t = document.querySelectorAll(":hover");
    for (let s = 0; s < t.length; s++)
      if (t[s] === e)
        return !0;
    return !1;
  }
  onSelectionChange(e) {
    var o;
    if (this.isMouseOver(this.HTMLElement))
      return;
    const t = document.querySelector(".p-contextmenu");
    if (t && this.isMouseOver(t))
      return;
    if (e.text === "") {
      this.hide();
      return;
    }
    this.activeEditor = this.getActiveEditor(), (o = this.activeEditor) != null && o.state.readOnly ? this.setReadOnly(!0) : this.setReadOnly(!1), this.showQuickDecode(e.text);
  }
  showQuickDecode(e) {
    const t = this.tryToDecode(e);
    this.updateText(t.decodedContent), this.updateEncodeMethod(t.encodeMethod), this.show();
  }
  setReadOnly(e) {
    e ? (this.textArea.disabled = !0, this.encodeMethodSelect.disabled = !0, this.encodeMethodSelect.value = "none") : (this.textArea.disabled = !1, this.encodeMethodSelect.disabled = !1);
  }
  isUrlEncoded(e) {
    return /(%[0-9A-Fa-f]{2})+/g.test(e);
  }
  base64Decode(e) {
    let t = e;
    if (e.length % 4 === 1 ? t += "=" : e.length % 4 === 2 && (t += "=="), /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(t))
      try {
        return { encodeMethod: "base64", decodedContent: atob(t) };
      } catch {
        return { encodeMethod: "none", decodedContent: e };
      }
    return { encodeMethod: "none", decodedContent: e };
  }
  tryToDecode(e) {
    const t = this.base64Decode(e);
    if (t.encodeMethod !== "none") {
      if (this.isUrlEncoded(t.decodedContent))
        try {
          return {
            encodeMethod: "base64+url",
            decodedContent: decodeURIComponent(t.decodedContent)
          };
        } catch {
          return t;
        }
      return t;
    }
    const s = /\\u([0-9a-fA-F]{4})/g;
    if (s.test(e))
      try {
        return { encodeMethod: "unicode", decodedContent: e.replace(
          s,
          (r, a) => String.fromCharCode(parseInt(a, 16))
        ) };
      } catch {
        return { encodeMethod: "none", decodedContent: e };
      }
    if (this.isUrlEncoded(e))
      try {
        const o = decodeURIComponent(e), r = this.base64Decode(o);
        return r.encodeMethod !== "none" && e.length > 8 ? {
          encodeMethod: "url+base64",
          decodedContent: r.decodedContent
        } : { encodeMethod: "url", decodedContent: o };
      } catch {
        return { encodeMethod: "none", decodedContent: e };
      }
    return { encodeMethod: "none", decodedContent: e };
  }
}
class jt {
  constructor() {
  }
  attachQuickDecode() {
    if (document.getElementById("evenbetter__qd-body"))
      return;
    const e = document.querySelector(".c-session-list-body");
    if (!e)
      return;
    const t = new Ut();
    e.appendChild(t.getElement());
  }
  init() {
    if (E("quickDecode") !== "true")
      return;
    const s = () => {
      let o = 0;
      const r = setInterval(() => {
        if (o++, o > 80) {
          console.error("Could not find editors"), clearInterval(r);
          return;
        }
        document.querySelectorAll(".cm-editor .cm-content") && (clearInterval(r), this.attachQuickDecode());
      }, 25);
    };
    h().eventManager.on("onPageOpen", (o) => {
      o.newUrl === "#/replay" && s();
    }), h().eventManager.on("onProjectChange", async () => {
      await new Promise((o) => setTimeout(o, 500)), window.location.hash === "#/replay" && s();
    });
  }
}
let V;
const Wt = () => {
  V || (V = new jt(), V.init());
}, Vt = () => {
  document.addEventListener("keydown", (n) => {
    if (n.key === "Escape") {
      const e = document.querySelector(
        ".c-context-menu__floating > .c-menu"
      );
      e && e.remove();
    }
  });
};
class Gt {
  constructor() {
    _(this, "workflows", []);
    _(this, "installedWorkflows", []);
  }
  async fetchWorkflows() {
    const t = await (await fetch(
      "https://raw.githubusercontent.com/bebiksior/EvenBetter/main/workflows/workflows.json?cache=" + (/* @__PURE__ */ new Date()).getTime()
    )).json();
    this.workflows = t.workflows;
  }
  async loadInstalledWorkflows() {
    this.installedWorkflows = [], (await p().graphql.workflows()).workflows.forEach(
      (t) => this.installedWorkflows.push(t.name)
    ), this.updateAddButtons();
  }
  getWorkflows() {
    return this.workflows;
  }
  isWorkflowInstalled(e) {
    return this.installedWorkflows.includes(e);
  }
  async addWorkflow(e) {
    const t = await fetch(e.url).then(
      (s) => s.json()
    );
    await p().graphql.createWorkflow({
      input: {
        definition: {
          ...t
        },
        global: !1
      }
    }), this.installedWorkflows.push(e.name), this.updateAddButtons();
  }
  updateAddButtons() {
    document.querySelectorAll(
      ".c-evenbetter_button__input"
    ).forEach((t) => {
      var r, a, i, c;
      const s = t.querySelector(".c-evenbetter_button__label");
      if (!s)
        return;
      const o = (a = (r = t.closest("tr")) == null ? void 0 : r.querySelector("td:nth-child(2)")) == null ? void 0 : a.textContent;
      o && this.isWorkflowInstalled(o) ? (s.textContent = "Added", (i = s.parentElement) == null || i.setAttribute("added", "true"), t.disabled = !0) : ((c = s.parentElement) == null || c.setAttribute("added", "false"), s.textContent = "Add", t.disabled = !1);
    });
  }
}
let x;
const zt = () => {
  var s, o, r;
  const n = document.querySelector(".p-menubar-root-list");
  if (!n || n.querySelector("#workflows-library"))
    return;
  const e = (s = n.children[0]) == null ? void 0 : s.cloneNode(!0);
  e.id = "workflows-library";
  const t = e.querySelector("span");
  t && (t.textContent = "Library", (o = e.querySelector("a")) == null || o.setAttribute("href", "#/workflows/library"), (r = e.querySelector(".c-workflows__item")) == null || r.setAttribute("data-is-active", "false"), n.appendChild(e));
}, Kt = async () => {
  const n = await Zt();
  n && (p().navigation.addPage("workflows/library", {
    body: n
  }), h().eventManager.on(
    "onPageOpen",
    async (e) => {
      Oe(
        "Workflows",
        window.location.hash.startsWith("#/workflows/") ? "true" : "false"
      ), e.newUrl.startsWith("#/workflows/") && e.newUrl !== "#/workflows/library" && zt(), e.newUrl === "#/workflows/library" && await x.loadInstalledWorkflows();
    }
  ));
}, Qt = '<button class="p-row-toggler p-link" type="button" aria-expanded="true" aria-controls="pv_id_10_0_expansion" aria-label="Row Expanded" data-pc-section="rowtoggler" data-pc-group-section="rowactionbutton"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="p-icon p-row-toggler-icon" aria-hidden="true" data-pc-section="rowtogglericon"><path d="M7.01744 10.398C6.91269 10.3985 6.8089 10.378 6.71215 10.3379C6.61541 10.2977 6.52766 10.2386 6.45405 10.1641L1.13907 4.84913C1.03306 4.69404 0.985221 4.5065 1.00399 4.31958C1.02276 4.13266 1.10693 3.95838 1.24166 3.82747C1.37639 3.69655 1.55301 3.61742 1.74039 3.60402C1.92777 3.59062 2.11386 3.64382 2.26584 3.75424L7.01744 8.47394L11.769 3.75424C11.9189 3.65709 12.097 3.61306 12.2748 3.62921C12.4527 3.64535 12.6199 3.72073 12.7498 3.84328C12.8797 3.96582 12.9647 4.12842 12.9912 4.30502C13.0177 4.48162 12.9841 4.662 12.8958 4.81724L7.58083 10.1322C7.50996 10.2125 7.42344 10.2775 7.32656 10.3232C7.22968 10.3689 7.12449 10.3944 7.01744 10.398Z" fill="currentColor"></path></svg></button>', ge = '<svg width="14" height="14" fill="none" xmlns="http://www.w3.org/2000/svg" class="p-icon p-row-toggler-icon" aria-hidden="true" data-pc-section="rowtogglericon" viewbox="0 0 14 14"><path d="M4.38708 13C4.28408 13.0005 4.18203 12.9804 4.08691 12.9409C3.99178 12.9014 3.9055 12.8433 3.83313 12.7701C3.68634 12.6231 3.60388 12.4238 3.60388 12.2161C3.60388 12.0084 3.68634 11.8091 3.83313 11.6622L8.50507 6.99022L3.83313 2.31827C3.69467 2.16968 3.61928 1.97313 3.62287 1.77005C3.62645 1.56698 3.70872 1.37322 3.85234 1.22959C3.99596 1.08597 4.18972 1.00371 4.3928 1.00012C4.59588 0.996539 4.79242 1.07192 4.94102 1.21039L10.1669 6.43628C10.3137 6.58325 10.3962 6.78249 10.3962 6.99022C10.3962 7.19795 10.3137 7.39718 10.1669 7.54416L4.94102 12.7701C4.86865 12.8433 4.78237 12.9014 4.68724 12.9409C4.59212 12.9804 4.49007 13.0005 4.38708 13Z" fill="currentColor"></path></svg>', Yt = (n) => {
  const e = document.createElement("button");
  e.classList.add("p-row-toggler", "p-link"), e.innerHTML = ge;
  let t = !1;
  const s = () => {
    t = !t, e.innerHTML = t ? Qt : ge;
  };
  return e.addEventListener("click", (o) => {
    var r;
    if (o.preventDefault(), t) {
      const i = o.target.closest("tr");
      i && ((r = i.nextElementSibling) == null || r.remove(), s());
    } else {
      const i = o.target.closest("tr");
      i && (i.after(Jt(n)), s());
    }
  }), e;
}, Jt = (n) => {
  const e = document.createElement("tr");
  e.className = "p-datatable-row-expansion", e.setAttribute("role", "row"), e.setAttribute("data-pc-section", "rowexpansion");
  const t = document.createElement("td");
  t.colSpan = 7, t.setAttribute("data-pc-section", "rowexpansioncell");
  const s = document.createElement("div");
  s.className = "c-table-expansion";
  const o = document.createElement("div");
  o.className = "c-table-expansion__meta";
  const r = document.createElement("h3");
  r.textContent = "URL";
  const a = document.createElement("a");
  a.href = n.url, a.textContent = n.url;
  const i = document.createElement("h3");
  i.textContent = "Description";
  const c = document.createElement("p");
  c.textContent = n.description;
  const u = document.createElement("h3");
  u.textContent = "Author";
  const l = document.createElement("p");
  l.textContent = n.author, a.addEventListener("click", (m) => {
    m.preventDefault(), h().helpers.openInBrowser(n.url);
  }), o.appendChild(r), o.appendChild(a), o.appendChild(i), o.appendChild(c), o.appendChild(u), o.appendChild(l);
  const d = document.createElement("div");
  return d.className = "c-table-expansion__workflows", s.appendChild(o), s.appendChild(d), t.appendChild(s), e.appendChild(t), e;
}, Zt = async () => {
  x = new Gt(), await x.fetchWorkflows();
  const n = [
    { name: "", width: "3em" },
    { name: "Name", width: "20em" },
    { name: "Description", width: "30em" },
    { name: "Version", width: "7em" },
    { name: "Author", width: "11em" },
    { name: "OS", width: "10em" },
    { name: "Actions", width: "10em" }
  ], e = document.createElement("div");
  e.id = "evenbetter-library";
  const t = document.createElement("div");
  t.classList.add("c-workflows__repository-link"), t.style.padding = "0 var(--c-space-4)", t.innerHTML = `
    <a style="font-size: var(--c-font-size-100); display: flex; align-items: center; gap: var(--c-space-2); cursor: pointer;">
      <i class="c-icon fas fa-external-link"></i>Community Workflows
    </a>
  `;
  const s = h().components.createNavigationBar({
    title: "Workflows",
    items: [
      {
        title: "Passive",
        url: "#/workflows/passive"
      },
      {
        title: "Active",
        url: "#/workflows/active"
      },
      {
        title: "Convert",
        url: "#/workflows/convert"
      },
      {
        title: "Library",
        url: "#/workflows/library"
      }
    ],
    customButtons: [t]
  });
  e.appendChild(s);
  const o = document.createElement("div");
  o.classList.add("c-evenbetter_library-body");
  const r = document.createElement("div");
  r.classList.add("c-evenbetter_library-header");
  const a = p().ui.button({
    label: "New workflow",
    leadingIcon: "fas fa-plus",
    variant: "primary"
  });
  a.addEventListener("click", () => {
    p().navigation.goTo("/workflows/convert/new");
  });
  const i = h().components.createTextInput(
    "fit-content",
    "Search...",
    !1,
    "fa-search"
  ), c = h().components.createTable({
    columns: n
  }), u = i.querySelector("input");
  if (!u)
    return;
  u.addEventListener("input", (g) => {
    const v = g.target.value;
    c.filterRows(v);
  });
  const l = p().ui.button({
    label: "Add all",
    leadingIcon: "fas fa-plus",
    variant: "secondary",
    size: "small"
  });
  l.addEventListener("click", async () => {
    let g = 0;
    const v = x.getWorkflows(), w = [];
    for (const C of v)
      if (!x.isWorkflowInstalled(C.name)) {
        const S = x.addWorkflow(C).then(() => g++);
        w.push(S);
      }
    await Promise.all(w), g === 0 ? p().window.showToast("No workflows to add!", {
      variant: "warning",
      duration: 1500
    }) : p().window.showToast(`Added ${g} workflows successfully!`, {
      variant: "success",
      duration: 1500
    });
  });
  const d = document.createElement("div");
  d.id = "evenbetter_library-left";
  const m = document.createElement("div");
  m.id = "evenbetter_library-right", d.appendChild(a), d.appendChild(i), m.appendChild(l), r.appendChild(d), r.appendChild(m);
  const f = document.createElement("div");
  f.classList.add("c-evenbetter_library-content");
  const b = document.createElement("div");
  return b.classList.add("c-evenbetter_library"), b.id = "evenbetter-library-content", f.appendChild(b), o.appendChild(r), o.appendChild(f), e.appendChild(o), x.getWorkflows().forEach((g) => {
    const v = Xt(g);
    v.addEventListener("click", async (w) => {
      var le;
      !((le = w.target.closest(".c-evenbetter_button")) != null && le.getAttribute("data-workflow-url")) || (await x.addWorkflow(g), await x.loadInstalledWorkflows(), !v.querySelector(".c-evenbetter_button__label")) || h().toast.showToast({
        message: "Workflow added successfully!",
        type: "success",
        duration: 1500,
        position: "bottom"
      });
    }), c.addRow([
      { columnName: "", value: Yt(g) },
      { columnName: "Name", value: g.name },
      {
        columnName: "Description",
        value: g.description
      },
      {
        columnName: "Version",
        value: g.version
      },
      {
        columnName: "Author",
        value: g.author
      },
      {
        columnName: "OS",
        value: g.os || "All"
      },
      { columnName: "Actions", value: v }
    ]);
  }), b.appendChild(c.getHTMLElement()), e;
}, Xt = (n) => {
  const e = document.createElement("div");
  return e.innerHTML = `
          <div class="evenbetter-table-actions">
              <div class="evenbetter-table-actions__select">
                  <div class="c-evenbetter_button" data-workflow-url="${se(
    n.url
  )}" data-size="small" data-block="true" data-variant="secondary" data-outline="true" data-plain="false" style="--9bad4558: center;">
                      <div class="formkit-outer" data-family="button" data-type="button" data-empty="true">
                          <div class="formkit-wrapper">
                              <button class="formkit-input c-evenbetter_button__input" type="button" name="button_82" id="input_83">
                                  <div class="c-evenbetter_button__label">
                                      Add
                                  </div>
                              </button>
                          </div>
                      </div>
                  </div>
              </div>
          </div>`, e;
};
class en {
  constructor() {
    _(this, "handlers", []);
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
  }
  trigger(e) {
    this.handlers.forEach((t) => t(e));
  }
}
const tn = () => {
  [
    "General",
    "Shortcuts",
    "Network",
    "Rendering",
    "Developer"
  ].forEach((e) => {
    p().commands.register("settings:" + e, {
      name: "Go to Settings: " + e,
      group: "Navigation",
      run: () => {
        p().navigation.goTo("/settings/" + e.toLowerCase());
      }
    }), p().commandPalette.register("settings:" + e);
  });
}, nn = () => {
  h().eventManager.on("onPageOpen", (n) => {
    n.newUrl === "#/findings" && sn();
  });
}, sn = () => {
  var e;
  if (document.querySelector("#clear-all-findings"))
    return;
  const n = p().ui.button({
    label: "Clear All",
    size: "small",
    variant: "primary",
    leadingIcon: "fas fa-trash"
  });
  n.id = "clear-all-findings", n.addEventListener("click", () => {
    p().graphql.getFindingsByOffset({
      limit: 1e5,
      offset: 0,
      filter: {},
      order: { by: "ID", ordering: "DESC" }
    }).then((t) => {
      p().graphql.deleteFindings({
        ids: t.findingsByOffset.edges.map((s) => s.node.id)
      });
    });
  }), (e = document.querySelector(".c-finding-table .c-card__header")) == null || e.appendChild(n);
}, on = async (n, e) => {
  const t = E("openaiApiKey");
  if (t)
    return X.info("Asking AI with OpenAI API key with prompt: " + e), (await (await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${t}`
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: n
          },
          {
            role: "user",
            content: e
          }
        ]
      })
    })).json()).choices[0].message.content;
  {
    X.info("Asking AI without OpenAI API key with prompt: " + e);
    const s = await rn(n);
    if (!s)
      throw new Error("Failed to create assistant session");
    return await an(s, e), await cn(s);
  }
}, rn = async (n) => {
  var t, s;
  const e = await p().graphql.createAssistantSession({
    input: {
      modelId: "gpt-3.5-turbo",
      systemMessage: n
    }
  });
  return (s = (t = e == null ? void 0 : e.createAssistantSession) == null ? void 0 : t.session) == null ? void 0 : s.id;
}, an = async (n, e) => {
  await p().graphql.sendAssistantMessage({
    sessionId: n,
    message: e
  });
}, cn = async (n) => new Promise((e, t) => {
  const s = setInterval(async () => {
    var o;
    try {
      const a = (await p().graphql.assistantSession({ id: n })).assistantSession;
      if (!a)
        return;
      if (a.messages.length >= 3) {
        const i = (o = a.messages[2]) == null ? void 0 : o.content;
        i ? (clearInterval(s), await p().graphql.deleteAssistantSession({ id: n }), e(i)) : t("Failed to get response from AI");
      }
    } catch (r) {
      clearInterval(s), t(r);
    }
  }, 1e3);
}), ln = `
You are the Caido HTTPQL assistant, an integral part of the EvenBetter AI system. You are here to help users with writing their HTTPQL queries.
Reply only with the HTTPQL query, nothing else. Don't explain the query, don't use markdown.
Example:

User: response contains hello
Expected response: resp.raw.cont:"hello". 

User: response contains email
Expected response: resp.raw.regex:/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,}/ 

User: response contains aws access key
Expected response: resp.raw.regex:/((?:ASIA|AKIA|AROA|AIDA)([A-Z0-7]{16}))/

Be smart, if user asks for a f.e. paypal api key give them a regex that matches paypal api keys, dont just write resp.raw.cont:"paypal api key".

HTTPQL is the query language we use in Caido to let you filtering requests and responses. It is an evolving language that we hope will eventually become an industry standard. Primitives Parts of a filter clause 1. Namespace The first part of a filter clause is the namespace. We currently support 3 namespaces: req: For HTTP requests resp: For HTTP responses preset: For filter presets The preset namespace is a bit different, it doesn't have a field nor an operator. See the filters page to learn more about filter presets. 2. Field The second part of filter clause is the field. Fields differ based on the the namespace. We will add more fields eventually. Let us know which ones you need! req ext: File extension (if we detected one). Extensions in Caido always contain the leading . (like .js). We are liberal in what we accept as an extension. host: Hostname of the target server. method: HTTP Method used for the request in uppercase. If the request is malformed, this will contain the bytes read until the first space. path: Path of the query, including the extension. port: Port of the target server. raw: The full raw data of the request. This allows you to search on things we currently don't index (like headers). resp code: Status code of the reponse. If the response is malformed, this will contain everything after HTTP/1.1 and the following space. raw: The full raw data of the response. This allows you to search on things we currently don't index (like headers). 3. Operator We have two categories of operators depending on the data type. Integers That category of operators work on field that are numbers like code and port. eq: Equal to value gt: Greater than value gte: Greater than or equal to value lt: Less than value lte: Less than or equal to value ne: No equal to value String/Bytes That category of operators work on field that are text (or bytes) like path and raw. cont: Contains value (case insensitive) eq: Equal to value like: Sqlite LIKE operator. The symbol % matches zero or more characters (like %.js to match .map.js) and the symbol _ matches one character (like v_lue to match vAlue). ncont: Doesn't contain value (case insensitive) ne: No equal to value nlike: SQLITE NOT LIKE operator, see like for more details. Regex That category of operators work on field that are text (or bytes) like path and raw. regex: Matches the regex /value.+/ nregex: Doesn't match the regex /value.+/ 4. Value This is the value against which the field will be compared. The value is either an integer (like 1), a string ("value") or a regex (/value/) depending on the field and operator. Preset The preset value is a different. You can reference presets in one of two ways: Name: preset:"Preset name" Alias: preset:preset-alias Head over to the filters page to learn more about filter presets. Standalone We support string standalone values without namespace, field and operator (like "my value"). It is a shortcut to search across both requests and responses, it is replaced at runtime by: (req.raw.cont:"my value" OR resp.raw.cont:"my value") Query A full HTTPQL Query Queries are composed of multiple filter clauses that are combined together using logical operators and logical grouping. Logical operators We offer two logical operators: AND: Both the left and right clauses must be true OR: Either the left or right clause must be true Operators can be written in upper or lower case. Both have the same priority. Logical grouping Caido supports the priority of operations, AND has a higher priority than OR. Here are some examples: clause1 AND clause2 OR clause3 is equivalent to ((clause1 AND clause2) OR clause3) clause1 OR clause2 AND clause3 is equivalent to (clause1 OR (clause2 AND clause3)) clause1 AND clause2 AND clause3 is equivalent to ((clause1 AND clause2) AND clause3) We still recommend that you insert parentheses to make sure the logicial groups represent what you are trying to accomplish
`.replaceAll(`
`, " "), dn = () => {
  h().promptCommands.createPromptCommand(
    "Suggest HTTPQL query",
    "Response contains 'hello' and status code is 200",
    un
  );
}, un = async (n) => {
  on(ln, n).then((e) => {
    pn(e);
  }).catch((e) => {
    console.error("Error:", e), h().toast.showToast({
      message: "Failed to suggest HTTPQL query. More details in the console.",
      duration: 3e3,
      position: "bottom",
      type: "error"
    });
  });
}, pn = async (n) => {
  try {
    p().navigation.goTo("/intercept");
    const e = setInterval(() => {
      const t = document.querySelector(".c-search-query-editor__editor .cm-line");
      t && (t.textContent = n, clearInterval(e));
    }, 5);
  } catch (e) {
    console.error("Error:", e);
  }
};
class mn {
  constructor() {
    _(this, "handlers", []);
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
  }
  trigger() {
    this.handlers.forEach((e) => e());
  }
}
const hn = async () => {
  try {
    p().graphql.interceptRequestMessages({ first: 1e3 }).then((n) => n.interceptMessages.nodes.forEach((e) => {
      p().graphql.dropInterceptMesage({ id: e.id });
    })), setTimeout(fn, 25);
  } catch (n) {
    console.error("Error executing drop requests based on fetched IDs:", n);
  }
}, fn = () => {
  document.querySelector(".c-global-actions__status button").click(), setTimeout(() => {
    document.querySelector(".c-global-actions__status button").click();
  }, 5);
}, bn = () => {
  var t;
  (t = document.querySelector("#dropAllButton")) == null || t.remove();
  const n = document.querySelector(".c-topbar__left");
  if (!n)
    return;
  const e = p().ui.button({
    variant: "primary",
    label: "Drop all",
    size: "small"
  });
  e.id = "dropAllButton", e.addEventListener("click", hn), n.appendChild(e);
}, gn = () => {
  h().eventManager.on("onPageOpen", (n) => {
    n.newUrl.startsWith("#/forward/") && bn();
  });
}, vn = async (n) => await p().graphql.replaySessionCollections().then((e) => e.replaySessionCollections.edges.find(
  (s) => s.node.id === n
)), yn = async (n, e) => await p().graphql.createReplaySession({
  input: {
    collectionId: n,
    requestSource: {
      raw: e
    }
  }
}), wn = async (n) => await p().graphql.createReplaySessionCollection({
  input: {
    name: n
  }
}), En = async (n) => {
  var a;
  const e = await vn(n);
  if (!e)
    return new Error("Collection not found");
  const t = [], s = e.node.sessions;
  if (s && s.length > 0)
    for (const i of s) {
      const c = (a = i.activeEntry) == null ? void 0 : a.id;
      if (!c)
        continue;
      const u = await p().graphql.replayEntry({
        id: c
      });
      t.push({ ...u.replayEntry, name: i.name });
    }
  const o = {
    name: e.node.name,
    replayEntries: t
  }, r = e.node.name.replaceAll(" ", "_");
  ae(
    "collection_" + r + ".json",
    JSON.stringify(o)
  ), h().toast.showToast({
    message: "Collection downloaded successfully!",
    duration: 3e3,
    position: "bottom",
    type: "success"
  });
}, Cn = async (n) => {
  var r, a;
  const e = n.name, s = (r = (await wn(e)).createReplaySessionCollection.collection) == null ? void 0 : r.id;
  if (!s)
    return;
  const o = n.replayEntries;
  if (o && o.length > 0)
    for (const i of o) {
      const c = {
        connectionInfo: {
          host: i.connection.host,
          port: i.connection.port,
          isTLS: i.connection.isTls
        },
        raw: i.raw
      }, l = (a = (await yn(s, c)).createReplaySession.session) == null ? void 0 : a.id;
      if (!l)
        return;
      await p().graphql.renameReplaySession({
        id: l,
        name: i.name
      });
    }
  return h().toast.showToast({
    message: "Collection imported successfully!",
    duration: 3e3,
    position: "bottom",
    type: "success"
  }), s;
}, ve = () => {
  if (document.querySelector("#import-collection"))
    return;
  const n = document.querySelector(".c-topbar__left");
  if (!n)
    return;
  const e = p().ui.button({
    label: "Import Collection",
    variant: "tertiary",
    size: "small",
    leadingIcon: "fas fa-file-import"
  });
  e.id = "import-collection", e.style.float = "left", e.style.marginRight = "1em", e.addEventListener("click", async () => {
    const t = document.createElement("input");
    t.type = "file", t.accept = ".json", t.click(), t.addEventListener("change", async () => {
      var r;
      const s = (r = t.files) == null ? void 0 : r[0];
      if (!s)
        return;
      const o = new FileReader();
      o.readAsText(s), o.onload = async () => {
        const a = JSON.parse(o.result);
        await Cn(a), setTimeout(() => {
          window.location.reload();
        }, 25);
      };
    });
  }), n.prepend(e);
}, G = () => {
  const n = document.querySelectorAll(".c-tree-collection");
  !n || n.length === 0 || n.forEach((e) => {
    var r;
    if (e.querySelector("#download-collection"))
      return;
    const t = e.querySelector(".c-tree-collection__actions");
    if (!t)
      return;
    const s = (r = t.childNodes[0]) == null ? void 0 : r.cloneNode(!0);
    if (!s)
      return;
    const o = s.querySelector("i");
    o && (s.id = "download-collection", o.classList.value = "c-icon fas fa-file-arrow-down", s.addEventListener("click", async () => {
      const a = e.getAttribute("data-collection-id");
      if (!a)
        return;
      const i = await En(a);
      i && h().toast.showToast({
        message: "Failed to download collection: " + i,
        duration: 3e3,
        position: "bottom",
        type: "error"
      });
    }), t.prepend(s));
  });
};
let F;
const Sn = () => {
  h().eventManager.on("onProjectChange", () => {
    window.location.hash === "#/replay" && (ve(), setTimeout(() => {
      G();
    }, 500));
  }), h().eventManager.on("onPageOpen", (n) => {
    if (n.newUrl === "#/replay") {
      ve(), G(), F && F.disconnect(), F = new MutationObserver((t) => {
        t.forEach((s) => {
          s.addedNodes.length > 0 && G();
        });
      });
      const e = document.querySelector(".c-session-list-body__tree .c-tree");
      if (!e)
        return;
      F.observe(e, {
        childList: !0,
        subtree: !0
      });
    }
  });
}, _n = (n) => {
  const [e, ...t] = n.split(`\r
`);
  if (!e)
    throw new Error("Invalid response");
  const [s, o, r] = e.split(" ");
  if (!s || !o || !r)
    throw new Error("Invalid status line");
  const a = t.slice(0, t.indexOf("")), i = t.slice(t.indexOf("") + 1).join(`\r
`);
  return {
    httpVersion: s,
    statusCode: o,
    statusText: r,
    headers: a,
    body: i
  };
}, kn = async () => {
  const n = document.querySelector(".c-response .c-response");
  if (!n)
    return;
  const e = n.getAttribute("data-response-id");
  if (e)
    return await p().graphql.response({ id: e }).then((t) => {
      var s;
      return (s = t.response) == null ? void 0 : s.raw;
    });
}, ee = () => {
  const n = document.querySelector(".c-response-header .c-response-header__right .c-response-header__actions");
  if (!n || n.querySelector("#preview-button"))
    return;
  n.style.display = "flex", n.style.gap = "1em";
  const e = p().ui.button({
    variant: "tertiary",
    size: "small",
    leadingIcon: "fas fa-eye"
  });
  e.id = "preview-button";
  const t = e.querySelector("button");
  t.style.backgroundColor = "var(--c-bg-default)";
  const s = e.querySelector(".c-button__leading-icon");
  s.style.margin = "0", s.style.color = "white", e.addEventListener("click", async () => {
    const o = await kn();
    if (!o) {
      h().toast.showToast({
        message: "Failed to get response",
        type: "error",
        duration: 3e3,
        position: "bottom"
      });
      return;
    }
    const r = _n(o);
    xn(r);
  }), n.appendChild(e);
}, xn = (n) => fetch(oe, {
  method: "POST"
}).then((e) => e.json()).then((e) => {
  const t = e;
  console.log(n), Te(t, parseInt(n.statusCode), n.body, n.headers.join(`\r
`)).then((s) => {
    setTimeout(() => navigator.clipboard.writeText(`https://${t}.c5.rs/`), 0), h().toast.showToast({
      message: "Navigate to the copied URL to view the response!",
      type: "success",
      duration: 3e3,
      position: "bottom"
    });
  }).catch((s) => {
    h().toast.showToast({
      message: "Failed to send response to CVSSAdvisor!",
      type: "error",
      duration: 3e3,
      position: "bottom"
    }), console.error(s);
  });
});
let T;
const In = () => {
  T == null || T.disconnect();
  const n = document.querySelector(".c-intercept .c-grid .c-grid .c-grid-item ~ .c-grid-item");
  if (!n) {
    console.warn("Target node not found.");
    return;
  }
  const e = { attributes: !0, childList: !0, subtree: !0 }, t = (s) => {
    for (const o of s)
      o.type === "childList" && ee();
  };
  T = new MutationObserver(t), T.observe(n, e);
};
let q = null;
const Ln = () => {
  q == null || q.disconnect(), ee();
  const n = document.querySelector(".c-replay__replay-session");
  if (!n) {
    console.warn("Target node not found.");
    return;
  }
  const e = { attributes: !0, childList: !0, subtree: !0 }, t = (s) => {
    for (const o of s)
      for (const r of Array.from(o.addedNodes))
        r instanceof HTMLElement && (r.classList.contains("c-replay-session") || r.classList.contains("c-response")) && ee();
  };
  q = new MutationObserver(t), q.observe(n, e);
}, An = () => {
  h().eventManager.on("onPageOpen", (n) => {
    n.newUrl === "#/intercept" ? In() : n.newUrl === "#/replay" ? Ln() : (T == null || T.disconnect(), q == null || q.disconnect());
  });
};
let k;
const Tn = () => {
  h().eventManager.on("onPageOpen", (n) => {
    n.newUrl === "#/automate" && setTimeout(() => {
      qn();
    }, 100);
  }), p().commandPalette.register("evenbetter:numbersPayload");
};
let $;
const qn = () => {
  var e;
  $ && $.disconnect();
  const n = (e = document.querySelector(
    ".p-tabview-panels"
  )) == null ? void 0 : e.parentElement;
  n && ($ = new MutationObserver(() => {
    document.querySelector(".c-empty-state__body-content") || (Rn(), Mn());
  }), $.observe(n, {
    attributes: !0,
    subtree: !0
  }));
};
let U;
const Mn = () => {
  var t;
  U && U.disconnect();
  const n = (t = document.querySelector(
    ".c-payload-settings__body .c-kind-dropdown .p-inputtext"
  )) == null ? void 0 : t.textContent;
  n && k && (k.style.display = n === "Simple List" ? "block" : "none");
  const e = document.querySelector(
    ".c-payload-settings__body .c-kind-dropdown"
  );
  e && (U = new MutationObserver((s) => {
    k && s.forEach((o) => {
      var r;
      if (o.attributeName === "aria-label") {
        const a = (r = document.querySelector(
          ".c-payload-settings__body .c-kind-dropdown .p-inputtext"
        )) == null ? void 0 : r.textContent;
        k.style.display = a === "Simple List" ? "block" : "none";
      }
    });
  }), U.observe(e, {
    attributes: !0,
    subtree: !0
  }));
}, Rn = () => {
  if (document.getElementById("numbersPayload"))
    return;
  const n = document.querySelector(
    ".c-payload-settings__kind"
  );
  if (!n)
    return;
  k = document.createElement("div"), k.style.marginBottom = "0.5em", k.style.display = "none", k.id = "numbersPayload";
  const e = document.createElement("label");
  e.innerText = "Numbers", e.style.fontSize = "var(--c-font-size-100)", k.appendChild(e);
  const t = document.createElement("div");
  t.style.display = "flex", t.style.gap = "1em";
  const s = h().components.createTextInput(
    "10em",
    "Min",
    !1
  );
  t.appendChild(s);
  const o = h().components.createTextInput(
    "10em",
    "Max",
    !1
  );
  t.appendChild(o);
  const r = h().components.createTextInput(
    "10em",
    "Step",
    !1
  ), a = s.querySelector("input"), i = o.querySelector("input"), c = r.querySelector("input");
  !a || !i || !c || (c.value = "1", t.appendChild(r), a.addEventListener("input", (u) => {
    if (!i.value)
      return;
    const l = parseInt(u.target.value), d = parseInt(i.value), m = parseInt(c.value), f = K(l, d, m);
    z(f.join(`
`));
  }), i.addEventListener("input", (u) => {
    if (!a.value)
      return;
    const l = parseInt(a.value), d = parseInt(u.target.value), m = parseInt(c.value), f = K(l, d, m);
    z(f.join(`
`));
  }), c.addEventListener("input", (u) => {
    if (!a.value || !i.value)
      return;
    const l = parseInt(a.value), d = parseInt(i.value), m = parseInt(u.target.value), f = K(l, d, m);
    z(f.join(`
`));
  }), k.appendChild(t), n.prepend(k));
}, z = (n) => {
  const e = document.querySelector(".c-simple-list__list .cm-content");
  e && (e.textContent = n);
}, K = (n, e, t) => {
  const s = [];
  for (let o = n; o <= e; o += t)
    s.push(o);
  return s;
}, Nn = () => {
  h().eventManager.on("onPageOpen", (n) => {
    n.newUrl == "#/tamper" ? (Pn(), On()) : M && (M.disconnect(), M = null);
  });
}, Pn = () => {
  const n = document.querySelector(
    ".c-rule-list-header__new"
  );
  if (!n || document.querySelector("#scope-presents-import"))
    return;
  n.style.display = "flex", n.style.gap = "0.5em";
  const e = n.parentElement;
  if (!e)
    return;
  e.style.display = "flex", e.style.justifyContent = "space-between", e.style.alignItems = "center", e.style.padding = "var(--c-space-3)";
  const t = document.createElement("div");
  t.textContent = "Rules", t.classList.add("c-header__title"), e.prepend(t);
  const s = p().ui.button({
    label: "Import",
    leadingIcon: "fas fa-file-upload",
    variant: "primary"
  });
  s.id = "scope-presents-import", s.addEventListener("click", () => {
    const o = document.createElement("input");
    o.type = "file", o.accept = ".json", o.style.display = "none", o.addEventListener("change", (r) => {
      const a = r.target;
      if (!a.files || !a.files.length)
        return;
      const i = a.files[0];
      if (!i)
        return;
      const c = new FileReader();
      c.onload = async (u) => {
        const l = u.target, d = JSON.parse(l.result), m = await Bn();
        m && (p().graphql.createTamperRule({
          input: {
            collectionId: m,
            name: d.name,
            condition: d.condition,
            isEnabled: d.isEnabled,
            isRegex: d.isRegex,
            matchTerm: d.matchTerm,
            replaceTerm: d.replaceTerm,
            strategy: d.strategy
          }
        }), setTimeout(() => {
          window.location.reload();
        }, 20));
      }, c.readAsText(i);
    }), document.body.prepend(o), o.click(), o.remove();
  }), n.appendChild(s);
}, Bn = () => p().graphql.tamperRuleCollections().then((n) => {
  var e, t;
  return (t = (e = n.tamperRuleCollections) == null ? void 0 : e.nodes[0]) == null ? void 0 : t.id;
});
let M = null;
const On = () => {
  const n = document.querySelector(".c-tamper");
  n && (M && (M.disconnect(), M = null), M = new MutationObserver((e) => {
    e.some((t) => {
      const s = t.target;
      for (let o = 0; o < t.addedNodes.length; o++)
        if (t.addedNodes[o].id == "rules-download")
          return !0;
      return !!s.classList.contains("c-grid-item");
    }) || Dn();
  }), M.observe(n, {
    childList: !0,
    attributes: !0,
    subtree: !0
  }));
}, Dn = () => {
  var t;
  (t = document.querySelector("#rules-download")) == null || t.remove();
  const n = document.querySelector(
    ".c-rule-form-update__header"
  );
  if (!n)
    return;
  const e = p().ui.button({
    label: "Download",
    leadingIcon: "fas fa-file-arrow-down",
    variant: "tertiary",
    size: "small"
  });
  e.id = "rules-download", e.addEventListener("click", () => {
    const s = Hn();
    s && p().graphql.tamperRuleCollections().then((o) => {
      o.tamperRuleCollections.nodes.forEach((a) => {
        a.rules.forEach((c) => {
          if (c.id == s) {
            const u = c.name.replace(/[^a-zA-Z0-9]/g, "-");
            ae("rule-" + u + ".json", JSON.stringify(c));
          }
        });
      });
    });
  }), n.appendChild(e);
}, Hn = () => {
  var e;
  return (e = document.querySelector('.c-tree-item__subtree [data-is-active="true"]')) == null ? void 0 : e.getAttribute("data-rule-id");
};
class Fn {
  log(e, t) {
  }
  info(e) {
    this.log("info", e);
  }
  error(e) {
    this.log("error", e);
  }
  warn(e) {
    this.log("warn", e);
  }
}
const ie = new Fn();
class $n {
  constructor() {
    this.events = {};
  }
  registerEvent(e, t) {
    this.events[e] = t;
  }
  triggerEvent(e, t) {
    const s = this.events[e];
    s ? s.trigger(t) : console.error(`Event "${e}" not registered.`);
  }
  on(e, t) {
    const s = this.events[e];
    s ? s.addHandler(t) : console.error(`Event "${e}" not registered.`);
  }
  initEvents() {
    ie.info(`Initializing ${Object.keys(this.events).length} custom events`);
    for (const e in this.events)
      this.events[e].init();
  }
}
class Un {
  constructor() {
    this.handlers = [];
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    const e = setInterval(() => {
      jn() && (clearInterval(e), this.trigger());
    }, 25);
  }
  trigger() {
    this.handlers.forEach((e) => e());
  }
}
const jn = () => document.querySelector(".c-content") !== null;
class Wn {
  constructor() {
    this.handlers = [];
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    new MutationObserver((t) => {
      for (let s of t)
        s.type === "childList" && s.addedNodes.forEach((o) => {
          const r = o;
          o.nodeType === 1 && r.classList.contains("p-contextmenu") && this.trigger(r);
        });
    }).observe(document.body, { childList: !0, subtree: !0 });
  }
  trigger(e) {
    this.handlers.forEach((t) => t(e));
  }
}
class Vn {
  constructor(e) {
    this.handlers = [], this.eventManager = e;
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    let e = window.location.href;
    const t = new MutationObserver(() => {
      var o;
      if (window.location.href !== e) {
        let r = new URL(window.location.href).hash, a = new URL(e).hash;
        e = window.location.href, r.includes("?custom-path=") && (r = r.split("?custom-path=")[1]), a.includes("?custom-path=") && (a = a.split("?custom-path=")[1]), (o = document.querySelector(".c-content")) == null || o.setAttribute("data-page", r), this.trigger({
          newUrl: r,
          oldUrl: a
        });
      }
    }), s = { subtree: !0, childList: !0 };
    t.observe(document, s);
  }
  trigger(e) {
    ie.info(`Page updated: ${e.oldUrl} -> ${e.newUrl}`), e.newUrl.startsWith("#/settings/") && this.eventManager.triggerEvent(
      "onSettingsTabOpen",
      e.newUrl.replace("#/settings/", "")
    ), this.handlers.forEach((t) => t(e));
  }
}
class Gn {
  constructor() {
    this.handlers = [];
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
  }
  trigger(e) {
    ie.info(`Settings tab opened: ${e}`), this.handlers.forEach((t) => t(e));
  }
}
let te = null;
const zn = (n) => {
  te = n;
}, H = () => {
  if (!te)
    throw new Error("PluginData is not set yet!");
  return te;
}, ye = async (n, e) => {
  const t = H();
  localStorage.setItem(`ebapi:settings:${t.manifestID}:${n}`, e);
}, O = (n) => {
  const e = H();
  return localStorage.getItem(`ebapi:settings:${e.manifestID}:${n}`);
}, Kn = () => localStorage.getItem(`ebapi:${H().manifestID}:welcomeToast`), we = () => {
  localStorage.removeItem(`ebapi:${H().manifestID}:welcomeToast`);
}, Qn = async (n) => {
  localStorage.setItem(`ebapi:${H().manifestID}:welcomeToast`, JSON.stringify(n));
}, Yn = `
.v-toast--fade-in {
    animation: fadeIn 0.15s ease-in-out forwards;
}
@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}
.v-toast--fade-out {
    animation: fadeOut 0.15s ease-in-out forwards;
}
@keyframes fadeOut {
    from {
        opacity: 1;
    }
    to {
        opacity: 0;
    }
}`, Jn = (n, e, t) => {
  const s = document.createElement("div");
  s.classList.add("v-toast"), s.classList.add(`v-toast--${t}`);
  const o = document.createElement("div");
  o.setAttribute("role", "alert"), o.classList.add("v-toast__item"), o.classList.add(`v-toast__item--${e}`), o.classList.add(`v-toast__item--${t}`), s.appendChild(o);
  const r = document.createElement("div");
  r.classList.add("v-toast__icon"), o.appendChild(r);
  const a = document.createElement("p");
  return a.classList.add("v-toast__text"), a.textContent = n, o.appendChild(a), s.classList.add("v-toast--fade-in"), s;
}, Zn = (n) => {
  let { message: e, type: t, position: s, duration: o } = n;
  s || (s = "bottom"), t || (t = "success"), o || (o = 3e3);
  let r = document.querySelector(
    `.v-toast--${s}`
  );
  r || (r = document.createElement("div"), r.classList.add("v-toast"), r.classList.add(`v-toast--${s}`), document.body.appendChild(r));
  const a = Jn(e, t, s);
  r.appendChild(a), setTimeout(() => {
    a.classList.add("v-toast--fade-out"), setTimeout(() => {
      a.remove();
    }, 150);
  }, o - 150);
};
class Xn {
  constructor(e) {
    this.showToast = (t) => {
      Zn(t);
    }, this.setWelcomeMessage = (t) => {
      Qn(t);
    }, this.evenBetterAPI = e, this.evenBetterAPI.helpers.loadCSS({ id: "eb-toast", cssText: Yn });
  }
}
class es {
  constructor() {
    this.handlers = [], this.commandObserver = null, this.selectedCommand = null;
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    const e = (o) => {
      this.commandObserver = new MutationObserver((r) => {
        const a = t();
        a !== this.selectedCommand && (this.selectedCommand = a);
      }), this.commandObserver.observe(o, {
        attributes: !0,
        subtree: !0
      });
    }, t = () => document.querySelector("[command-item][aria-selected='true']");
    new MutationObserver((o) => {
      for (let r of o)
        r.type === "childList" && (r.addedNodes.forEach((a) => {
          const i = a;
          a.nodeType === 1 && i.hasAttribute("command-theme") && e(i);
        }), r.removedNodes.forEach((a) => {
          const i = a;
          if (a.nodeType === 1 && i.hasAttribute("command-theme")) {
            if (!this.selectedCommand)
              return;
            const c = this.selectedCommand.getAttribute("data-value");
            c && this.trigger(c), this.commandObserver && (this.commandObserver.disconnect(), this.commandObserver = null);
          }
        }));
    }).observe(document.body, { childList: !0, subtree: !0 });
  }
  trigger(e) {
    this.handlers.forEach((t) => t(e));
  }
}
const ts = "2.0.0";
let ne = null;
const ns = (n) => {
  ne = n;
}, ss = () => {
  if (!ne)
    throw new Error("CaidoAPI is not set yet!");
  return ne;
}, os = `
.eb-checkbox__input {
    cursor: pointer;
    -webkit-appearance: none;
    appearance: none;
    width: 1.15em;
    height: 1.15em;
    border: .1em solid grey;
    border-radius: 4px;
    display: inline-grid;
    place-content: center;
    margin: 0;
}
.eb-checkbox__input:checked:before {
    transform: scale(1);
}
.eb-checkbox__input:before {
    content: "";
    transform: scale(0);
    width: .65em;
    height: .65em;
    border-radius: 2px;
    box-shadow: inset 1em 1em var(--c-fg-secondary);
}
.eb-button__label {
    display: inline-flex;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
`, rs = (n) => {
  n.helpers.loadCSS({ id: "checkbox", cssText: os });
  const e = document.createElement("div");
  e.classList.add("eb-button__label");
  const t = document.createElement("div");
  t.classList.add("eb-checkbox");
  const s = document.createElement("div");
  s.classList.add("formkit-outer"), s.dataset.family = "box", s.dataset.type = "checkbox", s.dataset.complete = "true";
  const o = document.createElement("label");
  o.classList.add("formkit-wrapper", "eb-checkbox__wrapper"), o.dataset.checked = "true";
  const r = document.createElement("span");
  r.classList.add("formkit-inner", "eb-checkbox__inner");
  const a = document.createElement("input");
  a.classList.add("formkit-input", "eb-checkbox__input"), a.type = "checkbox";
  const i = document.createElement("span");
  return i.classList.add("formkit-decorator"), i.setAttribute("aria-hidden", "true"), r.appendChild(a), r.appendChild(i), o.appendChild(r), s.appendChild(o), t.appendChild(s), e.appendChild(t), e;
}, as = `
.eb-text-input__inner {
    gap: var(--c-space-1); 
    flex: 1; 
    display: flex; 
    align-items: center; 
    padding-left: var(--c-space-2); 
    padding-right: var(--c-space-2); 
    box-sizing: border-box; 
    border: var(--c-border-width-1) solid var(--c-border-default); 
    border-radius: var(--c-border-radius-2); 
    color: var(--c-fg-default); 
    background-color: var(--c-bg-default); 
    min-height: var(--c-space-10);
}
.eb-text-input__inner:focus-within {
    border: var(--c-border-width-2) solid var(--c-border-secondary);
}
.eb-text-input__inner textarea {
  padding-top: var(--c-space-2);
}
`;
function is(n, e, t, s = !1, o) {
  n.helpers.loadCSS({ id: "eb-text-input", cssText: as });
  const r = document.createElement("div");
  r.classList.add("formkit-outer", "c-text-input__outer"), r.setAttribute("style", `width: ${e};`);
  const a = document.createElement("div");
  a.classList.add("formkit-wrapper"), a.style.display = "flex";
  const i = document.createElement("div");
  i.classList.add("formkit-inner", "eb-text-input__inner");
  const c = document.createElement("div");
  c.classList.add("c-text-input__prefix"), c.setAttribute(
    "style",
    "align-self: center; color: var(--c-fg-subtle);"
  );
  const u = document.createElement("i");
  u.classList.add("c-icon", "fas"), o && u.classList.add(o);
  const l = document.createElement("input");
  if (t && t != "" && l.setAttribute("placeholder", t), l.setAttribute("spellcheck", "false"), l.classList.add("formkit-input", "c-text-input__input"), l.setAttribute("type", "text"), l.setAttribute(
    "style",
    "width: 100%; background: transparent; border: 0; outline: 0; color: inherit; box-sizing: border-box; line-height: inherit;"
  ), o && c.appendChild(u), i.appendChild(c), i.appendChild(l), s) {
    const d = document.createElement("button");
    d.innerHTML = '<i class="fas fa-copy"></i>', d.setAttribute(
      "style",
      "background: transparent; border: 0; outline: 0; cursor: pointer; padding: 0; margin-left: 10px;"
    ), d.addEventListener("click", () => {
      navigator.clipboard.writeText(l.value), n.toast.showToast({
        message: "Copied to clipboard",
        position: "bottom",
        type: "info",
        duration: 1e3
      });
    }), i.appendChild(d);
  }
  return a.appendChild(i), r.appendChild(a), r;
}
function cs(n, e) {
  const t = document.createElement("div");
  t.classList.add("c-menu-bar"), t.style.width = "100%";
  const s = document.createElement("div");
  s.classList.add("p-menubar", "p-component"), s.setAttribute("data-pc-name", "menubar"), s.setAttribute("data-pc-section", "root");
  const o = document.createElement("div");
  o.classList.add("p-menubar-start"), o.setAttribute("data-pc-section", "start");
  const r = document.createElement("div");
  r.classList.add("c-settings__title"), r.style.padding = "0 var(--c-space-4)", r.style.fontWeight = "700", r.textContent = e.title, o.appendChild(r);
  const a = document.createElement("ul");
  a.classList.add("p-menubar-root-list");
  const i = e.items.map((l) => l.url);
  e.items.forEach((l) => {
    const d = document.createElement("li");
    d.classList.add("p-menuitem"), d.setAttribute("role", "menuitem"), d.style.margin = "0";
    const m = document.createElement("div");
    m.classList.add("p-menuitem-content"), m.setAttribute("data-pc-section", "content");
    const f = document.createElement("div");
    f.classList.add("c-settings__item"), f.setAttribute("data-is-active", "true"), f.addEventListener("click", () => {
      s.classList.remove("p-menubar-mobile-active");
    });
    const b = document.createElement("a");
    b.setAttribute("href", l.url), b.setAttribute("draggable", "false"), b.draggable = !1, b.classList.add("p-menuitem-link"), l.url === location.hash && (b.style.backgroundColor = "rgba(255,255,255,.04)", b.style.borderRadius = "var(--c-border-radius-2)");
    let g = null;
    if (n.eventManager.on("onPageOpen", (w) => {
      if (l.sidebarItemName)
        if (i.includes(w.newUrl)) {
          const C = document.querySelectorAll(".c-sidebar-item");
          if (C) {
            const S = Array.from(C).filter(
              (L) => L.textContent === l.sidebarItemName
            );
            S.length >= 1 && (g = S[0], g.setAttribute("data-is-selected", "true"), g.setAttribute("data-is-active", "true"));
          }
        } else
          g && (g.removeAttribute("data-is-selected"), g.removeAttribute("data-is-active"), g = null);
      w.newUrl === l.url ? (l.onOpen && l.onOpen(), b.style.backgroundColor = "rgba(255,255,255,.04)", b.style.borderRadius = "var(--c-border-radius-2)") : (b.style.backgroundColor = "", b.style.borderRadius = "");
    }), l.icon) {
      const w = document.createElement("i");
      w.classList.add("c-icon", "fas", l.icon), w.style.marginRight = "var(--c-space-2)", b.appendChild(w);
    }
    const v = document.createElement("span");
    v.textContent = l.title, b.appendChild(v), f.appendChild(b), m.appendChild(f), d.appendChild(m), a.appendChild(d);
  });
  const c = document.createElement("a");
  c.setAttribute("role", "button"), c.setAttribute("tabindex", "0"), c.classList.add("p-menubar-button"), c.setAttribute("aria-haspopup", "true"), c.setAttribute("aria-expanded", "false"), c.setAttribute("aria-label", "Navigation"), c.setAttribute("data-pc-section", "button"), c.setAttribute("aria-controls", "pv_id_3"), c.innerHTML = '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="p-icon" aria-hidden="true" data-pc-section="menubuttonicon"><path fill-rule="evenodd" clip-rule="evenodd" d="M13.3226 3.6129H0.677419C0.497757 3.6129 0.325452 3.54152 0.198411 3.41448C0.0713707 3.28744 0 3.11514 0 2.93548C0 2.75581 0.0713707 2.58351 0.198411 2.45647C0.325452 2.32943 0.497757 2.25806 0.677419 2.25806H13.3226C13.5022 2.25806 13.6745 2.32943 13.8016 2.45647C13.9286 2.58351 14 2.75581 14 2.93548C14 3.11514 13.9286 3.28744 13.8016 3.41448C13.6745 3.54152 13.5022 3.6129 13.3226 3.6129ZM13.3226 7.67741H0.677419C0.497757 7.67741 0.325452 7.60604 0.198411 7.479C0.0713707 7.35196 0 7.17965 0 6.99999C0 6.82033 0.0713707 6.64802 0.198411 6.52098C0.325452 6.39394 0.497757 6.32257 0.677419 6.32257H13.3226C13.5022 6.32257 13.6745 6.39394 13.8016 6.52098C13.9286 6.64802 14 6.82033 14 6.99999C14 7.17965 13.9286 7.35196 13.8016 7.479C13.6745 7.60604 13.5022 7.67741 13.3226 7.67741ZM0.677419 11.7419H13.3226C13.5022 11.7419 13.6745 11.6706 13.8016 11.5435C13.9286 11.4165 14 11.2442 14 11.0645C14 10.8848 13.9286 10.7125 13.8016 10.5855C13.6745 10.4585 13.5022 10.3871 13.3226 10.3871H0.677419C0.497757 10.3871 0.325452 10.4585 0.198411 10.5855C0.0713707 10.7125 0 10.8848 0 11.0645C0 11.2442 0.0713707 11.4165 0.198411 11.5435C0.325452 11.6706 0.497757 11.7419 0.677419 11.7419Z" fill="currentColor"></path></svg>', c.addEventListener("click", () => {
    s.classList.toggle("p-menubar-mobile-active"), a.style.zIndex = s.classList.contains("p-menubar-mobile-active") ? "1200" : "";
  }), window.addEventListener("resize", () => {
    window.innerWidth < 955 ? s.classList.add("p-menubar-mobile") : (s.classList.remove("p-menubar-mobile"), s.classList.remove("p-menubar-mobile-active"));
  }), window.dispatchEvent(new Event("resize"));
  const u = document.createElement("div");
  return u.classList.add("p-menubar-end"), u.setAttribute("data-pc-section", "end"), u.style.display = "flex", u.style.gap = ".5em", u.style.alignItems = "center", e.customButtons && e.customButtons.forEach((l) => {
    u.appendChild(l);
  }), s.appendChild(o), s.appendChild(c), s.appendChild(a), s.appendChild(u), t.appendChild(s), t;
}
const ls = `
.eb-select {
    background-image: url(data:image/svg+xml;charset=US-ASCII,%3Csvg%20viewBox%3D%220%20-4.5%2020%2020%22%20version%3D%221.1%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%20fill%3D%22%23ffffff%22%3E%3Cg%20id%3D%22SVGRepo_bgCarrier%22%20stroke-width%3D%220%22%3E%3C%2Fg%3E%3Cg%20id%3D%22SVGRepo_tracerCarrier%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%3C%2Fg%3E%3Cg%20id%3D%22SVGRepo_iconCarrier%22%3E%20%3Ctitle%3Earrow_down%20%5B%23ffffff%5D%3C%2Ftitle%3E%20%3Cdesc%3ECreated%20with%20Sketch.%3C%2Fdesc%3E%20%3Cdefs%3E%20%3C%2Fdefs%3E%20%3Cg%20id%3D%22Page-1%22%20stroke%3D%22none%22%20stroke-width%3D%221%22%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%20%3Cg%20id%3D%22Dribbble-Light-Preview%22%20transform%3D%22translate%28-220.000000%2C%20-6684.000000%29%22%20fill%3D%22%23ffffff%22%3E%20%3Cg%20id%3D%22icons%22%20transform%3D%22translate%2856.000000%2C%20160.000000%29%22%3E%20%3Cpath%20d%3D%22M164.292308%2C6524.36583%20L164.292308%2C6524.36583%20C163.902564%2C6524.77071%20163.902564%2C6525.42619%20164.292308%2C6525.83004%20L172.555873%2C6534.39267%20C173.33636%2C6535.20244%20174.602528%2C6535.20244%20175.383014%2C6534.39267%20L183.70754%2C6525.76791%20C184.093286%2C6525.36716%20184.098283%2C6524.71997%20183.717533%2C6524.31405%20C183.328789%2C6523.89985%20182.68821%2C6523.89467%20182.29347%2C6524.30266%20L174.676479%2C6532.19636%20C174.285736%2C6532.60124%20173.653152%2C6532.60124%20173.262409%2C6532.19636%20L165.705379%2C6524.36583%20C165.315635%2C6523.96094%20164.683051%2C6523.96094%20164.292308%2C6524.36583%22%20id%3D%22arrow_down-%5B%23ffffff%5D%22%3E%20%3C%2Fpath%3E%20%3C%2Fg%3E%20%3C%2Fg%3E%20%3C%2Fg%3E%20%3C%2Fg%3E%3C%2Fsvg%3E);
    background-repeat: no-repeat;
    background-position: right 0.7rem top 50%;
    background-size: 0.65rem auto;
    width: 100%;
    height: var(--c-space-10);
    border-radius: var(--c-border-radius-2) 0px 0px var(--c-border-radius-2) !important;
    border: var(--c-border-width-1) solid var(--c-border-default);
    background-color: var(--c-bg-default);
    color: var(--c-fg-default);
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    padding: 0 0.5em;
}
`;
function ds(n, e) {
  n.helpers.loadCSS({ id: "eb-select", cssText: ls });
  const t = document.createElement("select");
  return t.classList.add("eb-select"), e.forEach((s) => {
    const o = document.createElement("option");
    o.value = s.value, o.textContent = s.label, t.appendChild(o);
  }), t;
}
function us(n, ...e) {
  return n.reduce((t, s, o) => {
    let r = s + (e[o] !== void 0 ? e[o] : "");
    return t + r.replace(/\s+/g, " ").trim();
  }, "");
}
const ps = () => us`
      <table role="table" class="p-datatable-table" data-pc-section="table">
        <thead class="p-datatable-thead" role="rowgroup" data-pc-section="thead" style="position: sticky;">
          <tr role="row" data-pc-section="headerrow">
          </tr>
        </thead>
        <tbody class="p-datatable-tbody" role="rowgroup" data-pc-section="tbody">
        </tbody>
      </table>
    `.trim(), ms = (n, e) => new ce(e);
class ce {
  constructor(e) {
    this.config = e, this.rows = [], this.tableElement = document.createElement("div"), this.tableElement.className = "p-datatable p-datatable-responsive-scroll p-datatable-striped p-datatable-sm", this.tableElement.style.overflow = "auto", this.tableElement.style.width = "100%", this.tableElement.style.height = "100%", this.tableElement.innerHTML = ps(), this.tableBody = this.tableElement.querySelector(
      ".p-datatable-tbody"
    );
    const t = this.tableElement.querySelector("table");
    t.style.width = "100%", t.style.tableLayout = "fixed";
    const s = this.tableElement.querySelector(
      "[data-pc-section=headerrow]"
    );
    if (!s)
      throw new Error("Column row not found");
    this.config.columns.forEach((o) => {
      const r = document.createElement("th");
      r.className = "p-column-header", r.setAttribute("role", "columnheader"), r.setAttribute("data-pc-section", "headercell"), r.setAttribute("data-p-resizable-column", "false"), r.setAttribute("data-p-filter-column", "false"), r.setAttribute("data-p-reorderable-column", "false"), r.setAttribute("first", "0");
      const a = document.createElement("div");
      a.className = "p-column-header-content", a.setAttribute("data-pc-section", "headercontent");
      const i = document.createElement("span");
      i.className = "p-column-title", i.setAttribute("data-pc-section", "headertitle"), i.textContent = o.name, a.appendChild(i), r.appendChild(a), o.width && (r.style.width = o.width), s.appendChild(r);
    });
  }
  filterRows(e) {
    let t = 0;
    this.rows.forEach((s) => {
      const o = s.htmlElement, r = s.cells;
      let a = !1;
      r.forEach((i) => {
        var c;
        typeof i.value == "string" ? i.value.toLowerCase().includes(e.toLowerCase()) && (a = !0) : (c = i.value.textContent) != null && c.toLowerCase().includes(e.toLowerCase()) && (a = !0);
      }), a ? (o.style.removeProperty("display"), o.classList.remove("p-row-even", "p-row-odd"), o.classList.add(
        t % 2 === 0 ? "p-row-even" : "p-row-odd"
      ), t++) : (o.style.display = "none", o.removeAttribute("data-is-even"));
    });
  }
  clearRows() {
    this.rows.forEach((e) => {
      e.htmlElement.remove();
    }), this.rows = [];
  }
  addRow(e, t) {
    const s = (this.tableBody.children.length + 1) % 2 !== 0, o = document.createElement("tr");
    o.className = `p-row-${s ? "even" : "odd"}`, o.setAttribute("tabindex", "-1"), o.setAttribute("role", "row"), o.setAttribute("data-pc-section", "bodyrow"), o.setAttribute("data-p-index", "0"), o.setAttribute("data-p-selectable-row", "false"), o.setAttribute("draggable", "false"), e.forEach((r) => {
      var c;
      const a = (c = this.config.columns.find(
        (u) => u.name === r.columnName
      )) == null ? void 0 : c.width, i = document.createElement("td");
      i.setAttribute("role", "cell"), i.style.whiteSpace = "nowrap", i.style.overflow = "hidden", i.setAttribute("data-pc-section", "bodycell"), i.setAttribute("data-pc-name", "bodycell"), i.setAttribute("data-p-selection-column", "false"), i.setAttribute("data-p-cell-editing", "false"), a && (i.style.width = a), typeof r.value == "string" ? i.textContent = r.value : i.appendChild(r.value), o.appendChild(i);
    }), t && o.addEventListener("click", t), this.tableBody.appendChild(o), this.rows.push({
      htmlElement: o,
      cells: e
    });
  }
  getHTMLElement() {
    return this.tableElement;
  }
  static createTable(e) {
    return new ce(e);
  }
}
class hs {
  constructor(e) {
    this.apiInstance = e;
  }
  createTable(e) {
    return ms(this.apiInstance, e);
  }
  createNavigationBar(e) {
    return cs(this.apiInstance, e);
  }
  createCheckbox() {
    return rs(this.apiInstance);
  }
  createTextInput(e, t, s = !1, o) {
    return is(this.apiInstance, e, t, s, o);
  }
  createSelectInput(e) {
    return ds(this.apiInstance, e);
  }
}
let We = [];
const fs = (n, e) => {
  var l;
  const t = document.createElement("div");
  t.classList.add("custom");
  const s = document.createElement("div");
  s.setAttribute("command-root", ""), t.appendChild(s);
  const o = document.createElement("div");
  o.setAttribute("command-dialog", ""), s.appendChild(o);
  const r = document.createElement("div");
  r.setAttribute("command-dialog-mask", ""), r.style.display = "flex", r.style.justifyContent = "center", r.style.alignItems = "center", r.addEventListener("click", () => {
    t.remove();
  }), o.appendChild(r);
  const a = document.createElement("div");
  a.setAttribute("command-dialog-wrapper", ""), a.style.minWidth = "600px", a.style.padding = "1em", a.style.margin = "0", r.appendChild(a);
  const i = document.createElement("div");
  i.setAttribute("command-dialog-body", ""), i.style.display = "flex", i.style.gap = "0.5em", a.addEventListener("click", (d) => {
    d.stopPropagation();
  }), a.appendChild(i);
  const c = n.components.createTextInput(
    "100%",
    e.promptPlaceholder
  );
  c.style.zIndex = "100", c.addEventListener("click", (d) => {
    d.stopPropagation();
  }), i.appendChild(c);
  const u = ss().ui.button({
    label: "Submit",
    variant: "primary"
  });
  u.addEventListener("click", () => {
    const d = c.querySelector("input");
    e.onPrompt(d.value), t.remove();
  }), i.appendChild(u), document.body.appendChild(t), (l = c.querySelector("input")) == null || l.focus(), c.addEventListener("keydown", (d) => {
    d.key === "Enter" && u.click(), d.key === "Escape" && t.remove();
  });
}, bs = (n, e, t, s) => {
  We.push({
    commandName: e,
    promptPlaceholder: t,
    onPrompt: s
  });
};
class gs {
  constructor(e) {
    this.apiInstance = e, this.apiInstance.eventManager.on("onCommandRun", (t) => {
      const s = We.find(
        (o) => o.commandName === t
      );
      s && fs(this.apiInstance, s);
    });
  }
  createPromptCommand(e, t, s) {
    bs(this.apiInstance, e, t, s);
  }
}
const vs = `
  .evenbetter-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 99999;
  }
  
  .evenbetter-modal__content {
    background-color: var(--c-bg-default);
    padding: 1rem;
    border-radius: 5px;
    width: 50%;
    max-width: 500px;
  }
  
  .evenbetter-modal__content-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
  }
  
  .evenbetter-modal__content-header-title {
    font-size: 1.1rem;
    margin: 0;
  }
  
  .evenbetter-modal__content-body {
    margin-bottom: 1rem;
  }
  
  .evenbetter-modal__content-body-text {
    font-size: 0.9rem;
    color: var(--c-fg-subtle);
    word-break: break-word;
    user-select: text !important;
    -webkit-user-select: text !important;
  
    white-space: break-spaces;
    overflow: auto;
    max-height: 40em;
  }
  
  .evenbetter-modal__content-body a {
    color: var(--c-fg-default);
  }
  
  .evenbetter-modal__content-body-close {
    background-color: var(--c-bg-subtle);
    border: 1px solid var(--c-header-cell-border);
    color: #fff;
    padding: 0.5rem;
    width: 100%;
    margin-top: 0.5rem;
    cursor: pointer;
    transition: 0.2s ease background-color;
  }
  
  .evenbetter-modal__content-body-close:hover {
    background-color: var(--c-bg-default);
  }
`, ys = ({
  modalAPI: n,
  title: e,
  content: t
}) => {
  const s = document.createElement("div");
  s.classList.add("evenbetter-modal");
  const o = document.createElement("div");
  o.classList.add("evenbetter-modal__content");
  const r = document.createElement("div");
  r.classList.add("evenbetter-modal__content-header");
  const a = document.createElement("h2");
  a.classList.add("evenbetter-modal__content-header-title"), a.textContent = e, r.appendChild(a);
  const i = document.createElement("div");
  i.classList.add("evenbetter-modal__content-body");
  const c = document.createElement("p");
  c.classList.add("evenbetter-modal__content-body-text"), typeof t == "string" ? c.innerHTML = t : t instanceof HTMLElement && c.appendChild(t);
  const u = document.createElement("button");
  return u.classList.add("evenbetter-modal__content-body-close"), u.textContent = "Close", u.addEventListener("click", n.closeModal), i.appendChild(c), i.appendChild(u), o.appendChild(r), o.appendChild(i), s.appendChild(o), s.setAttribute("data-modal-title", e), s;
}, ws = () => document.querySelector(".evenbetter-modal") !== null;
class Es {
  constructor(e) {
    this.evenBetterAPI = e, this.evenBetterAPI.helpers.loadCSS({
      id: "evenbetterapi-modal",
      cssText: vs.toString()
    }), document.addEventListener("keydown", (t) => {
      t.key === "Escape" && this.closeModal();
    });
  }
  openModal({
    title: e,
    content: t
  }) {
    ws() && this.closeModal();
    const s = ys({ modalAPI: this, title: e, content: t });
    document.body.appendChild(s);
  }
  closeModal() {
    const e = document.querySelector(".evenbetter-modal");
    e == null || e.remove();
  }
}
const Ee = () => typeof __TAURI_INVOKE__ < "u", Ce = async (n, e) => await __TAURI_INVOKE__(n, e), Se = /* @__PURE__ */ new Set();
class Cs {
  constructor() {
    this.downloadFile = async (e, t) => {
      if (Ee())
        return Ce("download", { filename: e, data: t });
      {
        const s = new Blob([t], { type: "text/plain" }), o = URL.createObjectURL(s), r = document.createElement("a");
        r.href = o, r.download = e, r.click();
      }
    }, this.openInBrowser = (e) => {
      Ee() ? Ce("open_in_browser", { url: e }) : window.open(e, "_blank");
    }, this.loadCSS = ({ id: e, cssText: t }) => {
      if (Se.has(e) || document.querySelector(`#${e}`))
        return;
      const s = document.createElement("style");
      s.id = e, s.textContent = t, s.classList.add("evenbetterapi-css-module"), document.head.appendChild(s), Se.add(e);
    };
  }
}
var R = /* @__PURE__ */ ((n) => (n.TEXT = "text", n.NUMBER = "number", n.CHECKBOX = "checkbox", n.SELECT = "select", n))(R || {});
class Ss {
  constructor(e, t) {
    this.evenBetterAPI = e, this.title = t.title, this.description = t.description, this.inputGroups = t.inputGroups, this.initDefaults();
  }
  async initDefaults() {
    for (const [e, t] of this.inputGroups.entries())
      for (const [s, o] of t.inputs.entries())
        o.defaultValue && !O(o.id) && await ye(o.id, o.defaultValue);
  }
  className(e) {
    return `eb-settings-page__${e}`;
  }
  render() {
    const e = document.createElement("div");
    e.classList.add(this.className("container"));
    const t = document.createElement("div");
    t.classList.add(this.className("header"));
    const s = document.createElement("h1");
    s.textContent = this.title, s.classList.add(this.className("title")), t.appendChild(s);
    const o = document.createElement("p");
    o.textContent = this.description, o.classList.add(this.className("description")), t.appendChild(o), e.appendChild(t);
    const r = document.createElement("div");
    return r.classList.add(this.className("groups")), this.inputGroups.forEach((a) => {
      const i = document.createElement("div");
      i.classList.add(this.className("group")), a.width && (a.width.toLowerCase() == "fill-space" ? i.style.flex = "1" : i.style.width = a.width);
      const c = document.createElement("div");
      c.classList.add(this.className("group-header"));
      const u = document.createElement("div");
      u.textContent = a.groupName, u.classList.add(this.className("group-name"));
      const l = document.createElement("p");
      l.textContent = a.groupDescription, l.classList.add(this.className("group-description")), c.appendChild(u), c.appendChild(l), i.appendChild(c);
      const d = document.createElement("div");
      d.classList.add(this.className("group-inputs")), a.inputs.forEach((m) => {
        if (a.separateWithLine) {
          const b = document.createElement("hr");
          b.classList.add(this.className("line")), d.appendChild(b);
        }
        const f = this.createInputElement(m, (b) => {
          ye(m.id, b);
        });
        d.appendChild(f);
      }), i.appendChild(d), r.appendChild(i);
    }), e.appendChild(r), e;
  }
  createInputElement(e, t) {
    const s = document.createElement("div");
    s.classList.add(this.className("input-wrapper")), e.type == R.CHECKBOX && s.classList.add(this.className("checkbox-wrapper"));
    const o = document.createElement("label");
    e.labelAsHTML ? o.innerHTML = e.label : o.textContent = e.label, o.setAttribute("for", e.id), s.appendChild(o);
    let r;
    switch (e.type) {
      case R.TEXT:
        r = this.evenBetterAPI.components.createTextInput(
          "100%",
          e.placeholder
        );
        const a = r.querySelector(
          "input"
        ), i = O(e.id);
        i ? a.value = i : a.value = e.defaultValue, t && a.addEventListener("input", (g) => {
          t(a.value);
        });
        break;
      case R.NUMBER:
        r = this.evenBetterAPI.components.createTextInput(
          "100%",
          e.placeholder
        ), r.querySelector("input").type = "number";
        const c = r.querySelector(
          "input"
        ), u = O(e.id);
        u ? c.value = u : c.value = e.defaultValue, t && c.addEventListener("input", (g) => {
          t(c.value);
        });
        break;
      case R.CHECKBOX:
        r = this.evenBetterAPI.components.createCheckbox();
        const l = r.querySelector(
          "input"
        ), d = O(e.id);
        d ? l.checked = d == "true" : l.checked = e.defaultValue == "true", t && l.addEventListener("change", (g) => {
          t(l.checked.toString());
        });
        break;
      case R.SELECT:
        const m = e.options;
        r = this.evenBetterAPI.components.createSelectInput(m);
        const f = r, b = O(e.id);
        b ? f.value = b : f.value = e.defaultValue, t && f.addEventListener("change", (g) => {
          t(f.value);
        });
        break;
      default:
        throw new Error(`Invalid input type: ${e.type}`);
    }
    return s.appendChild(r), s;
  }
}
class _s {
  constructor(e) {
    this.apiInstance = e;
  }
  createSettingsPage(e) {
    return new Ss(this.apiInstance, e);
  }
}
class ks {
  constructor() {
    this.handlers = [];
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    const e = document.querySelector(".c-current-project");
    if (e) {
      const t = (r, a) => {
        for (const i of r)
          if (i.type === "attributes" && i.attributeName === "data-project-id") {
            const c = e.getAttribute("data-project-id");
            c && this.trigger(c);
          }
      }, s = new MutationObserver(t), o = { attributes: !0, attributeFilter: ["data-project-id"] };
      s.observe(e, o);
    }
  }
  trigger(e) {
    this.handlers.forEach((t) => t(e));
  }
}
class xs {
  constructor(e, t) {
    ns(e), zn(t), this.eventManager = new $n();
    const s = new Un(), o = new Gn(), r = new Vn(this.eventManager), a = new Wn(), i = new es(), c = new ks();
    this.eventManager.registerEvent("onCaidoLoad", s), this.eventManager.registerEvent("onSettingsTabOpen", o), this.eventManager.registerEvent("onPageOpen", r), this.eventManager.registerEvent("onContextMenuOpen", a), this.eventManager.registerEvent("onCommandRun", i), this.eventManager.registerEvent("onProjectChange", c), this.eventManager.on("onCaidoLoad", () => {
      this.eventManager.triggerEvent("onPageOpen", {
        newUrl: location.hash,
        oldUrl: ""
      });
      const u = Kn();
      if (u) {
        try {
          this.toast.showToast(JSON.parse(u));
        } catch (l) {
          console.error(l), we();
        }
        we();
      }
    }), this.eventManager.initEvents(), this.helpers = new Cs(), this.promptCommands = new gs(this), this.modal = new Es(this), this.toast = new Xn(this), this.components = new hs(this), this.templates = new _s(this), this.version = ts;
  }
}
const Is = () => {
  const n = p();
  n.commands.register("eb:excludehost", {
    name: "Exclude Host",
    run: async () => {
      const e = await ke();
      e && _e(`req.host.ne:"${e.host}"`);
    }
  }), n.menu.registerItem({
    type: "RequestRow",
    commandId: "eb:excludehost",
    leadingIcon: "fa fa-ban"
  }), n.commands.register("eb:excludepath", {
    name: "Exclude Path",
    run: async () => {
      const e = await ke();
      e && _e(`req.path.ne:"${e.path}"`);
    }
  }), n.menu.registerItem({
    type: "RequestRow",
    commandId: "eb:excludepath",
    leadingIcon: "fa fa-ban"
  });
}, _e = async (n) => {
  const e = document.querySelector(
    ".c-search-query-editor__editor .cm-line"
  );
  if (!e)
    return;
  e.querySelector(".cm-placeholder") ? e.textContent = n : e.textContent += ` AND ${n}`;
  const t = document.activeElement;
  e.focus();
  const s = new KeyboardEvent("keydown", {
    bubbles: !0,
    cancelable: !0,
    key: "Enter",
    code: "Enter",
    keyCode: 13,
    charCode: 13
  });
  e.dispatchEvent(s), t == null || t.focus();
}, Ls = () => {
  var n;
  return (n = document.querySelector(".c-read-only-request")) == null ? void 0 : n.getAttribute("data-request-id");
}, ke = async () => {
  const n = Ls();
  if (!n)
    return;
  const e = await p().graphql.request({
    id: n
  });
  return e == null ? void 0 : e.request;
}, qs = (n) => {
  ze(n), X.info(`EvenBetter ${N} is loading, thanks for using it! 🎉`);
  const e = new xs(n, {
    manifestID: "evenbetter-extensions",
    name: "EvenBetter: Extensions"
  });
  Je(e), et();
  const t = new en(), s = new mn();
  e.eventManager.registerEvent("onSSRFHit", t), e.eventManager.registerEvent(
    "onSSRFInstanceChange",
    s
  ), p().commands.register("evenbetter:suggesthttpql", {
    name: "Suggest HTTPQL query",
    group: "EvenBetter: AI",
    run: () => {
    }
  }), p().commandPalette.register("evenbetter:suggesthttpql"), dn(), e.eventManager.on("onPageOpen", () => {
    localStorage.setItem("previousPath", window.location.hash);
    const o = document.querySelector(
      ".c-sidebar-item[data-is-active='true']"
    );
    if (o) {
      let r = o.querySelector(".c-sidebar-item__count");
      r && (r.innerHTML = "");
    }
  }), e.eventManager.on("onSettingsTabOpen", (o) => {
    switch (o) {
      case "developer":
        const r = document.querySelector(".c-custom-js__footer");
        if (!r)
          return;
        r.removeEventListener("click", xe), r.addEventListener("click", xe);
    }
  }), e.eventManager.on("onCaidoLoad", () => {
    Le(E("theme")), Ae(E("font")), nn(), Kt(), wt(), _t(), Nn(), tn(), Wt(), Vt(), gn(), Sn(), An(), Tn(), Ot(), Is(), Ht(), setTimeout(
      () => {
        var r;
        const o = window.location.hash;
        (r = document.querySelector(".c-content")) == null || r.setAttribute("data-page", o), e.eventManager.triggerEvent("onPageOpen", {
          newUrl: o,
          oldUrl: ""
        });
      },
      window.location.hash.startsWith("#/settings/") ? 10 : 100
    );
  });
}, xe = () => {
  setTimeout(() => {
    location.reload();
  }, 250);
};
export {
  qs as init
};
