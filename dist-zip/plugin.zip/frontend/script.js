var xt = Object.defineProperty;
var St = (t, e, n) => e in t ? xt(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var gt = (t, e, n) => (St(t, typeof e != "symbol" ? e + "" : e, n), n);
let CaidoAPI$1 = null;
const setCaidoAPI$1 = (t) => {
  CaidoAPI$1 = t;
}, getCaidoAPI$1 = () => {
  if (!CaidoAPI$1)
    throw new Error("CaidoAPI is not set yet!");
  return CaidoAPI$1;
}, CURRENT_VERSION = "v2.4", EVENBETTER_VERSION_CHECK_URL = "https://raw.githubusercontent.com/bebiksior/EvenBetter/main/version.txt", defaultSettings = {
  ssrfInstancePlaceholder: "$ssrfinstance",
  ssrfInstanceFunctionality: "true",
  sidebarHideGroups: "true",
  sidebarRearrangeGroups: "true",
  showOutdatedVersionWarning: "true",
  highlightRowsFunctionality: "true",
  quickDecode: "true",
  ssrfInstanceTool: "ssrf.cvssadvisor.com"
}, getSetting$1 = (t) => {
  if (localStorage.getItem(`evenbetter_${t}`) === null) {
    const e = defaultSettings[t];
    e !== void 0 && localStorage.setItem(`evenbetter_${t}`, e);
  }
  return localStorage.getItem(`evenbetter_${t}`) || "";
}, setSetting$1 = (t, e) => {
  localStorage.setItem(`evenbetter_${t}`, e);
}, checkForUpdates = async () => {
  try {
    const e = await (await fetch(EVENBETTER_VERSION_CHECK_URL, {
      cache: "no-store"
    })).text(), n = parseFloat(e.replace("v", ""));
    return parseFloat(
      CURRENT_VERSION.replace("v", "")
    ) > n ? {
      isLatest: !0,
      message: `You are using a development version: ${CURRENT_VERSION}.`
    } : e.trim() === CURRENT_VERSION ? {
      isLatest: !0,
      message: "You are using the latest version! 🎉"
    } : {
      isLatest: !1,
      message: `New EvenBetter version available: ${e}.`
    };
  } catch {
    return {
      isLatest: !0,
      message: "Failed to check for updates"
    };
  }
}, themes = {
  gray: {
    name: "Gray",
    "--c-header-cell-border": "#101010",
    "--c-bg-default": "#202020",
    "--c-bg-subtle": "#252525",
    "--c-table-item-row": "#252525",
    "--c-table-item-row-hover": "#303030",
    "--header-cell-width": "1px",
    "--c-table-even-item-row": "#282828",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#222222"
  },
  evendarker: {
    name: "Even Darker",
    "--c-header-cell-border": "#101010",
    "--c-bg-default": "#050607",
    "--c-bg-subtle": "#090a0c",
    "--c-table-item-row": "#08090a",
    "--c-table-item-row-hover": "#0f1012",
    "--header-cell-width": "1px",
    "--c-table-even-item-row": "#08090a",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#0b0b0b"
  },
  caido: {
    name: "Caido Default",
    "--c-header-cell-border": "#101010",
    "--c-bg-default": "#25272d",
    "--c-bg-subtle": "var(--c-gray-800)",
    "--c-table-item-row": "#08090a",
    "--c-table-item-row-hover": "#25272d",
    "--header-cell-width": "0px",
    "--c-table-even-item-row": "#353942",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "rgb(43, 46, 53)"
  },
  oceanblue: {
    name: "Ocean Blue",
    "--c-header-cell-border": "#116699",
    "--c-bg-default": "#1a2b3c",
    "--c-bg-subtle": "#2a3b4c",
    "--c-table-item-row": "#1c2d3e",
    "--c-table-item-row-hover": "#2a3b4c",
    "--header-cell-width": "0px",
    "--c-table-even-item-row": "#2c3d4e",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#213345"
  },
  solarized: {
    name: "Solarized",
    "--c-header-cell-border": "#93a1a1",
    "--c-bg-default": "#002b36",
    "--c-bg-subtle": "#073642",
    "--c-table-item-row": "#073642",
    "--c-table-item-row-hover": "#586e75",
    "--header-cell-width": "1px",
    "--c-table-even-item-row": "#073642",
    "--c-fg-default": "#e3e3e3",
    "--c-fg-subtle": "#657b83",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "#073642",
    "--c-table-background": "#03303c"
  },
  black: {
    name: "Black",
    "--c-header-cell-border": "#070707",
    "--c-bg-default": "#000000",
    "--c-bg-subtle": "#000000",
    "--c-table-item-row": "#050505",
    "--c-table-item-row-hover": "#222222",
    "--header-cell-width": "0px",
    "--c-table-even-item-row": "#111111",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#000000"
  },
  /*light: {
      name: "Light",
      customCSS: `
        .toggle-features,
        .settings-box {
          border: 1px solid var(--c-gray-400);
        }
  
        .c-table-item__key {
          background-color: #d3d3d3 !important;
        }
      `,
      "--c-bg-inset": "#ffffff",
      "--c-header-cell-border": "#e1e4e8",
      "--c-bg-default": "#f6f8fa",
      "--c-bg-subtle": "#f6f8fa",
      "--c-table-item-row": "#f1f1f1",
      "--c-table-item-row-hover": "#e7e7e7",
      "--header-cell-width": "1px",
      "--c-table-even-item-row": "#ffffff",
      "--c-fg-default": "var(--c-black-100)",
      "--c-fg-subtle": "var(--c-gray-400)",
      "--selection-background": "rgba(0, 0, 0, 0.15)",
      "--selected-row-background": "var(--c-bg-default)",
    },*/
  neon: {
    name: "Neon",
    "--c-header-cell-border": "#ff6ac1",
    "--c-bg-default": "#2b213a",
    "--c-bg-subtle": "#30263e",
    "--c-table-item-row": "#2b213a",
    "--c-table-item-row-hover": "#3c2e52",
    "--header-cell-width": "1px",
    "--c-table-even-item-row": "#372e45",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#2b213a"
  },
  deepdark: {
    name: "Deep Dark",
    "--c-header-cell-border": "#101010",
    "--c-bg-default": "#0b0b0b",
    "--c-bg-subtle": "#050505",
    "--c-table-item-row": "#0f0f0f",
    "--c-table-item-row-hover": "#1a1a1a",
    "--header-cell-width": "1px",
    "--c-table-even-item-row": "#0e0e0e",
    "--c-fg-default": "var(--c-white-100)",
    "--c-fg-subtle": "var(--c-gray-400)",
    "--selection-background": "rgba(255, 255, 255, 0.15)",
    "--selected-row-background": "var(--c-bg-default)",
    "--c-table-background": "#0b0b0b"
  }
}, loadTheme = (t) => {
  var n;
  const e = themes[t];
  if (e && ((n = document.getElementById("evenbetter-custom-theme")) == null || n.remove(), Object.keys(e).forEach((a) => {
    a.startsWith("--") && document.documentElement.style.setProperty(a, e[a], "important");
  }), e.customCSS)) {
    const a = document.createElement("style");
    a.id = "evenbetter-custom-theme", a.innerHTML = e.customCSS, document.head.appendChild(a);
  }
}, fonts = {
  defaultCaido: {
    name: "Caido Default"
  },
  jetbrainsMono: {
    name: "Jetbrains Mono",
    url: "https://fonts.cdnfonts.com/css/jetbrains-mono"
  },
  comicSans: {
    name: "Comic Sans MS",
    url: "https://fonts.googleapis.com/css2?family=Comic+Sans+MS"
  },
  firaCode: {
    name: "Fira Code",
    url: "https://fonts.googleapis.com/css2?family=Fira+Code:wght@300..600&display=swap"
  }
}, loadFont = (t) => {
  var a;
  const e = fonts[t];
  if (!e || (document.getElementById("evenbetter-custom-font") && ((a = document.getElementById("evenbetter-custom-font")) == null || a.remove()), !e.url))
    return;
  const n = document.createElement("style");
  n.id = "evenbetter-custom-font", n.innerHTML = `@import url('${e.url}'); body { font-family: '${e.name}', sans-serif; }`, document.head.appendChild(n);
};
let evenBetterAPI = null;
const setEvenBetterAPI = (t) => {
  evenBetterAPI = t;
}, getEvenBetterAPI = () => {
  if (!evenBetterAPI)
    throw new Error("EvenBetterAPI is not set yet!");
  return evenBetterAPI;
}, evenBetterSettingsTab = () => {
  const t = getSetting$1("theme"), e = document.createElement("div");
  e.innerHTML = createEvenBetterTabHTML(themes, t), e.classList.add("evenbetter-custom-tab"), e.querySelector(
    "#theme-select"
  ).addEventListener("change", (l) => {
    const E = l.target.value;
    setSetting$1("theme", E), loadTheme(E);
  }), e.querySelector(
    "#font-select"
  ).addEventListener("change", (l) => {
    const E = l.target.value;
    setSetting$1("font", E), loadFont(E);
  });
  const c = [];
  let o = !1;
  e.querySelectorAll("input[type=checkbox]").forEach((l) => {
    l.addEventListener("change", (b) => {
      const E = b.target, C = E.name, q = E.checked, F = c.findIndex(
        (H) => H.name === C
      );
      F !== -1 ? c.splice(F, 1) : c.push({ name: C, value: q }), o = c.length > 0;
      const z = e.querySelector(
        ".toggle-features__content button"
      );
      z && (o ? z.removeAttribute("disabled") : z.setAttribute("disabled", "true"));
    });
  });
  const h = e.querySelector(
    ".toggle-features__content button"
  );
  if (!h)
    return;
  h.addEventListener("click", () => {
    c.forEach((l) => {
      setSetting$1(l.name, l.value);
    }), localStorage.setItem("previousPath", "#/settings/evenbetter"), location.reload();
  });
  const p = e.querySelector(
    ".ssrfInstanceFunctionality"
  );
  if (p) {
    const l = [], b = p.querySelector("input");
    if (!b)
      return;
    b.value = getSetting$1(
      "ssrfInstancePlaceholder"
    ), b.addEventListener("input", (C) => {
      const F = C.target.value;
      l.push({
        name: "ssrfInstancePlaceholder",
        value: F
      });
      const z = p.querySelector("button");
      z && z.removeAttribute("disabled");
    });
    const E = p.querySelector("button");
    if (!E)
      return;
    E.addEventListener("click", () => {
      l.forEach((C) => {
        setSetting$1(C.name, C.value), localStorage.setItem("previousPath", window.location.hash), location.reload();
      });
    });
  }
  const x = e.querySelector(".useopenai");
  if (x) {
    const l = x.querySelector("button");
    if (!l)
      return;
    const b = x.querySelector("input");
    b.value = getSetting$1("openaiApiKey") || "";
    let E = b.value;
    b.addEventListener("input", (C) => {
      const F = C.target.value;
      l && (F === E ? l.setAttribute("disabled", "true") : l.removeAttribute("disabled"));
    }), l.addEventListener("click", (C) => {
      const q = b.value;
      setSetting$1("openaiApiKey", q), E = q, l.setAttribute("disabled", "true"), getEvenBetterAPI().toast.showToast({
        message: "OpenAI API key saved!",
        duration: 2e3,
        position: "bottom",
        type: "success"
      });
    });
  }
  return checkForUpdates().then(({ isLatest: l, message: b }) => {
    if (!l) {
      const E = e.querySelector(
        ".header-outdated"
      );
      E.style.display = "block";
    }
  }), e;
}, createEvenBetterTabHTML = (t, e) => {
  const n = [
    {
      name: "sidebarTweaks",
      title: "Sidebar tweaks",
      items: [
        {
          name: "sidebarRearrangeGroups",
          title: "Groups Rearrange",
          description: "Show move buttons next to sidebar groups."
        },
        {
          name: "sidebarHideGroups",
          title: "Groups Collapse",
          description: "This allows you to collapse groups in the sidebar."
        }
      ]
    },
    {
      name: "ssrfInstanceFunctionality",
      title: "Quick SSRF Instance",
      items: [
        {
          name: "ssrfInstanceFunctionality",
          title: "Quick SSRF Instance",
          description: "Adds a Quick SSRF sidebar page and allows you to quickly create new SSRF instance by typing the placeholder."
        }
      ]
    },
    {
      name: "quickDecode",
      title: "Quick Decode",
      items: [
        {
          name: "quickDecode",
          title: "Quick Decode",
          description: "Selecting text on the Replay page will attempt to decode it and show the result at the left bottom corner."
        }
      ]
    },
    {
      name: "versionCheckWarning",
      title: "Version Check Warning",
      items: [
        {
          name: "showOutdatedVersionWarning",
          title: "Version Check Warning",
          description: "Choose if you want to see warning on startup if you are using outdated EvenBetter version."
        }
      ]
    }
  ], a = (c) => {
    const o = getEvenBetterAPI().components.createCheckbox(), u = o.querySelector(
      ".eb-checkbox__input"
    );
    return u.name = c, u.id = c, getSetting$1(c) === "true" && u.setAttribute("checked", "true"), o;
  };
  return `
  <div class="even-better__settings" id="evenbetter-settings-content">
    <header>
      <div class="header-title">
        <h1>EvenBetter ${CURRENT_VERSION} - Settings</h1>
        <div class="header-outdated" style="display:none;">You are using outdated version!</div>
      </div>
      <div class="header-description">
        Customize EvenBetter plugin here and make your Caido even better :D
      </div>
    </header>

    <main>
      <div class="left">
        <div class="settings-box">
          <!-- Settings header -->
          <div class="settings-box__header">
            <div class="settings-box__header-title">Appearance</div>
            <div class="settings-box__header-description">
              Change the appearance of your Caido
            </div>
          </div>

          <!-- Settings content -->
          <div class="settings-box__content">
            <div class="settings-box__content-item">
              <div class="settings-box__content-item-title">Theme</div>
              <select id="theme-select">
                ${Object.keys(t).map(
    (c) => {
      var o;
      return `<option value="${c}" ${c === e ? "selected" : ""}>${(o = t[c]) == null ? void 0 : o.name}</option>`;
    }
  ).join("")}
              </select>
            </div>
            <div class="settings-box__content-item">
              <div class="settings-box__content-item-title">Font</div>
              <select id="font-select">
                ${Object.keys(fonts).map(
    (c) => {
      var o;
      return `<option value="${c}" ${c === getSetting$1("font") ? "selected" : ""}>${(o = fonts[c]) == null ? void 0 : o.name}</option>`;
    }
  ).join("")}
              </select>
            </div>
          </div>
        </div>
        ${getSetting$1("ssrfInstanceFunctionality") == "true" ? `
        <div class="settings-box ssrfInstanceFunctionality">
          <!-- Settings header -->
          <div class="settings-box__header">
            <div class="settings-box__header-title">Quick SSRF placeholder</div>
            <div class="settings-box__header-description">
              Set the placeholder that will be used to create new SSRF instance
            </div>
          </div>

          <!-- Settings content -->
          <div class="settings-box__content">
            <div class="c-text-input">
              <div class="c-text-input__outer">
                <div class="c-text-input__inner">
                  <input
                    placeholder="$ssrfinstance"
                    spellcheck="false"
                    class="c-text-input__input"
                  />
                </div>
              </div>
            </div>

            <button disabled>Save</button>
          </div>
        </div>` : ""}
        <div class="settings-box useopenai">
          <!-- Settings header -->
          <div class="settings-box__header">
            <div class="settings-box__header-title">Use OpenAI API</div>
            <div class="settings-box__header-description">
              Use the OpenAI API instead of Caido default assistant API.
            </div>
          </div>

          <!-- Settings content -->
          <div class="settings-box__content">
            <div class="c-text-input">
              <div class="c-text-input__outer">
                <div class="c-text-input__inner">
                  <input
                    placeholder="sk-xxxxxxx"
                    spellcheck="false"
                    class="c-text-input__input"
                    type="password"
                  />
                </div>
              </div>
            </div>

            <button disabled>Save</button>
          </div>
        </div>
      </div>

      <div class="right">
        <div class="toggle-features">
          <div class="toggle-features__header">
            <div class="toggle-features__header-title">Toggle features</div>
            <div class="toggle-features__header-description">
              Enable or disable features of the EvenBetter plugin. Note that there are some smaller features that can't be turned off.
            </div>
          </div>
          <hr />
          <div class="toggle-features__content">
            ${n.map(
    (c) => `
              <div class="toggle-features__content-item">
                <div class="toggle-features__content-item-title">
                  ${c.title}
                </div>

                ${c.items.map(
      (o) => `
                  <div class="toggle-features__content-item-toggle">
                    <div class="toggle-features__content-item-description">
                      <b>${o.title}:</b> ${o.description}
                    </div>
                    <div>
                      ${a(o.name).innerHTML}
                    </div>
                  </div>`
    ).join("")}

              </div>

              <hr />`
  ).join("")}

            <button disabled>Save</button>
          </div>
        </div>
      </div>
    </main>
  </div>`;
}, setup = () => {
  const t = evenBetterSettingsTab();
  t && (getCaidoAPI$1().navigation.addPage("/settings/evenbetter", {
    body: t
  }), getCaidoAPI$1().menu.registerItem({
    type: "Settings",
    label: "EvenBetter",
    path: "/settings/evenbetter",
    leadingIcon: "fas fa-cogs"
  }), getCaidoAPI$1().commands.register("evenbetter:settings", {
    name: "Go to EvenBetter: Settings",
    group: "EvenBetter: Navigation",
    run: () => {
      getCaidoAPI$1().navigation.goTo("/settings/evenbetter");
    }
  }), getCaidoAPI$1().commandPalette.register("evenbetter:settings"), getCaidoAPI$1().commands.register("evenbetter:library", {
    name: "Go to EvenBetter: Library",
    group: "EvenBetter: Navigation",
    run: () => {
      getCaidoAPI$1().navigation.goTo("/workflows/library");
    }
  }), getCaidoAPI$1().commandPalette.register("evenbetter:library"));
}, entityMap = new Map(
  Object.entries({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
    "/": "&#x2F;"
  })
);
function escapeHTML(t) {
  return String(t).replace(/[&<>"'\/]/g, (e) => entityMap.get(e));
}
const CA_SSRF_INSTANCE_API_URL = "https://api.cvssadvisor.com/ssrf/api/instance", customizeHTTPResponse = async (t, e, n, a) => fetch(`https://api.cvssadvisor.com/ssrf/api/instance/${t}`, {
  method: "POST",
  body: JSON.stringify({
    statusCode: e,
    body: n,
    headers: a
  })
}).then((c) => c.ok), getCASSRFInstance = async (t) => fetch(
  `https://api.cvssadvisor.com/ssrf/api/instance/${t}`
).then((e) => e.json());
var buffer$1 = {}, base64Js = {};
base64Js.byteLength = byteLength;
base64Js.toByteArray = toByteArray;
base64Js.fromByteArray = fromByteArray;
var lookup = [], revLookup = [], Arr = typeof Uint8Array < "u" ? Uint8Array : Array, code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (var i = 0, len = code.length; i < len; ++i)
  lookup[i] = code[i], revLookup[code.charCodeAt(i)] = i;
revLookup[45] = 62;
revLookup[95] = 63;
function getLens(t) {
  var e = t.length;
  if (e % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var n = t.indexOf("=");
  n === -1 && (n = e);
  var a = n === e ? 0 : 4 - n % 4;
  return [n, a];
}
function byteLength(t) {
  var e = getLens(t), n = e[0], a = e[1];
  return (n + a) * 3 / 4 - a;
}
function _byteLength(t, e, n) {
  return (e + n) * 3 / 4 - n;
}
function toByteArray(t) {
  var e, n = getLens(t), a = n[0], c = n[1], o = new Arr(_byteLength(t, a, c)), u = 0, h = c > 0 ? a - 4 : a, p;
  for (p = 0; p < h; p += 4)
    e = revLookup[t.charCodeAt(p)] << 18 | revLookup[t.charCodeAt(p + 1)] << 12 | revLookup[t.charCodeAt(p + 2)] << 6 | revLookup[t.charCodeAt(p + 3)], o[u++] = e >> 16 & 255, o[u++] = e >> 8 & 255, o[u++] = e & 255;
  return c === 2 && (e = revLookup[t.charCodeAt(p)] << 2 | revLookup[t.charCodeAt(p + 1)] >> 4, o[u++] = e & 255), c === 1 && (e = revLookup[t.charCodeAt(p)] << 10 | revLookup[t.charCodeAt(p + 1)] << 4 | revLookup[t.charCodeAt(p + 2)] >> 2, o[u++] = e >> 8 & 255, o[u++] = e & 255), o;
}
function tripletToBase64(t) {
  return lookup[t >> 18 & 63] + lookup[t >> 12 & 63] + lookup[t >> 6 & 63] + lookup[t & 63];
}
function encodeChunk(t, e, n) {
  for (var a, c = [], o = e; o < n; o += 3)
    a = (t[o] << 16 & 16711680) + (t[o + 1] << 8 & 65280) + (t[o + 2] & 255), c.push(tripletToBase64(a));
  return c.join("");
}
function fromByteArray(t) {
  for (var e, n = t.length, a = n % 3, c = [], o = 16383, u = 0, h = n - a; u < h; u += o)
    c.push(encodeChunk(t, u, u + o > h ? h : u + o));
  return a === 1 ? (e = t[n - 1], c.push(
    lookup[e >> 2] + lookup[e << 4 & 63] + "=="
  )) : a === 2 && (e = (t[n - 2] << 8) + t[n - 1], c.push(
    lookup[e >> 10] + lookup[e >> 4 & 63] + lookup[e << 2 & 63] + "="
  )), c.join("");
}
var ieee754 = {};
/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
ieee754.read = function(t, e, n, a, c) {
  var o, u, h = c * 8 - a - 1, p = (1 << h) - 1, x = p >> 1, l = -7, b = n ? c - 1 : 0, E = n ? -1 : 1, C = t[e + b];
  for (b += E, o = C & (1 << -l) - 1, C >>= -l, l += h; l > 0; o = o * 256 + t[e + b], b += E, l -= 8)
    ;
  for (u = o & (1 << -l) - 1, o >>= -l, l += a; l > 0; u = u * 256 + t[e + b], b += E, l -= 8)
    ;
  if (o === 0)
    o = 1 - x;
  else {
    if (o === p)
      return u ? NaN : (C ? -1 : 1) * (1 / 0);
    u = u + Math.pow(2, a), o = o - x;
  }
  return (C ? -1 : 1) * u * Math.pow(2, o - a);
};
ieee754.write = function(t, e, n, a, c, o) {
  var u, h, p, x = o * 8 - c - 1, l = (1 << x) - 1, b = l >> 1, E = c === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0, C = a ? 0 : o - 1, q = a ? 1 : -1, F = e < 0 || e === 0 && 1 / e < 0 ? 1 : 0;
  for (e = Math.abs(e), isNaN(e) || e === 1 / 0 ? (h = isNaN(e) ? 1 : 0, u = l) : (u = Math.floor(Math.log(e) / Math.LN2), e * (p = Math.pow(2, -u)) < 1 && (u--, p *= 2), u + b >= 1 ? e += E / p : e += E * Math.pow(2, 1 - b), e * p >= 2 && (u++, p /= 2), u + b >= l ? (h = 0, u = l) : u + b >= 1 ? (h = (e * p - 1) * Math.pow(2, c), u = u + b) : (h = e * Math.pow(2, b - 1) * Math.pow(2, c), u = 0)); c >= 8; t[n + C] = h & 255, C += q, h /= 256, c -= 8)
    ;
  for (u = u << c | h, x += c; x > 0; t[n + C] = u & 255, C += q, u /= 256, x -= 8)
    ;
  t[n + C - q] |= F * 128;
};
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
(function(t) {
  const e = base64Js, n = ieee754, a = typeof Symbol == "function" && typeof Symbol.for == "function" ? Symbol.for("nodejs.util.inspect.custom") : null;
  t.Buffer = l, t.SlowBuffer = se, t.INSPECT_MAX_BYTES = 50;
  const c = 2147483647;
  t.kMaxLength = c;
  const { Uint8Array: o, ArrayBuffer: u, SharedArrayBuffer: h } = globalThis;
  l.TYPED_ARRAY_SUPPORT = p(), !l.TYPED_ARRAY_SUPPORT && typeof console < "u" && typeof console.error == "function" && console.error(
    "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
  );
  function p() {
    try {
      const L = new o(1), S = { foo: function() {
        return 42;
      } };
      return Object.setPrototypeOf(S, o.prototype), Object.setPrototypeOf(L, S), L.foo() === 42;
    } catch {
      return !1;
    }
  }
  Object.defineProperty(l.prototype, "parent", {
    enumerable: !0,
    get: function() {
      if (l.isBuffer(this))
        return this.buffer;
    }
  }), Object.defineProperty(l.prototype, "offset", {
    enumerable: !0,
    get: function() {
      if (l.isBuffer(this))
        return this.byteOffset;
    }
  });
  function x(L) {
    if (L > c)
      throw new RangeError('The value "' + L + '" is invalid for option "size"');
    const S = new o(L);
    return Object.setPrototypeOf(S, l.prototype), S;
  }
  function l(L, S, I) {
    if (typeof L == "number") {
      if (typeof S == "string")
        throw new TypeError(
          'The "string" argument must be of type string. Received type number'
        );
      return q(L);
    }
    return b(L, S, I);
  }
  l.poolSize = 8192;
  function b(L, S, I) {
    if (typeof L == "string")
      return F(L, S);
    if (u.isView(L))
      return H(L);
    if (L == null)
      throw new TypeError(
        "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof L
      );
    if (Be(L, u) || L && Be(L.buffer, u) || typeof h < "u" && (Be(L, h) || L && Be(L.buffer, h)))
      return U(L, S, I);
    if (typeof L == "number")
      throw new TypeError(
        'The "value" argument must not be of type number. Received type number'
      );
    const j = L.valueOf && L.valueOf();
    if (j != null && j !== L)
      return l.from(j, S, I);
    const Q = Y(L);
    if (Q)
      return Q;
    if (typeof Symbol < "u" && Symbol.toPrimitive != null && typeof L[Symbol.toPrimitive] == "function")
      return l.from(L[Symbol.toPrimitive]("string"), S, I);
    throw new TypeError(
      "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof L
    );
  }
  l.from = function(L, S, I) {
    return b(L, S, I);
  }, Object.setPrototypeOf(l.prototype, o.prototype), Object.setPrototypeOf(l, o);
  function E(L) {
    if (typeof L != "number")
      throw new TypeError('"size" argument must be of type number');
    if (L < 0)
      throw new RangeError('The value "' + L + '" is invalid for option "size"');
  }
  function C(L, S, I) {
    return E(L), L <= 0 ? x(L) : S !== void 0 ? typeof I == "string" ? x(L).fill(S, I) : x(L).fill(S) : x(L);
  }
  l.alloc = function(L, S, I) {
    return C(L, S, I);
  };
  function q(L) {
    return E(L), x(L < 0 ? 0 : ee(L) | 0);
  }
  l.allocUnsafe = function(L) {
    return q(L);
  }, l.allocUnsafeSlow = function(L) {
    return q(L);
  };
  function F(L, S) {
    if ((typeof S != "string" || S === "") && (S = "utf8"), !l.isEncoding(S))
      throw new TypeError("Unknown encoding: " + S);
    const I = fe(L, S) | 0;
    let j = x(I);
    const Q = j.write(L, S);
    return Q !== I && (j = j.slice(0, Q)), j;
  }
  function z(L) {
    const S = L.length < 0 ? 0 : ee(L.length) | 0, I = x(S);
    for (let j = 0; j < S; j += 1)
      I[j] = L[j] & 255;
    return I;
  }
  function H(L) {
    if (Be(L, o)) {
      const S = new o(L);
      return U(S.buffer, S.byteOffset, S.byteLength);
    }
    return z(L);
  }
  function U(L, S, I) {
    if (S < 0 || L.byteLength < S)
      throw new RangeError('"offset" is outside of buffer bounds');
    if (L.byteLength < S + (I || 0))
      throw new RangeError('"length" is outside of buffer bounds');
    let j;
    return S === void 0 && I === void 0 ? j = new o(L) : I === void 0 ? j = new o(L, S) : j = new o(L, S, I), Object.setPrototypeOf(j, l.prototype), j;
  }
  function Y(L) {
    if (l.isBuffer(L)) {
      const S = ee(L.length) | 0, I = x(S);
      return I.length === 0 || L.copy(I, 0, 0, S), I;
    }
    if (L.length !== void 0)
      return typeof L.length != "number" || Le(L.length) ? x(0) : z(L);
    if (L.type === "Buffer" && Array.isArray(L.data))
      return z(L.data);
  }
  function ee(L) {
    if (L >= c)
      throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + c.toString(16) + " bytes");
    return L | 0;
  }
  function se(L) {
    return +L != L && (L = 0), l.alloc(+L);
  }
  l.isBuffer = function(S) {
    return S != null && S._isBuffer === !0 && S !== l.prototype;
  }, l.compare = function(S, I) {
    if (Be(S, o) && (S = l.from(S, S.offset, S.byteLength)), Be(I, o) && (I = l.from(I, I.offset, I.byteLength)), !l.isBuffer(S) || !l.isBuffer(I))
      throw new TypeError(
        'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
      );
    if (S === I)
      return 0;
    let j = S.length, Q = I.length;
    for (let re = 0, ae = Math.min(j, Q); re < ae; ++re)
      if (S[re] !== I[re]) {
        j = S[re], Q = I[re];
        break;
      }
    return j < Q ? -1 : Q < j ? 1 : 0;
  }, l.isEncoding = function(S) {
    switch (String(S).toLowerCase()) {
      case "hex":
      case "utf8":
      case "utf-8":
      case "ascii":
      case "latin1":
      case "binary":
      case "base64":
      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return !0;
      default:
        return !1;
    }
  }, l.concat = function(S, I) {
    if (!Array.isArray(S))
      throw new TypeError('"list" argument must be an Array of Buffers');
    if (S.length === 0)
      return l.alloc(0);
    let j;
    if (I === void 0)
      for (I = 0, j = 0; j < S.length; ++j)
        I += S[j].length;
    const Q = l.allocUnsafe(I);
    let re = 0;
    for (j = 0; j < S.length; ++j) {
      let ae = S[j];
      if (Be(ae, o))
        re + ae.length > Q.length ? (l.isBuffer(ae) || (ae = l.from(ae)), ae.copy(Q, re)) : o.prototype.set.call(
          Q,
          ae,
          re
        );
      else if (l.isBuffer(ae))
        ae.copy(Q, re);
      else
        throw new TypeError('"list" argument must be an Array of Buffers');
      re += ae.length;
    }
    return Q;
  };
  function fe(L, S) {
    if (l.isBuffer(L))
      return L.length;
    if (u.isView(L) || Be(L, u))
      return L.byteLength;
    if (typeof L != "string")
      throw new TypeError(
        'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof L
      );
    const I = L.length, j = arguments.length > 2 && arguments[2] === !0;
    if (!j && I === 0)
      return 0;
    let Q = !1;
    for (; ; )
      switch (S) {
        case "ascii":
        case "latin1":
        case "binary":
          return I;
        case "utf8":
        case "utf-8":
          return qe(L).length;
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return I * 2;
        case "hex":
          return I >>> 1;
        case "base64":
          return De(L).length;
        default:
          if (Q)
            return j ? -1 : qe(L).length;
          S = ("" + S).toLowerCase(), Q = !0;
      }
  }
  l.byteLength = fe;
  function pe(L, S, I) {
    let j = !1;
    if ((S === void 0 || S < 0) && (S = 0), S > this.length || ((I === void 0 || I > this.length) && (I = this.length), I <= 0) || (I >>>= 0, S >>>= 0, I <= S))
      return "";
    for (L || (L = "utf8"); ; )
      switch (L) {
        case "hex":
          return y(this, S, I);
        case "utf8":
        case "utf-8":
          return $(this, S, I);
        case "ascii":
          return v(this, S, I);
        case "latin1":
        case "binary":
          return A(this, S, I);
        case "base64":
          return B(this, S, I);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return T(this, S, I);
        default:
          if (j)
            throw new TypeError("Unknown encoding: " + L);
          L = (L + "").toLowerCase(), j = !0;
      }
  }
  l.prototype._isBuffer = !0;
  function ue(L, S, I) {
    const j = L[S];
    L[S] = L[I], L[I] = j;
  }
  l.prototype.swap16 = function() {
    const S = this.length;
    if (S % 2 !== 0)
      throw new RangeError("Buffer size must be a multiple of 16-bits");
    for (let I = 0; I < S; I += 2)
      ue(this, I, I + 1);
    return this;
  }, l.prototype.swap32 = function() {
    const S = this.length;
    if (S % 4 !== 0)
      throw new RangeError("Buffer size must be a multiple of 32-bits");
    for (let I = 0; I < S; I += 4)
      ue(this, I, I + 3), ue(this, I + 1, I + 2);
    return this;
  }, l.prototype.swap64 = function() {
    const S = this.length;
    if (S % 8 !== 0)
      throw new RangeError("Buffer size must be a multiple of 64-bits");
    for (let I = 0; I < S; I += 8)
      ue(this, I, I + 7), ue(this, I + 1, I + 6), ue(this, I + 2, I + 5), ue(this, I + 3, I + 4);
    return this;
  }, l.prototype.toString = function() {
    const S = this.length;
    return S === 0 ? "" : arguments.length === 0 ? $(this, 0, S) : pe.apply(this, arguments);
  }, l.prototype.toLocaleString = l.prototype.toString, l.prototype.equals = function(S) {
    if (!l.isBuffer(S))
      throw new TypeError("Argument must be a Buffer");
    return this === S ? !0 : l.compare(this, S) === 0;
  }, l.prototype.inspect = function() {
    let S = "";
    const I = t.INSPECT_MAX_BYTES;
    return S = this.toString("hex", 0, I).replace(/(.{2})/g, "$1 ").trim(), this.length > I && (S += " ... "), "<Buffer " + S + ">";
  }, a && (l.prototype[a] = l.prototype.inspect), l.prototype.compare = function(S, I, j, Q, re) {
    if (Be(S, o) && (S = l.from(S, S.offset, S.byteLength)), !l.isBuffer(S))
      throw new TypeError(
        'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof S
      );
    if (I === void 0 && (I = 0), j === void 0 && (j = S ? S.length : 0), Q === void 0 && (Q = 0), re === void 0 && (re = this.length), I < 0 || j > S.length || Q < 0 || re > this.length)
      throw new RangeError("out of range index");
    if (Q >= re && I >= j)
      return 0;
    if (Q >= re)
      return -1;
    if (I >= j)
      return 1;
    if (I >>>= 0, j >>>= 0, Q >>>= 0, re >>>= 0, this === S)
      return 0;
    let ae = re - Q, ve = j - I;
    const Se = Math.min(ae, ve), be = this.slice(Q, re), Ee = S.slice(I, j);
    for (let we = 0; we < Se; ++we)
      if (be[we] !== Ee[we]) {
        ae = be[we], ve = Ee[we];
        break;
      }
    return ae < ve ? -1 : ve < ae ? 1 : 0;
  };
  function ce(L, S, I, j, Q) {
    if (L.length === 0)
      return -1;
    if (typeof I == "string" ? (j = I, I = 0) : I > 2147483647 ? I = 2147483647 : I < -2147483648 && (I = -2147483648), I = +I, Le(I) && (I = Q ? 0 : L.length - 1), I < 0 && (I = L.length + I), I >= L.length) {
      if (Q)
        return -1;
      I = L.length - 1;
    } else if (I < 0)
      if (Q)
        I = 0;
      else
        return -1;
    if (typeof S == "string" && (S = l.from(S, j)), l.isBuffer(S))
      return S.length === 0 ? -1 : $e(L, S, I, j, Q);
    if (typeof S == "number")
      return S = S & 255, typeof o.prototype.indexOf == "function" ? Q ? o.prototype.indexOf.call(L, S, I) : o.prototype.lastIndexOf.call(L, S, I) : $e(L, [S], I, j, Q);
    throw new TypeError("val must be string, number or Buffer");
  }
  function $e(L, S, I, j, Q) {
    let re = 1, ae = L.length, ve = S.length;
    if (j !== void 0 && (j = String(j).toLowerCase(), j === "ucs2" || j === "ucs-2" || j === "utf16le" || j === "utf-16le")) {
      if (L.length < 2 || S.length < 2)
        return -1;
      re = 2, ae /= 2, ve /= 2, I /= 2;
    }
    function Se(Ee, we) {
      return re === 1 ? Ee[we] : Ee.readUInt16BE(we * re);
    }
    let be;
    if (Q) {
      let Ee = -1;
      for (be = I; be < ae; be++)
        if (Se(L, be) === Se(S, Ee === -1 ? 0 : be - Ee)) {
          if (Ee === -1 && (Ee = be), be - Ee + 1 === ve)
            return Ee * re;
        } else
          Ee !== -1 && (be -= be - Ee), Ee = -1;
    } else
      for (I + ve > ae && (I = ae - ve), be = I; be >= 0; be--) {
        let Ee = !0;
        for (let we = 0; we < ve; we++)
          if (Se(L, be + we) !== Se(S, we)) {
            Ee = !1;
            break;
          }
        if (Ee)
          return be;
      }
    return -1;
  }
  l.prototype.includes = function(S, I, j) {
    return this.indexOf(S, I, j) !== -1;
  }, l.prototype.indexOf = function(S, I, j) {
    return ce(this, S, I, j, !0);
  }, l.prototype.lastIndexOf = function(S, I, j) {
    return ce(this, S, I, j, !1);
  };
  function V(L, S, I, j) {
    I = Number(I) || 0;
    const Q = L.length - I;
    j ? (j = Number(j), j > Q && (j = Q)) : j = Q;
    const re = S.length;
    j > re / 2 && (j = re / 2);
    let ae;
    for (ae = 0; ae < j; ++ae) {
      const ve = parseInt(S.substr(ae * 2, 2), 16);
      if (Le(ve))
        return ae;
      L[I + ae] = ve;
    }
    return ae;
  }
  function _(L, S, I, j) {
    return ye(qe(S, L.length - I), L, I, j);
  }
  function w(L, S, I, j) {
    return ye(_e(S), L, I, j);
  }
  function d(L, S, I, j) {
    return ye(De(S), L, I, j);
  }
  function m(L, S, I, j) {
    return ye(Oe(S, L.length - I), L, I, j);
  }
  l.prototype.write = function(S, I, j, Q) {
    if (I === void 0)
      Q = "utf8", j = this.length, I = 0;
    else if (j === void 0 && typeof I == "string")
      Q = I, j = this.length, I = 0;
    else if (isFinite(I))
      I = I >>> 0, isFinite(j) ? (j = j >>> 0, Q === void 0 && (Q = "utf8")) : (Q = j, j = void 0);
    else
      throw new Error(
        "Buffer.write(string, encoding, offset[, length]) is no longer supported"
      );
    const re = this.length - I;
    if ((j === void 0 || j > re) && (j = re), S.length > 0 && (j < 0 || I < 0) || I > this.length)
      throw new RangeError("Attempt to write outside buffer bounds");
    Q || (Q = "utf8");
    let ae = !1;
    for (; ; )
      switch (Q) {
        case "hex":
          return V(this, S, I, j);
        case "utf8":
        case "utf-8":
          return _(this, S, I, j);
        case "ascii":
        case "latin1":
        case "binary":
          return w(this, S, I, j);
        case "base64":
          return d(this, S, I, j);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return m(this, S, I, j);
        default:
          if (ae)
            throw new TypeError("Unknown encoding: " + Q);
          Q = ("" + Q).toLowerCase(), ae = !0;
      }
  }, l.prototype.toJSON = function() {
    return {
      type: "Buffer",
      data: Array.prototype.slice.call(this._arr || this, 0)
    };
  };
  function B(L, S, I) {
    return S === 0 && I === L.length ? e.fromByteArray(L) : e.fromByteArray(L.slice(S, I));
  }
  function $(L, S, I) {
    I = Math.min(L.length, I);
    const j = [];
    let Q = S;
    for (; Q < I; ) {
      const re = L[Q];
      let ae = null, ve = re > 239 ? 4 : re > 223 ? 3 : re > 191 ? 2 : 1;
      if (Q + ve <= I) {
        let Se, be, Ee, we;
        switch (ve) {
          case 1:
            re < 128 && (ae = re);
            break;
          case 2:
            Se = L[Q + 1], (Se & 192) === 128 && (we = (re & 31) << 6 | Se & 63, we > 127 && (ae = we));
            break;
          case 3:
            Se = L[Q + 1], be = L[Q + 2], (Se & 192) === 128 && (be & 192) === 128 && (we = (re & 15) << 12 | (Se & 63) << 6 | be & 63, we > 2047 && (we < 55296 || we > 57343) && (ae = we));
            break;
          case 4:
            Se = L[Q + 1], be = L[Q + 2], Ee = L[Q + 3], (Se & 192) === 128 && (be & 192) === 128 && (Ee & 192) === 128 && (we = (re & 15) << 18 | (Se & 63) << 12 | (be & 63) << 6 | Ee & 63, we > 65535 && we < 1114112 && (ae = we));
        }
      }
      ae === null ? (ae = 65533, ve = 1) : ae > 65535 && (ae -= 65536, j.push(ae >>> 10 & 1023 | 55296), ae = 56320 | ae & 1023), j.push(ae), Q += ve;
    }
    return M(j);
  }
  const P = 4096;
  function M(L) {
    const S = L.length;
    if (S <= P)
      return String.fromCharCode.apply(String, L);
    let I = "", j = 0;
    for (; j < S; )
      I += String.fromCharCode.apply(
        String,
        L.slice(j, j += P)
      );
    return I;
  }
  function v(L, S, I) {
    let j = "";
    I = Math.min(L.length, I);
    for (let Q = S; Q < I; ++Q)
      j += String.fromCharCode(L[Q] & 127);
    return j;
  }
  function A(L, S, I) {
    let j = "";
    I = Math.min(L.length, I);
    for (let Q = S; Q < I; ++Q)
      j += String.fromCharCode(L[Q]);
    return j;
  }
  function y(L, S, I) {
    const j = L.length;
    (!S || S < 0) && (S = 0), (!I || I < 0 || I > j) && (I = j);
    let Q = "";
    for (let re = S; re < I; ++re)
      Q += xe[L[re]];
    return Q;
  }
  function T(L, S, I) {
    const j = L.slice(S, I);
    let Q = "";
    for (let re = 0; re < j.length - 1; re += 2)
      Q += String.fromCharCode(j[re] + j[re + 1] * 256);
    return Q;
  }
  l.prototype.slice = function(S, I) {
    const j = this.length;
    S = ~~S, I = I === void 0 ? j : ~~I, S < 0 ? (S += j, S < 0 && (S = 0)) : S > j && (S = j), I < 0 ? (I += j, I < 0 && (I = 0)) : I > j && (I = j), I < S && (I = S);
    const Q = this.subarray(S, I);
    return Object.setPrototypeOf(Q, l.prototype), Q;
  };
  function Z(L, S, I) {
    if (L % 1 !== 0 || L < 0)
      throw new RangeError("offset is not uint");
    if (L + S > I)
      throw new RangeError("Trying to access beyond buffer length");
  }
  l.prototype.readUintLE = l.prototype.readUIntLE = function(S, I, j) {
    S = S >>> 0, I = I >>> 0, j || Z(S, I, this.length);
    let Q = this[S], re = 1, ae = 0;
    for (; ++ae < I && (re *= 256); )
      Q += this[S + ae] * re;
    return Q;
  }, l.prototype.readUintBE = l.prototype.readUIntBE = function(S, I, j) {
    S = S >>> 0, I = I >>> 0, j || Z(S, I, this.length);
    let Q = this[S + --I], re = 1;
    for (; I > 0 && (re *= 256); )
      Q += this[S + --I] * re;
    return Q;
  }, l.prototype.readUint8 = l.prototype.readUInt8 = function(S, I) {
    return S = S >>> 0, I || Z(S, 1, this.length), this[S];
  }, l.prototype.readUint16LE = l.prototype.readUInt16LE = function(S, I) {
    return S = S >>> 0, I || Z(S, 2, this.length), this[S] | this[S + 1] << 8;
  }, l.prototype.readUint16BE = l.prototype.readUInt16BE = function(S, I) {
    return S = S >>> 0, I || Z(S, 2, this.length), this[S] << 8 | this[S + 1];
  }, l.prototype.readUint32LE = l.prototype.readUInt32LE = function(S, I) {
    return S = S >>> 0, I || Z(S, 4, this.length), (this[S] | this[S + 1] << 8 | this[S + 2] << 16) + this[S + 3] * 16777216;
  }, l.prototype.readUint32BE = l.prototype.readUInt32BE = function(S, I) {
    return S = S >>> 0, I || Z(S, 4, this.length), this[S] * 16777216 + (this[S + 1] << 16 | this[S + 2] << 8 | this[S + 3]);
  }, l.prototype.readBigUInt64LE = Te(function(S) {
    S = S >>> 0, he(S, "offset");
    const I = this[S], j = this[S + 7];
    (I === void 0 || j === void 0) && me(S, this.length - 8);
    const Q = I + this[++S] * 2 ** 8 + this[++S] * 2 ** 16 + this[++S] * 2 ** 24, re = this[++S] + this[++S] * 2 ** 8 + this[++S] * 2 ** 16 + j * 2 ** 24;
    return BigInt(Q) + (BigInt(re) << BigInt(32));
  }), l.prototype.readBigUInt64BE = Te(function(S) {
    S = S >>> 0, he(S, "offset");
    const I = this[S], j = this[S + 7];
    (I === void 0 || j === void 0) && me(S, this.length - 8);
    const Q = I * 2 ** 24 + this[++S] * 2 ** 16 + this[++S] * 2 ** 8 + this[++S], re = this[++S] * 2 ** 24 + this[++S] * 2 ** 16 + this[++S] * 2 ** 8 + j;
    return (BigInt(Q) << BigInt(32)) + BigInt(re);
  }), l.prototype.readIntLE = function(S, I, j) {
    S = S >>> 0, I = I >>> 0, j || Z(S, I, this.length);
    let Q = this[S], re = 1, ae = 0;
    for (; ++ae < I && (re *= 256); )
      Q += this[S + ae] * re;
    return re *= 128, Q >= re && (Q -= Math.pow(2, 8 * I)), Q;
  }, l.prototype.readIntBE = function(S, I, j) {
    S = S >>> 0, I = I >>> 0, j || Z(S, I, this.length);
    let Q = I, re = 1, ae = this[S + --Q];
    for (; Q > 0 && (re *= 256); )
      ae += this[S + --Q] * re;
    return re *= 128, ae >= re && (ae -= Math.pow(2, 8 * I)), ae;
  }, l.prototype.readInt8 = function(S, I) {
    return S = S >>> 0, I || Z(S, 1, this.length), this[S] & 128 ? (255 - this[S] + 1) * -1 : this[S];
  }, l.prototype.readInt16LE = function(S, I) {
    S = S >>> 0, I || Z(S, 2, this.length);
    const j = this[S] | this[S + 1] << 8;
    return j & 32768 ? j | 4294901760 : j;
  }, l.prototype.readInt16BE = function(S, I) {
    S = S >>> 0, I || Z(S, 2, this.length);
    const j = this[S + 1] | this[S] << 8;
    return j & 32768 ? j | 4294901760 : j;
  }, l.prototype.readInt32LE = function(S, I) {
    return S = S >>> 0, I || Z(S, 4, this.length), this[S] | this[S + 1] << 8 | this[S + 2] << 16 | this[S + 3] << 24;
  }, l.prototype.readInt32BE = function(S, I) {
    return S = S >>> 0, I || Z(S, 4, this.length), this[S] << 24 | this[S + 1] << 16 | this[S + 2] << 8 | this[S + 3];
  }, l.prototype.readBigInt64LE = Te(function(S) {
    S = S >>> 0, he(S, "offset");
    const I = this[S], j = this[S + 7];
    (I === void 0 || j === void 0) && me(S, this.length - 8);
    const Q = this[S + 4] + this[S + 5] * 2 ** 8 + this[S + 6] * 2 ** 16 + (j << 24);
    return (BigInt(Q) << BigInt(32)) + BigInt(I + this[++S] * 2 ** 8 + this[++S] * 2 ** 16 + this[++S] * 2 ** 24);
  }), l.prototype.readBigInt64BE = Te(function(S) {
    S = S >>> 0, he(S, "offset");
    const I = this[S], j = this[S + 7];
    (I === void 0 || j === void 0) && me(S, this.length - 8);
    const Q = (I << 24) + // Overflow
    this[++S] * 2 ** 16 + this[++S] * 2 ** 8 + this[++S];
    return (BigInt(Q) << BigInt(32)) + BigInt(this[++S] * 2 ** 24 + this[++S] * 2 ** 16 + this[++S] * 2 ** 8 + j);
  }), l.prototype.readFloatLE = function(S, I) {
    return S = S >>> 0, I || Z(S, 4, this.length), n.read(this, S, !0, 23, 4);
  }, l.prototype.readFloatBE = function(S, I) {
    return S = S >>> 0, I || Z(S, 4, this.length), n.read(this, S, !1, 23, 4);
  }, l.prototype.readDoubleLE = function(S, I) {
    return S = S >>> 0, I || Z(S, 8, this.length), n.read(this, S, !0, 52, 8);
  }, l.prototype.readDoubleBE = function(S, I) {
    return S = S >>> 0, I || Z(S, 8, this.length), n.read(this, S, !1, 52, 8);
  };
  function ie(L, S, I, j, Q, re) {
    if (!l.isBuffer(L))
      throw new TypeError('"buffer" argument must be a Buffer instance');
    if (S > Q || S < re)
      throw new RangeError('"value" argument is out of bounds');
    if (I + j > L.length)
      throw new RangeError("Index out of range");
  }
  l.prototype.writeUintLE = l.prototype.writeUIntLE = function(S, I, j, Q) {
    if (S = +S, I = I >>> 0, j = j >>> 0, !Q) {
      const ve = Math.pow(2, 8 * j) - 1;
      ie(this, S, I, j, ve, 0);
    }
    let re = 1, ae = 0;
    for (this[I] = S & 255; ++ae < j && (re *= 256); )
      this[I + ae] = S / re & 255;
    return I + j;
  }, l.prototype.writeUintBE = l.prototype.writeUIntBE = function(S, I, j, Q) {
    if (S = +S, I = I >>> 0, j = j >>> 0, !Q) {
      const ve = Math.pow(2, 8 * j) - 1;
      ie(this, S, I, j, ve, 0);
    }
    let re = j - 1, ae = 1;
    for (this[I + re] = S & 255; --re >= 0 && (ae *= 256); )
      this[I + re] = S / ae & 255;
    return I + j;
  }, l.prototype.writeUint8 = l.prototype.writeUInt8 = function(S, I, j) {
    return S = +S, I = I >>> 0, j || ie(this, S, I, 1, 255, 0), this[I] = S & 255, I + 1;
  }, l.prototype.writeUint16LE = l.prototype.writeUInt16LE = function(S, I, j) {
    return S = +S, I = I >>> 0, j || ie(this, S, I, 2, 65535, 0), this[I] = S & 255, this[I + 1] = S >>> 8, I + 2;
  }, l.prototype.writeUint16BE = l.prototype.writeUInt16BE = function(S, I, j) {
    return S = +S, I = I >>> 0, j || ie(this, S, I, 2, 65535, 0), this[I] = S >>> 8, this[I + 1] = S & 255, I + 2;
  }, l.prototype.writeUint32LE = l.prototype.writeUInt32LE = function(S, I, j) {
    return S = +S, I = I >>> 0, j || ie(this, S, I, 4, 4294967295, 0), this[I + 3] = S >>> 24, this[I + 2] = S >>> 16, this[I + 1] = S >>> 8, this[I] = S & 255, I + 4;
  }, l.prototype.writeUint32BE = l.prototype.writeUInt32BE = function(S, I, j) {
    return S = +S, I = I >>> 0, j || ie(this, S, I, 4, 4294967295, 0), this[I] = S >>> 24, this[I + 1] = S >>> 16, this[I + 2] = S >>> 8, this[I + 3] = S & 255, I + 4;
  };
  function J(L, S, I, j, Q) {
    le(S, j, Q, L, I, 7);
    let re = Number(S & BigInt(4294967295));
    L[I++] = re, re = re >> 8, L[I++] = re, re = re >> 8, L[I++] = re, re = re >> 8, L[I++] = re;
    let ae = Number(S >> BigInt(32) & BigInt(4294967295));
    return L[I++] = ae, ae = ae >> 8, L[I++] = ae, ae = ae >> 8, L[I++] = ae, ae = ae >> 8, L[I++] = ae, I;
  }
  function k(L, S, I, j, Q) {
    le(S, j, Q, L, I, 7);
    let re = Number(S & BigInt(4294967295));
    L[I + 7] = re, re = re >> 8, L[I + 6] = re, re = re >> 8, L[I + 5] = re, re = re >> 8, L[I + 4] = re;
    let ae = Number(S >> BigInt(32) & BigInt(4294967295));
    return L[I + 3] = ae, ae = ae >> 8, L[I + 2] = ae, ae = ae >> 8, L[I + 1] = ae, ae = ae >> 8, L[I] = ae, I + 8;
  }
  l.prototype.writeBigUInt64LE = Te(function(S, I = 0) {
    return J(this, S, I, BigInt(0), BigInt("0xffffffffffffffff"));
  }), l.prototype.writeBigUInt64BE = Te(function(S, I = 0) {
    return k(this, S, I, BigInt(0), BigInt("0xffffffffffffffff"));
  }), l.prototype.writeIntLE = function(S, I, j, Q) {
    if (S = +S, I = I >>> 0, !Q) {
      const Se = Math.pow(2, 8 * j - 1);
      ie(this, S, I, j, Se - 1, -Se);
    }
    let re = 0, ae = 1, ve = 0;
    for (this[I] = S & 255; ++re < j && (ae *= 256); )
      S < 0 && ve === 0 && this[I + re - 1] !== 0 && (ve = 1), this[I + re] = (S / ae >> 0) - ve & 255;
    return I + j;
  }, l.prototype.writeIntBE = function(S, I, j, Q) {
    if (S = +S, I = I >>> 0, !Q) {
      const Se = Math.pow(2, 8 * j - 1);
      ie(this, S, I, j, Se - 1, -Se);
    }
    let re = j - 1, ae = 1, ve = 0;
    for (this[I + re] = S & 255; --re >= 0 && (ae *= 256); )
      S < 0 && ve === 0 && this[I + re + 1] !== 0 && (ve = 1), this[I + re] = (S / ae >> 0) - ve & 255;
    return I + j;
  }, l.prototype.writeInt8 = function(S, I, j) {
    return S = +S, I = I >>> 0, j || ie(this, S, I, 1, 127, -128), S < 0 && (S = 255 + S + 1), this[I] = S & 255, I + 1;
  }, l.prototype.writeInt16LE = function(S, I, j) {
    return S = +S, I = I >>> 0, j || ie(this, S, I, 2, 32767, -32768), this[I] = S & 255, this[I + 1] = S >>> 8, I + 2;
  }, l.prototype.writeInt16BE = function(S, I, j) {
    return S = +S, I = I >>> 0, j || ie(this, S, I, 2, 32767, -32768), this[I] = S >>> 8, this[I + 1] = S & 255, I + 2;
  }, l.prototype.writeInt32LE = function(S, I, j) {
    return S = +S, I = I >>> 0, j || ie(this, S, I, 4, 2147483647, -2147483648), this[I] = S & 255, this[I + 1] = S >>> 8, this[I + 2] = S >>> 16, this[I + 3] = S >>> 24, I + 4;
  }, l.prototype.writeInt32BE = function(S, I, j) {
    return S = +S, I = I >>> 0, j || ie(this, S, I, 4, 2147483647, -2147483648), S < 0 && (S = 4294967295 + S + 1), this[I] = S >>> 24, this[I + 1] = S >>> 16, this[I + 2] = S >>> 8, this[I + 3] = S & 255, I + 4;
  }, l.prototype.writeBigInt64LE = Te(function(S, I = 0) {
    return J(this, S, I, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
  }), l.prototype.writeBigInt64BE = Te(function(S, I = 0) {
    return k(this, S, I, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
  });
  function D(L, S, I, j, Q, re) {
    if (I + j > L.length)
      throw new RangeError("Index out of range");
    if (I < 0)
      throw new RangeError("Index out of range");
  }
  function X(L, S, I, j, Q) {
    return S = +S, I = I >>> 0, Q || D(L, S, I, 4), n.write(L, S, I, j, 23, 4), I + 4;
  }
  l.prototype.writeFloatLE = function(S, I, j) {
    return X(this, S, I, !0, j);
  }, l.prototype.writeFloatBE = function(S, I, j) {
    return X(this, S, I, !1, j);
  };
  function te(L, S, I, j, Q) {
    return S = +S, I = I >>> 0, Q || D(L, S, I, 8), n.write(L, S, I, j, 52, 8), I + 8;
  }
  l.prototype.writeDoubleLE = function(S, I, j) {
    return te(this, S, I, !0, j);
  }, l.prototype.writeDoubleBE = function(S, I, j) {
    return te(this, S, I, !1, j);
  }, l.prototype.copy = function(S, I, j, Q) {
    if (!l.isBuffer(S))
      throw new TypeError("argument should be a Buffer");
    if (j || (j = 0), !Q && Q !== 0 && (Q = this.length), I >= S.length && (I = S.length), I || (I = 0), Q > 0 && Q < j && (Q = j), Q === j || S.length === 0 || this.length === 0)
      return 0;
    if (I < 0)
      throw new RangeError("targetStart out of bounds");
    if (j < 0 || j >= this.length)
      throw new RangeError("Index out of range");
    if (Q < 0)
      throw new RangeError("sourceEnd out of bounds");
    Q > this.length && (Q = this.length), S.length - I < Q - j && (Q = S.length - I + j);
    const re = Q - j;
    return this === S && typeof o.prototype.copyWithin == "function" ? this.copyWithin(I, j, Q) : o.prototype.set.call(
      S,
      this.subarray(j, Q),
      I
    ), re;
  }, l.prototype.fill = function(S, I, j, Q) {
    if (typeof S == "string") {
      if (typeof I == "string" ? (Q = I, I = 0, j = this.length) : typeof j == "string" && (Q = j, j = this.length), Q !== void 0 && typeof Q != "string")
        throw new TypeError("encoding must be a string");
      if (typeof Q == "string" && !l.isEncoding(Q))
        throw new TypeError("Unknown encoding: " + Q);
      if (S.length === 1) {
        const ae = S.charCodeAt(0);
        (Q === "utf8" && ae < 128 || Q === "latin1") && (S = ae);
      }
    } else
      typeof S == "number" ? S = S & 255 : typeof S == "boolean" && (S = Number(S));
    if (I < 0 || this.length < I || this.length < j)
      throw new RangeError("Out of range index");
    if (j <= I)
      return this;
    I = I >>> 0, j = j === void 0 ? this.length : j >>> 0, S || (S = 0);
    let re;
    if (typeof S == "number")
      for (re = I; re < j; ++re)
        this[re] = S;
    else {
      const ae = l.isBuffer(S) ? S : l.from(S, Q), ve = ae.length;
      if (ve === 0)
        throw new TypeError('The value "' + S + '" is invalid for argument "value"');
      for (re = 0; re < j - I; ++re)
        this[re + I] = ae[re % ve];
    }
    return this;
  };
  const N = {};
  function O(L, S, I) {
    N[L] = class extends I {
      constructor() {
        super(), Object.defineProperty(this, "message", {
          value: S.apply(this, arguments),
          writable: !0,
          configurable: !0
        }), this.name = `${this.name} [${L}]`, this.stack, delete this.name;
      }
      get code() {
        return L;
      }
      set code(Q) {
        Object.defineProperty(this, "code", {
          configurable: !0,
          enumerable: !0,
          value: Q,
          writable: !0
        });
      }
      toString() {
        return `${this.name} [${L}]: ${this.message}`;
      }
    };
  }
  O(
    "ERR_BUFFER_OUT_OF_BOUNDS",
    function(L) {
      return L ? `${L} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds";
    },
    RangeError
  ), O(
    "ERR_INVALID_ARG_TYPE",
    function(L, S) {
      return `The "${L}" argument must be of type number. Received type ${typeof S}`;
    },
    TypeError
  ), O(
    "ERR_OUT_OF_RANGE",
    function(L, S, I) {
      let j = `The value of "${L}" is out of range.`, Q = I;
      return Number.isInteger(I) && Math.abs(I) > 2 ** 32 ? Q = ne(String(I)) : typeof I == "bigint" && (Q = String(I), (I > BigInt(2) ** BigInt(32) || I < -(BigInt(2) ** BigInt(32))) && (Q = ne(Q)), Q += "n"), j += ` It must be ${S}. Received ${Q}`, j;
    },
    RangeError
  );
  function ne(L) {
    let S = "", I = L.length;
    const j = L[0] === "-" ? 1 : 0;
    for (; I >= j + 4; I -= 3)
      S = `_${L.slice(I - 3, I)}${S}`;
    return `${L.slice(0, I)}${S}`;
  }
  function de(L, S, I) {
    he(S, "offset"), (L[S] === void 0 || L[S + I] === void 0) && me(S, L.length - (I + 1));
  }
  function le(L, S, I, j, Q, re) {
    if (L > I || L < S) {
      const ae = typeof S == "bigint" ? "n" : "";
      let ve;
      throw S === 0 || S === BigInt(0) ? ve = `>= 0${ae} and < 2${ae} ** ${(re + 1) * 8}${ae}` : ve = `>= -(2${ae} ** ${(re + 1) * 8 - 1}${ae}) and < 2 ** ${(re + 1) * 8 - 1}${ae}`, new N.ERR_OUT_OF_RANGE("value", ve, L);
    }
    de(j, Q, re);
  }
  function he(L, S) {
    if (typeof L != "number")
      throw new N.ERR_INVALID_ARG_TYPE(S, "number", L);
  }
  function me(L, S, I) {
    throw Math.floor(L) !== L ? (he(L, I), new N.ERR_OUT_OF_RANGE("offset", "an integer", L)) : S < 0 ? new N.ERR_BUFFER_OUT_OF_BOUNDS() : new N.ERR_OUT_OF_RANGE(
      "offset",
      `>= 0 and <= ${S}`,
      L
    );
  }
  const ge = /[^+/0-9A-Za-z-_]/g;
  function oe(L) {
    if (L = L.split("=")[0], L = L.trim().replace(ge, ""), L.length < 2)
      return "";
    for (; L.length % 4 !== 0; )
      L = L + "=";
    return L;
  }
  function qe(L, S) {
    S = S || 1 / 0;
    let I;
    const j = L.length;
    let Q = null;
    const re = [];
    for (let ae = 0; ae < j; ++ae) {
      if (I = L.charCodeAt(ae), I > 55295 && I < 57344) {
        if (!Q) {
          if (I > 56319) {
            (S -= 3) > -1 && re.push(239, 191, 189);
            continue;
          } else if (ae + 1 === j) {
            (S -= 3) > -1 && re.push(239, 191, 189);
            continue;
          }
          Q = I;
          continue;
        }
        if (I < 56320) {
          (S -= 3) > -1 && re.push(239, 191, 189), Q = I;
          continue;
        }
        I = (Q - 55296 << 10 | I - 56320) + 65536;
      } else
        Q && (S -= 3) > -1 && re.push(239, 191, 189);
      if (Q = null, I < 128) {
        if ((S -= 1) < 0)
          break;
        re.push(I);
      } else if (I < 2048) {
        if ((S -= 2) < 0)
          break;
        re.push(
          I >> 6 | 192,
          I & 63 | 128
        );
      } else if (I < 65536) {
        if ((S -= 3) < 0)
          break;
        re.push(
          I >> 12 | 224,
          I >> 6 & 63 | 128,
          I & 63 | 128
        );
      } else if (I < 1114112) {
        if ((S -= 4) < 0)
          break;
        re.push(
          I >> 18 | 240,
          I >> 12 & 63 | 128,
          I >> 6 & 63 | 128,
          I & 63 | 128
        );
      } else
        throw new Error("Invalid code point");
    }
    return re;
  }
  function _e(L) {
    const S = [];
    for (let I = 0; I < L.length; ++I)
      S.push(L.charCodeAt(I) & 255);
    return S;
  }
  function Oe(L, S) {
    let I, j, Q;
    const re = [];
    for (let ae = 0; ae < L.length && !((S -= 2) < 0); ++ae)
      I = L.charCodeAt(ae), j = I >> 8, Q = I % 256, re.push(Q), re.push(j);
    return re;
  }
  function De(L) {
    return e.toByteArray(oe(L));
  }
  function ye(L, S, I, j) {
    let Q;
    for (Q = 0; Q < j && !(Q + I >= S.length || Q >= L.length); ++Q)
      S[Q + I] = L[Q];
    return Q;
  }
  function Be(L, S) {
    return L instanceof S || L != null && L.constructor != null && L.constructor.name != null && L.constructor.name === S.name;
  }
  function Le(L) {
    return L !== L;
  }
  const xe = function() {
    const L = "0123456789abcdef", S = new Array(256);
    for (let I = 0; I < 16; ++I) {
      const j = I * 16;
      for (let Q = 0; Q < 16; ++Q)
        S[j + Q] = L[I] + L[Q];
    }
    return S;
  }();
  function Te(L) {
    return typeof BigInt > "u" ? Ne : L;
  }
  function Ne() {
    throw new Error("BigInt not supported");
  }
})(buffer$1);
const Buffer$B = buffer$1.Buffer, Blob$1 = buffer$1.Blob, BlobOptions = buffer$1.BlobOptions, Buffer$1$1 = buffer$1.Buffer, File = buffer$1.File, FileOptions = buffer$1.FileOptions, INSPECT_MAX_BYTES = buffer$1.INSPECT_MAX_BYTES, SlowBuffer = buffer$1.SlowBuffer, TranscodeEncoding = buffer$1.TranscodeEncoding, atob$1 = buffer$1.atob, btoa$1 = buffer$1.btoa, constants$1 = buffer$1.constants, isAscii = buffer$1.isAscii, isUtf8 = buffer$1.isUtf8, kMaxLength = buffer$1.kMaxLength, kStringMaxLength = buffer$1.kStringMaxLength, resolveObjectURL = buffer$1.resolveObjectURL, transcode = buffer$1.transcode, dist = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Blob: Blob$1,
  BlobOptions,
  Buffer: Buffer$1$1,
  File,
  FileOptions,
  INSPECT_MAX_BYTES,
  SlowBuffer,
  TranscodeEncoding,
  atob: atob$1,
  btoa: btoa$1,
  constants: constants$1,
  default: Buffer$B,
  isAscii,
  isUtf8,
  kMaxLength,
  kStringMaxLength,
  resolveObjectURL,
  transcode
}, Symbol.toStringTag, { value: "Module" }));
var commonjsGlobal = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function getDefaultExportFromCjs$1(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
function getAugmentedNamespace(t) {
  if (t.__esModule)
    return t;
  var e = t.default;
  if (typeof e == "function") {
    var n = function a() {
      return this instanceof a ? Reflect.construct(e, arguments, this.constructor) : e.apply(this, arguments);
    };
    n.prototype = e.prototype;
  } else
    n = {};
  return Object.defineProperty(n, "__esModule", { value: !0 }), Object.keys(t).forEach(function(a) {
    var c = Object.getOwnPropertyDescriptor(t, a);
    Object.defineProperty(n, a, c.get ? c : {
      enumerable: !0,
      get: function() {
        return t[a];
      }
    });
  }), n;
}
var cryptoBrowserify = {};
function getDefaultExportFromCjs(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
var browser$c = { exports: {} }, process = browser$c.exports = {}, cachedSetTimeout, cachedClearTimeout;
function defaultSetTimout() {
  throw new Error("setTimeout has not been defined");
}
function defaultClearTimeout() {
  throw new Error("clearTimeout has not been defined");
}
(function() {
  try {
    typeof setTimeout == "function" ? cachedSetTimeout = setTimeout : cachedSetTimeout = defaultSetTimout;
  } catch {
    cachedSetTimeout = defaultSetTimout;
  }
  try {
    typeof clearTimeout == "function" ? cachedClearTimeout = clearTimeout : cachedClearTimeout = defaultClearTimeout;
  } catch {
    cachedClearTimeout = defaultClearTimeout;
  }
})();
function runTimeout(t) {
  if (cachedSetTimeout === setTimeout)
    return setTimeout(t, 0);
  if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout)
    return cachedSetTimeout = setTimeout, setTimeout(t, 0);
  try {
    return cachedSetTimeout(t, 0);
  } catch {
    try {
      return cachedSetTimeout.call(null, t, 0);
    } catch {
      return cachedSetTimeout.call(this, t, 0);
    }
  }
}
function runClearTimeout(t) {
  if (cachedClearTimeout === clearTimeout)
    return clearTimeout(t);
  if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout)
    return cachedClearTimeout = clearTimeout, clearTimeout(t);
  try {
    return cachedClearTimeout(t);
  } catch {
    try {
      return cachedClearTimeout.call(null, t);
    } catch {
      return cachedClearTimeout.call(this, t);
    }
  }
}
var queue = [], draining = !1, currentQueue, queueIndex = -1;
function cleanUpNextTick() {
  !draining || !currentQueue || (draining = !1, currentQueue.length ? queue = currentQueue.concat(queue) : queueIndex = -1, queue.length && drainQueue());
}
function drainQueue() {
  if (!draining) {
    var t = runTimeout(cleanUpNextTick);
    draining = !0;
    for (var e = queue.length; e; ) {
      for (currentQueue = queue, queue = []; ++queueIndex < e; )
        currentQueue && currentQueue[queueIndex].run();
      queueIndex = -1, e = queue.length;
    }
    currentQueue = null, draining = !1, runClearTimeout(t);
  }
}
process.nextTick = function(t) {
  var e = new Array(arguments.length - 1);
  if (arguments.length > 1)
    for (var n = 1; n < arguments.length; n++)
      e[n - 1] = arguments[n];
  queue.push(new Item(t, e)), queue.length === 1 && !draining && runTimeout(drainQueue);
};
function Item(t, e) {
  this.fun = t, this.array = e;
}
Item.prototype.run = function() {
  this.fun.apply(null, this.array);
};
process.title = "browser";
process.browser = !0;
process.env = {};
process.argv = [];
process.version = "";
process.versions = {};
function noop() {
}
process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;
process.listeners = function(t) {
  return [];
};
process.binding = function(t) {
  throw new Error("process.binding is not supported");
};
process.cwd = function() {
  return "/";
};
process.chdir = function(t) {
  throw new Error("process.chdir is not supported");
};
process.umask = function() {
  return 0;
};
var browserExports$1 = browser$c.exports;
const process$1 = /* @__PURE__ */ getDefaultExportFromCjs(browserExports$1);
var browser$b = { exports: {} }, safeBuffer$2 = { exports: {} };
const require$$1$2 = /* @__PURE__ */ getAugmentedNamespace(dist);
(function(t, e) {
  var n = require$$1$2, a = n.Buffer;
  function c(u, h) {
    for (var p in u)
      h[p] = u[p];
  }
  a.from && a.alloc && a.allocUnsafe && a.allocUnsafeSlow ? t.exports = n : (c(n, e), e.Buffer = o);
  function o(u, h, p) {
    return a(u, h, p);
  }
  c(a, o), o.from = function(u, h, p) {
    if (typeof u == "number")
      throw new TypeError("Argument must not be a number");
    return a(u, h, p);
  }, o.alloc = function(u, h, p) {
    if (typeof u != "number")
      throw new TypeError("Argument must be a number");
    var x = a(u);
    return h !== void 0 ? typeof p == "string" ? x.fill(h, p) : x.fill(h) : x.fill(0), x;
  }, o.allocUnsafe = function(u) {
    if (typeof u != "number")
      throw new TypeError("Argument must be a number");
    return a(u);
  }, o.allocUnsafeSlow = function(u) {
    if (typeof u != "number")
      throw new TypeError("Argument must be a number");
    return n.SlowBuffer(u);
  };
})(safeBuffer$2, safeBuffer$2.exports);
var safeBufferExports$1 = safeBuffer$2.exports, MAX_BYTES = 65536, MAX_UINT32 = 4294967295;
function oldBrowser$1() {
  throw new Error(`Secure random number generation is not supported by this browser.
Use Chrome, Firefox or Internet Explorer 11`);
}
var Buffer$A = safeBufferExports$1.Buffer, crypto$1 = commonjsGlobal.crypto || commonjsGlobal.msCrypto;
crypto$1 && crypto$1.getRandomValues ? browser$b.exports = randomBytes$2 : browser$b.exports = oldBrowser$1;
function randomBytes$2(t, e) {
  if (t > MAX_UINT32)
    throw new RangeError("requested too many random bytes");
  var n = Buffer$A.allocUnsafe(t);
  if (t > 0)
    if (t > MAX_BYTES)
      for (var a = 0; a < t; a += MAX_BYTES)
        crypto$1.getRandomValues(n.slice(a, a + MAX_BYTES));
    else
      crypto$1.getRandomValues(n);
  return typeof e == "function" ? process$1.nextTick(function() {
    e(null, n);
  }) : n;
}
var browserExports = browser$b.exports, inherits_browser = { exports: {} };
typeof Object.create == "function" ? inherits_browser.exports = function(e, n) {
  n && (e.super_ = n, e.prototype = Object.create(n.prototype, {
    constructor: {
      value: e,
      enumerable: !1,
      writable: !0,
      configurable: !0
    }
  }));
} : inherits_browser.exports = function(e, n) {
  if (n) {
    e.super_ = n;
    var a = function() {
    };
    a.prototype = n.prototype, e.prototype = new a(), e.prototype.constructor = e;
  }
};
var inherits_browserExports = inherits_browser.exports, safeBuffer$1 = { exports: {} };
/*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
(function(t, e) {
  var n = require$$1$2, a = n.Buffer;
  function c(u, h) {
    for (var p in u)
      h[p] = u[p];
  }
  a.from && a.alloc && a.allocUnsafe && a.allocUnsafeSlow ? t.exports = n : (c(n, e), e.Buffer = o);
  function o(u, h, p) {
    return a(u, h, p);
  }
  o.prototype = Object.create(a.prototype), c(a, o), o.from = function(u, h, p) {
    if (typeof u == "number")
      throw new TypeError("Argument must not be a number");
    return a(u, h, p);
  }, o.alloc = function(u, h, p) {
    if (typeof u != "number")
      throw new TypeError("Argument must be a number");
    var x = a(u);
    return h !== void 0 ? typeof p == "string" ? x.fill(h, p) : x.fill(h) : x.fill(0), x;
  }, o.allocUnsafe = function(u) {
    if (typeof u != "number")
      throw new TypeError("Argument must be a number");
    return a(u);
  }, o.allocUnsafeSlow = function(u) {
    if (typeof u != "number")
      throw new TypeError("Argument must be a number");
    return n.SlowBuffer(u);
  };
})(safeBuffer$1, safeBuffer$1.exports);
var safeBufferExports = safeBuffer$1.exports, readableBrowser$1 = { exports: {} }, events = { exports: {} }, R = typeof Reflect == "object" ? Reflect : null, ReflectApply = R && typeof R.apply == "function" ? R.apply : function(e, n, a) {
  return Function.prototype.apply.call(e, n, a);
}, ReflectOwnKeys;
R && typeof R.ownKeys == "function" ? ReflectOwnKeys = R.ownKeys : Object.getOwnPropertySymbols ? ReflectOwnKeys = function(e) {
  return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e));
} : ReflectOwnKeys = function(e) {
  return Object.getOwnPropertyNames(e);
};
function ProcessEmitWarning(t) {
  console && console.warn && console.warn(t);
}
var NumberIsNaN = Number.isNaN || function(e) {
  return e !== e;
};
function EventEmitter() {
  EventEmitter.init.call(this);
}
events.exports = EventEmitter;
events.exports.once = once;
EventEmitter.EventEmitter = EventEmitter;
EventEmitter.prototype._events = void 0;
EventEmitter.prototype._eventsCount = 0;
EventEmitter.prototype._maxListeners = void 0;
var defaultMaxListeners = 10;
function checkListener(t) {
  if (typeof t != "function")
    throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof t);
}
Object.defineProperty(EventEmitter, "defaultMaxListeners", {
  enumerable: !0,
  get: function() {
    return defaultMaxListeners;
  },
  set: function(t) {
    if (typeof t != "number" || t < 0 || NumberIsNaN(t))
      throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + t + ".");
    defaultMaxListeners = t;
  }
});
EventEmitter.init = function() {
  (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
};
EventEmitter.prototype.setMaxListeners = function(e) {
  if (typeof e != "number" || e < 0 || NumberIsNaN(e))
    throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + e + ".");
  return this._maxListeners = e, this;
};
function _getMaxListeners(t) {
  return t._maxListeners === void 0 ? EventEmitter.defaultMaxListeners : t._maxListeners;
}
EventEmitter.prototype.getMaxListeners = function() {
  return _getMaxListeners(this);
};
EventEmitter.prototype.emit = function(e) {
  for (var n = [], a = 1; a < arguments.length; a++)
    n.push(arguments[a]);
  var c = e === "error", o = this._events;
  if (o !== void 0)
    c = c && o.error === void 0;
  else if (!c)
    return !1;
  if (c) {
    var u;
    if (n.length > 0 && (u = n[0]), u instanceof Error)
      throw u;
    var h = new Error("Unhandled error." + (u ? " (" + u.message + ")" : ""));
    throw h.context = u, h;
  }
  var p = o[e];
  if (p === void 0)
    return !1;
  if (typeof p == "function")
    ReflectApply(p, this, n);
  else
    for (var x = p.length, l = arrayClone(p, x), a = 0; a < x; ++a)
      ReflectApply(l[a], this, n);
  return !0;
};
function _addListener(t, e, n, a) {
  var c, o, u;
  if (checkListener(n), o = t._events, o === void 0 ? (o = t._events = /* @__PURE__ */ Object.create(null), t._eventsCount = 0) : (o.newListener !== void 0 && (t.emit(
    "newListener",
    e,
    n.listener ? n.listener : n
  ), o = t._events), u = o[e]), u === void 0)
    u = o[e] = n, ++t._eventsCount;
  else if (typeof u == "function" ? u = o[e] = a ? [n, u] : [u, n] : a ? u.unshift(n) : u.push(n), c = _getMaxListeners(t), c > 0 && u.length > c && !u.warned) {
    u.warned = !0;
    var h = new Error("Possible EventEmitter memory leak detected. " + u.length + " " + String(e) + " listeners added. Use emitter.setMaxListeners() to increase limit");
    h.name = "MaxListenersExceededWarning", h.emitter = t, h.type = e, h.count = u.length, ProcessEmitWarning(h);
  }
  return t;
}
EventEmitter.prototype.addListener = function(e, n) {
  return _addListener(this, e, n, !1);
};
EventEmitter.prototype.on = EventEmitter.prototype.addListener;
EventEmitter.prototype.prependListener = function(e, n) {
  return _addListener(this, e, n, !0);
};
function onceWrapper() {
  if (!this.fired)
    return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
}
function _onceWrap(t, e, n) {
  var a = { fired: !1, wrapFn: void 0, target: t, type: e, listener: n }, c = onceWrapper.bind(a);
  return c.listener = n, a.wrapFn = c, c;
}
EventEmitter.prototype.once = function(e, n) {
  return checkListener(n), this.on(e, _onceWrap(this, e, n)), this;
};
EventEmitter.prototype.prependOnceListener = function(e, n) {
  return checkListener(n), this.prependListener(e, _onceWrap(this, e, n)), this;
};
EventEmitter.prototype.removeListener = function(e, n) {
  var a, c, o, u, h;
  if (checkListener(n), c = this._events, c === void 0)
    return this;
  if (a = c[e], a === void 0)
    return this;
  if (a === n || a.listener === n)
    --this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : (delete c[e], c.removeListener && this.emit("removeListener", e, a.listener || n));
  else if (typeof a != "function") {
    for (o = -1, u = a.length - 1; u >= 0; u--)
      if (a[u] === n || a[u].listener === n) {
        h = a[u].listener, o = u;
        break;
      }
    if (o < 0)
      return this;
    o === 0 ? a.shift() : spliceOne(a, o), a.length === 1 && (c[e] = a[0]), c.removeListener !== void 0 && this.emit("removeListener", e, h || n);
  }
  return this;
};
EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
EventEmitter.prototype.removeAllListeners = function(e) {
  var n, a, c;
  if (a = this._events, a === void 0)
    return this;
  if (a.removeListener === void 0)
    return arguments.length === 0 ? (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0) : a[e] !== void 0 && (--this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : delete a[e]), this;
  if (arguments.length === 0) {
    var o = Object.keys(a), u;
    for (c = 0; c < o.length; ++c)
      u = o[c], u !== "removeListener" && this.removeAllListeners(u);
    return this.removeAllListeners("removeListener"), this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0, this;
  }
  if (n = a[e], typeof n == "function")
    this.removeListener(e, n);
  else if (n !== void 0)
    for (c = n.length - 1; c >= 0; c--)
      this.removeListener(e, n[c]);
  return this;
};
function _listeners(t, e, n) {
  var a = t._events;
  if (a === void 0)
    return [];
  var c = a[e];
  return c === void 0 ? [] : typeof c == "function" ? n ? [c.listener || c] : [c] : n ? unwrapListeners(c) : arrayClone(c, c.length);
}
EventEmitter.prototype.listeners = function(e) {
  return _listeners(this, e, !0);
};
EventEmitter.prototype.rawListeners = function(e) {
  return _listeners(this, e, !1);
};
EventEmitter.listenerCount = function(t, e) {
  return typeof t.listenerCount == "function" ? t.listenerCount(e) : listenerCount.call(t, e);
};
EventEmitter.prototype.listenerCount = listenerCount;
function listenerCount(t) {
  var e = this._events;
  if (e !== void 0) {
    var n = e[t];
    if (typeof n == "function")
      return 1;
    if (n !== void 0)
      return n.length;
  }
  return 0;
}
EventEmitter.prototype.eventNames = function() {
  return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
};
function arrayClone(t, e) {
  for (var n = new Array(e), a = 0; a < e; ++a)
    n[a] = t[a];
  return n;
}
function spliceOne(t, e) {
  for (; e + 1 < t.length; e++)
    t[e] = t[e + 1];
  t.pop();
}
function unwrapListeners(t) {
  for (var e = new Array(t.length), n = 0; n < e.length; ++n)
    e[n] = t[n].listener || t[n];
  return e;
}
function once(t, e) {
  return new Promise(function(n, a) {
    function c(u) {
      t.removeListener(e, o), a(u);
    }
    function o() {
      typeof t.removeListener == "function" && t.removeListener("error", c), n([].slice.call(arguments));
    }
    eventTargetAgnosticAddListener(t, e, o, { once: !0 }), e !== "error" && addErrorHandlerIfEventEmitter(t, c, { once: !0 });
  });
}
function addErrorHandlerIfEventEmitter(t, e, n) {
  typeof t.on == "function" && eventTargetAgnosticAddListener(t, "error", e, n);
}
function eventTargetAgnosticAddListener(t, e, n, a) {
  if (typeof t.on == "function")
    a.once ? t.once(e, n) : t.on(e, n);
  else if (typeof t.addEventListener == "function")
    t.addEventListener(e, function c(o) {
      a.once && t.removeEventListener(e, c), n(o);
    });
  else
    throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof t);
}
var eventsExports = events.exports, streamBrowser$1, hasRequiredStreamBrowser;
function requireStreamBrowser() {
  return hasRequiredStreamBrowser || (hasRequiredStreamBrowser = 1, streamBrowser$1 = eventsExports.EventEmitter), streamBrowser$1;
}
var util$3 = {}, types = {}, shams$1 = function() {
  if (typeof Symbol != "function" || typeof Object.getOwnPropertySymbols != "function")
    return !1;
  if (typeof Symbol.iterator == "symbol")
    return !0;
  var e = {}, n = Symbol("test"), a = Object(n);
  if (typeof n == "string" || Object.prototype.toString.call(n) !== "[object Symbol]" || Object.prototype.toString.call(a) !== "[object Symbol]")
    return !1;
  var c = 42;
  e[n] = c;
  for (n in e)
    return !1;
  if (typeof Object.keys == "function" && Object.keys(e).length !== 0 || typeof Object.getOwnPropertyNames == "function" && Object.getOwnPropertyNames(e).length !== 0)
    return !1;
  var o = Object.getOwnPropertySymbols(e);
  if (o.length !== 1 || o[0] !== n || !Object.prototype.propertyIsEnumerable.call(e, n))
    return !1;
  if (typeof Object.getOwnPropertyDescriptor == "function") {
    var u = Object.getOwnPropertyDescriptor(e, n);
    if (u.value !== c || u.enumerable !== !0)
      return !1;
  }
  return !0;
}, hasSymbols$2 = shams$1, shams = function() {
  return hasSymbols$2() && !!Symbol.toStringTag;
}, esErrors = Error, _eval = EvalError, range = RangeError, ref = ReferenceError, syntax = SyntaxError, type = TypeError, uri = URIError, origSymbol = typeof Symbol < "u" && Symbol, hasSymbolSham = shams$1, hasSymbols$1 = function() {
  return typeof origSymbol != "function" || typeof Symbol != "function" || typeof origSymbol("foo") != "symbol" || typeof Symbol("bar") != "symbol" ? !1 : hasSymbolSham();
}, test = {
  __proto__: null,
  foo: {}
}, $Object = Object, hasProto$1 = function() {
  return { __proto__: test }.foo === test.foo && !(test instanceof $Object);
}, ERROR_MESSAGE = "Function.prototype.bind called on incompatible ", toStr$3 = Object.prototype.toString, max = Math.max, funcType = "[object Function]", concatty = function(e, n) {
  for (var a = [], c = 0; c < e.length; c += 1)
    a[c] = e[c];
  for (var o = 0; o < n.length; o += 1)
    a[o + e.length] = n[o];
  return a;
}, slicy = function(e, n) {
  for (var a = [], c = n, o = 0; c < e.length; c += 1, o += 1)
    a[o] = e[c];
  return a;
}, joiny = function(t, e) {
  for (var n = "", a = 0; a < t.length; a += 1)
    n += t[a], a + 1 < t.length && (n += e);
  return n;
}, implementation$1 = function(e) {
  var n = this;
  if (typeof n != "function" || toStr$3.apply(n) !== funcType)
    throw new TypeError(ERROR_MESSAGE + n);
  for (var a = slicy(arguments, 1), c, o = function() {
    if (this instanceof c) {
      var l = n.apply(
        this,
        concatty(a, arguments)
      );
      return Object(l) === l ? l : this;
    }
    return n.apply(
      e,
      concatty(a, arguments)
    );
  }, u = max(0, n.length - a.length), h = [], p = 0; p < u; p++)
    h[p] = "$" + p;
  if (c = Function("binder", "return function (" + joiny(h, ",") + "){ return binder.apply(this,arguments); }")(o), n.prototype) {
    var x = function() {
    };
    x.prototype = n.prototype, c.prototype = new x(), x.prototype = null;
  }
  return c;
}, implementation = implementation$1, functionBind = Function.prototype.bind || implementation, call = Function.prototype.call, $hasOwn = Object.prototype.hasOwnProperty, bind$1 = functionBind, hasown = bind$1.call(call, $hasOwn), undefined$1, $Error = esErrors, $EvalError = _eval, $RangeError = range, $ReferenceError = ref, $SyntaxError$1 = syntax, $TypeError$2 = type, $URIError = uri, $Function = Function, getEvalledConstructor = function(t) {
  try {
    return $Function('"use strict"; return (' + t + ").constructor;")();
  } catch {
  }
}, $gOPD$1 = Object.getOwnPropertyDescriptor;
if ($gOPD$1)
  try {
    $gOPD$1({}, "");
  } catch {
    $gOPD$1 = null;
  }
var throwTypeError = function() {
  throw new $TypeError$2();
}, ThrowTypeError = $gOPD$1 ? function() {
  try {
    return arguments.callee, throwTypeError;
  } catch {
    try {
      return $gOPD$1(arguments, "callee").get;
    } catch {
      return throwTypeError;
    }
  }
}() : throwTypeError, hasSymbols = hasSymbols$1(), hasProto = hasProto$1(), getProto$1 = Object.getPrototypeOf || (hasProto ? function(t) {
  return t.__proto__;
} : null), needsEval = {}, TypedArray = typeof Uint8Array > "u" || !getProto$1 ? undefined$1 : getProto$1(Uint8Array), INTRINSICS = {
  __proto__: null,
  "%AggregateError%": typeof AggregateError > "u" ? undefined$1 : AggregateError,
  "%Array%": Array,
  "%ArrayBuffer%": typeof ArrayBuffer > "u" ? undefined$1 : ArrayBuffer,
  "%ArrayIteratorPrototype%": hasSymbols && getProto$1 ? getProto$1([][Symbol.iterator]()) : undefined$1,
  "%AsyncFromSyncIteratorPrototype%": undefined$1,
  "%AsyncFunction%": needsEval,
  "%AsyncGenerator%": needsEval,
  "%AsyncGeneratorFunction%": needsEval,
  "%AsyncIteratorPrototype%": needsEval,
  "%Atomics%": typeof Atomics > "u" ? undefined$1 : Atomics,
  "%BigInt%": typeof BigInt > "u" ? undefined$1 : BigInt,
  "%BigInt64Array%": typeof BigInt64Array > "u" ? undefined$1 : BigInt64Array,
  "%BigUint64Array%": typeof BigUint64Array > "u" ? undefined$1 : BigUint64Array,
  "%Boolean%": Boolean,
  "%DataView%": typeof DataView > "u" ? undefined$1 : DataView,
  "%Date%": Date,
  "%decodeURI%": decodeURI,
  "%decodeURIComponent%": decodeURIComponent,
  "%encodeURI%": encodeURI,
  "%encodeURIComponent%": encodeURIComponent,
  "%Error%": $Error,
  "%eval%": eval,
  // eslint-disable-line no-eval
  "%EvalError%": $EvalError,
  "%Float32Array%": typeof Float32Array > "u" ? undefined$1 : Float32Array,
  "%Float64Array%": typeof Float64Array > "u" ? undefined$1 : Float64Array,
  "%FinalizationRegistry%": typeof FinalizationRegistry > "u" ? undefined$1 : FinalizationRegistry,
  "%Function%": $Function,
  "%GeneratorFunction%": needsEval,
  "%Int8Array%": typeof Int8Array > "u" ? undefined$1 : Int8Array,
  "%Int16Array%": typeof Int16Array > "u" ? undefined$1 : Int16Array,
  "%Int32Array%": typeof Int32Array > "u" ? undefined$1 : Int32Array,
  "%isFinite%": isFinite,
  "%isNaN%": isNaN,
  "%IteratorPrototype%": hasSymbols && getProto$1 ? getProto$1(getProto$1([][Symbol.iterator]())) : undefined$1,
  "%JSON%": typeof JSON == "object" ? JSON : undefined$1,
  "%Map%": typeof Map > "u" ? undefined$1 : Map,
  "%MapIteratorPrototype%": typeof Map > "u" || !hasSymbols || !getProto$1 ? undefined$1 : getProto$1((/* @__PURE__ */ new Map())[Symbol.iterator]()),
  "%Math%": Math,
  "%Number%": Number,
  "%Object%": Object,
  "%parseFloat%": parseFloat,
  "%parseInt%": parseInt,
  "%Promise%": typeof Promise > "u" ? undefined$1 : Promise,
  "%Proxy%": typeof Proxy > "u" ? undefined$1 : Proxy,
  "%RangeError%": $RangeError,
  "%ReferenceError%": $ReferenceError,
  "%Reflect%": typeof Reflect > "u" ? undefined$1 : Reflect,
  "%RegExp%": RegExp,
  "%Set%": typeof Set > "u" ? undefined$1 : Set,
  "%SetIteratorPrototype%": typeof Set > "u" || !hasSymbols || !getProto$1 ? undefined$1 : getProto$1((/* @__PURE__ */ new Set())[Symbol.iterator]()),
  "%SharedArrayBuffer%": typeof SharedArrayBuffer > "u" ? undefined$1 : SharedArrayBuffer,
  "%String%": String,
  "%StringIteratorPrototype%": hasSymbols && getProto$1 ? getProto$1(""[Symbol.iterator]()) : undefined$1,
  "%Symbol%": hasSymbols ? Symbol : undefined$1,
  "%SyntaxError%": $SyntaxError$1,
  "%ThrowTypeError%": ThrowTypeError,
  "%TypedArray%": TypedArray,
  "%TypeError%": $TypeError$2,
  "%Uint8Array%": typeof Uint8Array > "u" ? undefined$1 : Uint8Array,
  "%Uint8ClampedArray%": typeof Uint8ClampedArray > "u" ? undefined$1 : Uint8ClampedArray,
  "%Uint16Array%": typeof Uint16Array > "u" ? undefined$1 : Uint16Array,
  "%Uint32Array%": typeof Uint32Array > "u" ? undefined$1 : Uint32Array,
  "%URIError%": $URIError,
  "%WeakMap%": typeof WeakMap > "u" ? undefined$1 : WeakMap,
  "%WeakRef%": typeof WeakRef > "u" ? undefined$1 : WeakRef,
  "%WeakSet%": typeof WeakSet > "u" ? undefined$1 : WeakSet
};
if (getProto$1)
  try {
    null.error;
  } catch (t) {
    var errorProto = getProto$1(getProto$1(t));
    INTRINSICS["%Error.prototype%"] = errorProto;
  }
var doEval = function t(e) {
  var n;
  if (e === "%AsyncFunction%")
    n = getEvalledConstructor("async function () {}");
  else if (e === "%GeneratorFunction%")
    n = getEvalledConstructor("function* () {}");
  else if (e === "%AsyncGeneratorFunction%")
    n = getEvalledConstructor("async function* () {}");
  else if (e === "%AsyncGenerator%") {
    var a = t("%AsyncGeneratorFunction%");
    a && (n = a.prototype);
  } else if (e === "%AsyncIteratorPrototype%") {
    var c = t("%AsyncGenerator%");
    c && getProto$1 && (n = getProto$1(c.prototype));
  }
  return INTRINSICS[e] = n, n;
}, LEGACY_ALIASES = {
  __proto__: null,
  "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
  "%ArrayPrototype%": ["Array", "prototype"],
  "%ArrayProto_entries%": ["Array", "prototype", "entries"],
  "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
  "%ArrayProto_keys%": ["Array", "prototype", "keys"],
  "%ArrayProto_values%": ["Array", "prototype", "values"],
  "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
  "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
  "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
  "%BooleanPrototype%": ["Boolean", "prototype"],
  "%DataViewPrototype%": ["DataView", "prototype"],
  "%DatePrototype%": ["Date", "prototype"],
  "%ErrorPrototype%": ["Error", "prototype"],
  "%EvalErrorPrototype%": ["EvalError", "prototype"],
  "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
  "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
  "%FunctionPrototype%": ["Function", "prototype"],
  "%Generator%": ["GeneratorFunction", "prototype"],
  "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
  "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
  "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
  "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
  "%JSONParse%": ["JSON", "parse"],
  "%JSONStringify%": ["JSON", "stringify"],
  "%MapPrototype%": ["Map", "prototype"],
  "%NumberPrototype%": ["Number", "prototype"],
  "%ObjectPrototype%": ["Object", "prototype"],
  "%ObjProto_toString%": ["Object", "prototype", "toString"],
  "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
  "%PromisePrototype%": ["Promise", "prototype"],
  "%PromiseProto_then%": ["Promise", "prototype", "then"],
  "%Promise_all%": ["Promise", "all"],
  "%Promise_reject%": ["Promise", "reject"],
  "%Promise_resolve%": ["Promise", "resolve"],
  "%RangeErrorPrototype%": ["RangeError", "prototype"],
  "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
  "%RegExpPrototype%": ["RegExp", "prototype"],
  "%SetPrototype%": ["Set", "prototype"],
  "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
  "%StringPrototype%": ["String", "prototype"],
  "%SymbolPrototype%": ["Symbol", "prototype"],
  "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
  "%TypedArrayPrototype%": ["TypedArray", "prototype"],
  "%TypeErrorPrototype%": ["TypeError", "prototype"],
  "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
  "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
  "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
  "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
  "%URIErrorPrototype%": ["URIError", "prototype"],
  "%WeakMapPrototype%": ["WeakMap", "prototype"],
  "%WeakSetPrototype%": ["WeakSet", "prototype"]
}, bind = functionBind, hasOwn = hasown, $concat = bind.call(Function.call, Array.prototype.concat), $spliceApply = bind.call(Function.apply, Array.prototype.splice), $replace = bind.call(Function.call, String.prototype.replace), $strSlice = bind.call(Function.call, String.prototype.slice), $exec = bind.call(Function.call, RegExp.prototype.exec), rePropName = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g, reEscapeChar = /\\(\\)?/g, stringToPath = function(e) {
  var n = $strSlice(e, 0, 1), a = $strSlice(e, -1);
  if (n === "%" && a !== "%")
    throw new $SyntaxError$1("invalid intrinsic syntax, expected closing `%`");
  if (a === "%" && n !== "%")
    throw new $SyntaxError$1("invalid intrinsic syntax, expected opening `%`");
  var c = [];
  return $replace(e, rePropName, function(o, u, h, p) {
    c[c.length] = h ? $replace(p, reEscapeChar, "$1") : u || o;
  }), c;
}, getBaseIntrinsic = function(e, n) {
  var a = e, c;
  if (hasOwn(LEGACY_ALIASES, a) && (c = LEGACY_ALIASES[a], a = "%" + c[0] + "%"), hasOwn(INTRINSICS, a)) {
    var o = INTRINSICS[a];
    if (o === needsEval && (o = doEval(a)), typeof o > "u" && !n)
      throw new $TypeError$2("intrinsic " + e + " exists, but is not available. Please file an issue!");
    return {
      alias: c,
      name: a,
      value: o
    };
  }
  throw new $SyntaxError$1("intrinsic " + e + " does not exist!");
}, getIntrinsic = function(e, n) {
  if (typeof e != "string" || e.length === 0)
    throw new $TypeError$2("intrinsic name must be a non-empty string");
  if (arguments.length > 1 && typeof n != "boolean")
    throw new $TypeError$2('"allowMissing" argument must be a boolean');
  if ($exec(/^%?[^%]*%?$/, e) === null)
    throw new $SyntaxError$1("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
  var a = stringToPath(e), c = a.length > 0 ? a[0] : "", o = getBaseIntrinsic("%" + c + "%", n), u = o.name, h = o.value, p = !1, x = o.alias;
  x && (c = x[0], $spliceApply(a, $concat([0, 1], x)));
  for (var l = 1, b = !0; l < a.length; l += 1) {
    var E = a[l], C = $strSlice(E, 0, 1), q = $strSlice(E, -1);
    if ((C === '"' || C === "'" || C === "`" || q === '"' || q === "'" || q === "`") && C !== q)
      throw new $SyntaxError$1("property names with quotes must have matching quotes");
    if ((E === "constructor" || !b) && (p = !0), c += "." + E, u = "%" + c + "%", hasOwn(INTRINSICS, u))
      h = INTRINSICS[u];
    else if (h != null) {
      if (!(E in h)) {
        if (!n)
          throw new $TypeError$2("base intrinsic for " + e + " exists, but the property is not available.");
        return;
      }
      if ($gOPD$1 && l + 1 >= a.length) {
        var F = $gOPD$1(h, E);
        b = !!F, b && "get" in F && !("originalValue" in F.get) ? h = F.get : h = h[E];
      } else
        b = hasOwn(h, E), h = h[E];
      b && !p && (INTRINSICS[u] = h);
    }
  }
  return h;
}, callBind$2 = { exports: {} }, esDefineProperty, hasRequiredEsDefineProperty;
function requireEsDefineProperty() {
  if (hasRequiredEsDefineProperty)
    return esDefineProperty;
  hasRequiredEsDefineProperty = 1;
  var t = getIntrinsic, e = t("%Object.defineProperty%", !0) || !1;
  if (e)
    try {
      e({}, "a", { value: 1 });
    } catch {
      e = !1;
    }
  return esDefineProperty = e, esDefineProperty;
}
var GetIntrinsic$2 = getIntrinsic, $gOPD = GetIntrinsic$2("%Object.getOwnPropertyDescriptor%", !0);
if ($gOPD)
  try {
    $gOPD([], "length");
  } catch {
    $gOPD = null;
  }
var gopd$1 = $gOPD, $defineProperty$1 = requireEsDefineProperty(), $SyntaxError = syntax, $TypeError$1 = type, gopd = gopd$1, defineDataProperty = function(e, n, a) {
  if (!e || typeof e != "object" && typeof e != "function")
    throw new $TypeError$1("`obj` must be an object or a function`");
  if (typeof n != "string" && typeof n != "symbol")
    throw new $TypeError$1("`property` must be a string or a symbol`");
  if (arguments.length > 3 && typeof arguments[3] != "boolean" && arguments[3] !== null)
    throw new $TypeError$1("`nonEnumerable`, if provided, must be a boolean or null");
  if (arguments.length > 4 && typeof arguments[4] != "boolean" && arguments[4] !== null)
    throw new $TypeError$1("`nonWritable`, if provided, must be a boolean or null");
  if (arguments.length > 5 && typeof arguments[5] != "boolean" && arguments[5] !== null)
    throw new $TypeError$1("`nonConfigurable`, if provided, must be a boolean or null");
  if (arguments.length > 6 && typeof arguments[6] != "boolean")
    throw new $TypeError$1("`loose`, if provided, must be a boolean");
  var c = arguments.length > 3 ? arguments[3] : null, o = arguments.length > 4 ? arguments[4] : null, u = arguments.length > 5 ? arguments[5] : null, h = arguments.length > 6 ? arguments[6] : !1, p = !!gopd && gopd(e, n);
  if ($defineProperty$1)
    $defineProperty$1(e, n, {
      configurable: u === null && p ? p.configurable : !u,
      enumerable: c === null && p ? p.enumerable : !c,
      value: a,
      writable: o === null && p ? p.writable : !o
    });
  else if (h || !c && !o && !u)
    e[n] = a;
  else
    throw new $SyntaxError("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.");
}, $defineProperty = requireEsDefineProperty(), hasPropertyDescriptors = function() {
  return !!$defineProperty;
};
hasPropertyDescriptors.hasArrayLengthDefineBug = function() {
  if (!$defineProperty)
    return null;
  try {
    return $defineProperty([], "length", { value: 1 }).length !== 1;
  } catch {
    return !0;
  }
};
var hasPropertyDescriptors_1 = hasPropertyDescriptors, GetIntrinsic$1 = getIntrinsic, define = defineDataProperty, hasDescriptors = hasPropertyDescriptors_1(), gOPD$1 = gopd$1, $TypeError = type, $floor = GetIntrinsic$1("%Math.floor%"), setFunctionLength = function(e, n) {
  if (typeof e != "function")
    throw new $TypeError("`fn` is not a function");
  if (typeof n != "number" || n < 0 || n > 4294967295 || $floor(n) !== n)
    throw new $TypeError("`length` must be a positive 32-bit integer");
  var a = arguments.length > 2 && !!arguments[2], c = !0, o = !0;
  if ("length" in e && gOPD$1) {
    var u = gOPD$1(e, "length");
    u && !u.configurable && (c = !1), u && !u.writable && (o = !1);
  }
  return (c || o || !a) && (hasDescriptors ? define(
    /** @type {Parameters<define>[0]} */
    e,
    "length",
    n,
    !0,
    !0
  ) : define(
    /** @type {Parameters<define>[0]} */
    e,
    "length",
    n
  )), e;
};
(function(t) {
  var e = functionBind, n = getIntrinsic, a = setFunctionLength, c = type, o = n("%Function.prototype.apply%"), u = n("%Function.prototype.call%"), h = n("%Reflect.apply%", !0) || e.call(u, o), p = requireEsDefineProperty(), x = n("%Math.max%");
  t.exports = function(E) {
    if (typeof E != "function")
      throw new c("a function is required");
    var C = h(e, u, arguments);
    return a(
      C,
      1 + x(0, E.length - (arguments.length - 1)),
      !0
    );
  };
  var l = function() {
    return h(e, o, arguments);
  };
  p ? p(t.exports, "apply", { value: l }) : t.exports.apply = l;
})(callBind$2);
var callBindExports = callBind$2.exports, GetIntrinsic = getIntrinsic, callBind$1 = callBindExports, $indexOf$1 = callBind$1(GetIntrinsic("String.prototype.indexOf")), callBound$2 = function(e, n) {
  var a = GetIntrinsic(e, !!n);
  return typeof a == "function" && $indexOf$1(e, ".prototype.") > -1 ? callBind$1(a) : a;
}, hasToStringTag$3 = shams(), callBound$1 = callBound$2, $toString$1 = callBound$1("Object.prototype.toString"), isStandardArguments = function(e) {
  return hasToStringTag$3 && e && typeof e == "object" && Symbol.toStringTag in e ? !1 : $toString$1(e) === "[object Arguments]";
}, isLegacyArguments = function(e) {
  return isStandardArguments(e) ? !0 : e !== null && typeof e == "object" && typeof e.length == "number" && e.length >= 0 && $toString$1(e) !== "[object Array]" && $toString$1(e.callee) === "[object Function]";
}, supportsStandardArguments = function() {
  return isStandardArguments(arguments);
}();
isStandardArguments.isLegacyArguments = isLegacyArguments;
var isArguments = supportsStandardArguments ? isStandardArguments : isLegacyArguments, toStr$2 = Object.prototype.toString, fnToStr$1 = Function.prototype.toString, isFnRegex = /^\s*(?:function)?\*/, hasToStringTag$2 = shams(), getProto = Object.getPrototypeOf, getGeneratorFunc = function() {
  if (!hasToStringTag$2)
    return !1;
  try {
    return Function("return function*() {}")();
  } catch {
  }
}, GeneratorFunction, isGeneratorFunction = function(e) {
  if (typeof e != "function")
    return !1;
  if (isFnRegex.test(fnToStr$1.call(e)))
    return !0;
  if (!hasToStringTag$2) {
    var n = toStr$2.call(e);
    return n === "[object GeneratorFunction]";
  }
  if (!getProto)
    return !1;
  if (typeof GeneratorFunction > "u") {
    var a = getGeneratorFunc();
    GeneratorFunction = a ? getProto(a) : !1;
  }
  return getProto(e) === GeneratorFunction;
}, fnToStr = Function.prototype.toString, reflectApply = typeof Reflect == "object" && Reflect !== null && Reflect.apply, badArrayLike, isCallableMarker;
if (typeof reflectApply == "function" && typeof Object.defineProperty == "function")
  try {
    badArrayLike = Object.defineProperty({}, "length", {
      get: function() {
        throw isCallableMarker;
      }
    }), isCallableMarker = {}, reflectApply(function() {
      throw 42;
    }, null, badArrayLike);
  } catch (t) {
    t !== isCallableMarker && (reflectApply = null);
  }
else
  reflectApply = null;
var constructorRegex = /^\s*class\b/, isES6ClassFn = function(e) {
  try {
    var n = fnToStr.call(e);
    return constructorRegex.test(n);
  } catch {
    return !1;
  }
}, tryFunctionObject = function(e) {
  try {
    return isES6ClassFn(e) ? !1 : (fnToStr.call(e), !0);
  } catch {
    return !1;
  }
}, toStr$1 = Object.prototype.toString, objectClass = "[object Object]", fnClass = "[object Function]", genClass = "[object GeneratorFunction]", ddaClass = "[object HTMLAllCollection]", ddaClass2 = "[object HTML document.all class]", ddaClass3 = "[object HTMLCollection]", hasToStringTag$1 = typeof Symbol == "function" && !!Symbol.toStringTag, isIE68 = !(0 in [,]), isDDA = function() {
  return !1;
};
if (typeof document == "object") {
  var all = document.all;
  toStr$1.call(all) === toStr$1.call(document.all) && (isDDA = function(e) {
    if ((isIE68 || !e) && (typeof e > "u" || typeof e == "object"))
      try {
        var n = toStr$1.call(e);
        return (n === ddaClass || n === ddaClass2 || n === ddaClass3 || n === objectClass) && e("") == null;
      } catch {
      }
    return !1;
  });
}
var isCallable$1 = reflectApply ? function(e) {
  if (isDDA(e))
    return !0;
  if (!e || typeof e != "function" && typeof e != "object")
    return !1;
  try {
    reflectApply(e, null, badArrayLike);
  } catch (n) {
    if (n !== isCallableMarker)
      return !1;
  }
  return !isES6ClassFn(e) && tryFunctionObject(e);
} : function(e) {
  if (isDDA(e))
    return !0;
  if (!e || typeof e != "function" && typeof e != "object")
    return !1;
  if (hasToStringTag$1)
    return tryFunctionObject(e);
  if (isES6ClassFn(e))
    return !1;
  var n = toStr$1.call(e);
  return n !== fnClass && n !== genClass && !/^\[object HTML/.test(n) ? !1 : tryFunctionObject(e);
}, isCallable = isCallable$1, toStr = Object.prototype.toString, hasOwnProperty = Object.prototype.hasOwnProperty, forEachArray = function(e, n, a) {
  for (var c = 0, o = e.length; c < o; c++)
    hasOwnProperty.call(e, c) && (a == null ? n(e[c], c, e) : n.call(a, e[c], c, e));
}, forEachString = function(e, n, a) {
  for (var c = 0, o = e.length; c < o; c++)
    a == null ? n(e.charAt(c), c, e) : n.call(a, e.charAt(c), c, e);
}, forEachObject = function(e, n, a) {
  for (var c in e)
    hasOwnProperty.call(e, c) && (a == null ? n(e[c], c, e) : n.call(a, e[c], c, e));
}, forEach$1 = function(e, n, a) {
  if (!isCallable(n))
    throw new TypeError("iterator must be a function");
  var c;
  arguments.length >= 3 && (c = a), toStr.call(e) === "[object Array]" ? forEachArray(e, n, c) : typeof e == "string" ? forEachString(e, n, c) : forEachObject(e, n, c);
}, forEach_1 = forEach$1, possibleTypedArrayNames = [
  "Float32Array",
  "Float64Array",
  "Int8Array",
  "Int16Array",
  "Int32Array",
  "Uint8Array",
  "Uint8ClampedArray",
  "Uint16Array",
  "Uint32Array",
  "BigInt64Array",
  "BigUint64Array"
], possibleNames = possibleTypedArrayNames, g$1 = typeof globalThis > "u" ? commonjsGlobal : globalThis, availableTypedArrays$1 = function() {
  for (var e = [], n = 0; n < possibleNames.length; n++)
    typeof g$1[possibleNames[n]] == "function" && (e[e.length] = possibleNames[n]);
  return e;
}, forEach = forEach_1, availableTypedArrays = availableTypedArrays$1, callBind = callBindExports, callBound = callBound$2, gOPD = gopd$1, $toString = callBound("Object.prototype.toString"), hasToStringTag = shams(), g = typeof globalThis > "u" ? commonjsGlobal : globalThis, typedArrays = availableTypedArrays(), $slice = callBound("String.prototype.slice"), getPrototypeOf = Object.getPrototypeOf, $indexOf = callBound("Array.prototype.indexOf", !0) || function(e, n) {
  for (var a = 0; a < e.length; a += 1)
    if (e[a] === n)
      return a;
  return -1;
}, cache = { __proto__: null };
hasToStringTag && gOPD && getPrototypeOf ? forEach(typedArrays, function(t) {
  var e = new g[t]();
  if (Symbol.toStringTag in e) {
    var n = getPrototypeOf(e), a = gOPD(n, Symbol.toStringTag);
    if (!a) {
      var c = getPrototypeOf(n);
      a = gOPD(c, Symbol.toStringTag);
    }
    cache["$" + t] = callBind(a.get);
  }
}) : forEach(typedArrays, function(t) {
  var e = new g[t](), n = e.slice || e.set;
  n && (cache["$" + t] = callBind(n));
});
var tryTypedArrays = function(e) {
  var n = !1;
  return forEach(
    // eslint-disable-next-line no-extra-parens
    /** @type {Record<`\$${TypedArrayName}`, Getter>} */
    /** @type {any} */
    cache,
    /** @type {(getter: Getter, name: `\$${import('.').TypedArrayName}`) => void} */
    function(a, c) {
      if (!n)
        try {
          "$" + a(e) === c && (n = $slice(c, 1));
        } catch {
        }
    }
  ), n;
}, trySlices = function(e) {
  var n = !1;
  return forEach(
    // eslint-disable-next-line no-extra-parens
    /** @type {Record<`\$${TypedArrayName}`, Getter>} */
    /** @type {any} */
    cache,
    /** @type {(getter: typeof cache, name: `\$${import('.').TypedArrayName}`) => void} */
    function(a, c) {
      if (!n)
        try {
          a(e), n = $slice(c, 1);
        } catch {
        }
    }
  ), n;
}, whichTypedArray$1 = function(e) {
  if (!e || typeof e != "object")
    return !1;
  if (!hasToStringTag) {
    var n = $slice($toString(e), 8, -1);
    return $indexOf(typedArrays, n) > -1 ? n : n !== "Object" ? !1 : trySlices(e);
  }
  return gOPD ? tryTypedArrays(e) : null;
}, whichTypedArray = whichTypedArray$1, isTypedArray = function(e) {
  return !!whichTypedArray(e);
};
(function(t) {
  var e = isArguments, n = isGeneratorFunction, a = whichTypedArray$1, c = isTypedArray;
  function o(oe) {
    return oe.call.bind(oe);
  }
  var u = typeof BigInt < "u", h = typeof Symbol < "u", p = o(Object.prototype.toString), x = o(Number.prototype.valueOf), l = o(String.prototype.valueOf), b = o(Boolean.prototype.valueOf);
  if (u)
    var E = o(BigInt.prototype.valueOf);
  if (h)
    var C = o(Symbol.prototype.valueOf);
  function q(oe, qe) {
    if (typeof oe != "object")
      return !1;
    try {
      return qe(oe), !0;
    } catch {
      return !1;
    }
  }
  t.isArgumentsObject = e, t.isGeneratorFunction = n, t.isTypedArray = c;
  function F(oe) {
    return typeof Promise < "u" && oe instanceof Promise || oe !== null && typeof oe == "object" && typeof oe.then == "function" && typeof oe.catch == "function";
  }
  t.isPromise = F;
  function z(oe) {
    return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? ArrayBuffer.isView(oe) : c(oe) || T(oe);
  }
  t.isArrayBufferView = z;
  function H(oe) {
    return a(oe) === "Uint8Array";
  }
  t.isUint8Array = H;
  function U(oe) {
    return a(oe) === "Uint8ClampedArray";
  }
  t.isUint8ClampedArray = U;
  function Y(oe) {
    return a(oe) === "Uint16Array";
  }
  t.isUint16Array = Y;
  function ee(oe) {
    return a(oe) === "Uint32Array";
  }
  t.isUint32Array = ee;
  function se(oe) {
    return a(oe) === "Int8Array";
  }
  t.isInt8Array = se;
  function fe(oe) {
    return a(oe) === "Int16Array";
  }
  t.isInt16Array = fe;
  function pe(oe) {
    return a(oe) === "Int32Array";
  }
  t.isInt32Array = pe;
  function ue(oe) {
    return a(oe) === "Float32Array";
  }
  t.isFloat32Array = ue;
  function ce(oe) {
    return a(oe) === "Float64Array";
  }
  t.isFloat64Array = ce;
  function $e(oe) {
    return a(oe) === "BigInt64Array";
  }
  t.isBigInt64Array = $e;
  function V(oe) {
    return a(oe) === "BigUint64Array";
  }
  t.isBigUint64Array = V;
  function _(oe) {
    return p(oe) === "[object Map]";
  }
  _.working = typeof Map < "u" && _(/* @__PURE__ */ new Map());
  function w(oe) {
    return typeof Map > "u" ? !1 : _.working ? _(oe) : oe instanceof Map;
  }
  t.isMap = w;
  function d(oe) {
    return p(oe) === "[object Set]";
  }
  d.working = typeof Set < "u" && d(/* @__PURE__ */ new Set());
  function m(oe) {
    return typeof Set > "u" ? !1 : d.working ? d(oe) : oe instanceof Set;
  }
  t.isSet = m;
  function B(oe) {
    return p(oe) === "[object WeakMap]";
  }
  B.working = typeof WeakMap < "u" && B(/* @__PURE__ */ new WeakMap());
  function $(oe) {
    return typeof WeakMap > "u" ? !1 : B.working ? B(oe) : oe instanceof WeakMap;
  }
  t.isWeakMap = $;
  function P(oe) {
    return p(oe) === "[object WeakSet]";
  }
  P.working = typeof WeakSet < "u" && P(/* @__PURE__ */ new WeakSet());
  function M(oe) {
    return P(oe);
  }
  t.isWeakSet = M;
  function v(oe) {
    return p(oe) === "[object ArrayBuffer]";
  }
  v.working = typeof ArrayBuffer < "u" && v(new ArrayBuffer());
  function A(oe) {
    return typeof ArrayBuffer > "u" ? !1 : v.working ? v(oe) : oe instanceof ArrayBuffer;
  }
  t.isArrayBuffer = A;
  function y(oe) {
    return p(oe) === "[object DataView]";
  }
  y.working = typeof ArrayBuffer < "u" && typeof DataView < "u" && y(new DataView(new ArrayBuffer(1), 0, 1));
  function T(oe) {
    return typeof DataView > "u" ? !1 : y.working ? y(oe) : oe instanceof DataView;
  }
  t.isDataView = T;
  var Z = typeof SharedArrayBuffer < "u" ? SharedArrayBuffer : void 0;
  function ie(oe) {
    return p(oe) === "[object SharedArrayBuffer]";
  }
  function J(oe) {
    return typeof Z > "u" ? !1 : (typeof ie.working > "u" && (ie.working = ie(new Z())), ie.working ? ie(oe) : oe instanceof Z);
  }
  t.isSharedArrayBuffer = J;
  function k(oe) {
    return p(oe) === "[object AsyncFunction]";
  }
  t.isAsyncFunction = k;
  function D(oe) {
    return p(oe) === "[object Map Iterator]";
  }
  t.isMapIterator = D;
  function X(oe) {
    return p(oe) === "[object Set Iterator]";
  }
  t.isSetIterator = X;
  function te(oe) {
    return p(oe) === "[object Generator]";
  }
  t.isGeneratorObject = te;
  function N(oe) {
    return p(oe) === "[object WebAssembly.Module]";
  }
  t.isWebAssemblyCompiledModule = N;
  function O(oe) {
    return q(oe, x);
  }
  t.isNumberObject = O;
  function ne(oe) {
    return q(oe, l);
  }
  t.isStringObject = ne;
  function de(oe) {
    return q(oe, b);
  }
  t.isBooleanObject = de;
  function le(oe) {
    return u && q(oe, E);
  }
  t.isBigIntObject = le;
  function he(oe) {
    return h && q(oe, C);
  }
  t.isSymbolObject = he;
  function me(oe) {
    return O(oe) || ne(oe) || de(oe) || le(oe) || he(oe);
  }
  t.isBoxedPrimitive = me;
  function ge(oe) {
    return typeof Uint8Array < "u" && (A(oe) || J(oe));
  }
  t.isAnyArrayBuffer = ge, ["isProxy", "isExternal", "isModuleNamespaceObject"].forEach(function(oe) {
    Object.defineProperty(t, oe, {
      enumerable: !1,
      value: function() {
        throw new Error(oe + " is not supported in userland");
      }
    });
  });
})(types);
var isBufferBrowser = function(e) {
  return e && typeof e == "object" && typeof e.copy == "function" && typeof e.fill == "function" && typeof e.readUInt8 == "function";
};
(function(t) {
  var e = Object.getOwnPropertyDescriptors || function(T) {
    for (var Z = Object.keys(T), ie = {}, J = 0; J < Z.length; J++)
      ie[Z[J]] = Object.getOwnPropertyDescriptor(T, Z[J]);
    return ie;
  }, n = /%[sdj%]/g;
  t.format = function(y) {
    if (!se(y)) {
      for (var T = [], Z = 0; Z < arguments.length; Z++)
        T.push(u(arguments[Z]));
      return T.join(" ");
    }
    for (var Z = 1, ie = arguments, J = ie.length, k = String(y).replace(n, function(X) {
      if (X === "%%")
        return "%";
      if (Z >= J)
        return X;
      switch (X) {
        case "%s":
          return String(ie[Z++]);
        case "%d":
          return Number(ie[Z++]);
        case "%j":
          try {
            return JSON.stringify(ie[Z++]);
          } catch {
            return "[Circular]";
          }
        default:
          return X;
      }
    }), D = ie[Z]; Z < J; D = ie[++Z])
      U(D) || !ce(D) ? k += " " + D : k += " " + u(D);
    return k;
  }, t.deprecate = function(y, T) {
    if (typeof process$1 < "u" && process$1.noDeprecation === !0)
      return y;
    if (typeof process$1 > "u")
      return function() {
        return t.deprecate(y, T).apply(this, arguments);
      };
    var Z = !1;
    function ie() {
      if (!Z) {
        if (process$1.throwDeprecation)
          throw new Error(T);
        process$1.traceDeprecation ? console.trace(T) : console.error(T), Z = !0;
      }
      return y.apply(this, arguments);
    }
    return ie;
  };
  var a = {}, c = /^$/;
  if (process$1.env.NODE_DEBUG) {
    var o = process$1.env.NODE_DEBUG;
    o = o.replace(/[|\\{}()[\]^$+?.]/g, "\\$&").replace(/\*/g, ".*").replace(/,/g, "$|^").toUpperCase(), c = new RegExp("^" + o + "$", "i");
  }
  t.debuglog = function(y) {
    if (y = y.toUpperCase(), !a[y])
      if (c.test(y)) {
        var T = process$1.pid;
        a[y] = function() {
          var Z = t.format.apply(t, arguments);
          console.error("%s %d: %s", y, T, Z);
        };
      } else
        a[y] = function() {
        };
    return a[y];
  };
  function u(y, T) {
    var Z = {
      seen: [],
      stylize: p
    };
    return arguments.length >= 3 && (Z.depth = arguments[2]), arguments.length >= 4 && (Z.colors = arguments[3]), H(T) ? Z.showHidden = T : T && t._extend(Z, T), pe(Z.showHidden) && (Z.showHidden = !1), pe(Z.depth) && (Z.depth = 2), pe(Z.colors) && (Z.colors = !1), pe(Z.customInspect) && (Z.customInspect = !0), Z.colors && (Z.stylize = h), l(Z, y, Z.depth);
  }
  t.inspect = u, u.colors = {
    bold: [1, 22],
    italic: [3, 23],
    underline: [4, 24],
    inverse: [7, 27],
    white: [37, 39],
    grey: [90, 39],
    black: [30, 39],
    blue: [34, 39],
    cyan: [36, 39],
    green: [32, 39],
    magenta: [35, 39],
    red: [31, 39],
    yellow: [33, 39]
  }, u.styles = {
    special: "cyan",
    number: "yellow",
    boolean: "yellow",
    undefined: "grey",
    null: "bold",
    string: "green",
    date: "magenta",
    // "name": intentionally not styling
    regexp: "red"
  };
  function h(y, T) {
    var Z = u.styles[T];
    return Z ? "\x1B[" + u.colors[Z][0] + "m" + y + "\x1B[" + u.colors[Z][1] + "m" : y;
  }
  function p(y, T) {
    return y;
  }
  function x(y) {
    var T = {};
    return y.forEach(function(Z, ie) {
      T[Z] = !0;
    }), T;
  }
  function l(y, T, Z) {
    if (y.customInspect && T && _(T.inspect) && // Filter out the util module, it's inspect function is special
    T.inspect !== t.inspect && // Also filter out any prototype objects using the circular check.
    !(T.constructor && T.constructor.prototype === T)) {
      var ie = T.inspect(Z, y);
      return se(ie) || (ie = l(y, ie, Z)), ie;
    }
    var J = b(y, T);
    if (J)
      return J;
    var k = Object.keys(T), D = x(k);
    if (y.showHidden && (k = Object.getOwnPropertyNames(T)), V(T) && (k.indexOf("message") >= 0 || k.indexOf("description") >= 0))
      return E(T);
    if (k.length === 0) {
      if (_(T)) {
        var X = T.name ? ": " + T.name : "";
        return y.stylize("[Function" + X + "]", "special");
      }
      if (ue(T))
        return y.stylize(RegExp.prototype.toString.call(T), "regexp");
      if ($e(T))
        return y.stylize(Date.prototype.toString.call(T), "date");
      if (V(T))
        return E(T);
    }
    var te = "", N = !1, O = ["{", "}"];
    if (z(T) && (N = !0, O = ["[", "]"]), _(T)) {
      var ne = T.name ? ": " + T.name : "";
      te = " [Function" + ne + "]";
    }
    if (ue(T) && (te = " " + RegExp.prototype.toString.call(T)), $e(T) && (te = " " + Date.prototype.toUTCString.call(T)), V(T) && (te = " " + E(T)), k.length === 0 && (!N || T.length == 0))
      return O[0] + te + O[1];
    if (Z < 0)
      return ue(T) ? y.stylize(RegExp.prototype.toString.call(T), "regexp") : y.stylize("[Object]", "special");
    y.seen.push(T);
    var de;
    return N ? de = C(y, T, Z, D, k) : de = k.map(function(le) {
      return q(y, T, Z, D, le, N);
    }), y.seen.pop(), F(de, te, O);
  }
  function b(y, T) {
    if (pe(T))
      return y.stylize("undefined", "undefined");
    if (se(T)) {
      var Z = "'" + JSON.stringify(T).replace(/^"|"$/g, "").replace(/'/g, "\\'").replace(/\\"/g, '"') + "'";
      return y.stylize(Z, "string");
    }
    if (ee(T))
      return y.stylize("" + T, "number");
    if (H(T))
      return y.stylize("" + T, "boolean");
    if (U(T))
      return y.stylize("null", "null");
  }
  function E(y) {
    return "[" + Error.prototype.toString.call(y) + "]";
  }
  function C(y, T, Z, ie, J) {
    for (var k = [], D = 0, X = T.length; D < X; ++D)
      P(T, String(D)) ? k.push(q(
        y,
        T,
        Z,
        ie,
        String(D),
        !0
      )) : k.push("");
    return J.forEach(function(te) {
      te.match(/^\d+$/) || k.push(q(
        y,
        T,
        Z,
        ie,
        te,
        !0
      ));
    }), k;
  }
  function q(y, T, Z, ie, J, k) {
    var D, X, te;
    if (te = Object.getOwnPropertyDescriptor(T, J) || { value: T[J] }, te.get ? te.set ? X = y.stylize("[Getter/Setter]", "special") : X = y.stylize("[Getter]", "special") : te.set && (X = y.stylize("[Setter]", "special")), P(ie, J) || (D = "[" + J + "]"), X || (y.seen.indexOf(te.value) < 0 ? (U(Z) ? X = l(y, te.value, null) : X = l(y, te.value, Z - 1), X.indexOf(`
`) > -1 && (k ? X = X.split(`
`).map(function(N) {
      return "  " + N;
    }).join(`
`).slice(2) : X = `
` + X.split(`
`).map(function(N) {
      return "   " + N;
    }).join(`
`))) : X = y.stylize("[Circular]", "special")), pe(D)) {
      if (k && J.match(/^\d+$/))
        return X;
      D = JSON.stringify("" + J), D.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/) ? (D = D.slice(1, -1), D = y.stylize(D, "name")) : (D = D.replace(/'/g, "\\'").replace(/\\"/g, '"').replace(/(^"|"$)/g, "'"), D = y.stylize(D, "string"));
    }
    return D + ": " + X;
  }
  function F(y, T, Z) {
    var ie = y.reduce(function(J, k) {
      return k.indexOf(`
`) >= 0, J + k.replace(/\u001b\[\d\d?m/g, "").length + 1;
    }, 0);
    return ie > 60 ? Z[0] + (T === "" ? "" : T + `
 `) + " " + y.join(`,
  `) + " " + Z[1] : Z[0] + T + " " + y.join(", ") + " " + Z[1];
  }
  t.types = types;
  function z(y) {
    return Array.isArray(y);
  }
  t.isArray = z;
  function H(y) {
    return typeof y == "boolean";
  }
  t.isBoolean = H;
  function U(y) {
    return y === null;
  }
  t.isNull = U;
  function Y(y) {
    return y == null;
  }
  t.isNullOrUndefined = Y;
  function ee(y) {
    return typeof y == "number";
  }
  t.isNumber = ee;
  function se(y) {
    return typeof y == "string";
  }
  t.isString = se;
  function fe(y) {
    return typeof y == "symbol";
  }
  t.isSymbol = fe;
  function pe(y) {
    return y === void 0;
  }
  t.isUndefined = pe;
  function ue(y) {
    return ce(y) && d(y) === "[object RegExp]";
  }
  t.isRegExp = ue, t.types.isRegExp = ue;
  function ce(y) {
    return typeof y == "object" && y !== null;
  }
  t.isObject = ce;
  function $e(y) {
    return ce(y) && d(y) === "[object Date]";
  }
  t.isDate = $e, t.types.isDate = $e;
  function V(y) {
    return ce(y) && (d(y) === "[object Error]" || y instanceof Error);
  }
  t.isError = V, t.types.isNativeError = V;
  function _(y) {
    return typeof y == "function";
  }
  t.isFunction = _;
  function w(y) {
    return y === null || typeof y == "boolean" || typeof y == "number" || typeof y == "string" || typeof y == "symbol" || // ES6 symbol
    typeof y > "u";
  }
  t.isPrimitive = w, t.isBuffer = isBufferBrowser;
  function d(y) {
    return Object.prototype.toString.call(y);
  }
  function m(y) {
    return y < 10 ? "0" + y.toString(10) : y.toString(10);
  }
  var B = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];
  function $() {
    var y = /* @__PURE__ */ new Date(), T = [
      m(y.getHours()),
      m(y.getMinutes()),
      m(y.getSeconds())
    ].join(":");
    return [y.getDate(), B[y.getMonth()], T].join(" ");
  }
  t.log = function() {
    console.log("%s - %s", $(), t.format.apply(t, arguments));
  }, t.inherits = inherits_browserExports, t._extend = function(y, T) {
    if (!T || !ce(T))
      return y;
    for (var Z = Object.keys(T), ie = Z.length; ie--; )
      y[Z[ie]] = T[Z[ie]];
    return y;
  };
  function P(y, T) {
    return Object.prototype.hasOwnProperty.call(y, T);
  }
  var M = typeof Symbol < "u" ? Symbol("util.promisify.custom") : void 0;
  t.promisify = function(T) {
    if (typeof T != "function")
      throw new TypeError('The "original" argument must be of type Function');
    if (M && T[M]) {
      var Z = T[M];
      if (typeof Z != "function")
        throw new TypeError('The "util.promisify.custom" argument must be of type Function');
      return Object.defineProperty(Z, M, {
        value: Z,
        enumerable: !1,
        writable: !1,
        configurable: !0
      }), Z;
    }
    function Z() {
      for (var ie, J, k = new Promise(function(te, N) {
        ie = te, J = N;
      }), D = [], X = 0; X < arguments.length; X++)
        D.push(arguments[X]);
      D.push(function(te, N) {
        te ? J(te) : ie(N);
      });
      try {
        T.apply(this, D);
      } catch (te) {
        J(te);
      }
      return k;
    }
    return Object.setPrototypeOf(Z, Object.getPrototypeOf(T)), M && Object.defineProperty(Z, M, {
      value: Z,
      enumerable: !1,
      writable: !1,
      configurable: !0
    }), Object.defineProperties(
      Z,
      e(T)
    );
  }, t.promisify.custom = M;
  function v(y, T) {
    if (!y) {
      var Z = new Error("Promise was rejected with a falsy value");
      Z.reason = y, y = Z;
    }
    return T(y);
  }
  function A(y) {
    if (typeof y != "function")
      throw new TypeError('The "original" argument must be of type Function');
    function T() {
      for (var Z = [], ie = 0; ie < arguments.length; ie++)
        Z.push(arguments[ie]);
      var J = Z.pop();
      if (typeof J != "function")
        throw new TypeError("The last argument must be of type Function");
      var k = this, D = function() {
        return J.apply(k, arguments);
      };
      y.apply(this, Z).then(
        function(X) {
          process$1.nextTick(D.bind(null, null, X));
        },
        function(X) {
          process$1.nextTick(v.bind(null, X, D));
        }
      );
    }
    return Object.setPrototypeOf(T, Object.getPrototypeOf(y)), Object.defineProperties(
      T,
      e(y)
    ), T;
  }
  t.callbackify = A;
})(util$3);
var buffer_list, hasRequiredBuffer_list;
function requireBuffer_list() {
  if (hasRequiredBuffer_list)
    return buffer_list;
  hasRequiredBuffer_list = 1;
  function t(q, F) {
    var z = Object.keys(q);
    if (Object.getOwnPropertySymbols) {
      var H = Object.getOwnPropertySymbols(q);
      F && (H = H.filter(function(U) {
        return Object.getOwnPropertyDescriptor(q, U).enumerable;
      })), z.push.apply(z, H);
    }
    return z;
  }
  function e(q) {
    for (var F = 1; F < arguments.length; F++) {
      var z = arguments[F] != null ? arguments[F] : {};
      F % 2 ? t(Object(z), !0).forEach(function(H) {
        n(q, H, z[H]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(q, Object.getOwnPropertyDescriptors(z)) : t(Object(z)).forEach(function(H) {
        Object.defineProperty(q, H, Object.getOwnPropertyDescriptor(z, H));
      });
    }
    return q;
  }
  function n(q, F, z) {
    return F = u(F), F in q ? Object.defineProperty(q, F, { value: z, enumerable: !0, configurable: !0, writable: !0 }) : q[F] = z, q;
  }
  function a(q, F) {
    if (!(q instanceof F))
      throw new TypeError("Cannot call a class as a function");
  }
  function c(q, F) {
    for (var z = 0; z < F.length; z++) {
      var H = F[z];
      H.enumerable = H.enumerable || !1, H.configurable = !0, "value" in H && (H.writable = !0), Object.defineProperty(q, u(H.key), H);
    }
  }
  function o(q, F, z) {
    return F && c(q.prototype, F), Object.defineProperty(q, "prototype", { writable: !1 }), q;
  }
  function u(q) {
    var F = h(q, "string");
    return typeof F == "symbol" ? F : String(F);
  }
  function h(q, F) {
    if (typeof q != "object" || q === null)
      return q;
    var z = q[Symbol.toPrimitive];
    if (z !== void 0) {
      var H = z.call(q, F || "default");
      if (typeof H != "object")
        return H;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (F === "string" ? String : Number)(q);
  }
  var p = require$$1$2, x = p.Buffer, l = util$3, b = l.inspect, E = b && b.custom || "inspect";
  function C(q, F, z) {
    x.prototype.copy.call(q, F, z);
  }
  return buffer_list = /* @__PURE__ */ function() {
    function q() {
      a(this, q), this.head = null, this.tail = null, this.length = 0;
    }
    return o(q, [{
      key: "push",
      value: function(z) {
        var H = {
          data: z,
          next: null
        };
        this.length > 0 ? this.tail.next = H : this.head = H, this.tail = H, ++this.length;
      }
    }, {
      key: "unshift",
      value: function(z) {
        var H = {
          data: z,
          next: this.head
        };
        this.length === 0 && (this.tail = H), this.head = H, ++this.length;
      }
    }, {
      key: "shift",
      value: function() {
        if (this.length !== 0) {
          var z = this.head.data;
          return this.length === 1 ? this.head = this.tail = null : this.head = this.head.next, --this.length, z;
        }
      }
    }, {
      key: "clear",
      value: function() {
        this.head = this.tail = null, this.length = 0;
      }
    }, {
      key: "join",
      value: function(z) {
        if (this.length === 0)
          return "";
        for (var H = this.head, U = "" + H.data; H = H.next; )
          U += z + H.data;
        return U;
      }
    }, {
      key: "concat",
      value: function(z) {
        if (this.length === 0)
          return x.alloc(0);
        for (var H = x.allocUnsafe(z >>> 0), U = this.head, Y = 0; U; )
          C(U.data, H, Y), Y += U.data.length, U = U.next;
        return H;
      }
      // Consumes a specified amount of bytes or characters from the buffered data.
    }, {
      key: "consume",
      value: function(z, H) {
        var U;
        return z < this.head.data.length ? (U = this.head.data.slice(0, z), this.head.data = this.head.data.slice(z)) : z === this.head.data.length ? U = this.shift() : U = H ? this._getString(z) : this._getBuffer(z), U;
      }
    }, {
      key: "first",
      value: function() {
        return this.head.data;
      }
      // Consumes a specified amount of characters from the buffered data.
    }, {
      key: "_getString",
      value: function(z) {
        var H = this.head, U = 1, Y = H.data;
        for (z -= Y.length; H = H.next; ) {
          var ee = H.data, se = z > ee.length ? ee.length : z;
          if (se === ee.length ? Y += ee : Y += ee.slice(0, z), z -= se, z === 0) {
            se === ee.length ? (++U, H.next ? this.head = H.next : this.head = this.tail = null) : (this.head = H, H.data = ee.slice(se));
            break;
          }
          ++U;
        }
        return this.length -= U, Y;
      }
      // Consumes a specified amount of bytes from the buffered data.
    }, {
      key: "_getBuffer",
      value: function(z) {
        var H = x.allocUnsafe(z), U = this.head, Y = 1;
        for (U.data.copy(H), z -= U.data.length; U = U.next; ) {
          var ee = U.data, se = z > ee.length ? ee.length : z;
          if (ee.copy(H, H.length - z, 0, se), z -= se, z === 0) {
            se === ee.length ? (++Y, U.next ? this.head = U.next : this.head = this.tail = null) : (this.head = U, U.data = ee.slice(se));
            break;
          }
          ++Y;
        }
        return this.length -= Y, H;
      }
      // Make sure the linked list only shows the minimal necessary information.
    }, {
      key: E,
      value: function(z, H) {
        return b(this, e(e({}, H), {}, {
          // Only inspect one level.
          depth: 0,
          // It should not recurse.
          customInspect: !1
        }));
      }
    }]), q;
  }(), buffer_list;
}
var destroy_1$1, hasRequiredDestroy;
function requireDestroy() {
  if (hasRequiredDestroy)
    return destroy_1$1;
  hasRequiredDestroy = 1;
  function t(u, h) {
    var p = this, x = this._readableState && this._readableState.destroyed, l = this._writableState && this._writableState.destroyed;
    return x || l ? (h ? h(u) : u && (this._writableState ? this._writableState.errorEmitted || (this._writableState.errorEmitted = !0, process$1.nextTick(c, this, u)) : process$1.nextTick(c, this, u)), this) : (this._readableState && (this._readableState.destroyed = !0), this._writableState && (this._writableState.destroyed = !0), this._destroy(u || null, function(b) {
      !h && b ? p._writableState ? p._writableState.errorEmitted ? process$1.nextTick(n, p) : (p._writableState.errorEmitted = !0, process$1.nextTick(e, p, b)) : process$1.nextTick(e, p, b) : h ? (process$1.nextTick(n, p), h(b)) : process$1.nextTick(n, p);
    }), this);
  }
  function e(u, h) {
    c(u, h), n(u);
  }
  function n(u) {
    u._writableState && !u._writableState.emitClose || u._readableState && !u._readableState.emitClose || u.emit("close");
  }
  function a() {
    this._readableState && (this._readableState.destroyed = !1, this._readableState.reading = !1, this._readableState.ended = !1, this._readableState.endEmitted = !1), this._writableState && (this._writableState.destroyed = !1, this._writableState.ended = !1, this._writableState.ending = !1, this._writableState.finalCalled = !1, this._writableState.prefinished = !1, this._writableState.finished = !1, this._writableState.errorEmitted = !1);
  }
  function c(u, h) {
    u.emit("error", h);
  }
  function o(u, h) {
    var p = u._readableState, x = u._writableState;
    p && p.autoDestroy || x && x.autoDestroy ? u.destroy(h) : u.emit("error", h);
  }
  return destroy_1$1 = {
    destroy: t,
    undestroy: a,
    errorOrDestroy: o
  }, destroy_1$1;
}
var errorsBrowser = {}, hasRequiredErrorsBrowser;
function requireErrorsBrowser() {
  if (hasRequiredErrorsBrowser)
    return errorsBrowser;
  hasRequiredErrorsBrowser = 1;
  function t(h, p) {
    h.prototype = Object.create(p.prototype), h.prototype.constructor = h, h.__proto__ = p;
  }
  var e = {};
  function n(h, p, x) {
    x || (x = Error);
    function l(E, C, q) {
      return typeof p == "string" ? p : p(E, C, q);
    }
    var b = /* @__PURE__ */ function(E) {
      t(C, E);
      function C(q, F, z) {
        return E.call(this, l(q, F, z)) || this;
      }
      return C;
    }(x);
    b.prototype.name = x.name, b.prototype.code = h, e[h] = b;
  }
  function a(h, p) {
    if (Array.isArray(h)) {
      var x = h.length;
      return h = h.map(function(l) {
        return String(l);
      }), x > 2 ? "one of ".concat(p, " ").concat(h.slice(0, x - 1).join(", "), ", or ") + h[x - 1] : x === 2 ? "one of ".concat(p, " ").concat(h[0], " or ").concat(h[1]) : "of ".concat(p, " ").concat(h[0]);
    } else
      return "of ".concat(p, " ").concat(String(h));
  }
  function c(h, p, x) {
    return h.substr(0, p.length) === p;
  }
  function o(h, p, x) {
    return (x === void 0 || x > h.length) && (x = h.length), h.substring(x - p.length, x) === p;
  }
  function u(h, p, x) {
    return typeof x != "number" && (x = 0), x + p.length > h.length ? !1 : h.indexOf(p, x) !== -1;
  }
  return n("ERR_INVALID_OPT_VALUE", function(h, p) {
    return 'The value "' + p + '" is invalid for option "' + h + '"';
  }, TypeError), n("ERR_INVALID_ARG_TYPE", function(h, p, x) {
    var l;
    typeof p == "string" && c(p, "not ") ? (l = "must not be", p = p.replace(/^not /, "")) : l = "must be";
    var b;
    if (o(h, " argument"))
      b = "The ".concat(h, " ").concat(l, " ").concat(a(p, "type"));
    else {
      var E = u(h, ".") ? "property" : "argument";
      b = 'The "'.concat(h, '" ').concat(E, " ").concat(l, " ").concat(a(p, "type"));
    }
    return b += ". Received type ".concat(typeof x), b;
  }, TypeError), n("ERR_STREAM_PUSH_AFTER_EOF", "stream.push() after EOF"), n("ERR_METHOD_NOT_IMPLEMENTED", function(h) {
    return "The " + h + " method is not implemented";
  }), n("ERR_STREAM_PREMATURE_CLOSE", "Premature close"), n("ERR_STREAM_DESTROYED", function(h) {
    return "Cannot call " + h + " after a stream was destroyed";
  }), n("ERR_MULTIPLE_CALLBACK", "Callback called multiple times"), n("ERR_STREAM_CANNOT_PIPE", "Cannot pipe, not readable"), n("ERR_STREAM_WRITE_AFTER_END", "write after end"), n("ERR_STREAM_NULL_VALUES", "May not write null values to stream", TypeError), n("ERR_UNKNOWN_ENCODING", function(h) {
    return "Unknown encoding: " + h;
  }, TypeError), n("ERR_STREAM_UNSHIFT_AFTER_END_EVENT", "stream.unshift() after end event"), errorsBrowser.codes = e, errorsBrowser;
}
var state, hasRequiredState;
function requireState() {
  if (hasRequiredState)
    return state;
  hasRequiredState = 1;
  var t = requireErrorsBrowser().codes.ERR_INVALID_OPT_VALUE;
  function e(a, c, o) {
    return a.highWaterMark != null ? a.highWaterMark : c ? a[o] : null;
  }
  function n(a, c, o, u) {
    var h = e(c, u, o);
    if (h != null) {
      if (!(isFinite(h) && Math.floor(h) === h) || h < 0) {
        var p = u ? o : "highWaterMark";
        throw new t(p, h);
      }
      return Math.floor(h);
    }
    return a.objectMode ? 16 : 16 * 1024;
  }
  return state = {
    getHighWaterMark: n
  }, state;
}
var browser$a = deprecate;
function deprecate(t, e) {
  if (config("noDeprecation"))
    return t;
  var n = !1;
  function a() {
    if (!n) {
      if (config("throwDeprecation"))
        throw new Error(e);
      config("traceDeprecation") ? console.trace(e) : console.warn(e), n = !0;
    }
    return t.apply(this, arguments);
  }
  return a;
}
function config(t) {
  try {
    if (!commonjsGlobal.localStorage)
      return !1;
  } catch {
    return !1;
  }
  var e = commonjsGlobal.localStorage[t];
  return e == null ? !1 : String(e).toLowerCase() === "true";
}
var _stream_writable$1, hasRequired_stream_writable$1;
function require_stream_writable$1() {
  if (hasRequired_stream_writable$1)
    return _stream_writable$1;
  hasRequired_stream_writable$1 = 1, _stream_writable$1 = ue;
  function t(J) {
    var k = this;
    this.next = null, this.entry = null, this.finish = function() {
      ie(k, J);
    };
  }
  var e;
  ue.WritableState = fe;
  var n = {
    deprecate: browser$a
  }, a = requireStreamBrowser(), c = require$$1$2.Buffer, o = (typeof commonjsGlobal < "u" ? commonjsGlobal : typeof window < "u" ? window : typeof self < "u" ? self : {}).Uint8Array || function() {
  };
  function u(J) {
    return c.from(J);
  }
  function h(J) {
    return c.isBuffer(J) || J instanceof o;
  }
  var p = requireDestroy(), x = requireState(), l = x.getHighWaterMark, b = requireErrorsBrowser().codes, E = b.ERR_INVALID_ARG_TYPE, C = b.ERR_METHOD_NOT_IMPLEMENTED, q = b.ERR_MULTIPLE_CALLBACK, F = b.ERR_STREAM_CANNOT_PIPE, z = b.ERR_STREAM_DESTROYED, H = b.ERR_STREAM_NULL_VALUES, U = b.ERR_STREAM_WRITE_AFTER_END, Y = b.ERR_UNKNOWN_ENCODING, ee = p.errorOrDestroy;
  inherits_browserExports(ue, a);
  function se() {
  }
  function fe(J, k, D) {
    e = e || require_stream_duplex$1(), J = J || {}, typeof D != "boolean" && (D = k instanceof e), this.objectMode = !!J.objectMode, D && (this.objectMode = this.objectMode || !!J.writableObjectMode), this.highWaterMark = l(this, J, "writableHighWaterMark", D), this.finalCalled = !1, this.needDrain = !1, this.ending = !1, this.ended = !1, this.finished = !1, this.destroyed = !1;
    var X = J.decodeStrings === !1;
    this.decodeStrings = !X, this.defaultEncoding = J.defaultEncoding || "utf8", this.length = 0, this.writing = !1, this.corked = 0, this.sync = !0, this.bufferProcessing = !1, this.onwrite = function(te) {
      B(k, te);
    }, this.writecb = null, this.writelen = 0, this.bufferedRequest = null, this.lastBufferedRequest = null, this.pendingcb = 0, this.prefinished = !1, this.errorEmitted = !1, this.emitClose = J.emitClose !== !1, this.autoDestroy = !!J.autoDestroy, this.bufferedRequestCount = 0, this.corkedRequestsFree = new t(this);
  }
  fe.prototype.getBuffer = function() {
    for (var k = this.bufferedRequest, D = []; k; )
      D.push(k), k = k.next;
    return D;
  }, function() {
    try {
      Object.defineProperty(fe.prototype, "buffer", {
        get: n.deprecate(function() {
          return this.getBuffer();
        }, "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003")
      });
    } catch {
    }
  }();
  var pe;
  typeof Symbol == "function" && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] == "function" ? (pe = Function.prototype[Symbol.hasInstance], Object.defineProperty(ue, Symbol.hasInstance, {
    value: function(k) {
      return pe.call(this, k) ? !0 : this !== ue ? !1 : k && k._writableState instanceof fe;
    }
  })) : pe = function(k) {
    return k instanceof this;
  };
  function ue(J) {
    e = e || require_stream_duplex$1();
    var k = this instanceof e;
    if (!k && !pe.call(ue, this))
      return new ue(J);
    this._writableState = new fe(J, this, k), this.writable = !0, J && (typeof J.write == "function" && (this._write = J.write), typeof J.writev == "function" && (this._writev = J.writev), typeof J.destroy == "function" && (this._destroy = J.destroy), typeof J.final == "function" && (this._final = J.final)), a.call(this);
  }
  ue.prototype.pipe = function() {
    ee(this, new F());
  };
  function ce(J, k) {
    var D = new U();
    ee(J, D), process$1.nextTick(k, D);
  }
  function $e(J, k, D, X) {
    var te;
    return D === null ? te = new H() : typeof D != "string" && !k.objectMode && (te = new E("chunk", ["string", "Buffer"], D)), te ? (ee(J, te), process$1.nextTick(X, te), !1) : !0;
  }
  ue.prototype.write = function(J, k, D) {
    var X = this._writableState, te = !1, N = !X.objectMode && h(J);
    return N && !c.isBuffer(J) && (J = u(J)), typeof k == "function" && (D = k, k = null), N ? k = "buffer" : k || (k = X.defaultEncoding), typeof D != "function" && (D = se), X.ending ? ce(this, D) : (N || $e(this, X, J, D)) && (X.pendingcb++, te = _(this, X, N, J, k, D)), te;
  }, ue.prototype.cork = function() {
    this._writableState.corked++;
  }, ue.prototype.uncork = function() {
    var J = this._writableState;
    J.corked && (J.corked--, !J.writing && !J.corked && !J.bufferProcessing && J.bufferedRequest && M(this, J));
  }, ue.prototype.setDefaultEncoding = function(k) {
    if (typeof k == "string" && (k = k.toLowerCase()), !(["hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw"].indexOf((k + "").toLowerCase()) > -1))
      throw new Y(k);
    return this._writableState.defaultEncoding = k, this;
  }, Object.defineProperty(ue.prototype, "writableBuffer", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._writableState && this._writableState.getBuffer();
    }
  });
  function V(J, k, D) {
    return !J.objectMode && J.decodeStrings !== !1 && typeof k == "string" && (k = c.from(k, D)), k;
  }
  Object.defineProperty(ue.prototype, "writableHighWaterMark", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._writableState.highWaterMark;
    }
  });
  function _(J, k, D, X, te, N) {
    if (!D) {
      var O = V(k, X, te);
      X !== O && (D = !0, te = "buffer", X = O);
    }
    var ne = k.objectMode ? 1 : X.length;
    k.length += ne;
    var de = k.length < k.highWaterMark;
    if (de || (k.needDrain = !0), k.writing || k.corked) {
      var le = k.lastBufferedRequest;
      k.lastBufferedRequest = {
        chunk: X,
        encoding: te,
        isBuf: D,
        callback: N,
        next: null
      }, le ? le.next = k.lastBufferedRequest : k.bufferedRequest = k.lastBufferedRequest, k.bufferedRequestCount += 1;
    } else
      w(J, k, !1, ne, X, te, N);
    return de;
  }
  function w(J, k, D, X, te, N, O) {
    k.writelen = X, k.writecb = O, k.writing = !0, k.sync = !0, k.destroyed ? k.onwrite(new z("write")) : D ? J._writev(te, k.onwrite) : J._write(te, N, k.onwrite), k.sync = !1;
  }
  function d(J, k, D, X, te) {
    --k.pendingcb, D ? (process$1.nextTick(te, X), process$1.nextTick(T, J, k), J._writableState.errorEmitted = !0, ee(J, X)) : (te(X), J._writableState.errorEmitted = !0, ee(J, X), T(J, k));
  }
  function m(J) {
    J.writing = !1, J.writecb = null, J.length -= J.writelen, J.writelen = 0;
  }
  function B(J, k) {
    var D = J._writableState, X = D.sync, te = D.writecb;
    if (typeof te != "function")
      throw new q();
    if (m(D), k)
      d(J, D, X, k, te);
    else {
      var N = v(D) || J.destroyed;
      !N && !D.corked && !D.bufferProcessing && D.bufferedRequest && M(J, D), X ? process$1.nextTick($, J, D, N, te) : $(J, D, N, te);
    }
  }
  function $(J, k, D, X) {
    D || P(J, k), k.pendingcb--, X(), T(J, k);
  }
  function P(J, k) {
    k.length === 0 && k.needDrain && (k.needDrain = !1, J.emit("drain"));
  }
  function M(J, k) {
    k.bufferProcessing = !0;
    var D = k.bufferedRequest;
    if (J._writev && D && D.next) {
      var X = k.bufferedRequestCount, te = new Array(X), N = k.corkedRequestsFree;
      N.entry = D;
      for (var O = 0, ne = !0; D; )
        te[O] = D, D.isBuf || (ne = !1), D = D.next, O += 1;
      te.allBuffers = ne, w(J, k, !0, k.length, te, "", N.finish), k.pendingcb++, k.lastBufferedRequest = null, N.next ? (k.corkedRequestsFree = N.next, N.next = null) : k.corkedRequestsFree = new t(k), k.bufferedRequestCount = 0;
    } else {
      for (; D; ) {
        var de = D.chunk, le = D.encoding, he = D.callback, me = k.objectMode ? 1 : de.length;
        if (w(J, k, !1, me, de, le, he), D = D.next, k.bufferedRequestCount--, k.writing)
          break;
      }
      D === null && (k.lastBufferedRequest = null);
    }
    k.bufferedRequest = D, k.bufferProcessing = !1;
  }
  ue.prototype._write = function(J, k, D) {
    D(new C("_write()"));
  }, ue.prototype._writev = null, ue.prototype.end = function(J, k, D) {
    var X = this._writableState;
    return typeof J == "function" ? (D = J, J = null, k = null) : typeof k == "function" && (D = k, k = null), J != null && this.write(J, k), X.corked && (X.corked = 1, this.uncork()), X.ending || Z(this, X, D), this;
  }, Object.defineProperty(ue.prototype, "writableLength", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._writableState.length;
    }
  });
  function v(J) {
    return J.ending && J.length === 0 && J.bufferedRequest === null && !J.finished && !J.writing;
  }
  function A(J, k) {
    J._final(function(D) {
      k.pendingcb--, D && ee(J, D), k.prefinished = !0, J.emit("prefinish"), T(J, k);
    });
  }
  function y(J, k) {
    !k.prefinished && !k.finalCalled && (typeof J._final == "function" && !k.destroyed ? (k.pendingcb++, k.finalCalled = !0, process$1.nextTick(A, J, k)) : (k.prefinished = !0, J.emit("prefinish")));
  }
  function T(J, k) {
    var D = v(k);
    if (D && (y(J, k), k.pendingcb === 0 && (k.finished = !0, J.emit("finish"), k.autoDestroy))) {
      var X = J._readableState;
      (!X || X.autoDestroy && X.endEmitted) && J.destroy();
    }
    return D;
  }
  function Z(J, k, D) {
    k.ending = !0, T(J, k), D && (k.finished ? process$1.nextTick(D) : J.once("finish", D)), k.ended = !0, J.writable = !1;
  }
  function ie(J, k, D) {
    var X = J.entry;
    for (J.entry = null; X; ) {
      var te = X.callback;
      k.pendingcb--, te(D), X = X.next;
    }
    k.corkedRequestsFree.next = J;
  }
  return Object.defineProperty(ue.prototype, "destroyed", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._writableState === void 0 ? !1 : this._writableState.destroyed;
    },
    set: function(k) {
      this._writableState && (this._writableState.destroyed = k);
    }
  }), ue.prototype.destroy = p.destroy, ue.prototype._undestroy = p.undestroy, ue.prototype._destroy = function(J, k) {
    k(J);
  }, _stream_writable$1;
}
var _stream_duplex$1, hasRequired_stream_duplex$1;
function require_stream_duplex$1() {
  if (hasRequired_stream_duplex$1)
    return _stream_duplex$1;
  hasRequired_stream_duplex$1 = 1;
  var t = Object.keys || function(x) {
    var l = [];
    for (var b in x)
      l.push(b);
    return l;
  };
  _stream_duplex$1 = u;
  var e = require_stream_readable$1(), n = require_stream_writable$1();
  inherits_browserExports(u, e);
  for (var a = t(n.prototype), c = 0; c < a.length; c++) {
    var o = a[c];
    u.prototype[o] || (u.prototype[o] = n.prototype[o]);
  }
  function u(x) {
    if (!(this instanceof u))
      return new u(x);
    e.call(this, x), n.call(this, x), this.allowHalfOpen = !0, x && (x.readable === !1 && (this.readable = !1), x.writable === !1 && (this.writable = !1), x.allowHalfOpen === !1 && (this.allowHalfOpen = !1, this.once("end", h)));
  }
  Object.defineProperty(u.prototype, "writableHighWaterMark", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._writableState.highWaterMark;
    }
  }), Object.defineProperty(u.prototype, "writableBuffer", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._writableState && this._writableState.getBuffer();
    }
  }), Object.defineProperty(u.prototype, "writableLength", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._writableState.length;
    }
  });
  function h() {
    this._writableState.ended || process$1.nextTick(p, this);
  }
  function p(x) {
    x.end();
  }
  return Object.defineProperty(u.prototype, "destroyed", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._readableState === void 0 || this._writableState === void 0 ? !1 : this._readableState.destroyed && this._writableState.destroyed;
    },
    set: function(l) {
      this._readableState === void 0 || this._writableState === void 0 || (this._readableState.destroyed = l, this._writableState.destroyed = l);
    }
  }), _stream_duplex$1;
}
var string_decoder = {}, Buffer$z = safeBufferExports$1.Buffer, isEncoding = Buffer$z.isEncoding || function(t) {
  switch (t = "" + t, t && t.toLowerCase()) {
    case "hex":
    case "utf8":
    case "utf-8":
    case "ascii":
    case "binary":
    case "base64":
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
    case "raw":
      return !0;
    default:
      return !1;
  }
};
function _normalizeEncoding(t) {
  if (!t)
    return "utf8";
  for (var e; ; )
    switch (t) {
      case "utf8":
      case "utf-8":
        return "utf8";
      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return "utf16le";
      case "latin1":
      case "binary":
        return "latin1";
      case "base64":
      case "ascii":
      case "hex":
        return t;
      default:
        if (e)
          return;
        t = ("" + t).toLowerCase(), e = !0;
    }
}
function normalizeEncoding(t) {
  var e = _normalizeEncoding(t);
  if (typeof e != "string" && (Buffer$z.isEncoding === isEncoding || !isEncoding(t)))
    throw new Error("Unknown encoding: " + t);
  return e || t;
}
string_decoder.StringDecoder = StringDecoder$1;
function StringDecoder$1(t) {
  this.encoding = normalizeEncoding(t);
  var e;
  switch (this.encoding) {
    case "utf16le":
      this.text = utf16Text, this.end = utf16End, e = 4;
      break;
    case "utf8":
      this.fillLast = utf8FillLast, e = 4;
      break;
    case "base64":
      this.text = base64Text, this.end = base64End, e = 3;
      break;
    default:
      this.write = simpleWrite, this.end = simpleEnd;
      return;
  }
  this.lastNeed = 0, this.lastTotal = 0, this.lastChar = Buffer$z.allocUnsafe(e);
}
StringDecoder$1.prototype.write = function(t) {
  if (t.length === 0)
    return "";
  var e, n;
  if (this.lastNeed) {
    if (e = this.fillLast(t), e === void 0)
      return "";
    n = this.lastNeed, this.lastNeed = 0;
  } else
    n = 0;
  return n < t.length ? e ? e + this.text(t, n) : this.text(t, n) : e || "";
};
StringDecoder$1.prototype.end = utf8End;
StringDecoder$1.prototype.text = utf8Text;
StringDecoder$1.prototype.fillLast = function(t) {
  if (this.lastNeed <= t.length)
    return t.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
  t.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, t.length), this.lastNeed -= t.length;
};
function utf8CheckByte(t) {
  return t <= 127 ? 0 : t >> 5 === 6 ? 2 : t >> 4 === 14 ? 3 : t >> 3 === 30 ? 4 : t >> 6 === 2 ? -1 : -2;
}
function utf8CheckIncomplete(t, e, n) {
  var a = e.length - 1;
  if (a < n)
    return 0;
  var c = utf8CheckByte(e[a]);
  return c >= 0 ? (c > 0 && (t.lastNeed = c - 1), c) : --a < n || c === -2 ? 0 : (c = utf8CheckByte(e[a]), c >= 0 ? (c > 0 && (t.lastNeed = c - 2), c) : --a < n || c === -2 ? 0 : (c = utf8CheckByte(e[a]), c >= 0 ? (c > 0 && (c === 2 ? c = 0 : t.lastNeed = c - 3), c) : 0));
}
function utf8CheckExtraBytes(t, e, n) {
  if ((e[0] & 192) !== 128)
    return t.lastNeed = 0, "�";
  if (t.lastNeed > 1 && e.length > 1) {
    if ((e[1] & 192) !== 128)
      return t.lastNeed = 1, "�";
    if (t.lastNeed > 2 && e.length > 2 && (e[2] & 192) !== 128)
      return t.lastNeed = 2, "�";
  }
}
function utf8FillLast(t) {
  var e = this.lastTotal - this.lastNeed, n = utf8CheckExtraBytes(this, t);
  if (n !== void 0)
    return n;
  if (this.lastNeed <= t.length)
    return t.copy(this.lastChar, e, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
  t.copy(this.lastChar, e, 0, t.length), this.lastNeed -= t.length;
}
function utf8Text(t, e) {
  var n = utf8CheckIncomplete(this, t, e);
  if (!this.lastNeed)
    return t.toString("utf8", e);
  this.lastTotal = n;
  var a = t.length - (n - this.lastNeed);
  return t.copy(this.lastChar, 0, a), t.toString("utf8", e, a);
}
function utf8End(t) {
  var e = t && t.length ? this.write(t) : "";
  return this.lastNeed ? e + "�" : e;
}
function utf16Text(t, e) {
  if ((t.length - e) % 2 === 0) {
    var n = t.toString("utf16le", e);
    if (n) {
      var a = n.charCodeAt(n.length - 1);
      if (a >= 55296 && a <= 56319)
        return this.lastNeed = 2, this.lastTotal = 4, this.lastChar[0] = t[t.length - 2], this.lastChar[1] = t[t.length - 1], n.slice(0, -1);
    }
    return n;
  }
  return this.lastNeed = 1, this.lastTotal = 2, this.lastChar[0] = t[t.length - 1], t.toString("utf16le", e, t.length - 1);
}
function utf16End(t) {
  var e = t && t.length ? this.write(t) : "";
  if (this.lastNeed) {
    var n = this.lastTotal - this.lastNeed;
    return e + this.lastChar.toString("utf16le", 0, n);
  }
  return e;
}
function base64Text(t, e) {
  var n = (t.length - e) % 3;
  return n === 0 ? t.toString("base64", e) : (this.lastNeed = 3 - n, this.lastTotal = 3, n === 1 ? this.lastChar[0] = t[t.length - 1] : (this.lastChar[0] = t[t.length - 2], this.lastChar[1] = t[t.length - 1]), t.toString("base64", e, t.length - n));
}
function base64End(t) {
  var e = t && t.length ? this.write(t) : "";
  return this.lastNeed ? e + this.lastChar.toString("base64", 0, 3 - this.lastNeed) : e;
}
function simpleWrite(t) {
  return t.toString(this.encoding);
}
function simpleEnd(t) {
  return t && t.length ? this.write(t) : "";
}
var endOfStream, hasRequiredEndOfStream;
function requireEndOfStream() {
  if (hasRequiredEndOfStream)
    return endOfStream;
  hasRequiredEndOfStream = 1;
  var t = requireErrorsBrowser().codes.ERR_STREAM_PREMATURE_CLOSE;
  function e(o) {
    var u = !1;
    return function() {
      if (!u) {
        u = !0;
        for (var h = arguments.length, p = new Array(h), x = 0; x < h; x++)
          p[x] = arguments[x];
        o.apply(this, p);
      }
    };
  }
  function n() {
  }
  function a(o) {
    return o.setHeader && typeof o.abort == "function";
  }
  function c(o, u, h) {
    if (typeof u == "function")
      return c(o, null, u);
    u || (u = {}), h = e(h || n);
    var p = u.readable || u.readable !== !1 && o.readable, x = u.writable || u.writable !== !1 && o.writable, l = function() {
      o.writable || E();
    }, b = o._writableState && o._writableState.finished, E = function() {
      x = !1, b = !0, p || h.call(o);
    }, C = o._readableState && o._readableState.endEmitted, q = function() {
      p = !1, C = !0, x || h.call(o);
    }, F = function(Y) {
      h.call(o, Y);
    }, z = function() {
      var Y;
      if (p && !C)
        return (!o._readableState || !o._readableState.ended) && (Y = new t()), h.call(o, Y);
      if (x && !b)
        return (!o._writableState || !o._writableState.ended) && (Y = new t()), h.call(o, Y);
    }, H = function() {
      o.req.on("finish", E);
    };
    return a(o) ? (o.on("complete", E), o.on("abort", z), o.req ? H() : o.on("request", H)) : x && !o._writableState && (o.on("end", l), o.on("close", l)), o.on("end", q), o.on("finish", E), u.error !== !1 && o.on("error", F), o.on("close", z), function() {
      o.removeListener("complete", E), o.removeListener("abort", z), o.removeListener("request", H), o.req && o.req.removeListener("finish", E), o.removeListener("end", l), o.removeListener("close", l), o.removeListener("finish", E), o.removeListener("end", q), o.removeListener("error", F), o.removeListener("close", z);
    };
  }
  return endOfStream = c, endOfStream;
}
var async_iterator, hasRequiredAsync_iterator;
function requireAsync_iterator() {
  if (hasRequiredAsync_iterator)
    return async_iterator;
  hasRequiredAsync_iterator = 1;
  var t;
  function e(Y, ee, se) {
    return ee = n(ee), ee in Y ? Object.defineProperty(Y, ee, { value: se, enumerable: !0, configurable: !0, writable: !0 }) : Y[ee] = se, Y;
  }
  function n(Y) {
    var ee = a(Y, "string");
    return typeof ee == "symbol" ? ee : String(ee);
  }
  function a(Y, ee) {
    if (typeof Y != "object" || Y === null)
      return Y;
    var se = Y[Symbol.toPrimitive];
    if (se !== void 0) {
      var fe = se.call(Y, ee || "default");
      if (typeof fe != "object")
        return fe;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (ee === "string" ? String : Number)(Y);
  }
  var c = requireEndOfStream(), o = Symbol("lastResolve"), u = Symbol("lastReject"), h = Symbol("error"), p = Symbol("ended"), x = Symbol("lastPromise"), l = Symbol("handlePromise"), b = Symbol("stream");
  function E(Y, ee) {
    return {
      value: Y,
      done: ee
    };
  }
  function C(Y) {
    var ee = Y[o];
    if (ee !== null) {
      var se = Y[b].read();
      se !== null && (Y[x] = null, Y[o] = null, Y[u] = null, ee(E(se, !1)));
    }
  }
  function q(Y) {
    process$1.nextTick(C, Y);
  }
  function F(Y, ee) {
    return function(se, fe) {
      Y.then(function() {
        if (ee[p]) {
          se(E(void 0, !0));
          return;
        }
        ee[l](se, fe);
      }, fe);
    };
  }
  var z = Object.getPrototypeOf(function() {
  }), H = Object.setPrototypeOf((t = {
    get stream() {
      return this[b];
    },
    next: function() {
      var ee = this, se = this[h];
      if (se !== null)
        return Promise.reject(se);
      if (this[p])
        return Promise.resolve(E(void 0, !0));
      if (this[b].destroyed)
        return new Promise(function(ce, $e) {
          process$1.nextTick(function() {
            ee[h] ? $e(ee[h]) : ce(E(void 0, !0));
          });
        });
      var fe = this[x], pe;
      if (fe)
        pe = new Promise(F(fe, this));
      else {
        var ue = this[b].read();
        if (ue !== null)
          return Promise.resolve(E(ue, !1));
        pe = new Promise(this[l]);
      }
      return this[x] = pe, pe;
    }
  }, e(t, Symbol.asyncIterator, function() {
    return this;
  }), e(t, "return", function() {
    var ee = this;
    return new Promise(function(se, fe) {
      ee[b].destroy(null, function(pe) {
        if (pe) {
          fe(pe);
          return;
        }
        se(E(void 0, !0));
      });
    });
  }), t), z), U = function(ee) {
    var se, fe = Object.create(H, (se = {}, e(se, b, {
      value: ee,
      writable: !0
    }), e(se, o, {
      value: null,
      writable: !0
    }), e(se, u, {
      value: null,
      writable: !0
    }), e(se, h, {
      value: null,
      writable: !0
    }), e(se, p, {
      value: ee._readableState.endEmitted,
      writable: !0
    }), e(se, l, {
      value: function(ue, ce) {
        var $e = fe[b].read();
        $e ? (fe[x] = null, fe[o] = null, fe[u] = null, ue(E($e, !1))) : (fe[o] = ue, fe[u] = ce);
      },
      writable: !0
    }), se));
    return fe[x] = null, c(ee, function(pe) {
      if (pe && pe.code !== "ERR_STREAM_PREMATURE_CLOSE") {
        var ue = fe[u];
        ue !== null && (fe[x] = null, fe[o] = null, fe[u] = null, ue(pe)), fe[h] = pe;
        return;
      }
      var ce = fe[o];
      ce !== null && (fe[x] = null, fe[o] = null, fe[u] = null, ce(E(void 0, !0))), fe[p] = !0;
    }), ee.on("readable", q.bind(null, fe)), fe;
  };
  return async_iterator = U, async_iterator;
}
var fromBrowser, hasRequiredFromBrowser;
function requireFromBrowser() {
  return hasRequiredFromBrowser || (hasRequiredFromBrowser = 1, fromBrowser = function() {
    throw new Error("Readable.from is not available in the browser");
  }), fromBrowser;
}
var _stream_readable$1, hasRequired_stream_readable$1;
function require_stream_readable$1() {
  if (hasRequired_stream_readable$1)
    return _stream_readable$1;
  hasRequired_stream_readable$1 = 1, _stream_readable$1 = ce;
  var t;
  ce.ReadableState = ue, eventsExports.EventEmitter;
  var e = function(O, ne) {
    return O.listeners(ne).length;
  }, n = requireStreamBrowser(), a = require$$1$2.Buffer, c = (typeof commonjsGlobal < "u" ? commonjsGlobal : typeof window < "u" ? window : typeof self < "u" ? self : {}).Uint8Array || function() {
  };
  function o(N) {
    return a.from(N);
  }
  function u(N) {
    return a.isBuffer(N) || N instanceof c;
  }
  var h = util$3, p;
  h && h.debuglog ? p = h.debuglog("stream") : p = function() {
  };
  var x = requireBuffer_list(), l = requireDestroy(), b = requireState(), E = b.getHighWaterMark, C = requireErrorsBrowser().codes, q = C.ERR_INVALID_ARG_TYPE, F = C.ERR_STREAM_PUSH_AFTER_EOF, z = C.ERR_METHOD_NOT_IMPLEMENTED, H = C.ERR_STREAM_UNSHIFT_AFTER_END_EVENT, U, Y, ee;
  inherits_browserExports(ce, n);
  var se = l.errorOrDestroy, fe = ["error", "close", "destroy", "pause", "resume"];
  function pe(N, O, ne) {
    if (typeof N.prependListener == "function")
      return N.prependListener(O, ne);
    !N._events || !N._events[O] ? N.on(O, ne) : Array.isArray(N._events[O]) ? N._events[O].unshift(ne) : N._events[O] = [ne, N._events[O]];
  }
  function ue(N, O, ne) {
    t = t || require_stream_duplex$1(), N = N || {}, typeof ne != "boolean" && (ne = O instanceof t), this.objectMode = !!N.objectMode, ne && (this.objectMode = this.objectMode || !!N.readableObjectMode), this.highWaterMark = E(this, N, "readableHighWaterMark", ne), this.buffer = new x(), this.length = 0, this.pipes = null, this.pipesCount = 0, this.flowing = null, this.ended = !1, this.endEmitted = !1, this.reading = !1, this.sync = !0, this.needReadable = !1, this.emittedReadable = !1, this.readableListening = !1, this.resumeScheduled = !1, this.paused = !0, this.emitClose = N.emitClose !== !1, this.autoDestroy = !!N.autoDestroy, this.destroyed = !1, this.defaultEncoding = N.defaultEncoding || "utf8", this.awaitDrain = 0, this.readingMore = !1, this.decoder = null, this.encoding = null, N.encoding && (U || (U = string_decoder.StringDecoder), this.decoder = new U(N.encoding), this.encoding = N.encoding);
  }
  function ce(N) {
    if (t = t || require_stream_duplex$1(), !(this instanceof ce))
      return new ce(N);
    var O = this instanceof t;
    this._readableState = new ue(N, this, O), this.readable = !0, N && (typeof N.read == "function" && (this._read = N.read), typeof N.destroy == "function" && (this._destroy = N.destroy)), n.call(this);
  }
  Object.defineProperty(ce.prototype, "destroyed", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._readableState === void 0 ? !1 : this._readableState.destroyed;
    },
    set: function(O) {
      this._readableState && (this._readableState.destroyed = O);
    }
  }), ce.prototype.destroy = l.destroy, ce.prototype._undestroy = l.undestroy, ce.prototype._destroy = function(N, O) {
    O(N);
  }, ce.prototype.push = function(N, O) {
    var ne = this._readableState, de;
    return ne.objectMode ? de = !0 : typeof N == "string" && (O = O || ne.defaultEncoding, O !== ne.encoding && (N = a.from(N, O), O = ""), de = !0), $e(this, N, O, !1, de);
  }, ce.prototype.unshift = function(N) {
    return $e(this, N, null, !0, !1);
  };
  function $e(N, O, ne, de, le) {
    p("readableAddChunk", O);
    var he = N._readableState;
    if (O === null)
      he.reading = !1, B(N, he);
    else {
      var me;
      if (le || (me = _(he, O)), me)
        se(N, me);
      else if (he.objectMode || O && O.length > 0)
        if (typeof O != "string" && !he.objectMode && Object.getPrototypeOf(O) !== a.prototype && (O = o(O)), de)
          he.endEmitted ? se(N, new H()) : V(N, he, O, !0);
        else if (he.ended)
          se(N, new F());
        else {
          if (he.destroyed)
            return !1;
          he.reading = !1, he.decoder && !ne ? (O = he.decoder.write(O), he.objectMode || O.length !== 0 ? V(N, he, O, !1) : M(N, he)) : V(N, he, O, !1);
        }
      else
        de || (he.reading = !1, M(N, he));
    }
    return !he.ended && (he.length < he.highWaterMark || he.length === 0);
  }
  function V(N, O, ne, de) {
    O.flowing && O.length === 0 && !O.sync ? (O.awaitDrain = 0, N.emit("data", ne)) : (O.length += O.objectMode ? 1 : ne.length, de ? O.buffer.unshift(ne) : O.buffer.push(ne), O.needReadable && $(N)), M(N, O);
  }
  function _(N, O) {
    var ne;
    return !u(O) && typeof O != "string" && O !== void 0 && !N.objectMode && (ne = new q("chunk", ["string", "Buffer", "Uint8Array"], O)), ne;
  }
  ce.prototype.isPaused = function() {
    return this._readableState.flowing === !1;
  }, ce.prototype.setEncoding = function(N) {
    U || (U = string_decoder.StringDecoder);
    var O = new U(N);
    this._readableState.decoder = O, this._readableState.encoding = this._readableState.decoder.encoding;
    for (var ne = this._readableState.buffer.head, de = ""; ne !== null; )
      de += O.write(ne.data), ne = ne.next;
    return this._readableState.buffer.clear(), de !== "" && this._readableState.buffer.push(de), this._readableState.length = de.length, this;
  };
  var w = 1073741824;
  function d(N) {
    return N >= w ? N = w : (N--, N |= N >>> 1, N |= N >>> 2, N |= N >>> 4, N |= N >>> 8, N |= N >>> 16, N++), N;
  }
  function m(N, O) {
    return N <= 0 || O.length === 0 && O.ended ? 0 : O.objectMode ? 1 : N !== N ? O.flowing && O.length ? O.buffer.head.data.length : O.length : (N > O.highWaterMark && (O.highWaterMark = d(N)), N <= O.length ? N : O.ended ? O.length : (O.needReadable = !0, 0));
  }
  ce.prototype.read = function(N) {
    p("read", N), N = parseInt(N, 10);
    var O = this._readableState, ne = N;
    if (N !== 0 && (O.emittedReadable = !1), N === 0 && O.needReadable && ((O.highWaterMark !== 0 ? O.length >= O.highWaterMark : O.length > 0) || O.ended))
      return p("read: emitReadable", O.length, O.ended), O.length === 0 && O.ended ? D(this) : $(this), null;
    if (N = m(N, O), N === 0 && O.ended)
      return O.length === 0 && D(this), null;
    var de = O.needReadable;
    p("need readable", de), (O.length === 0 || O.length - N < O.highWaterMark) && (de = !0, p("length less than watermark", de)), O.ended || O.reading ? (de = !1, p("reading or ended", de)) : de && (p("do read"), O.reading = !0, O.sync = !0, O.length === 0 && (O.needReadable = !0), this._read(O.highWaterMark), O.sync = !1, O.reading || (N = m(ne, O)));
    var le;
    return N > 0 ? le = k(N, O) : le = null, le === null ? (O.needReadable = O.length <= O.highWaterMark, N = 0) : (O.length -= N, O.awaitDrain = 0), O.length === 0 && (O.ended || (O.needReadable = !0), ne !== N && O.ended && D(this)), le !== null && this.emit("data", le), le;
  };
  function B(N, O) {
    if (p("onEofChunk"), !O.ended) {
      if (O.decoder) {
        var ne = O.decoder.end();
        ne && ne.length && (O.buffer.push(ne), O.length += O.objectMode ? 1 : ne.length);
      }
      O.ended = !0, O.sync ? $(N) : (O.needReadable = !1, O.emittedReadable || (O.emittedReadable = !0, P(N)));
    }
  }
  function $(N) {
    var O = N._readableState;
    p("emitReadable", O.needReadable, O.emittedReadable), O.needReadable = !1, O.emittedReadable || (p("emitReadable", O.flowing), O.emittedReadable = !0, process$1.nextTick(P, N));
  }
  function P(N) {
    var O = N._readableState;
    p("emitReadable_", O.destroyed, O.length, O.ended), !O.destroyed && (O.length || O.ended) && (N.emit("readable"), O.emittedReadable = !1), O.needReadable = !O.flowing && !O.ended && O.length <= O.highWaterMark, J(N);
  }
  function M(N, O) {
    O.readingMore || (O.readingMore = !0, process$1.nextTick(v, N, O));
  }
  function v(N, O) {
    for (; !O.reading && !O.ended && (O.length < O.highWaterMark || O.flowing && O.length === 0); ) {
      var ne = O.length;
      if (p("maybeReadMore read 0"), N.read(0), ne === O.length)
        break;
    }
    O.readingMore = !1;
  }
  ce.prototype._read = function(N) {
    se(this, new z("_read()"));
  }, ce.prototype.pipe = function(N, O) {
    var ne = this, de = this._readableState;
    switch (de.pipesCount) {
      case 0:
        de.pipes = N;
        break;
      case 1:
        de.pipes = [de.pipes, N];
        break;
      default:
        de.pipes.push(N);
        break;
    }
    de.pipesCount += 1, p("pipe count=%d opts=%j", de.pipesCount, O);
    var le = (!O || O.end !== !1) && N !== process$1.stdout && N !== process$1.stderr, he = le ? ge : Le;
    de.endEmitted ? process$1.nextTick(he) : ne.once("end", he), N.on("unpipe", me);
    function me(xe, Te) {
      p("onunpipe"), xe === ne && Te && Te.hasUnpiped === !1 && (Te.hasUnpiped = !0, _e());
    }
    function ge() {
      p("onend"), N.end();
    }
    var oe = A(ne);
    N.on("drain", oe);
    var qe = !1;
    function _e() {
      p("cleanup"), N.removeListener("close", ye), N.removeListener("finish", Be), N.removeListener("drain", oe), N.removeListener("error", De), N.removeListener("unpipe", me), ne.removeListener("end", ge), ne.removeListener("end", Le), ne.removeListener("data", Oe), qe = !0, de.awaitDrain && (!N._writableState || N._writableState.needDrain) && oe();
    }
    ne.on("data", Oe);
    function Oe(xe) {
      p("ondata");
      var Te = N.write(xe);
      p("dest.write", Te), Te === !1 && ((de.pipesCount === 1 && de.pipes === N || de.pipesCount > 1 && te(de.pipes, N) !== -1) && !qe && (p("false write response, pause", de.awaitDrain), de.awaitDrain++), ne.pause());
    }
    function De(xe) {
      p("onerror", xe), Le(), N.removeListener("error", De), e(N, "error") === 0 && se(N, xe);
    }
    pe(N, "error", De);
    function ye() {
      N.removeListener("finish", Be), Le();
    }
    N.once("close", ye);
    function Be() {
      p("onfinish"), N.removeListener("close", ye), Le();
    }
    N.once("finish", Be);
    function Le() {
      p("unpipe"), ne.unpipe(N);
    }
    return N.emit("pipe", ne), de.flowing || (p("pipe resume"), ne.resume()), N;
  };
  function A(N) {
    return function() {
      var ne = N._readableState;
      p("pipeOnDrain", ne.awaitDrain), ne.awaitDrain && ne.awaitDrain--, ne.awaitDrain === 0 && e(N, "data") && (ne.flowing = !0, J(N));
    };
  }
  ce.prototype.unpipe = function(N) {
    var O = this._readableState, ne = {
      hasUnpiped: !1
    };
    if (O.pipesCount === 0)
      return this;
    if (O.pipesCount === 1)
      return N && N !== O.pipes ? this : (N || (N = O.pipes), O.pipes = null, O.pipesCount = 0, O.flowing = !1, N && N.emit("unpipe", this, ne), this);
    if (!N) {
      var de = O.pipes, le = O.pipesCount;
      O.pipes = null, O.pipesCount = 0, O.flowing = !1;
      for (var he = 0; he < le; he++)
        de[he].emit("unpipe", this, {
          hasUnpiped: !1
        });
      return this;
    }
    var me = te(O.pipes, N);
    return me === -1 ? this : (O.pipes.splice(me, 1), O.pipesCount -= 1, O.pipesCount === 1 && (O.pipes = O.pipes[0]), N.emit("unpipe", this, ne), this);
  }, ce.prototype.on = function(N, O) {
    var ne = n.prototype.on.call(this, N, O), de = this._readableState;
    return N === "data" ? (de.readableListening = this.listenerCount("readable") > 0, de.flowing !== !1 && this.resume()) : N === "readable" && !de.endEmitted && !de.readableListening && (de.readableListening = de.needReadable = !0, de.flowing = !1, de.emittedReadable = !1, p("on readable", de.length, de.reading), de.length ? $(this) : de.reading || process$1.nextTick(T, this)), ne;
  }, ce.prototype.addListener = ce.prototype.on, ce.prototype.removeListener = function(N, O) {
    var ne = n.prototype.removeListener.call(this, N, O);
    return N === "readable" && process$1.nextTick(y, this), ne;
  }, ce.prototype.removeAllListeners = function(N) {
    var O = n.prototype.removeAllListeners.apply(this, arguments);
    return (N === "readable" || N === void 0) && process$1.nextTick(y, this), O;
  };
  function y(N) {
    var O = N._readableState;
    O.readableListening = N.listenerCount("readable") > 0, O.resumeScheduled && !O.paused ? O.flowing = !0 : N.listenerCount("data") > 0 && N.resume();
  }
  function T(N) {
    p("readable nexttick read 0"), N.read(0);
  }
  ce.prototype.resume = function() {
    var N = this._readableState;
    return N.flowing || (p("resume"), N.flowing = !N.readableListening, Z(this, N)), N.paused = !1, this;
  };
  function Z(N, O) {
    O.resumeScheduled || (O.resumeScheduled = !0, process$1.nextTick(ie, N, O));
  }
  function ie(N, O) {
    p("resume", O.reading), O.reading || N.read(0), O.resumeScheduled = !1, N.emit("resume"), J(N), O.flowing && !O.reading && N.read(0);
  }
  ce.prototype.pause = function() {
    return p("call pause flowing=%j", this._readableState.flowing), this._readableState.flowing !== !1 && (p("pause"), this._readableState.flowing = !1, this.emit("pause")), this._readableState.paused = !0, this;
  };
  function J(N) {
    var O = N._readableState;
    for (p("flow", O.flowing); O.flowing && N.read() !== null; )
      ;
  }
  ce.prototype.wrap = function(N) {
    var O = this, ne = this._readableState, de = !1;
    N.on("end", function() {
      if (p("wrapped end"), ne.decoder && !ne.ended) {
        var me = ne.decoder.end();
        me && me.length && O.push(me);
      }
      O.push(null);
    }), N.on("data", function(me) {
      if (p("wrapped data"), ne.decoder && (me = ne.decoder.write(me)), !(ne.objectMode && me == null) && !(!ne.objectMode && (!me || !me.length))) {
        var ge = O.push(me);
        ge || (de = !0, N.pause());
      }
    });
    for (var le in N)
      this[le] === void 0 && typeof N[le] == "function" && (this[le] = /* @__PURE__ */ function(ge) {
        return function() {
          return N[ge].apply(N, arguments);
        };
      }(le));
    for (var he = 0; he < fe.length; he++)
      N.on(fe[he], this.emit.bind(this, fe[he]));
    return this._read = function(me) {
      p("wrapped _read", me), de && (de = !1, N.resume());
    }, this;
  }, typeof Symbol == "function" && (ce.prototype[Symbol.asyncIterator] = function() {
    return Y === void 0 && (Y = requireAsync_iterator()), Y(this);
  }), Object.defineProperty(ce.prototype, "readableHighWaterMark", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._readableState.highWaterMark;
    }
  }), Object.defineProperty(ce.prototype, "readableBuffer", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._readableState && this._readableState.buffer;
    }
  }), Object.defineProperty(ce.prototype, "readableFlowing", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._readableState.flowing;
    },
    set: function(O) {
      this._readableState && (this._readableState.flowing = O);
    }
  }), ce._fromList = k, Object.defineProperty(ce.prototype, "readableLength", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._readableState.length;
    }
  });
  function k(N, O) {
    if (O.length === 0)
      return null;
    var ne;
    return O.objectMode ? ne = O.buffer.shift() : !N || N >= O.length ? (O.decoder ? ne = O.buffer.join("") : O.buffer.length === 1 ? ne = O.buffer.first() : ne = O.buffer.concat(O.length), O.buffer.clear()) : ne = O.buffer.consume(N, O.decoder), ne;
  }
  function D(N) {
    var O = N._readableState;
    p("endReadable", O.endEmitted), O.endEmitted || (O.ended = !0, process$1.nextTick(X, O, N));
  }
  function X(N, O) {
    if (p("endReadableNT", N.endEmitted, N.length), !N.endEmitted && N.length === 0 && (N.endEmitted = !0, O.readable = !1, O.emit("end"), N.autoDestroy)) {
      var ne = O._writableState;
      (!ne || ne.autoDestroy && ne.finished) && O.destroy();
    }
  }
  typeof Symbol == "function" && (ce.from = function(N, O) {
    return ee === void 0 && (ee = requireFromBrowser()), ee(ce, N, O);
  });
  function te(N, O) {
    for (var ne = 0, de = N.length; ne < de; ne++)
      if (N[ne] === O)
        return ne;
    return -1;
  }
  return _stream_readable$1;
}
var _stream_transform$1, hasRequired_stream_transform;
function require_stream_transform() {
  if (hasRequired_stream_transform)
    return _stream_transform$1;
  hasRequired_stream_transform = 1, _stream_transform$1 = h;
  var t = requireErrorsBrowser().codes, e = t.ERR_METHOD_NOT_IMPLEMENTED, n = t.ERR_MULTIPLE_CALLBACK, a = t.ERR_TRANSFORM_ALREADY_TRANSFORMING, c = t.ERR_TRANSFORM_WITH_LENGTH_0, o = require_stream_duplex$1();
  inherits_browserExports(h, o);
  function u(l, b) {
    var E = this._transformState;
    E.transforming = !1;
    var C = E.writecb;
    if (C === null)
      return this.emit("error", new n());
    E.writechunk = null, E.writecb = null, b != null && this.push(b), C(l);
    var q = this._readableState;
    q.reading = !1, (q.needReadable || q.length < q.highWaterMark) && this._read(q.highWaterMark);
  }
  function h(l) {
    if (!(this instanceof h))
      return new h(l);
    o.call(this, l), this._transformState = {
      afterTransform: u.bind(this),
      needTransform: !1,
      transforming: !1,
      writecb: null,
      writechunk: null,
      writeencoding: null
    }, this._readableState.needReadable = !0, this._readableState.sync = !1, l && (typeof l.transform == "function" && (this._transform = l.transform), typeof l.flush == "function" && (this._flush = l.flush)), this.on("prefinish", p);
  }
  function p() {
    var l = this;
    typeof this._flush == "function" && !this._readableState.destroyed ? this._flush(function(b, E) {
      x(l, b, E);
    }) : x(this, null, null);
  }
  h.prototype.push = function(l, b) {
    return this._transformState.needTransform = !1, o.prototype.push.call(this, l, b);
  }, h.prototype._transform = function(l, b, E) {
    E(new e("_transform()"));
  }, h.prototype._write = function(l, b, E) {
    var C = this._transformState;
    if (C.writecb = E, C.writechunk = l, C.writeencoding = b, !C.transforming) {
      var q = this._readableState;
      (C.needTransform || q.needReadable || q.length < q.highWaterMark) && this._read(q.highWaterMark);
    }
  }, h.prototype._read = function(l) {
    var b = this._transformState;
    b.writechunk !== null && !b.transforming ? (b.transforming = !0, this._transform(b.writechunk, b.writeencoding, b.afterTransform)) : b.needTransform = !0;
  }, h.prototype._destroy = function(l, b) {
    o.prototype._destroy.call(this, l, function(E) {
      b(E);
    });
  };
  function x(l, b, E) {
    if (b)
      return l.emit("error", b);
    if (E != null && l.push(E), l._writableState.length)
      throw new c();
    if (l._transformState.transforming)
      throw new a();
    return l.push(null);
  }
  return _stream_transform$1;
}
var _stream_passthrough$1, hasRequired_stream_passthrough;
function require_stream_passthrough() {
  if (hasRequired_stream_passthrough)
    return _stream_passthrough$1;
  hasRequired_stream_passthrough = 1, _stream_passthrough$1 = e;
  var t = require_stream_transform();
  inherits_browserExports(e, t);
  function e(n) {
    if (!(this instanceof e))
      return new e(n);
    t.call(this, n);
  }
  return e.prototype._transform = function(n, a, c) {
    c(null, n);
  }, _stream_passthrough$1;
}
var pipeline_1, hasRequiredPipeline;
function requirePipeline() {
  if (hasRequiredPipeline)
    return pipeline_1;
  hasRequiredPipeline = 1;
  var t;
  function e(E) {
    var C = !1;
    return function() {
      C || (C = !0, E.apply(void 0, arguments));
    };
  }
  var n = requireErrorsBrowser().codes, a = n.ERR_MISSING_ARGS, c = n.ERR_STREAM_DESTROYED;
  function o(E) {
    if (E)
      throw E;
  }
  function u(E) {
    return E.setHeader && typeof E.abort == "function";
  }
  function h(E, C, q, F) {
    F = e(F);
    var z = !1;
    E.on("close", function() {
      z = !0;
    }), t === void 0 && (t = requireEndOfStream()), t(E, {
      readable: C,
      writable: q
    }, function(U) {
      if (U)
        return F(U);
      z = !0, F();
    });
    var H = !1;
    return function(U) {
      if (!z && !H) {
        if (H = !0, u(E))
          return E.abort();
        if (typeof E.destroy == "function")
          return E.destroy();
        F(U || new c("pipe"));
      }
    };
  }
  function p(E) {
    E();
  }
  function x(E, C) {
    return E.pipe(C);
  }
  function l(E) {
    return !E.length || typeof E[E.length - 1] != "function" ? o : E.pop();
  }
  function b() {
    for (var E = arguments.length, C = new Array(E), q = 0; q < E; q++)
      C[q] = arguments[q];
    var F = l(C);
    if (Array.isArray(C[0]) && (C = C[0]), C.length < 2)
      throw new a("streams");
    var z, H = C.map(function(U, Y) {
      var ee = Y < C.length - 1, se = Y > 0;
      return h(U, ee, se, function(fe) {
        z || (z = fe), fe && H.forEach(p), !ee && (H.forEach(p), F(z));
      });
    });
    return C.reduce(x);
  }
  return pipeline_1 = b, pipeline_1;
}
(function(t, e) {
  e = t.exports = require_stream_readable$1(), e.Stream = e, e.Readable = e, e.Writable = require_stream_writable$1(), e.Duplex = require_stream_duplex$1(), e.Transform = require_stream_transform(), e.PassThrough = require_stream_passthrough(), e.finished = requireEndOfStream(), e.pipeline = requirePipeline();
})(readableBrowser$1, readableBrowser$1.exports);
var readableBrowserExports$1 = readableBrowser$1.exports, Buffer$y = safeBufferExports.Buffer, Transform$7 = readableBrowserExports$1.Transform, inherits$q = inherits_browserExports;
function throwIfNotStringOrBuffer(t, e) {
  if (!Buffer$y.isBuffer(t) && typeof t != "string")
    throw new TypeError(e + " must be a string or a buffer");
}
function HashBase$2(t) {
  Transform$7.call(this), this._block = Buffer$y.allocUnsafe(t), this._blockSize = t, this._blockOffset = 0, this._length = [0, 0, 0, 0], this._finalized = !1;
}
inherits$q(HashBase$2, Transform$7);
HashBase$2.prototype._transform = function(t, e, n) {
  var a = null;
  try {
    this.update(t, e);
  } catch (c) {
    a = c;
  }
  n(a);
};
HashBase$2.prototype._flush = function(t) {
  var e = null;
  try {
    this.push(this.digest());
  } catch (n) {
    e = n;
  }
  t(e);
};
HashBase$2.prototype.update = function(t, e) {
  if (throwIfNotStringOrBuffer(t, "Data"), this._finalized)
    throw new Error("Digest already called");
  Buffer$y.isBuffer(t) || (t = Buffer$y.from(t, e));
  for (var n = this._block, a = 0; this._blockOffset + t.length - a >= this._blockSize; ) {
    for (var c = this._blockOffset; c < this._blockSize; )
      n[c++] = t[a++];
    this._update(), this._blockOffset = 0;
  }
  for (; a < t.length; )
    n[this._blockOffset++] = t[a++];
  for (var o = 0, u = t.length * 8; u > 0; ++o)
    this._length[o] += u, u = this._length[o] / 4294967296 | 0, u > 0 && (this._length[o] -= 4294967296 * u);
  return this;
};
HashBase$2.prototype._update = function() {
  throw new Error("_update is not implemented");
};
HashBase$2.prototype.digest = function(t) {
  if (this._finalized)
    throw new Error("Digest already called");
  this._finalized = !0;
  var e = this._digest();
  t !== void 0 && (e = e.toString(t)), this._block.fill(0), this._blockOffset = 0;
  for (var n = 0; n < 4; ++n)
    this._length[n] = 0;
  return e;
};
HashBase$2.prototype._digest = function() {
  throw new Error("_digest is not implemented");
};
var hashBase = HashBase$2, inherits$p = inherits_browserExports, HashBase$1 = hashBase, Buffer$x = safeBufferExports$1.Buffer, ARRAY16$1 = new Array(16);
function MD5$3() {
  HashBase$1.call(this, 64), this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878;
}
inherits$p(MD5$3, HashBase$1);
MD5$3.prototype._update = function() {
  for (var t = ARRAY16$1, e = 0; e < 16; ++e)
    t[e] = this._block.readInt32LE(e * 4);
  var n = this._a, a = this._b, c = this._c, o = this._d;
  n = fnF(n, a, c, o, t[0], 3614090360, 7), o = fnF(o, n, a, c, t[1], 3905402710, 12), c = fnF(c, o, n, a, t[2], 606105819, 17), a = fnF(a, c, o, n, t[3], 3250441966, 22), n = fnF(n, a, c, o, t[4], 4118548399, 7), o = fnF(o, n, a, c, t[5], 1200080426, 12), c = fnF(c, o, n, a, t[6], 2821735955, 17), a = fnF(a, c, o, n, t[7], 4249261313, 22), n = fnF(n, a, c, o, t[8], 1770035416, 7), o = fnF(o, n, a, c, t[9], 2336552879, 12), c = fnF(c, o, n, a, t[10], 4294925233, 17), a = fnF(a, c, o, n, t[11], 2304563134, 22), n = fnF(n, a, c, o, t[12], 1804603682, 7), o = fnF(o, n, a, c, t[13], 4254626195, 12), c = fnF(c, o, n, a, t[14], 2792965006, 17), a = fnF(a, c, o, n, t[15], 1236535329, 22), n = fnG(n, a, c, o, t[1], 4129170786, 5), o = fnG(o, n, a, c, t[6], 3225465664, 9), c = fnG(c, o, n, a, t[11], 643717713, 14), a = fnG(a, c, o, n, t[0], 3921069994, 20), n = fnG(n, a, c, o, t[5], 3593408605, 5), o = fnG(o, n, a, c, t[10], 38016083, 9), c = fnG(c, o, n, a, t[15], 3634488961, 14), a = fnG(a, c, o, n, t[4], 3889429448, 20), n = fnG(n, a, c, o, t[9], 568446438, 5), o = fnG(o, n, a, c, t[14], 3275163606, 9), c = fnG(c, o, n, a, t[3], 4107603335, 14), a = fnG(a, c, o, n, t[8], 1163531501, 20), n = fnG(n, a, c, o, t[13], 2850285829, 5), o = fnG(o, n, a, c, t[2], 4243563512, 9), c = fnG(c, o, n, a, t[7], 1735328473, 14), a = fnG(a, c, o, n, t[12], 2368359562, 20), n = fnH(n, a, c, o, t[5], 4294588738, 4), o = fnH(o, n, a, c, t[8], 2272392833, 11), c = fnH(c, o, n, a, t[11], 1839030562, 16), a = fnH(a, c, o, n, t[14], 4259657740, 23), n = fnH(n, a, c, o, t[1], 2763975236, 4), o = fnH(o, n, a, c, t[4], 1272893353, 11), c = fnH(c, o, n, a, t[7], 4139469664, 16), a = fnH(a, c, o, n, t[10], 3200236656, 23), n = fnH(n, a, c, o, t[13], 681279174, 4), o = fnH(o, n, a, c, t[0], 3936430074, 11), c = fnH(c, o, n, a, t[3], 3572445317, 16), a = fnH(a, c, o, n, t[6], 76029189, 23), n = fnH(n, a, c, o, t[9], 3654602809, 4), o = fnH(o, n, a, c, t[12], 3873151461, 11), c = fnH(c, o, n, a, t[15], 530742520, 16), a = fnH(a, c, o, n, t[2], 3299628645, 23), n = fnI(n, a, c, o, t[0], 4096336452, 6), o = fnI(o, n, a, c, t[7], 1126891415, 10), c = fnI(c, o, n, a, t[14], 2878612391, 15), a = fnI(a, c, o, n, t[5], 4237533241, 21), n = fnI(n, a, c, o, t[12], 1700485571, 6), o = fnI(o, n, a, c, t[3], 2399980690, 10), c = fnI(c, o, n, a, t[10], 4293915773, 15), a = fnI(a, c, o, n, t[1], 2240044497, 21), n = fnI(n, a, c, o, t[8], 1873313359, 6), o = fnI(o, n, a, c, t[15], 4264355552, 10), c = fnI(c, o, n, a, t[6], 2734768916, 15), a = fnI(a, c, o, n, t[13], 1309151649, 21), n = fnI(n, a, c, o, t[4], 4149444226, 6), o = fnI(o, n, a, c, t[11], 3174756917, 10), c = fnI(c, o, n, a, t[2], 718787259, 15), a = fnI(a, c, o, n, t[9], 3951481745, 21), this._a = this._a + n | 0, this._b = this._b + a | 0, this._c = this._c + c | 0, this._d = this._d + o | 0;
};
MD5$3.prototype._digest = function() {
  this._block[this._blockOffset++] = 128, this._blockOffset > 56 && (this._block.fill(0, this._blockOffset, 64), this._update(), this._blockOffset = 0), this._block.fill(0, this._blockOffset, 56), this._block.writeUInt32LE(this._length[0], 56), this._block.writeUInt32LE(this._length[1], 60), this._update();
  var t = Buffer$x.allocUnsafe(16);
  return t.writeInt32LE(this._a, 0), t.writeInt32LE(this._b, 4), t.writeInt32LE(this._c, 8), t.writeInt32LE(this._d, 12), t;
};
function rotl$1(t, e) {
  return t << e | t >>> 32 - e;
}
function fnF(t, e, n, a, c, o, u) {
  return rotl$1(t + (e & n | ~e & a) + c + o | 0, u) + e | 0;
}
function fnG(t, e, n, a, c, o, u) {
  return rotl$1(t + (e & a | n & ~a) + c + o | 0, u) + e | 0;
}
function fnH(t, e, n, a, c, o, u) {
  return rotl$1(t + (e ^ n ^ a) + c + o | 0, u) + e | 0;
}
function fnI(t, e, n, a, c, o, u) {
  return rotl$1(t + (n ^ (e | ~a)) + c + o | 0, u) + e | 0;
}
var md5_js = MD5$3, Buffer$w = require$$1$2.Buffer, inherits$o = inherits_browserExports, HashBase = hashBase, ARRAY16 = new Array(16), zl = [
  0,
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  14,
  15,
  7,
  4,
  13,
  1,
  10,
  6,
  15,
  3,
  12,
  0,
  9,
  5,
  2,
  14,
  11,
  8,
  3,
  10,
  14,
  4,
  9,
  15,
  8,
  1,
  2,
  7,
  0,
  6,
  13,
  11,
  5,
  12,
  1,
  9,
  11,
  10,
  0,
  8,
  12,
  4,
  13,
  3,
  7,
  15,
  14,
  5,
  6,
  2,
  4,
  0,
  5,
  9,
  7,
  12,
  2,
  10,
  14,
  1,
  3,
  8,
  11,
  6,
  15,
  13
], zr = [
  5,
  14,
  7,
  0,
  9,
  2,
  11,
  4,
  13,
  6,
  15,
  8,
  1,
  10,
  3,
  12,
  6,
  11,
  3,
  7,
  0,
  13,
  5,
  10,
  14,
  15,
  8,
  12,
  4,
  9,
  1,
  2,
  15,
  5,
  1,
  3,
  7,
  14,
  6,
  9,
  11,
  8,
  12,
  2,
  10,
  0,
  4,
  13,
  8,
  6,
  4,
  1,
  3,
  11,
  15,
  0,
  5,
  12,
  2,
  13,
  9,
  7,
  10,
  14,
  12,
  15,
  10,
  4,
  1,
  5,
  8,
  7,
  6,
  2,
  13,
  14,
  0,
  3,
  9,
  11
], sl = [
  11,
  14,
  15,
  12,
  5,
  8,
  7,
  9,
  11,
  13,
  14,
  15,
  6,
  7,
  9,
  8,
  7,
  6,
  8,
  13,
  11,
  9,
  7,
  15,
  7,
  12,
  15,
  9,
  11,
  7,
  13,
  12,
  11,
  13,
  6,
  7,
  14,
  9,
  13,
  15,
  14,
  8,
  13,
  6,
  5,
  12,
  7,
  5,
  11,
  12,
  14,
  15,
  14,
  15,
  9,
  8,
  9,
  14,
  5,
  6,
  8,
  6,
  5,
  12,
  9,
  15,
  5,
  11,
  6,
  8,
  13,
  12,
  5,
  12,
  13,
  14,
  11,
  8,
  5,
  6
], sr = [
  8,
  9,
  9,
  11,
  13,
  15,
  15,
  5,
  7,
  7,
  8,
  11,
  14,
  14,
  12,
  6,
  9,
  13,
  15,
  7,
  12,
  8,
  9,
  11,
  7,
  7,
  12,
  7,
  6,
  15,
  13,
  11,
  9,
  7,
  15,
  11,
  8,
  6,
  6,
  14,
  12,
  13,
  5,
  14,
  13,
  13,
  7,
  5,
  15,
  5,
  8,
  11,
  14,
  14,
  6,
  14,
  6,
  9,
  12,
  9,
  12,
  5,
  15,
  8,
  8,
  5,
  12,
  9,
  12,
  5,
  14,
  6,
  8,
  13,
  6,
  5,
  15,
  13,
  11,
  11
], hl = [0, 1518500249, 1859775393, 2400959708, 2840853838], hr = [1352829926, 1548603684, 1836072691, 2053994217, 0];
function RIPEMD160$4() {
  HashBase.call(this, 64), this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520;
}
inherits$o(RIPEMD160$4, HashBase);
RIPEMD160$4.prototype._update = function() {
  for (var t = ARRAY16, e = 0; e < 16; ++e)
    t[e] = this._block.readInt32LE(e * 4);
  for (var n = this._a | 0, a = this._b | 0, c = this._c | 0, o = this._d | 0, u = this._e | 0, h = this._a | 0, p = this._b | 0, x = this._c | 0, l = this._d | 0, b = this._e | 0, E = 0; E < 80; E += 1) {
    var C, q;
    E < 16 ? (C = fn1(n, a, c, o, u, t[zl[E]], hl[0], sl[E]), q = fn5(h, p, x, l, b, t[zr[E]], hr[0], sr[E])) : E < 32 ? (C = fn2(n, a, c, o, u, t[zl[E]], hl[1], sl[E]), q = fn4(h, p, x, l, b, t[zr[E]], hr[1], sr[E])) : E < 48 ? (C = fn3(n, a, c, o, u, t[zl[E]], hl[2], sl[E]), q = fn3(h, p, x, l, b, t[zr[E]], hr[2], sr[E])) : E < 64 ? (C = fn4(n, a, c, o, u, t[zl[E]], hl[3], sl[E]), q = fn2(h, p, x, l, b, t[zr[E]], hr[3], sr[E])) : (C = fn5(n, a, c, o, u, t[zl[E]], hl[4], sl[E]), q = fn1(h, p, x, l, b, t[zr[E]], hr[4], sr[E])), n = u, u = o, o = rotl(c, 10), c = a, a = C, h = b, b = l, l = rotl(x, 10), x = p, p = q;
  }
  var F = this._b + c + l | 0;
  this._b = this._c + o + b | 0, this._c = this._d + u + h | 0, this._d = this._e + n + p | 0, this._e = this._a + a + x | 0, this._a = F;
};
RIPEMD160$4.prototype._digest = function() {
  this._block[this._blockOffset++] = 128, this._blockOffset > 56 && (this._block.fill(0, this._blockOffset, 64), this._update(), this._blockOffset = 0), this._block.fill(0, this._blockOffset, 56), this._block.writeUInt32LE(this._length[0], 56), this._block.writeUInt32LE(this._length[1], 60), this._update();
  var t = Buffer$w.alloc ? Buffer$w.alloc(20) : new Buffer$w(20);
  return t.writeInt32LE(this._a, 0), t.writeInt32LE(this._b, 4), t.writeInt32LE(this._c, 8), t.writeInt32LE(this._d, 12), t.writeInt32LE(this._e, 16), t;
};
function rotl(t, e) {
  return t << e | t >>> 32 - e;
}
function fn1(t, e, n, a, c, o, u, h) {
  return rotl(t + (e ^ n ^ a) + o + u | 0, h) + c | 0;
}
function fn2(t, e, n, a, c, o, u, h) {
  return rotl(t + (e & n | ~e & a) + o + u | 0, h) + c | 0;
}
function fn3(t, e, n, a, c, o, u, h) {
  return rotl(t + ((e | ~n) ^ a) + o + u | 0, h) + c | 0;
}
function fn4(t, e, n, a, c, o, u, h) {
  return rotl(t + (e & a | n & ~a) + o + u | 0, h) + c | 0;
}
function fn5(t, e, n, a, c, o, u, h) {
  return rotl(t + (e ^ (n | ~a)) + o + u | 0, h) + c | 0;
}
var ripemd160 = RIPEMD160$4, sha_js = { exports: {} }, Buffer$v = safeBufferExports$1.Buffer;
function Hash$7(t, e) {
  this._block = Buffer$v.alloc(t), this._finalSize = e, this._blockSize = t, this._len = 0;
}
Hash$7.prototype.update = function(t, e) {
  typeof t == "string" && (e = e || "utf8", t = Buffer$v.from(t, e));
  for (var n = this._block, a = this._blockSize, c = t.length, o = this._len, u = 0; u < c; ) {
    for (var h = o % a, p = Math.min(c - u, a - h), x = 0; x < p; x++)
      n[h + x] = t[u + x];
    o += p, u += p, o % a === 0 && this._update(n);
  }
  return this._len += c, this;
};
Hash$7.prototype.digest = function(t) {
  var e = this._len % this._blockSize;
  this._block[e] = 128, this._block.fill(0, e + 1), e >= this._finalSize && (this._update(this._block), this._block.fill(0));
  var n = this._len * 8;
  if (n <= 4294967295)
    this._block.writeUInt32BE(n, this._blockSize - 4);
  else {
    var a = (n & 4294967295) >>> 0, c = (n - a) / 4294967296;
    this._block.writeUInt32BE(c, this._blockSize - 8), this._block.writeUInt32BE(a, this._blockSize - 4);
  }
  this._update(this._block);
  var o = this._hash();
  return t ? o.toString(t) : o;
};
Hash$7.prototype._update = function() {
  throw new Error("_update must be implemented by subclass");
};
var hash$3 = Hash$7, inherits$n = inherits_browserExports, Hash$6 = hash$3, Buffer$u = safeBufferExports$1.Buffer, K$4 = [
  1518500249,
  1859775393,
  -1894007588,
  -899497514
], W$5 = new Array(80);
function Sha() {
  this.init(), this._w = W$5, Hash$6.call(this, 64, 56);
}
inherits$n(Sha, Hash$6);
Sha.prototype.init = function() {
  return this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520, this;
};
function rotl5$1(t) {
  return t << 5 | t >>> 27;
}
function rotl30$1(t) {
  return t << 30 | t >>> 2;
}
function ft$1(t, e, n, a) {
  return t === 0 ? e & n | ~e & a : t === 2 ? e & n | e & a | n & a : e ^ n ^ a;
}
Sha.prototype._update = function(t) {
  for (var e = this._w, n = this._a | 0, a = this._b | 0, c = this._c | 0, o = this._d | 0, u = this._e | 0, h = 0; h < 16; ++h)
    e[h] = t.readInt32BE(h * 4);
  for (; h < 80; ++h)
    e[h] = e[h - 3] ^ e[h - 8] ^ e[h - 14] ^ e[h - 16];
  for (var p = 0; p < 80; ++p) {
    var x = ~~(p / 20), l = rotl5$1(n) + ft$1(x, a, c, o) + u + e[p] + K$4[x] | 0;
    u = o, o = c, c = rotl30$1(a), a = n, n = l;
  }
  this._a = n + this._a | 0, this._b = a + this._b | 0, this._c = c + this._c | 0, this._d = o + this._d | 0, this._e = u + this._e | 0;
};
Sha.prototype._hash = function() {
  var t = Buffer$u.allocUnsafe(20);
  return t.writeInt32BE(this._a | 0, 0), t.writeInt32BE(this._b | 0, 4), t.writeInt32BE(this._c | 0, 8), t.writeInt32BE(this._d | 0, 12), t.writeInt32BE(this._e | 0, 16), t;
};
var sha$4 = Sha, inherits$m = inherits_browserExports, Hash$5 = hash$3, Buffer$t = safeBufferExports$1.Buffer, K$3 = [
  1518500249,
  1859775393,
  -1894007588,
  -899497514
], W$4 = new Array(80);
function Sha1() {
  this.init(), this._w = W$4, Hash$5.call(this, 64, 56);
}
inherits$m(Sha1, Hash$5);
Sha1.prototype.init = function() {
  return this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520, this;
};
function rotl1(t) {
  return t << 1 | t >>> 31;
}
function rotl5(t) {
  return t << 5 | t >>> 27;
}
function rotl30(t) {
  return t << 30 | t >>> 2;
}
function ft(t, e, n, a) {
  return t === 0 ? e & n | ~e & a : t === 2 ? e & n | e & a | n & a : e ^ n ^ a;
}
Sha1.prototype._update = function(t) {
  for (var e = this._w, n = this._a | 0, a = this._b | 0, c = this._c | 0, o = this._d | 0, u = this._e | 0, h = 0; h < 16; ++h)
    e[h] = t.readInt32BE(h * 4);
  for (; h < 80; ++h)
    e[h] = rotl1(e[h - 3] ^ e[h - 8] ^ e[h - 14] ^ e[h - 16]);
  for (var p = 0; p < 80; ++p) {
    var x = ~~(p / 20), l = rotl5(n) + ft(x, a, c, o) + u + e[p] + K$3[x] | 0;
    u = o, o = c, c = rotl30(a), a = n, n = l;
  }
  this._a = n + this._a | 0, this._b = a + this._b | 0, this._c = c + this._c | 0, this._d = o + this._d | 0, this._e = u + this._e | 0;
};
Sha1.prototype._hash = function() {
  var t = Buffer$t.allocUnsafe(20);
  return t.writeInt32BE(this._a | 0, 0), t.writeInt32BE(this._b | 0, 4), t.writeInt32BE(this._c | 0, 8), t.writeInt32BE(this._d | 0, 12), t.writeInt32BE(this._e | 0, 16), t;
};
var sha1 = Sha1, inherits$l = inherits_browserExports, Hash$4 = hash$3, Buffer$s = safeBufferExports$1.Buffer, K$2 = [
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
], W$3 = new Array(64);
function Sha256$1() {
  this.init(), this._w = W$3, Hash$4.call(this, 64, 56);
}
inherits$l(Sha256$1, Hash$4);
Sha256$1.prototype.init = function() {
  return this._a = 1779033703, this._b = 3144134277, this._c = 1013904242, this._d = 2773480762, this._e = 1359893119, this._f = 2600822924, this._g = 528734635, this._h = 1541459225, this;
};
function ch(t, e, n) {
  return n ^ t & (e ^ n);
}
function maj$1(t, e, n) {
  return t & e | n & (t | e);
}
function sigma0$1(t) {
  return (t >>> 2 | t << 30) ^ (t >>> 13 | t << 19) ^ (t >>> 22 | t << 10);
}
function sigma1$1(t) {
  return (t >>> 6 | t << 26) ^ (t >>> 11 | t << 21) ^ (t >>> 25 | t << 7);
}
function gamma0(t) {
  return (t >>> 7 | t << 25) ^ (t >>> 18 | t << 14) ^ t >>> 3;
}
function gamma1(t) {
  return (t >>> 17 | t << 15) ^ (t >>> 19 | t << 13) ^ t >>> 10;
}
Sha256$1.prototype._update = function(t) {
  for (var e = this._w, n = this._a | 0, a = this._b | 0, c = this._c | 0, o = this._d | 0, u = this._e | 0, h = this._f | 0, p = this._g | 0, x = this._h | 0, l = 0; l < 16; ++l)
    e[l] = t.readInt32BE(l * 4);
  for (; l < 64; ++l)
    e[l] = gamma1(e[l - 2]) + e[l - 7] + gamma0(e[l - 15]) + e[l - 16] | 0;
  for (var b = 0; b < 64; ++b) {
    var E = x + sigma1$1(u) + ch(u, h, p) + K$2[b] + e[b] | 0, C = sigma0$1(n) + maj$1(n, a, c) | 0;
    x = p, p = h, h = u, u = o + E | 0, o = c, c = a, a = n, n = E + C | 0;
  }
  this._a = n + this._a | 0, this._b = a + this._b | 0, this._c = c + this._c | 0, this._d = o + this._d | 0, this._e = u + this._e | 0, this._f = h + this._f | 0, this._g = p + this._g | 0, this._h = x + this._h | 0;
};
Sha256$1.prototype._hash = function() {
  var t = Buffer$s.allocUnsafe(32);
  return t.writeInt32BE(this._a, 0), t.writeInt32BE(this._b, 4), t.writeInt32BE(this._c, 8), t.writeInt32BE(this._d, 12), t.writeInt32BE(this._e, 16), t.writeInt32BE(this._f, 20), t.writeInt32BE(this._g, 24), t.writeInt32BE(this._h, 28), t;
};
var sha256$1 = Sha256$1, inherits$k = inherits_browserExports, Sha256 = sha256$1, Hash$3 = hash$3, Buffer$r = safeBufferExports$1.Buffer, W$2 = new Array(64);
function Sha224() {
  this.init(), this._w = W$2, Hash$3.call(this, 64, 56);
}
inherits$k(Sha224, Sha256);
Sha224.prototype.init = function() {
  return this._a = 3238371032, this._b = 914150663, this._c = 812702999, this._d = 4144912697, this._e = 4290775857, this._f = 1750603025, this._g = 1694076839, this._h = 3204075428, this;
};
Sha224.prototype._hash = function() {
  var t = Buffer$r.allocUnsafe(28);
  return t.writeInt32BE(this._a, 0), t.writeInt32BE(this._b, 4), t.writeInt32BE(this._c, 8), t.writeInt32BE(this._d, 12), t.writeInt32BE(this._e, 16), t.writeInt32BE(this._f, 20), t.writeInt32BE(this._g, 24), t;
};
var sha224$1 = Sha224, inherits$j = inherits_browserExports, Hash$2 = hash$3, Buffer$q = safeBufferExports$1.Buffer, K$1 = [
  1116352408,
  3609767458,
  1899447441,
  602891725,
  3049323471,
  3964484399,
  3921009573,
  2173295548,
  961987163,
  4081628472,
  1508970993,
  3053834265,
  2453635748,
  2937671579,
  2870763221,
  3664609560,
  3624381080,
  2734883394,
  310598401,
  1164996542,
  607225278,
  1323610764,
  1426881987,
  3590304994,
  1925078388,
  4068182383,
  2162078206,
  991336113,
  2614888103,
  633803317,
  3248222580,
  3479774868,
  3835390401,
  2666613458,
  4022224774,
  944711139,
  264347078,
  2341262773,
  604807628,
  2007800933,
  770255983,
  1495990901,
  1249150122,
  1856431235,
  1555081692,
  3175218132,
  1996064986,
  2198950837,
  2554220882,
  3999719339,
  2821834349,
  766784016,
  2952996808,
  2566594879,
  3210313671,
  3203337956,
  3336571891,
  1034457026,
  3584528711,
  2466948901,
  113926993,
  3758326383,
  338241895,
  168717936,
  666307205,
  1188179964,
  773529912,
  1546045734,
  1294757372,
  1522805485,
  1396182291,
  2643833823,
  1695183700,
  2343527390,
  1986661051,
  1014477480,
  2177026350,
  1206759142,
  2456956037,
  344077627,
  2730485921,
  1290863460,
  2820302411,
  3158454273,
  3259730800,
  3505952657,
  3345764771,
  106217008,
  3516065817,
  3606008344,
  3600352804,
  1432725776,
  4094571909,
  1467031594,
  275423344,
  851169720,
  430227734,
  3100823752,
  506948616,
  1363258195,
  659060556,
  3750685593,
  883997877,
  3785050280,
  958139571,
  3318307427,
  1322822218,
  3812723403,
  1537002063,
  2003034995,
  1747873779,
  3602036899,
  1955562222,
  1575990012,
  2024104815,
  1125592928,
  2227730452,
  2716904306,
  2361852424,
  442776044,
  2428436474,
  593698344,
  2756734187,
  3733110249,
  3204031479,
  2999351573,
  3329325298,
  3815920427,
  3391569614,
  3928383900,
  3515267271,
  566280711,
  3940187606,
  3454069534,
  4118630271,
  4000239992,
  116418474,
  1914138554,
  174292421,
  2731055270,
  289380356,
  3203993006,
  460393269,
  320620315,
  685471733,
  587496836,
  852142971,
  1086792851,
  1017036298,
  365543100,
  1126000580,
  2618297676,
  1288033470,
  3409855158,
  1501505948,
  4234509866,
  1607167915,
  987167468,
  1816402316,
  1246189591
], W$1 = new Array(160);
function Sha512() {
  this.init(), this._w = W$1, Hash$2.call(this, 128, 112);
}
inherits$j(Sha512, Hash$2);
Sha512.prototype.init = function() {
  return this._ah = 1779033703, this._bh = 3144134277, this._ch = 1013904242, this._dh = 2773480762, this._eh = 1359893119, this._fh = 2600822924, this._gh = 528734635, this._hh = 1541459225, this._al = 4089235720, this._bl = 2227873595, this._cl = 4271175723, this._dl = 1595750129, this._el = 2917565137, this._fl = 725511199, this._gl = 4215389547, this._hl = 327033209, this;
};
function Ch(t, e, n) {
  return n ^ t & (e ^ n);
}
function maj(t, e, n) {
  return t & e | n & (t | e);
}
function sigma0(t, e) {
  return (t >>> 28 | e << 4) ^ (e >>> 2 | t << 30) ^ (e >>> 7 | t << 25);
}
function sigma1(t, e) {
  return (t >>> 14 | e << 18) ^ (t >>> 18 | e << 14) ^ (e >>> 9 | t << 23);
}
function Gamma0(t, e) {
  return (t >>> 1 | e << 31) ^ (t >>> 8 | e << 24) ^ t >>> 7;
}
function Gamma0l(t, e) {
  return (t >>> 1 | e << 31) ^ (t >>> 8 | e << 24) ^ (t >>> 7 | e << 25);
}
function Gamma1(t, e) {
  return (t >>> 19 | e << 13) ^ (e >>> 29 | t << 3) ^ t >>> 6;
}
function Gamma1l(t, e) {
  return (t >>> 19 | e << 13) ^ (e >>> 29 | t << 3) ^ (t >>> 6 | e << 26);
}
function getCarry(t, e) {
  return t >>> 0 < e >>> 0 ? 1 : 0;
}
Sha512.prototype._update = function(t) {
  for (var e = this._w, n = this._ah | 0, a = this._bh | 0, c = this._ch | 0, o = this._dh | 0, u = this._eh | 0, h = this._fh | 0, p = this._gh | 0, x = this._hh | 0, l = this._al | 0, b = this._bl | 0, E = this._cl | 0, C = this._dl | 0, q = this._el | 0, F = this._fl | 0, z = this._gl | 0, H = this._hl | 0, U = 0; U < 32; U += 2)
    e[U] = t.readInt32BE(U * 4), e[U + 1] = t.readInt32BE(U * 4 + 4);
  for (; U < 160; U += 2) {
    var Y = e[U - 30], ee = e[U - 15 * 2 + 1], se = Gamma0(Y, ee), fe = Gamma0l(ee, Y);
    Y = e[U - 2 * 2], ee = e[U - 2 * 2 + 1];
    var pe = Gamma1(Y, ee), ue = Gamma1l(ee, Y), ce = e[U - 7 * 2], $e = e[U - 7 * 2 + 1], V = e[U - 16 * 2], _ = e[U - 16 * 2 + 1], w = fe + $e | 0, d = se + ce + getCarry(w, fe) | 0;
    w = w + ue | 0, d = d + pe + getCarry(w, ue) | 0, w = w + _ | 0, d = d + V + getCarry(w, _) | 0, e[U] = d, e[U + 1] = w;
  }
  for (var m = 0; m < 160; m += 2) {
    d = e[m], w = e[m + 1];
    var B = maj(n, a, c), $ = maj(l, b, E), P = sigma0(n, l), M = sigma0(l, n), v = sigma1(u, q), A = sigma1(q, u), y = K$1[m], T = K$1[m + 1], Z = Ch(u, h, p), ie = Ch(q, F, z), J = H + A | 0, k = x + v + getCarry(J, H) | 0;
    J = J + ie | 0, k = k + Z + getCarry(J, ie) | 0, J = J + T | 0, k = k + y + getCarry(J, T) | 0, J = J + w | 0, k = k + d + getCarry(J, w) | 0;
    var D = M + $ | 0, X = P + B + getCarry(D, M) | 0;
    x = p, H = z, p = h, z = F, h = u, F = q, q = C + J | 0, u = o + k + getCarry(q, C) | 0, o = c, C = E, c = a, E = b, a = n, b = l, l = J + D | 0, n = k + X + getCarry(l, J) | 0;
  }
  this._al = this._al + l | 0, this._bl = this._bl + b | 0, this._cl = this._cl + E | 0, this._dl = this._dl + C | 0, this._el = this._el + q | 0, this._fl = this._fl + F | 0, this._gl = this._gl + z | 0, this._hl = this._hl + H | 0, this._ah = this._ah + n + getCarry(this._al, l) | 0, this._bh = this._bh + a + getCarry(this._bl, b) | 0, this._ch = this._ch + c + getCarry(this._cl, E) | 0, this._dh = this._dh + o + getCarry(this._dl, C) | 0, this._eh = this._eh + u + getCarry(this._el, q) | 0, this._fh = this._fh + h + getCarry(this._fl, F) | 0, this._gh = this._gh + p + getCarry(this._gl, z) | 0, this._hh = this._hh + x + getCarry(this._hl, H) | 0;
};
Sha512.prototype._hash = function() {
  var t = Buffer$q.allocUnsafe(64);
  function e(n, a, c) {
    t.writeInt32BE(n, c), t.writeInt32BE(a, c + 4);
  }
  return e(this._ah, this._al, 0), e(this._bh, this._bl, 8), e(this._ch, this._cl, 16), e(this._dh, this._dl, 24), e(this._eh, this._el, 32), e(this._fh, this._fl, 40), e(this._gh, this._gl, 48), e(this._hh, this._hl, 56), t;
};
var sha512$1 = Sha512, inherits$i = inherits_browserExports, SHA512$2 = sha512$1, Hash$1 = hash$3, Buffer$p = safeBufferExports$1.Buffer, W = new Array(160);
function Sha384() {
  this.init(), this._w = W, Hash$1.call(this, 128, 112);
}
inherits$i(Sha384, SHA512$2);
Sha384.prototype.init = function() {
  return this._ah = 3418070365, this._bh = 1654270250, this._ch = 2438529370, this._dh = 355462360, this._eh = 1731405415, this._fh = 2394180231, this._gh = 3675008525, this._hh = 1203062813, this._al = 3238371032, this._bl = 914150663, this._cl = 812702999, this._dl = 4144912697, this._el = 4290775857, this._fl = 1750603025, this._gl = 1694076839, this._hl = 3204075428, this;
};
Sha384.prototype._hash = function() {
  var t = Buffer$p.allocUnsafe(48);
  function e(n, a, c) {
    t.writeInt32BE(n, c), t.writeInt32BE(a, c + 4);
  }
  return e(this._ah, this._al, 0), e(this._bh, this._bl, 8), e(this._ch, this._cl, 16), e(this._dh, this._dl, 24), e(this._eh, this._el, 32), e(this._fh, this._fl, 40), t;
};
var sha384$1 = Sha384, exports = sha_js.exports = function(e) {
  e = e.toLowerCase();
  var n = exports[e];
  if (!n)
    throw new Error(e + " is not supported (we accept pull requests)");
  return new n();
};
exports.sha = sha$4;
exports.sha1 = sha1;
exports.sha224 = sha224$1;
exports.sha256 = sha256$1;
exports.sha384 = sha384$1;
exports.sha512 = sha512$1;
var sha_jsExports = sha_js.exports, streamBrowserify = Stream, EE = eventsExports.EventEmitter, inherits$h = inherits_browserExports;
inherits$h(Stream, EE);
Stream.Readable = require_stream_readable$1();
Stream.Writable = require_stream_writable$1();
Stream.Duplex = require_stream_duplex$1();
Stream.Transform = require_stream_transform();
Stream.PassThrough = require_stream_passthrough();
Stream.finished = requireEndOfStream();
Stream.pipeline = requirePipeline();
Stream.Stream = Stream;
function Stream() {
  EE.call(this);
}
Stream.prototype.pipe = function(t, e) {
  var n = this;
  function a(l) {
    t.writable && t.write(l) === !1 && n.pause && n.pause();
  }
  n.on("data", a);
  function c() {
    n.readable && n.resume && n.resume();
  }
  t.on("drain", c), !t._isStdio && (!e || e.end !== !1) && (n.on("end", u), n.on("close", h));
  var o = !1;
  function u() {
    o || (o = !0, t.end());
  }
  function h() {
    o || (o = !0, typeof t.destroy == "function" && t.destroy());
  }
  function p(l) {
    if (x(), EE.listenerCount(this, "error") === 0)
      throw l;
  }
  n.on("error", p), t.on("error", p);
  function x() {
    n.removeListener("data", a), t.removeListener("drain", c), n.removeListener("end", u), n.removeListener("close", h), n.removeListener("error", p), t.removeListener("error", p), n.removeListener("end", x), n.removeListener("close", x), t.removeListener("close", x);
  }
  return n.on("end", x), n.on("close", x), t.on("close", x), t.emit("pipe", n), t;
};
var Buffer$o = safeBufferExports$1.Buffer, Transform$6 = streamBrowserify.Transform, StringDecoder = string_decoder.StringDecoder, inherits$g = inherits_browserExports;
function CipherBase$1(t) {
  Transform$6.call(this), this.hashMode = typeof t == "string", this.hashMode ? this[t] = this._finalOrDigest : this.final = this._finalOrDigest, this._final && (this.__final = this._final, this._final = null), this._decoder = null, this._encoding = null;
}
inherits$g(CipherBase$1, Transform$6);
CipherBase$1.prototype.update = function(t, e, n) {
  typeof t == "string" && (t = Buffer$o.from(t, e));
  var a = this._update(t);
  return this.hashMode ? this : (n && (a = this._toString(a, n)), a);
};
CipherBase$1.prototype.setAutoPadding = function() {
};
CipherBase$1.prototype.getAuthTag = function() {
  throw new Error("trying to get auth tag in unsupported state");
};
CipherBase$1.prototype.setAuthTag = function() {
  throw new Error("trying to set auth tag in unsupported state");
};
CipherBase$1.prototype.setAAD = function() {
  throw new Error("trying to set aad in unsupported state");
};
CipherBase$1.prototype._transform = function(t, e, n) {
  var a;
  try {
    this.hashMode ? this._update(t) : this.push(this._update(t));
  } catch (c) {
    a = c;
  } finally {
    n(a);
  }
};
CipherBase$1.prototype._flush = function(t) {
  var e;
  try {
    this.push(this.__final());
  } catch (n) {
    e = n;
  }
  t(e);
};
CipherBase$1.prototype._finalOrDigest = function(t) {
  var e = this.__final() || Buffer$o.alloc(0);
  return t && (e = this._toString(e, t, !0)), e;
};
CipherBase$1.prototype._toString = function(t, e, n) {
  if (this._decoder || (this._decoder = new StringDecoder(e), this._encoding = e), this._encoding !== e)
    throw new Error("can't switch encodings");
  var a = this._decoder.write(t);
  return n && (a += this._decoder.end()), a;
};
var cipherBase = CipherBase$1, inherits$f = inherits_browserExports, MD5$2 = md5_js, RIPEMD160$3 = ripemd160, sha$3 = sha_jsExports, Base$5 = cipherBase;
function Hash(t) {
  Base$5.call(this, "digest"), this._hash = t;
}
inherits$f(Hash, Base$5);
Hash.prototype._update = function(t) {
  this._hash.update(t);
};
Hash.prototype._final = function() {
  return this._hash.digest();
};
var browser$9 = function(e) {
  return e = e.toLowerCase(), e === "md5" ? new MD5$2() : e === "rmd160" || e === "ripemd160" ? new RIPEMD160$3() : new Hash(sha$3(e));
}, inherits$e = inherits_browserExports, Buffer$n = safeBufferExports$1.Buffer, Base$4 = cipherBase, ZEROS$2 = Buffer$n.alloc(128), blocksize = 64;
function Hmac$3(t, e) {
  Base$4.call(this, "digest"), typeof e == "string" && (e = Buffer$n.from(e)), this._alg = t, this._key = e, e.length > blocksize ? e = t(e) : e.length < blocksize && (e = Buffer$n.concat([e, ZEROS$2], blocksize));
  for (var n = this._ipad = Buffer$n.allocUnsafe(blocksize), a = this._opad = Buffer$n.allocUnsafe(blocksize), c = 0; c < blocksize; c++)
    n[c] = e[c] ^ 54, a[c] = e[c] ^ 92;
  this._hash = [n];
}
inherits$e(Hmac$3, Base$4);
Hmac$3.prototype._update = function(t) {
  this._hash.push(t);
};
Hmac$3.prototype._final = function() {
  var t = this._alg(Buffer$n.concat(this._hash));
  return this._alg(Buffer$n.concat([this._opad, t]));
};
var legacy = Hmac$3, MD5$1 = md5_js, md5$2 = function(t) {
  return new MD5$1().update(t).digest();
}, inherits$d = inherits_browserExports, Legacy = legacy, Base$3 = cipherBase, Buffer$m = safeBufferExports$1.Buffer, md5$1 = md5$2, RIPEMD160$2 = ripemd160, sha$2 = sha_jsExports, ZEROS$1 = Buffer$m.alloc(128);
function Hmac$2(t, e) {
  Base$3.call(this, "digest"), typeof e == "string" && (e = Buffer$m.from(e));
  var n = t === "sha512" || t === "sha384" ? 128 : 64;
  if (this._alg = t, this._key = e, e.length > n) {
    var a = t === "rmd160" ? new RIPEMD160$2() : sha$2(t);
    e = a.update(e).digest();
  } else
    e.length < n && (e = Buffer$m.concat([e, ZEROS$1], n));
  for (var c = this._ipad = Buffer$m.allocUnsafe(n), o = this._opad = Buffer$m.allocUnsafe(n), u = 0; u < n; u++)
    c[u] = e[u] ^ 54, o[u] = e[u] ^ 92;
  this._hash = t === "rmd160" ? new RIPEMD160$2() : sha$2(t), this._hash.update(c);
}
inherits$d(Hmac$2, Base$3);
Hmac$2.prototype._update = function(t) {
  this._hash.update(t);
};
Hmac$2.prototype._final = function() {
  var t = this._hash.digest(), e = this._alg === "rmd160" ? new RIPEMD160$2() : sha$2(this._alg);
  return e.update(this._opad).update(t).digest();
};
var browser$8 = function(e, n) {
  return e = e.toLowerCase(), e === "rmd160" || e === "ripemd160" ? new Hmac$2("rmd160", n) : e === "md5" ? new Legacy(md5$1, n) : new Hmac$2(e, n);
};
const sha224WithRSAEncryption = {
  sign: "rsa",
  hash: "sha224",
  id: "302d300d06096086480165030402040500041c"
}, sha256WithRSAEncryption = {
  sign: "rsa",
  hash: "sha256",
  id: "3031300d060960864801650304020105000420"
}, sha384WithRSAEncryption = {
  sign: "rsa",
  hash: "sha384",
  id: "3041300d060960864801650304020205000430"
}, sha512WithRSAEncryption = {
  sign: "rsa",
  hash: "sha512",
  id: "3051300d060960864801650304020305000440"
}, sha256 = {
  sign: "ecdsa",
  hash: "sha256",
  id: ""
}, sha224 = {
  sign: "ecdsa",
  hash: "sha224",
  id: ""
}, sha384 = {
  sign: "ecdsa",
  hash: "sha384",
  id: ""
}, sha512 = {
  sign: "ecdsa",
  hash: "sha512",
  id: ""
}, DSA = {
  sign: "dsa",
  hash: "sha1",
  id: ""
}, ripemd160WithRSA = {
  sign: "rsa",
  hash: "rmd160",
  id: "3021300906052b2403020105000414"
}, md5WithRSAEncryption = {
  sign: "rsa",
  hash: "md5",
  id: "3020300c06082a864886f70d020505000410"
}, require$$6 = {
  sha224WithRSAEncryption,
  "RSA-SHA224": {
    sign: "ecdsa/rsa",
    hash: "sha224",
    id: "302d300d06096086480165030402040500041c"
  },
  sha256WithRSAEncryption,
  "RSA-SHA256": {
    sign: "ecdsa/rsa",
    hash: "sha256",
    id: "3031300d060960864801650304020105000420"
  },
  sha384WithRSAEncryption,
  "RSA-SHA384": {
    sign: "ecdsa/rsa",
    hash: "sha384",
    id: "3041300d060960864801650304020205000430"
  },
  sha512WithRSAEncryption,
  "RSA-SHA512": {
    sign: "ecdsa/rsa",
    hash: "sha512",
    id: "3051300d060960864801650304020305000440"
  },
  "RSA-SHA1": {
    sign: "rsa",
    hash: "sha1",
    id: "3021300906052b0e03021a05000414"
  },
  "ecdsa-with-SHA1": {
    sign: "ecdsa",
    hash: "sha1",
    id: ""
  },
  sha256,
  sha224,
  sha384,
  sha512,
  "DSA-SHA": {
    sign: "dsa",
    hash: "sha1",
    id: ""
  },
  "DSA-SHA1": {
    sign: "dsa",
    hash: "sha1",
    id: ""
  },
  DSA,
  "DSA-WITH-SHA224": {
    sign: "dsa",
    hash: "sha224",
    id: ""
  },
  "DSA-SHA224": {
    sign: "dsa",
    hash: "sha224",
    id: ""
  },
  "DSA-WITH-SHA256": {
    sign: "dsa",
    hash: "sha256",
    id: ""
  },
  "DSA-SHA256": {
    sign: "dsa",
    hash: "sha256",
    id: ""
  },
  "DSA-WITH-SHA384": {
    sign: "dsa",
    hash: "sha384",
    id: ""
  },
  "DSA-SHA384": {
    sign: "dsa",
    hash: "sha384",
    id: ""
  },
  "DSA-WITH-SHA512": {
    sign: "dsa",
    hash: "sha512",
    id: ""
  },
  "DSA-SHA512": {
    sign: "dsa",
    hash: "sha512",
    id: ""
  },
  "DSA-RIPEMD160": {
    sign: "dsa",
    hash: "rmd160",
    id: ""
  },
  ripemd160WithRSA,
  "RSA-RIPEMD160": {
    sign: "rsa",
    hash: "rmd160",
    id: "3021300906052b2403020105000414"
  },
  md5WithRSAEncryption,
  "RSA-MD5": {
    sign: "rsa",
    hash: "md5",
    id: "3020300c06082a864886f70d020505000410"
  }
};
var algos = require$$6, browser$7 = {}, MAX_ALLOC = Math.pow(2, 30) - 1, precondition = function(t, e) {
  if (typeof t != "number")
    throw new TypeError("Iterations not a number");
  if (t < 0)
    throw new TypeError("Bad iterations");
  if (typeof e != "number")
    throw new TypeError("Key length not a number");
  if (e < 0 || e > MAX_ALLOC || e !== e)
    throw new TypeError("Bad key length");
}, defaultEncoding$2;
if (commonjsGlobal.process && commonjsGlobal.process.browser)
  defaultEncoding$2 = "utf-8";
else if (commonjsGlobal.process && commonjsGlobal.process.version) {
  var pVersionMajor = parseInt(process$1.version.split(".")[0].slice(1), 10);
  defaultEncoding$2 = pVersionMajor >= 6 ? "utf-8" : "binary";
} else
  defaultEncoding$2 = "utf-8";
var defaultEncoding_1 = defaultEncoding$2, Buffer$l = safeBufferExports$1.Buffer, toBuffer$2 = function(t, e, n) {
  if (Buffer$l.isBuffer(t))
    return t;
  if (typeof t == "string")
    return Buffer$l.from(t, e);
  if (ArrayBuffer.isView(t))
    return Buffer$l.from(t.buffer);
  throw new TypeError(n + " must be a string, a Buffer, a typed array or a DataView");
}, md5 = md5$2, RIPEMD160$1 = ripemd160, sha$1 = sha_jsExports, Buffer$k = safeBufferExports$1.Buffer, checkParameters$1 = precondition, defaultEncoding$1 = defaultEncoding_1, toBuffer$1 = toBuffer$2, ZEROS = Buffer$k.alloc(128), sizes = {
  md5: 16,
  sha1: 20,
  sha224: 28,
  sha256: 32,
  sha384: 48,
  sha512: 64,
  rmd160: 20,
  ripemd160: 20
};
function Hmac$1(t, e, n) {
  var a = getDigest(t), c = t === "sha512" || t === "sha384" ? 128 : 64;
  e.length > c ? e = a(e) : e.length < c && (e = Buffer$k.concat([e, ZEROS], c));
  for (var o = Buffer$k.allocUnsafe(c + sizes[t]), u = Buffer$k.allocUnsafe(c + sizes[t]), h = 0; h < c; h++)
    o[h] = e[h] ^ 54, u[h] = e[h] ^ 92;
  var p = Buffer$k.allocUnsafe(c + n + 4);
  o.copy(p, 0, 0, c), this.ipad1 = p, this.ipad2 = o, this.opad = u, this.alg = t, this.blocksize = c, this.hash = a, this.size = sizes[t];
}
Hmac$1.prototype.run = function(t, e) {
  t.copy(e, this.blocksize);
  var n = this.hash(e);
  return n.copy(this.opad, this.blocksize), this.hash(this.opad);
};
function getDigest(t) {
  function e(a) {
    return sha$1(t).update(a).digest();
  }
  function n(a) {
    return new RIPEMD160$1().update(a).digest();
  }
  return t === "rmd160" || t === "ripemd160" ? n : t === "md5" ? md5 : e;
}
function pbkdf2(t, e, n, a, c) {
  checkParameters$1(n, a), t = toBuffer$1(t, defaultEncoding$1, "Password"), e = toBuffer$1(e, defaultEncoding$1, "Salt"), c = c || "sha1";
  var o = new Hmac$1(c, t, e.length), u = Buffer$k.allocUnsafe(a), h = Buffer$k.allocUnsafe(e.length + 4);
  e.copy(h, 0, 0, e.length);
  for (var p = 0, x = sizes[c], l = Math.ceil(a / x), b = 1; b <= l; b++) {
    h.writeUInt32BE(b, e.length);
    for (var E = o.run(h, o.ipad1), C = E, q = 1; q < n; q++) {
      C = o.run(C, o.ipad2);
      for (var F = 0; F < x; F++)
        E[F] ^= C[F];
    }
    E.copy(u, p), p += x;
  }
  return u;
}
var syncBrowser = pbkdf2, Buffer$j = safeBufferExports$1.Buffer, checkParameters = precondition, defaultEncoding = defaultEncoding_1, sync = syncBrowser, toBuffer = toBuffer$2, ZERO_BUF, subtle = commonjsGlobal.crypto && commonjsGlobal.crypto.subtle, toBrowser = {
  sha: "SHA-1",
  "sha-1": "SHA-1",
  sha1: "SHA-1",
  sha256: "SHA-256",
  "sha-256": "SHA-256",
  sha384: "SHA-384",
  "sha-384": "SHA-384",
  "sha-512": "SHA-512",
  sha512: "SHA-512"
}, checks = [];
function checkNative(t) {
  if (commonjsGlobal.process && !commonjsGlobal.process.browser || !subtle || !subtle.importKey || !subtle.deriveBits)
    return Promise.resolve(!1);
  if (checks[t] !== void 0)
    return checks[t];
  ZERO_BUF = ZERO_BUF || Buffer$j.alloc(8);
  var e = browserPbkdf2(ZERO_BUF, ZERO_BUF, 10, 128, t).then(function() {
    return !0;
  }).catch(function() {
    return !1;
  });
  return checks[t] = e, e;
}
var nextTick$1;
function getNextTick() {
  return nextTick$1 || (commonjsGlobal.process && commonjsGlobal.process.nextTick ? nextTick$1 = commonjsGlobal.process.nextTick : commonjsGlobal.queueMicrotask ? nextTick$1 = commonjsGlobal.queueMicrotask : commonjsGlobal.setImmediate ? nextTick$1 = commonjsGlobal.setImmediate : nextTick$1 = commonjsGlobal.setTimeout, nextTick$1);
}
function browserPbkdf2(t, e, n, a, c) {
  return subtle.importKey(
    "raw",
    t,
    { name: "PBKDF2" },
    !1,
    ["deriveBits"]
  ).then(function(o) {
    return subtle.deriveBits({
      name: "PBKDF2",
      salt: e,
      iterations: n,
      hash: {
        name: c
      }
    }, o, a << 3);
  }).then(function(o) {
    return Buffer$j.from(o);
  });
}
function resolvePromise(t, e) {
  t.then(function(n) {
    getNextTick()(function() {
      e(null, n);
    });
  }, function(n) {
    getNextTick()(function() {
      e(n);
    });
  });
}
var async = function(t, e, n, a, c, o) {
  typeof c == "function" && (o = c, c = void 0), c = c || "sha1";
  var u = toBrowser[c.toLowerCase()];
  if (!u || typeof commonjsGlobal.Promise != "function") {
    getNextTick()(function() {
      var h;
      try {
        h = sync(t, e, n, a, c);
      } catch (p) {
        return o(p);
      }
      o(null, h);
    });
    return;
  }
  if (checkParameters(n, a), t = toBuffer(t, defaultEncoding, "Password"), e = toBuffer(e, defaultEncoding, "Salt"), typeof o != "function")
    throw new Error("No callback provided to pbkdf2");
  resolvePromise(checkNative(u).then(function(h) {
    return h ? browserPbkdf2(t, e, n, a, u) : sync(t, e, n, a, c);
  }), o);
};
browser$7.pbkdf2 = async;
browser$7.pbkdf2Sync = syncBrowser;
var browser$6 = {}, des$2 = {}, utils$n = {};
utils$n.readUInt32BE = function(e, n) {
  var a = e[0 + n] << 24 | e[1 + n] << 16 | e[2 + n] << 8 | e[3 + n];
  return a >>> 0;
};
utils$n.writeUInt32BE = function(e, n, a) {
  e[0 + a] = n >>> 24, e[1 + a] = n >>> 16 & 255, e[2 + a] = n >>> 8 & 255, e[3 + a] = n & 255;
};
utils$n.ip = function(e, n, a, c) {
  for (var o = 0, u = 0, h = 6; h >= 0; h -= 2) {
    for (var p = 0; p <= 24; p += 8)
      o <<= 1, o |= n >>> p + h & 1;
    for (var p = 0; p <= 24; p += 8)
      o <<= 1, o |= e >>> p + h & 1;
  }
  for (var h = 6; h >= 0; h -= 2) {
    for (var p = 1; p <= 25; p += 8)
      u <<= 1, u |= n >>> p + h & 1;
    for (var p = 1; p <= 25; p += 8)
      u <<= 1, u |= e >>> p + h & 1;
  }
  a[c + 0] = o >>> 0, a[c + 1] = u >>> 0;
};
utils$n.rip = function(e, n, a, c) {
  for (var o = 0, u = 0, h = 0; h < 4; h++)
    for (var p = 24; p >= 0; p -= 8)
      o <<= 1, o |= n >>> p + h & 1, o <<= 1, o |= e >>> p + h & 1;
  for (var h = 4; h < 8; h++)
    for (var p = 24; p >= 0; p -= 8)
      u <<= 1, u |= n >>> p + h & 1, u <<= 1, u |= e >>> p + h & 1;
  a[c + 0] = o >>> 0, a[c + 1] = u >>> 0;
};
utils$n.pc1 = function(e, n, a, c) {
  for (var o = 0, u = 0, h = 7; h >= 5; h--) {
    for (var p = 0; p <= 24; p += 8)
      o <<= 1, o |= n >> p + h & 1;
    for (var p = 0; p <= 24; p += 8)
      o <<= 1, o |= e >> p + h & 1;
  }
  for (var p = 0; p <= 24; p += 8)
    o <<= 1, o |= n >> p + h & 1;
  for (var h = 1; h <= 3; h++) {
    for (var p = 0; p <= 24; p += 8)
      u <<= 1, u |= n >> p + h & 1;
    for (var p = 0; p <= 24; p += 8)
      u <<= 1, u |= e >> p + h & 1;
  }
  for (var p = 0; p <= 24; p += 8)
    u <<= 1, u |= e >> p + h & 1;
  a[c + 0] = o >>> 0, a[c + 1] = u >>> 0;
};
utils$n.r28shl = function(e, n) {
  return e << n & 268435455 | e >>> 28 - n;
};
var pc2table = [
  // inL => outL
  14,
  11,
  17,
  4,
  27,
  23,
  25,
  0,
  13,
  22,
  7,
  18,
  5,
  9,
  16,
  24,
  2,
  20,
  12,
  21,
  1,
  8,
  15,
  26,
  // inR => outR
  15,
  4,
  25,
  19,
  9,
  1,
  26,
  16,
  5,
  11,
  23,
  8,
  12,
  7,
  17,
  0,
  22,
  3,
  10,
  14,
  6,
  20,
  27,
  24
];
utils$n.pc2 = function(e, n, a, c) {
  for (var o = 0, u = 0, h = pc2table.length >>> 1, p = 0; p < h; p++)
    o <<= 1, o |= e >>> pc2table[p] & 1;
  for (var p = h; p < pc2table.length; p++)
    u <<= 1, u |= n >>> pc2table[p] & 1;
  a[c + 0] = o >>> 0, a[c + 1] = u >>> 0;
};
utils$n.expand = function(e, n, a) {
  var c = 0, o = 0;
  c = (e & 1) << 5 | e >>> 27;
  for (var u = 23; u >= 15; u -= 4)
    c <<= 6, c |= e >>> u & 63;
  for (var u = 11; u >= 3; u -= 4)
    o |= e >>> u & 63, o <<= 6;
  o |= (e & 31) << 1 | e >>> 31, n[a + 0] = c >>> 0, n[a + 1] = o >>> 0;
};
var sTable = [
  14,
  0,
  4,
  15,
  13,
  7,
  1,
  4,
  2,
  14,
  15,
  2,
  11,
  13,
  8,
  1,
  3,
  10,
  10,
  6,
  6,
  12,
  12,
  11,
  5,
  9,
  9,
  5,
  0,
  3,
  7,
  8,
  4,
  15,
  1,
  12,
  14,
  8,
  8,
  2,
  13,
  4,
  6,
  9,
  2,
  1,
  11,
  7,
  15,
  5,
  12,
  11,
  9,
  3,
  7,
  14,
  3,
  10,
  10,
  0,
  5,
  6,
  0,
  13,
  15,
  3,
  1,
  13,
  8,
  4,
  14,
  7,
  6,
  15,
  11,
  2,
  3,
  8,
  4,
  14,
  9,
  12,
  7,
  0,
  2,
  1,
  13,
  10,
  12,
  6,
  0,
  9,
  5,
  11,
  10,
  5,
  0,
  13,
  14,
  8,
  7,
  10,
  11,
  1,
  10,
  3,
  4,
  15,
  13,
  4,
  1,
  2,
  5,
  11,
  8,
  6,
  12,
  7,
  6,
  12,
  9,
  0,
  3,
  5,
  2,
  14,
  15,
  9,
  10,
  13,
  0,
  7,
  9,
  0,
  14,
  9,
  6,
  3,
  3,
  4,
  15,
  6,
  5,
  10,
  1,
  2,
  13,
  8,
  12,
  5,
  7,
  14,
  11,
  12,
  4,
  11,
  2,
  15,
  8,
  1,
  13,
  1,
  6,
  10,
  4,
  13,
  9,
  0,
  8,
  6,
  15,
  9,
  3,
  8,
  0,
  7,
  11,
  4,
  1,
  15,
  2,
  14,
  12,
  3,
  5,
  11,
  10,
  5,
  14,
  2,
  7,
  12,
  7,
  13,
  13,
  8,
  14,
  11,
  3,
  5,
  0,
  6,
  6,
  15,
  9,
  0,
  10,
  3,
  1,
  4,
  2,
  7,
  8,
  2,
  5,
  12,
  11,
  1,
  12,
  10,
  4,
  14,
  15,
  9,
  10,
  3,
  6,
  15,
  9,
  0,
  0,
  6,
  12,
  10,
  11,
  1,
  7,
  13,
  13,
  8,
  15,
  9,
  1,
  4,
  3,
  5,
  14,
  11,
  5,
  12,
  2,
  7,
  8,
  2,
  4,
  14,
  2,
  14,
  12,
  11,
  4,
  2,
  1,
  12,
  7,
  4,
  10,
  7,
  11,
  13,
  6,
  1,
  8,
  5,
  5,
  0,
  3,
  15,
  15,
  10,
  13,
  3,
  0,
  9,
  14,
  8,
  9,
  6,
  4,
  11,
  2,
  8,
  1,
  12,
  11,
  7,
  10,
  1,
  13,
  14,
  7,
  2,
  8,
  13,
  15,
  6,
  9,
  15,
  12,
  0,
  5,
  9,
  6,
  10,
  3,
  4,
  0,
  5,
  14,
  3,
  12,
  10,
  1,
  15,
  10,
  4,
  15,
  2,
  9,
  7,
  2,
  12,
  6,
  9,
  8,
  5,
  0,
  6,
  13,
  1,
  3,
  13,
  4,
  14,
  14,
  0,
  7,
  11,
  5,
  3,
  11,
  8,
  9,
  4,
  14,
  3,
  15,
  2,
  5,
  12,
  2,
  9,
  8,
  5,
  12,
  15,
  3,
  10,
  7,
  11,
  0,
  14,
  4,
  1,
  10,
  7,
  1,
  6,
  13,
  0,
  11,
  8,
  6,
  13,
  4,
  13,
  11,
  0,
  2,
  11,
  14,
  7,
  15,
  4,
  0,
  9,
  8,
  1,
  13,
  10,
  3,
  14,
  12,
  3,
  9,
  5,
  7,
  12,
  5,
  2,
  10,
  15,
  6,
  8,
  1,
  6,
  1,
  6,
  4,
  11,
  11,
  13,
  13,
  8,
  12,
  1,
  3,
  4,
  7,
  10,
  14,
  7,
  10,
  9,
  15,
  5,
  6,
  0,
  8,
  15,
  0,
  14,
  5,
  2,
  9,
  3,
  2,
  12,
  13,
  1,
  2,
  15,
  8,
  13,
  4,
  8,
  6,
  10,
  15,
  3,
  11,
  7,
  1,
  4,
  10,
  12,
  9,
  5,
  3,
  6,
  14,
  11,
  5,
  0,
  0,
  14,
  12,
  9,
  7,
  2,
  7,
  2,
  11,
  1,
  4,
  14,
  1,
  7,
  9,
  4,
  12,
  10,
  14,
  8,
  2,
  13,
  0,
  15,
  6,
  12,
  10,
  9,
  13,
  0,
  15,
  3,
  3,
  5,
  5,
  6,
  8,
  11
];
utils$n.substitute = function(e, n) {
  for (var a = 0, c = 0; c < 4; c++) {
    var o = e >>> 18 - c * 6 & 63, u = sTable[c * 64 + o];
    a <<= 4, a |= u;
  }
  for (var c = 0; c < 4; c++) {
    var o = n >>> 18 - c * 6 & 63, u = sTable[4 * 64 + c * 64 + o];
    a <<= 4, a |= u;
  }
  return a >>> 0;
};
var permuteTable = [
  16,
  25,
  12,
  11,
  3,
  20,
  4,
  15,
  31,
  17,
  9,
  6,
  27,
  14,
  1,
  22,
  30,
  24,
  8,
  18,
  0,
  5,
  29,
  23,
  13,
  19,
  2,
  26,
  10,
  21,
  28,
  7
];
utils$n.permute = function(e) {
  for (var n = 0, a = 0; a < permuteTable.length; a++)
    n <<= 1, n |= e >>> permuteTable[a] & 1;
  return n >>> 0;
};
utils$n.padSplit = function(e, n, a) {
  for (var c = e.toString(2); c.length < n; )
    c = "0" + c;
  for (var o = [], u = 0; u < n; u += a)
    o.push(c.slice(u, u + a));
  return o.join(" ");
};
var minimalisticAssert = assert$i;
function assert$i(t, e) {
  if (!t)
    throw new Error(e || "Assertion failed");
}
assert$i.equal = function(e, n, a) {
  if (e != n)
    throw new Error(a || "Assertion failed: " + e + " != " + n);
};
var assert$h = minimalisticAssert;
function Cipher$3(t) {
  this.options = t, this.type = this.options.type, this.blockSize = 8, this._init(), this.buffer = new Array(this.blockSize), this.bufferOff = 0, this.padding = t.padding !== !1;
}
var cipher = Cipher$3;
Cipher$3.prototype._init = function() {
};
Cipher$3.prototype.update = function(e) {
  return e.length === 0 ? [] : this.type === "decrypt" ? this._updateDecrypt(e) : this._updateEncrypt(e);
};
Cipher$3.prototype._buffer = function(e, n) {
  for (var a = Math.min(this.buffer.length - this.bufferOff, e.length - n), c = 0; c < a; c++)
    this.buffer[this.bufferOff + c] = e[n + c];
  return this.bufferOff += a, a;
};
Cipher$3.prototype._flushBuffer = function(e, n) {
  return this._update(this.buffer, 0, e, n), this.bufferOff = 0, this.blockSize;
};
Cipher$3.prototype._updateEncrypt = function(e) {
  var n = 0, a = 0, c = (this.bufferOff + e.length) / this.blockSize | 0, o = new Array(c * this.blockSize);
  this.bufferOff !== 0 && (n += this._buffer(e, n), this.bufferOff === this.buffer.length && (a += this._flushBuffer(o, a)));
  for (var u = e.length - (e.length - n) % this.blockSize; n < u; n += this.blockSize)
    this._update(e, n, o, a), a += this.blockSize;
  for (; n < e.length; n++, this.bufferOff++)
    this.buffer[this.bufferOff] = e[n];
  return o;
};
Cipher$3.prototype._updateDecrypt = function(e) {
  for (var n = 0, a = 0, c = Math.ceil((this.bufferOff + e.length) / this.blockSize) - 1, o = new Array(c * this.blockSize); c > 0; c--)
    n += this._buffer(e, n), a += this._flushBuffer(o, a);
  return n += this._buffer(e, n), o;
};
Cipher$3.prototype.final = function(e) {
  var n;
  e && (n = this.update(e));
  var a;
  return this.type === "encrypt" ? a = this._finalEncrypt() : a = this._finalDecrypt(), n ? n.concat(a) : a;
};
Cipher$3.prototype._pad = function(e, n) {
  if (n === 0)
    return !1;
  for (; n < e.length; )
    e[n++] = 0;
  return !0;
};
Cipher$3.prototype._finalEncrypt = function() {
  if (!this._pad(this.buffer, this.bufferOff))
    return [];
  var e = new Array(this.blockSize);
  return this._update(this.buffer, 0, e, 0), e;
};
Cipher$3.prototype._unpad = function(e) {
  return e;
};
Cipher$3.prototype._finalDecrypt = function() {
  assert$h.equal(this.bufferOff, this.blockSize, "Not enough data to decrypt");
  var e = new Array(this.blockSize);
  return this._flushBuffer(e, 0), this._unpad(e);
};
var assert$g = minimalisticAssert, inherits$c = inherits_browserExports, utils$m = utils$n, Cipher$2 = cipher;
function DESState() {
  this.tmp = new Array(2), this.keys = null;
}
function DES$3(t) {
  Cipher$2.call(this, t);
  var e = new DESState();
  this._desState = e, this.deriveKeys(e, t.key);
}
inherits$c(DES$3, Cipher$2);
var des$1 = DES$3;
DES$3.create = function(e) {
  return new DES$3(e);
};
var shiftTable = [
  1,
  1,
  2,
  2,
  2,
  2,
  2,
  2,
  1,
  2,
  2,
  2,
  2,
  2,
  2,
  1
];
DES$3.prototype.deriveKeys = function(e, n) {
  e.keys = new Array(16 * 2), assert$g.equal(n.length, this.blockSize, "Invalid key length");
  var a = utils$m.readUInt32BE(n, 0), c = utils$m.readUInt32BE(n, 4);
  utils$m.pc1(a, c, e.tmp, 0), a = e.tmp[0], c = e.tmp[1];
  for (var o = 0; o < e.keys.length; o += 2) {
    var u = shiftTable[o >>> 1];
    a = utils$m.r28shl(a, u), c = utils$m.r28shl(c, u), utils$m.pc2(a, c, e.keys, o);
  }
};
DES$3.prototype._update = function(e, n, a, c) {
  var o = this._desState, u = utils$m.readUInt32BE(e, n), h = utils$m.readUInt32BE(e, n + 4);
  utils$m.ip(u, h, o.tmp, 0), u = o.tmp[0], h = o.tmp[1], this.type === "encrypt" ? this._encrypt(o, u, h, o.tmp, 0) : this._decrypt(o, u, h, o.tmp, 0), u = o.tmp[0], h = o.tmp[1], utils$m.writeUInt32BE(a, u, c), utils$m.writeUInt32BE(a, h, c + 4);
};
DES$3.prototype._pad = function(e, n) {
  if (this.padding === !1)
    return !1;
  for (var a = e.length - n, c = n; c < e.length; c++)
    e[c] = a;
  return !0;
};
DES$3.prototype._unpad = function(e) {
  if (this.padding === !1)
    return e;
  for (var n = e[e.length - 1], a = e.length - n; a < e.length; a++)
    assert$g.equal(e[a], n);
  return e.slice(0, e.length - n);
};
DES$3.prototype._encrypt = function(e, n, a, c, o) {
  for (var u = n, h = a, p = 0; p < e.keys.length; p += 2) {
    var x = e.keys[p], l = e.keys[p + 1];
    utils$m.expand(h, e.tmp, 0), x ^= e.tmp[0], l ^= e.tmp[1];
    var b = utils$m.substitute(x, l), E = utils$m.permute(b), C = h;
    h = (u ^ E) >>> 0, u = C;
  }
  utils$m.rip(h, u, c, o);
};
DES$3.prototype._decrypt = function(e, n, a, c, o) {
  for (var u = a, h = n, p = e.keys.length - 2; p >= 0; p -= 2) {
    var x = e.keys[p], l = e.keys[p + 1];
    utils$m.expand(u, e.tmp, 0), x ^= e.tmp[0], l ^= e.tmp[1];
    var b = utils$m.substitute(x, l), E = utils$m.permute(b), C = u;
    u = (h ^ E) >>> 0, h = C;
  }
  utils$m.rip(u, h, c, o);
};
var cbc$1 = {}, assert$f = minimalisticAssert, inherits$b = inherits_browserExports, proto = {};
function CBCState(t) {
  assert$f.equal(t.length, 8, "Invalid IV length"), this.iv = new Array(8);
  for (var e = 0; e < this.iv.length; e++)
    this.iv[e] = t[e];
}
function instantiate(t) {
  function e(o) {
    t.call(this, o), this._cbcInit();
  }
  inherits$b(e, t);
  for (var n = Object.keys(proto), a = 0; a < n.length; a++) {
    var c = n[a];
    e.prototype[c] = proto[c];
  }
  return e.create = function(u) {
    return new e(u);
  }, e;
}
cbc$1.instantiate = instantiate;
proto._cbcInit = function() {
  var e = new CBCState(this.options.iv);
  this._cbcState = e;
};
proto._update = function(e, n, a, c) {
  var o = this._cbcState, u = this.constructor.super_.prototype, h = o.iv;
  if (this.type === "encrypt") {
    for (var p = 0; p < this.blockSize; p++)
      h[p] ^= e[n + p];
    u._update.call(this, h, 0, a, c);
    for (var p = 0; p < this.blockSize; p++)
      h[p] = a[c + p];
  } else {
    u._update.call(this, e, n, a, c);
    for (var p = 0; p < this.blockSize; p++)
      a[c + p] ^= h[p];
    for (var p = 0; p < this.blockSize; p++)
      h[p] = e[n + p];
  }
};
var assert$e = minimalisticAssert, inherits$a = inherits_browserExports, Cipher$1 = cipher, DES$2 = des$1;
function EDEState(t, e) {
  assert$e.equal(e.length, 24, "Invalid key length");
  var n = e.slice(0, 8), a = e.slice(8, 16), c = e.slice(16, 24);
  t === "encrypt" ? this.ciphers = [
    DES$2.create({ type: "encrypt", key: n }),
    DES$2.create({ type: "decrypt", key: a }),
    DES$2.create({ type: "encrypt", key: c })
  ] : this.ciphers = [
    DES$2.create({ type: "decrypt", key: c }),
    DES$2.create({ type: "encrypt", key: a }),
    DES$2.create({ type: "decrypt", key: n })
  ];
}
function EDE(t) {
  Cipher$1.call(this, t);
  var e = new EDEState(this.type, this.options.key);
  this._edeState = e;
}
inherits$a(EDE, Cipher$1);
var ede = EDE;
EDE.create = function(e) {
  return new EDE(e);
};
EDE.prototype._update = function(e, n, a, c) {
  var o = this._edeState;
  o.ciphers[0]._update(e, n, a, c), o.ciphers[1]._update(a, c, a, c), o.ciphers[2]._update(a, c, a, c);
};
EDE.prototype._pad = DES$2.prototype._pad;
EDE.prototype._unpad = DES$2.prototype._unpad;
des$2.utils = utils$n;
des$2.Cipher = cipher;
des$2.DES = des$1;
des$2.CBC = cbc$1;
des$2.EDE = ede;
var CipherBase = cipherBase, des = des$2, inherits$9 = inherits_browserExports, Buffer$i = safeBufferExports$1.Buffer, modes$3 = {
  "des-ede3-cbc": des.CBC.instantiate(des.EDE),
  "des-ede3": des.EDE,
  "des-ede-cbc": des.CBC.instantiate(des.EDE),
  "des-ede": des.EDE,
  "des-cbc": des.CBC.instantiate(des.DES),
  "des-ecb": des.DES
};
modes$3.des = modes$3["des-cbc"];
modes$3.des3 = modes$3["des-ede3-cbc"];
var browserifyDes = DES$1;
inherits$9(DES$1, CipherBase);
function DES$1(t) {
  CipherBase.call(this);
  var e = t.mode.toLowerCase(), n = modes$3[e], a;
  t.decrypt ? a = "decrypt" : a = "encrypt";
  var c = t.key;
  Buffer$i.isBuffer(c) || (c = Buffer$i.from(c)), (e === "des-ede" || e === "des-ede-cbc") && (c = Buffer$i.concat([c, c.slice(0, 8)]));
  var o = t.iv;
  Buffer$i.isBuffer(o) || (o = Buffer$i.from(o)), this._des = n.create({
    key: c,
    iv: o,
    type: a
  });
}
DES$1.prototype._update = function(t) {
  return Buffer$i.from(this._des.update(t));
};
DES$1.prototype._final = function() {
  return Buffer$i.from(this._des.final());
};
var browser$5 = {}, encrypter = {}, ecb = {};
ecb.encrypt = function(t, e) {
  return t._cipher.encryptBlock(e);
};
ecb.decrypt = function(t, e) {
  return t._cipher.decryptBlock(e);
};
var cbc = {}, bufferXor = function(e, n) {
  for (var a = Math.min(e.length, n.length), c = new Buffer$B(a), o = 0; o < a; ++o)
    c[o] = e[o] ^ n[o];
  return c;
}, xor$7 = bufferXor;
cbc.encrypt = function(t, e) {
  var n = xor$7(e, t._prev);
  return t._prev = t._cipher.encryptBlock(n), t._prev;
};
cbc.decrypt = function(t, e) {
  var n = t._prev;
  t._prev = e;
  var a = t._cipher.decryptBlock(e);
  return xor$7(a, n);
};
var cfb = {}, Buffer$h = safeBufferExports$1.Buffer, xor$6 = bufferXor;
function encryptStart(t, e, n) {
  var a = e.length, c = xor$6(e, t._cache);
  return t._cache = t._cache.slice(a), t._prev = Buffer$h.concat([t._prev, n ? e : c]), c;
}
cfb.encrypt = function(t, e, n) {
  for (var a = Buffer$h.allocUnsafe(0), c; e.length; )
    if (t._cache.length === 0 && (t._cache = t._cipher.encryptBlock(t._prev), t._prev = Buffer$h.allocUnsafe(0)), t._cache.length <= e.length)
      c = t._cache.length, a = Buffer$h.concat([a, encryptStart(t, e.slice(0, c), n)]), e = e.slice(c);
    else {
      a = Buffer$h.concat([a, encryptStart(t, e, n)]);
      break;
    }
  return a;
};
var cfb8 = {}, Buffer$g = safeBufferExports$1.Buffer;
function encryptByte$1(t, e, n) {
  var a = t._cipher.encryptBlock(t._prev), c = a[0] ^ e;
  return t._prev = Buffer$g.concat([
    t._prev.slice(1),
    Buffer$g.from([n ? e : c])
  ]), c;
}
cfb8.encrypt = function(t, e, n) {
  for (var a = e.length, c = Buffer$g.allocUnsafe(a), o = -1; ++o < a; )
    c[o] = encryptByte$1(t, e[o], n);
  return c;
};
var cfb1 = {}, Buffer$f = safeBufferExports$1.Buffer;
function encryptByte(t, e, n) {
  for (var a, c = -1, o = 8, u = 0, h, p; ++c < o; )
    a = t._cipher.encryptBlock(t._prev), h = e & 1 << 7 - c ? 128 : 0, p = a[0] ^ h, u += (p & 128) >> c % 8, t._prev = shiftIn(t._prev, n ? h : p);
  return u;
}
function shiftIn(t, e) {
  var n = t.length, a = -1, c = Buffer$f.allocUnsafe(t.length);
  for (t = Buffer$f.concat([t, Buffer$f.from([e])]); ++a < n; )
    c[a] = t[a] << 1 | t[a + 1] >> 7;
  return c;
}
cfb1.encrypt = function(t, e, n) {
  for (var a = e.length, c = Buffer$f.allocUnsafe(a), o = -1; ++o < a; )
    c[o] = encryptByte(t, e[o], n);
  return c;
};
var ofb = {}, xor$5 = bufferXor;
function getBlock$1(t) {
  return t._prev = t._cipher.encryptBlock(t._prev), t._prev;
}
ofb.encrypt = function(t, e) {
  for (; t._cache.length < e.length; )
    t._cache = Buffer$B.concat([t._cache, getBlock$1(t)]);
  var n = t._cache.slice(0, e.length);
  return t._cache = t._cache.slice(e.length), xor$5(e, n);
};
var ctr = {};
function incr32$2(t) {
  for (var e = t.length, n; e--; )
    if (n = t.readUInt8(e), n === 255)
      t.writeUInt8(0, e);
    else {
      n++, t.writeUInt8(n, e);
      break;
    }
}
var incr32_1 = incr32$2, xor$4 = bufferXor, Buffer$e = safeBufferExports$1.Buffer, incr32$1 = incr32_1;
function getBlock(t) {
  var e = t._cipher.encryptBlockRaw(t._prev);
  return incr32$1(t._prev), e;
}
var blockSize = 16;
ctr.encrypt = function(t, e) {
  var n = Math.ceil(e.length / blockSize), a = t._cache.length;
  t._cache = Buffer$e.concat([
    t._cache,
    Buffer$e.allocUnsafe(n * blockSize)
  ]);
  for (var c = 0; c < n; c++) {
    var o = getBlock(t), u = a + c * blockSize;
    t._cache.writeUInt32BE(o[0], u + 0), t._cache.writeUInt32BE(o[1], u + 4), t._cache.writeUInt32BE(o[2], u + 8), t._cache.writeUInt32BE(o[3], u + 12);
  }
  var h = t._cache.slice(0, e.length);
  return t._cache = t._cache.slice(e.length), xor$4(e, h);
};
const aes128 = {
  cipher: "AES",
  key: 128,
  iv: 16,
  mode: "CBC",
  type: "block"
}, aes192 = {
  cipher: "AES",
  key: 192,
  iv: 16,
  mode: "CBC",
  type: "block"
}, aes256 = {
  cipher: "AES",
  key: 256,
  iv: 16,
  mode: "CBC",
  type: "block"
}, require$$2 = {
  "aes-128-ecb": {
    cipher: "AES",
    key: 128,
    iv: 0,
    mode: "ECB",
    type: "block"
  },
  "aes-192-ecb": {
    cipher: "AES",
    key: 192,
    iv: 0,
    mode: "ECB",
    type: "block"
  },
  "aes-256-ecb": {
    cipher: "AES",
    key: 256,
    iv: 0,
    mode: "ECB",
    type: "block"
  },
  "aes-128-cbc": {
    cipher: "AES",
    key: 128,
    iv: 16,
    mode: "CBC",
    type: "block"
  },
  "aes-192-cbc": {
    cipher: "AES",
    key: 192,
    iv: 16,
    mode: "CBC",
    type: "block"
  },
  "aes-256-cbc": {
    cipher: "AES",
    key: 256,
    iv: 16,
    mode: "CBC",
    type: "block"
  },
  aes128,
  aes192,
  aes256,
  "aes-128-cfb": {
    cipher: "AES",
    key: 128,
    iv: 16,
    mode: "CFB",
    type: "stream"
  },
  "aes-192-cfb": {
    cipher: "AES",
    key: 192,
    iv: 16,
    mode: "CFB",
    type: "stream"
  },
  "aes-256-cfb": {
    cipher: "AES",
    key: 256,
    iv: 16,
    mode: "CFB",
    type: "stream"
  },
  "aes-128-cfb8": {
    cipher: "AES",
    key: 128,
    iv: 16,
    mode: "CFB8",
    type: "stream"
  },
  "aes-192-cfb8": {
    cipher: "AES",
    key: 192,
    iv: 16,
    mode: "CFB8",
    type: "stream"
  },
  "aes-256-cfb8": {
    cipher: "AES",
    key: 256,
    iv: 16,
    mode: "CFB8",
    type: "stream"
  },
  "aes-128-cfb1": {
    cipher: "AES",
    key: 128,
    iv: 16,
    mode: "CFB1",
    type: "stream"
  },
  "aes-192-cfb1": {
    cipher: "AES",
    key: 192,
    iv: 16,
    mode: "CFB1",
    type: "stream"
  },
  "aes-256-cfb1": {
    cipher: "AES",
    key: 256,
    iv: 16,
    mode: "CFB1",
    type: "stream"
  },
  "aes-128-ofb": {
    cipher: "AES",
    key: 128,
    iv: 16,
    mode: "OFB",
    type: "stream"
  },
  "aes-192-ofb": {
    cipher: "AES",
    key: 192,
    iv: 16,
    mode: "OFB",
    type: "stream"
  },
  "aes-256-ofb": {
    cipher: "AES",
    key: 256,
    iv: 16,
    mode: "OFB",
    type: "stream"
  },
  "aes-128-ctr": {
    cipher: "AES",
    key: 128,
    iv: 16,
    mode: "CTR",
    type: "stream"
  },
  "aes-192-ctr": {
    cipher: "AES",
    key: 192,
    iv: 16,
    mode: "CTR",
    type: "stream"
  },
  "aes-256-ctr": {
    cipher: "AES",
    key: 256,
    iv: 16,
    mode: "CTR",
    type: "stream"
  },
  "aes-128-gcm": {
    cipher: "AES",
    key: 128,
    iv: 12,
    mode: "GCM",
    type: "auth"
  },
  "aes-192-gcm": {
    cipher: "AES",
    key: 192,
    iv: 12,
    mode: "GCM",
    type: "auth"
  },
  "aes-256-gcm": {
    cipher: "AES",
    key: 256,
    iv: 12,
    mode: "GCM",
    type: "auth"
  }
};
var modeModules = {
  ECB: ecb,
  CBC: cbc,
  CFB: cfb,
  CFB8: cfb8,
  CFB1: cfb1,
  OFB: ofb,
  CTR: ctr,
  GCM: ctr
}, modes$2 = require$$2;
for (var key$2 in modes$2)
  modes$2[key$2].module = modeModules[modes$2[key$2].mode];
var modes_1 = modes$2, aes$5 = {}, Buffer$d = safeBufferExports$1.Buffer;
function asUInt32Array(t) {
  Buffer$d.isBuffer(t) || (t = Buffer$d.from(t));
  for (var e = t.length / 4 | 0, n = new Array(e), a = 0; a < e; a++)
    n[a] = t.readUInt32BE(a * 4);
  return n;
}
function scrubVec(t) {
  for (var e = 0; e < t.length; t++)
    t[e] = 0;
}
function cryptBlock(t, e, n, a, c) {
  for (var o = n[0], u = n[1], h = n[2], p = n[3], x = t[0] ^ e[0], l = t[1] ^ e[1], b = t[2] ^ e[2], E = t[3] ^ e[3], C, q, F, z, H = 4, U = 1; U < c; U++)
    C = o[x >>> 24] ^ u[l >>> 16 & 255] ^ h[b >>> 8 & 255] ^ p[E & 255] ^ e[H++], q = o[l >>> 24] ^ u[b >>> 16 & 255] ^ h[E >>> 8 & 255] ^ p[x & 255] ^ e[H++], F = o[b >>> 24] ^ u[E >>> 16 & 255] ^ h[x >>> 8 & 255] ^ p[l & 255] ^ e[H++], z = o[E >>> 24] ^ u[x >>> 16 & 255] ^ h[l >>> 8 & 255] ^ p[b & 255] ^ e[H++], x = C, l = q, b = F, E = z;
  return C = (a[x >>> 24] << 24 | a[l >>> 16 & 255] << 16 | a[b >>> 8 & 255] << 8 | a[E & 255]) ^ e[H++], q = (a[l >>> 24] << 24 | a[b >>> 16 & 255] << 16 | a[E >>> 8 & 255] << 8 | a[x & 255]) ^ e[H++], F = (a[b >>> 24] << 24 | a[E >>> 16 & 255] << 16 | a[x >>> 8 & 255] << 8 | a[l & 255]) ^ e[H++], z = (a[E >>> 24] << 24 | a[x >>> 16 & 255] << 16 | a[l >>> 8 & 255] << 8 | a[b & 255]) ^ e[H++], C = C >>> 0, q = q >>> 0, F = F >>> 0, z = z >>> 0, [C, q, F, z];
}
var RCON = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54], G = function() {
  for (var t = new Array(256), e = 0; e < 256; e++)
    e < 128 ? t[e] = e << 1 : t[e] = e << 1 ^ 283;
  for (var n = [], a = [], c = [[], [], [], []], o = [[], [], [], []], u = 0, h = 0, p = 0; p < 256; ++p) {
    var x = h ^ h << 1 ^ h << 2 ^ h << 3 ^ h << 4;
    x = x >>> 8 ^ x & 255 ^ 99, n[u] = x, a[x] = u;
    var l = t[u], b = t[l], E = t[b], C = t[x] * 257 ^ x * 16843008;
    c[0][u] = C << 24 | C >>> 8, c[1][u] = C << 16 | C >>> 16, c[2][u] = C << 8 | C >>> 24, c[3][u] = C, C = E * 16843009 ^ b * 65537 ^ l * 257 ^ u * 16843008, o[0][x] = C << 24 | C >>> 8, o[1][x] = C << 16 | C >>> 16, o[2][x] = C << 8 | C >>> 24, o[3][x] = C, u === 0 ? u = h = 1 : (u = l ^ t[t[t[E ^ l]]], h ^= t[t[h]]);
  }
  return {
    SBOX: n,
    INV_SBOX: a,
    SUB_MIX: c,
    INV_SUB_MIX: o
  };
}();
function AES(t) {
  this._key = asUInt32Array(t), this._reset();
}
AES.blockSize = 4 * 4;
AES.keySize = 256 / 8;
AES.prototype.blockSize = AES.blockSize;
AES.prototype.keySize = AES.keySize;
AES.prototype._reset = function() {
  for (var t = this._key, e = t.length, n = e + 6, a = (n + 1) * 4, c = [], o = 0; o < e; o++)
    c[o] = t[o];
  for (o = e; o < a; o++) {
    var u = c[o - 1];
    o % e === 0 ? (u = u << 8 | u >>> 24, u = G.SBOX[u >>> 24] << 24 | G.SBOX[u >>> 16 & 255] << 16 | G.SBOX[u >>> 8 & 255] << 8 | G.SBOX[u & 255], u ^= RCON[o / e | 0] << 24) : e > 6 && o % e === 4 && (u = G.SBOX[u >>> 24] << 24 | G.SBOX[u >>> 16 & 255] << 16 | G.SBOX[u >>> 8 & 255] << 8 | G.SBOX[u & 255]), c[o] = c[o - e] ^ u;
  }
  for (var h = [], p = 0; p < a; p++) {
    var x = a - p, l = c[x - (p % 4 ? 0 : 4)];
    p < 4 || x <= 4 ? h[p] = l : h[p] = G.INV_SUB_MIX[0][G.SBOX[l >>> 24]] ^ G.INV_SUB_MIX[1][G.SBOX[l >>> 16 & 255]] ^ G.INV_SUB_MIX[2][G.SBOX[l >>> 8 & 255]] ^ G.INV_SUB_MIX[3][G.SBOX[l & 255]];
  }
  this._nRounds = n, this._keySchedule = c, this._invKeySchedule = h;
};
AES.prototype.encryptBlockRaw = function(t) {
  return t = asUInt32Array(t), cryptBlock(t, this._keySchedule, G.SUB_MIX, G.SBOX, this._nRounds);
};
AES.prototype.encryptBlock = function(t) {
  var e = this.encryptBlockRaw(t), n = Buffer$d.allocUnsafe(16);
  return n.writeUInt32BE(e[0], 0), n.writeUInt32BE(e[1], 4), n.writeUInt32BE(e[2], 8), n.writeUInt32BE(e[3], 12), n;
};
AES.prototype.decryptBlock = function(t) {
  t = asUInt32Array(t);
  var e = t[1];
  t[1] = t[3], t[3] = e;
  var n = cryptBlock(t, this._invKeySchedule, G.INV_SUB_MIX, G.INV_SBOX, this._nRounds), a = Buffer$d.allocUnsafe(16);
  return a.writeUInt32BE(n[0], 0), a.writeUInt32BE(n[3], 4), a.writeUInt32BE(n[2], 8), a.writeUInt32BE(n[1], 12), a;
};
AES.prototype.scrub = function() {
  scrubVec(this._keySchedule), scrubVec(this._invKeySchedule), scrubVec(this._key);
};
aes$5.AES = AES;
var Buffer$c = safeBufferExports$1.Buffer, ZEROES = Buffer$c.alloc(16, 0);
function toArray$1(t) {
  return [
    t.readUInt32BE(0),
    t.readUInt32BE(4),
    t.readUInt32BE(8),
    t.readUInt32BE(12)
  ];
}
function fromArray(t) {
  var e = Buffer$c.allocUnsafe(16);
  return e.writeUInt32BE(t[0] >>> 0, 0), e.writeUInt32BE(t[1] >>> 0, 4), e.writeUInt32BE(t[2] >>> 0, 8), e.writeUInt32BE(t[3] >>> 0, 12), e;
}
function GHASH$1(t) {
  this.h = t, this.state = Buffer$c.alloc(16, 0), this.cache = Buffer$c.allocUnsafe(0);
}
GHASH$1.prototype.ghash = function(t) {
  for (var e = -1; ++e < t.length; )
    this.state[e] ^= t[e];
  this._multiply();
};
GHASH$1.prototype._multiply = function() {
  for (var t = toArray$1(this.h), e = [0, 0, 0, 0], n, a, c, o = -1; ++o < 128; ) {
    for (a = (this.state[~~(o / 8)] & 1 << 7 - o % 8) !== 0, a && (e[0] ^= t[0], e[1] ^= t[1], e[2] ^= t[2], e[3] ^= t[3]), c = (t[3] & 1) !== 0, n = 3; n > 0; n--)
      t[n] = t[n] >>> 1 | (t[n - 1] & 1) << 31;
    t[0] = t[0] >>> 1, c && (t[0] = t[0] ^ 225 << 24);
  }
  this.state = fromArray(e);
};
GHASH$1.prototype.update = function(t) {
  this.cache = Buffer$c.concat([this.cache, t]);
  for (var e; this.cache.length >= 16; )
    e = this.cache.slice(0, 16), this.cache = this.cache.slice(16), this.ghash(e);
};
GHASH$1.prototype.final = function(t, e) {
  return this.cache.length && this.ghash(Buffer$c.concat([this.cache, ZEROES], 16)), this.ghash(fromArray([0, t, 0, e])), this.state;
};
var ghash = GHASH$1, aes$4 = aes$5, Buffer$b = safeBufferExports$1.Buffer, Transform$5 = cipherBase, inherits$8 = inherits_browserExports, GHASH = ghash, xor$3 = bufferXor, incr32 = incr32_1;
function xorTest(t, e) {
  var n = 0;
  t.length !== e.length && n++;
  for (var a = Math.min(t.length, e.length), c = 0; c < a; ++c)
    n += t[c] ^ e[c];
  return n;
}
function calcIv(t, e, n) {
  if (e.length === 12)
    return t._finID = Buffer$b.concat([e, Buffer$b.from([0, 0, 0, 1])]), Buffer$b.concat([e, Buffer$b.from([0, 0, 0, 2])]);
  var a = new GHASH(n), c = e.length, o = c % 16;
  a.update(e), o && (o = 16 - o, a.update(Buffer$b.alloc(o, 0))), a.update(Buffer$b.alloc(8, 0));
  var u = c * 8, h = Buffer$b.alloc(8);
  h.writeUIntBE(u, 0, 8), a.update(h), t._finID = a.state;
  var p = Buffer$b.from(t._finID);
  return incr32(p), p;
}
function StreamCipher$3(t, e, n, a) {
  Transform$5.call(this);
  var c = Buffer$b.alloc(4, 0);
  this._cipher = new aes$4.AES(e);
  var o = this._cipher.encryptBlock(c);
  this._ghash = new GHASH(o), n = calcIv(this, n, o), this._prev = Buffer$b.from(n), this._cache = Buffer$b.allocUnsafe(0), this._secCache = Buffer$b.allocUnsafe(0), this._decrypt = a, this._alen = 0, this._len = 0, this._mode = t, this._authTag = null, this._called = !1;
}
inherits$8(StreamCipher$3, Transform$5);
StreamCipher$3.prototype._update = function(t) {
  if (!this._called && this._alen) {
    var e = 16 - this._alen % 16;
    e < 16 && (e = Buffer$b.alloc(e, 0), this._ghash.update(e));
  }
  this._called = !0;
  var n = this._mode.encrypt(this, t);
  return this._decrypt ? this._ghash.update(t) : this._ghash.update(n), this._len += t.length, n;
};
StreamCipher$3.prototype._final = function() {
  if (this._decrypt && !this._authTag)
    throw new Error("Unsupported state or unable to authenticate data");
  var t = xor$3(this._ghash.final(this._alen * 8, this._len * 8), this._cipher.encryptBlock(this._finID));
  if (this._decrypt && xorTest(t, this._authTag))
    throw new Error("Unsupported state or unable to authenticate data");
  this._authTag = t, this._cipher.scrub();
};
StreamCipher$3.prototype.getAuthTag = function() {
  if (this._decrypt || !Buffer$b.isBuffer(this._authTag))
    throw new Error("Attempting to get auth tag in unsupported state");
  return this._authTag;
};
StreamCipher$3.prototype.setAuthTag = function(e) {
  if (!this._decrypt)
    throw new Error("Attempting to set auth tag in unsupported state");
  this._authTag = e;
};
StreamCipher$3.prototype.setAAD = function(e) {
  if (this._called)
    throw new Error("Attempting to set AAD in unsupported state");
  this._ghash.update(e), this._alen += e.length;
};
var authCipher = StreamCipher$3, aes$3 = aes$5, Buffer$a = safeBufferExports$1.Buffer, Transform$4 = cipherBase, inherits$7 = inherits_browserExports;
function StreamCipher$2(t, e, n, a) {
  Transform$4.call(this), this._cipher = new aes$3.AES(e), this._prev = Buffer$a.from(n), this._cache = Buffer$a.allocUnsafe(0), this._secCache = Buffer$a.allocUnsafe(0), this._decrypt = a, this._mode = t;
}
inherits$7(StreamCipher$2, Transform$4);
StreamCipher$2.prototype._update = function(t) {
  return this._mode.encrypt(this, t, this._decrypt);
};
StreamCipher$2.prototype._final = function() {
  this._cipher.scrub();
};
var streamCipher = StreamCipher$2, Buffer$9 = safeBufferExports$1.Buffer, MD5 = md5_js;
function EVP_BytesToKey(t, e, n, a) {
  if (Buffer$9.isBuffer(t) || (t = Buffer$9.from(t, "binary")), e && (Buffer$9.isBuffer(e) || (e = Buffer$9.from(e, "binary")), e.length !== 8))
    throw new RangeError("salt should be Buffer with 8 byte length");
  for (var c = n / 8, o = Buffer$9.alloc(c), u = Buffer$9.alloc(a || 0), h = Buffer$9.alloc(0); c > 0 || a > 0; ) {
    var p = new MD5();
    p.update(h), p.update(t), e && p.update(e), h = p.digest();
    var x = 0;
    if (c > 0) {
      var l = o.length - c;
      x = Math.min(c, h.length), h.copy(o, l, 0, x), c -= x;
    }
    if (x < h.length && a > 0) {
      var b = u.length - a, E = Math.min(a, h.length - x);
      h.copy(u, b, x, x + E), a -= E;
    }
  }
  return h.fill(0), { key: o, iv: u };
}
var evp_bytestokey = EVP_BytesToKey, MODES$1 = modes_1, AuthCipher$1 = authCipher, Buffer$8 = safeBufferExports$1.Buffer, StreamCipher$1 = streamCipher, Transform$3 = cipherBase, aes$2 = aes$5, ebtk$2 = evp_bytestokey, inherits$6 = inherits_browserExports;
function Cipher(t, e, n) {
  Transform$3.call(this), this._cache = new Splitter$1(), this._cipher = new aes$2.AES(e), this._prev = Buffer$8.from(n), this._mode = t, this._autopadding = !0;
}
inherits$6(Cipher, Transform$3);
Cipher.prototype._update = function(t) {
  this._cache.add(t);
  for (var e, n, a = []; e = this._cache.get(); )
    n = this._mode.encrypt(this, e), a.push(n);
  return Buffer$8.concat(a);
};
var PADDING = Buffer$8.alloc(16, 16);
Cipher.prototype._final = function() {
  var t = this._cache.flush();
  if (this._autopadding)
    return t = this._mode.encrypt(this, t), this._cipher.scrub(), t;
  if (!t.equals(PADDING))
    throw this._cipher.scrub(), new Error("data not multiple of block length");
};
Cipher.prototype.setAutoPadding = function(t) {
  return this._autopadding = !!t, this;
};
function Splitter$1() {
  this.cache = Buffer$8.allocUnsafe(0);
}
Splitter$1.prototype.add = function(t) {
  this.cache = Buffer$8.concat([this.cache, t]);
};
Splitter$1.prototype.get = function() {
  if (this.cache.length > 15) {
    var t = this.cache.slice(0, 16);
    return this.cache = this.cache.slice(16), t;
  }
  return null;
};
Splitter$1.prototype.flush = function() {
  for (var t = 16 - this.cache.length, e = Buffer$8.allocUnsafe(t), n = -1; ++n < t; )
    e.writeUInt8(t, n);
  return Buffer$8.concat([this.cache, e]);
};
function createCipheriv$1(t, e, n) {
  var a = MODES$1[t.toLowerCase()];
  if (!a)
    throw new TypeError("invalid suite type");
  if (typeof e == "string" && (e = Buffer$8.from(e)), e.length !== a.key / 8)
    throw new TypeError("invalid key length " + e.length);
  if (typeof n == "string" && (n = Buffer$8.from(n)), a.mode !== "GCM" && n.length !== a.iv)
    throw new TypeError("invalid iv length " + n.length);
  return a.type === "stream" ? new StreamCipher$1(a.module, e, n) : a.type === "auth" ? new AuthCipher$1(a.module, e, n) : new Cipher(a.module, e, n);
}
function createCipher$1(t, e) {
  var n = MODES$1[t.toLowerCase()];
  if (!n)
    throw new TypeError("invalid suite type");
  var a = ebtk$2(e, !1, n.key, n.iv);
  return createCipheriv$1(t, a.key, a.iv);
}
encrypter.createCipheriv = createCipheriv$1;
encrypter.createCipher = createCipher$1;
var decrypter = {}, AuthCipher = authCipher, Buffer$7 = safeBufferExports$1.Buffer, MODES = modes_1, StreamCipher = streamCipher, Transform$2 = cipherBase, aes$1 = aes$5, ebtk$1 = evp_bytestokey, inherits$5 = inherits_browserExports;
function Decipher(t, e, n) {
  Transform$2.call(this), this._cache = new Splitter(), this._last = void 0, this._cipher = new aes$1.AES(e), this._prev = Buffer$7.from(n), this._mode = t, this._autopadding = !0;
}
inherits$5(Decipher, Transform$2);
Decipher.prototype._update = function(t) {
  this._cache.add(t);
  for (var e, n, a = []; e = this._cache.get(this._autopadding); )
    n = this._mode.decrypt(this, e), a.push(n);
  return Buffer$7.concat(a);
};
Decipher.prototype._final = function() {
  var t = this._cache.flush();
  if (this._autopadding)
    return unpad(this._mode.decrypt(this, t));
  if (t)
    throw new Error("data not multiple of block length");
};
Decipher.prototype.setAutoPadding = function(t) {
  return this._autopadding = !!t, this;
};
function Splitter() {
  this.cache = Buffer$7.allocUnsafe(0);
}
Splitter.prototype.add = function(t) {
  this.cache = Buffer$7.concat([this.cache, t]);
};
Splitter.prototype.get = function(t) {
  var e;
  if (t) {
    if (this.cache.length > 16)
      return e = this.cache.slice(0, 16), this.cache = this.cache.slice(16), e;
  } else if (this.cache.length >= 16)
    return e = this.cache.slice(0, 16), this.cache = this.cache.slice(16), e;
  return null;
};
Splitter.prototype.flush = function() {
  if (this.cache.length)
    return this.cache;
};
function unpad(t) {
  var e = t[15];
  if (e < 1 || e > 16)
    throw new Error("unable to decrypt data");
  for (var n = -1; ++n < e; )
    if (t[n + (16 - e)] !== e)
      throw new Error("unable to decrypt data");
  if (e !== 16)
    return t.slice(0, 16 - e);
}
function createDecipheriv$1(t, e, n) {
  var a = MODES[t.toLowerCase()];
  if (!a)
    throw new TypeError("invalid suite type");
  if (typeof n == "string" && (n = Buffer$7.from(n)), a.mode !== "GCM" && n.length !== a.iv)
    throw new TypeError("invalid iv length " + n.length);
  if (typeof e == "string" && (e = Buffer$7.from(e)), e.length !== a.key / 8)
    throw new TypeError("invalid key length " + e.length);
  return a.type === "stream" ? new StreamCipher(a.module, e, n, !0) : a.type === "auth" ? new AuthCipher(a.module, e, n, !0) : new Decipher(a.module, e, n);
}
function createDecipher$1(t, e) {
  var n = MODES[t.toLowerCase()];
  if (!n)
    throw new TypeError("invalid suite type");
  var a = ebtk$1(e, !1, n.key, n.iv);
  return createDecipheriv$1(t, a.key, a.iv);
}
decrypter.createDecipher = createDecipher$1;
decrypter.createDecipheriv = createDecipheriv$1;
var ciphers$2 = encrypter, deciphers = decrypter, modes$1 = require$$2;
function getCiphers$1() {
  return Object.keys(modes$1);
}
browser$5.createCipher = browser$5.Cipher = ciphers$2.createCipher;
browser$5.createCipheriv = browser$5.Cipheriv = ciphers$2.createCipheriv;
browser$5.createDecipher = browser$5.Decipher = deciphers.createDecipher;
browser$5.createDecipheriv = browser$5.Decipheriv = deciphers.createDecipheriv;
browser$5.listCiphers = browser$5.getCiphers = getCiphers$1;
var modes = {};
(function(t) {
  t["des-ecb"] = {
    key: 8,
    iv: 0
  }, t["des-cbc"] = t.des = {
    key: 8,
    iv: 8
  }, t["des-ede3-cbc"] = t.des3 = {
    key: 24,
    iv: 8
  }, t["des-ede3"] = {
    key: 24,
    iv: 0
  }, t["des-ede-cbc"] = {
    key: 16,
    iv: 8
  }, t["des-ede"] = {
    key: 16,
    iv: 0
  };
})(modes);
var DES = browserifyDes, aes = browser$5, aesModes = modes_1, desModes = modes, ebtk = evp_bytestokey;
function createCipher(t, e) {
  t = t.toLowerCase();
  var n, a;
  if (aesModes[t])
    n = aesModes[t].key, a = aesModes[t].iv;
  else if (desModes[t])
    n = desModes[t].key * 8, a = desModes[t].iv;
  else
    throw new TypeError("invalid suite type");
  var c = ebtk(e, !1, n, a);
  return createCipheriv(t, c.key, c.iv);
}
function createDecipher(t, e) {
  t = t.toLowerCase();
  var n, a;
  if (aesModes[t])
    n = aesModes[t].key, a = aesModes[t].iv;
  else if (desModes[t])
    n = desModes[t].key * 8, a = desModes[t].iv;
  else
    throw new TypeError("invalid suite type");
  var c = ebtk(e, !1, n, a);
  return createDecipheriv(t, c.key, c.iv);
}
function createCipheriv(t, e, n) {
  if (t = t.toLowerCase(), aesModes[t])
    return aes.createCipheriv(t, e, n);
  if (desModes[t])
    return new DES({ key: e, iv: n, mode: t });
  throw new TypeError("invalid suite type");
}
function createDecipheriv(t, e, n) {
  if (t = t.toLowerCase(), aesModes[t])
    return aes.createDecipheriv(t, e, n);
  if (desModes[t])
    return new DES({ key: e, iv: n, mode: t, decrypt: !0 });
  throw new TypeError("invalid suite type");
}
function getCiphers() {
  return Object.keys(desModes).concat(aes.getCiphers());
}
browser$6.createCipher = browser$6.Cipher = createCipher;
browser$6.createCipheriv = browser$6.Cipheriv = createCipheriv;
browser$6.createDecipher = browser$6.Decipher = createDecipher;
browser$6.createDecipheriv = browser$6.Decipheriv = createDecipheriv;
browser$6.listCiphers = browser$6.getCiphers = getCiphers;
var browser$4 = {}, bn$1 = { exports: {} };
bn$1.exports;
(function(t) {
  (function(e, n) {
    function a(V, _) {
      if (!V)
        throw new Error(_ || "Assertion failed");
    }
    function c(V, _) {
      V.super_ = _;
      var w = function() {
      };
      w.prototype = _.prototype, V.prototype = new w(), V.prototype.constructor = V;
    }
    function o(V, _, w) {
      if (o.isBN(V))
        return V;
      this.negative = 0, this.words = null, this.length = 0, this.red = null, V !== null && ((_ === "le" || _ === "be") && (w = _, _ = 10), this._init(V || 0, _ || 10, w || "be"));
    }
    typeof e == "object" ? e.exports = o : n.BN = o, o.BN = o, o.wordSize = 26;
    var u;
    try {
      typeof window < "u" && typeof window.Buffer < "u" ? u = window.Buffer : u = require$$1$2.Buffer;
    } catch {
    }
    o.isBN = function(_) {
      return _ instanceof o ? !0 : _ !== null && typeof _ == "object" && _.constructor.wordSize === o.wordSize && Array.isArray(_.words);
    }, o.max = function(_, w) {
      return _.cmp(w) > 0 ? _ : w;
    }, o.min = function(_, w) {
      return _.cmp(w) < 0 ? _ : w;
    }, o.prototype._init = function(_, w, d) {
      if (typeof _ == "number")
        return this._initNumber(_, w, d);
      if (typeof _ == "object")
        return this._initArray(_, w, d);
      w === "hex" && (w = 16), a(w === (w | 0) && w >= 2 && w <= 36), _ = _.toString().replace(/\s+/g, "");
      var m = 0;
      _[0] === "-" && (m++, this.negative = 1), m < _.length && (w === 16 ? this._parseHex(_, m, d) : (this._parseBase(_, w, m), d === "le" && this._initArray(this.toArray(), w, d)));
    }, o.prototype._initNumber = function(_, w, d) {
      _ < 0 && (this.negative = 1, _ = -_), _ < 67108864 ? (this.words = [_ & 67108863], this.length = 1) : _ < 4503599627370496 ? (this.words = [
        _ & 67108863,
        _ / 67108864 & 67108863
      ], this.length = 2) : (a(_ < 9007199254740992), this.words = [
        _ & 67108863,
        _ / 67108864 & 67108863,
        1
      ], this.length = 3), d === "le" && this._initArray(this.toArray(), w, d);
    }, o.prototype._initArray = function(_, w, d) {
      if (a(typeof _.length == "number"), _.length <= 0)
        return this.words = [0], this.length = 1, this;
      this.length = Math.ceil(_.length / 3), this.words = new Array(this.length);
      for (var m = 0; m < this.length; m++)
        this.words[m] = 0;
      var B, $, P = 0;
      if (d === "be")
        for (m = _.length - 1, B = 0; m >= 0; m -= 3)
          $ = _[m] | _[m - 1] << 8 | _[m - 2] << 16, this.words[B] |= $ << P & 67108863, this.words[B + 1] = $ >>> 26 - P & 67108863, P += 24, P >= 26 && (P -= 26, B++);
      else if (d === "le")
        for (m = 0, B = 0; m < _.length; m += 3)
          $ = _[m] | _[m + 1] << 8 | _[m + 2] << 16, this.words[B] |= $ << P & 67108863, this.words[B + 1] = $ >>> 26 - P & 67108863, P += 24, P >= 26 && (P -= 26, B++);
      return this.strip();
    };
    function h(V, _) {
      var w = V.charCodeAt(_);
      return w >= 65 && w <= 70 ? w - 55 : w >= 97 && w <= 102 ? w - 87 : w - 48 & 15;
    }
    function p(V, _, w) {
      var d = h(V, w);
      return w - 1 >= _ && (d |= h(V, w - 1) << 4), d;
    }
    o.prototype._parseHex = function(_, w, d) {
      this.length = Math.ceil((_.length - w) / 6), this.words = new Array(this.length);
      for (var m = 0; m < this.length; m++)
        this.words[m] = 0;
      var B = 0, $ = 0, P;
      if (d === "be")
        for (m = _.length - 1; m >= w; m -= 2)
          P = p(_, w, m) << B, this.words[$] |= P & 67108863, B >= 18 ? (B -= 18, $ += 1, this.words[$] |= P >>> 26) : B += 8;
      else {
        var M = _.length - w;
        for (m = M % 2 === 0 ? w + 1 : w; m < _.length; m += 2)
          P = p(_, w, m) << B, this.words[$] |= P & 67108863, B >= 18 ? (B -= 18, $ += 1, this.words[$] |= P >>> 26) : B += 8;
      }
      this.strip();
    };
    function x(V, _, w, d) {
      for (var m = 0, B = Math.min(V.length, w), $ = _; $ < B; $++) {
        var P = V.charCodeAt($) - 48;
        m *= d, P >= 49 ? m += P - 49 + 10 : P >= 17 ? m += P - 17 + 10 : m += P;
      }
      return m;
    }
    o.prototype._parseBase = function(_, w, d) {
      this.words = [0], this.length = 1;
      for (var m = 0, B = 1; B <= 67108863; B *= w)
        m++;
      m--, B = B / w | 0;
      for (var $ = _.length - d, P = $ % m, M = Math.min($, $ - P) + d, v = 0, A = d; A < M; A += m)
        v = x(_, A, A + m, w), this.imuln(B), this.words[0] + v < 67108864 ? this.words[0] += v : this._iaddn(v);
      if (P !== 0) {
        var y = 1;
        for (v = x(_, A, _.length, w), A = 0; A < P; A++)
          y *= w;
        this.imuln(y), this.words[0] + v < 67108864 ? this.words[0] += v : this._iaddn(v);
      }
      this.strip();
    }, o.prototype.copy = function(_) {
      _.words = new Array(this.length);
      for (var w = 0; w < this.length; w++)
        _.words[w] = this.words[w];
      _.length = this.length, _.negative = this.negative, _.red = this.red;
    }, o.prototype.clone = function() {
      var _ = new o(null);
      return this.copy(_), _;
    }, o.prototype._expand = function(_) {
      for (; this.length < _; )
        this.words[this.length++] = 0;
      return this;
    }, o.prototype.strip = function() {
      for (; this.length > 1 && this.words[this.length - 1] === 0; )
        this.length--;
      return this._normSign();
    }, o.prototype._normSign = function() {
      return this.length === 1 && this.words[0] === 0 && (this.negative = 0), this;
    }, o.prototype.inspect = function() {
      return (this.red ? "<BN-R: " : "<BN: ") + this.toString(16) + ">";
    };
    var l = [
      "",
      "0",
      "00",
      "000",
      "0000",
      "00000",
      "000000",
      "0000000",
      "00000000",
      "000000000",
      "0000000000",
      "00000000000",
      "000000000000",
      "0000000000000",
      "00000000000000",
      "000000000000000",
      "0000000000000000",
      "00000000000000000",
      "000000000000000000",
      "0000000000000000000",
      "00000000000000000000",
      "000000000000000000000",
      "0000000000000000000000",
      "00000000000000000000000",
      "000000000000000000000000",
      "0000000000000000000000000"
    ], b = [
      0,
      0,
      25,
      16,
      12,
      11,
      10,
      9,
      8,
      8,
      7,
      7,
      7,
      7,
      6,
      6,
      6,
      6,
      6,
      6,
      6,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5
    ], E = [
      0,
      0,
      33554432,
      43046721,
      16777216,
      48828125,
      60466176,
      40353607,
      16777216,
      43046721,
      1e7,
      19487171,
      35831808,
      62748517,
      7529536,
      11390625,
      16777216,
      24137569,
      34012224,
      47045881,
      64e6,
      4084101,
      5153632,
      6436343,
      7962624,
      9765625,
      11881376,
      14348907,
      17210368,
      20511149,
      243e5,
      28629151,
      33554432,
      39135393,
      45435424,
      52521875,
      60466176
    ];
    o.prototype.toString = function(_, w) {
      _ = _ || 10, w = w | 0 || 1;
      var d;
      if (_ === 16 || _ === "hex") {
        d = "";
        for (var m = 0, B = 0, $ = 0; $ < this.length; $++) {
          var P = this.words[$], M = ((P << m | B) & 16777215).toString(16);
          B = P >>> 24 - m & 16777215, B !== 0 || $ !== this.length - 1 ? d = l[6 - M.length] + M + d : d = M + d, m += 2, m >= 26 && (m -= 26, $--);
        }
        for (B !== 0 && (d = B.toString(16) + d); d.length % w !== 0; )
          d = "0" + d;
        return this.negative !== 0 && (d = "-" + d), d;
      }
      if (_ === (_ | 0) && _ >= 2 && _ <= 36) {
        var v = b[_], A = E[_];
        d = "";
        var y = this.clone();
        for (y.negative = 0; !y.isZero(); ) {
          var T = y.modn(A).toString(_);
          y = y.idivn(A), y.isZero() ? d = T + d : d = l[v - T.length] + T + d;
        }
        for (this.isZero() && (d = "0" + d); d.length % w !== 0; )
          d = "0" + d;
        return this.negative !== 0 && (d = "-" + d), d;
      }
      a(!1, "Base should be between 2 and 36");
    }, o.prototype.toNumber = function() {
      var _ = this.words[0];
      return this.length === 2 ? _ += this.words[1] * 67108864 : this.length === 3 && this.words[2] === 1 ? _ += 4503599627370496 + this.words[1] * 67108864 : this.length > 2 && a(!1, "Number can only safely store up to 53 bits"), this.negative !== 0 ? -_ : _;
    }, o.prototype.toJSON = function() {
      return this.toString(16);
    }, o.prototype.toBuffer = function(_, w) {
      return a(typeof u < "u"), this.toArrayLike(u, _, w);
    }, o.prototype.toArray = function(_, w) {
      return this.toArrayLike(Array, _, w);
    }, o.prototype.toArrayLike = function(_, w, d) {
      var m = this.byteLength(), B = d || Math.max(1, m);
      a(m <= B, "byte array longer than desired length"), a(B > 0, "Requested array length <= 0"), this.strip();
      var $ = w === "le", P = new _(B), M, v, A = this.clone();
      if ($) {
        for (v = 0; !A.isZero(); v++)
          M = A.andln(255), A.iushrn(8), P[v] = M;
        for (; v < B; v++)
          P[v] = 0;
      } else {
        for (v = 0; v < B - m; v++)
          P[v] = 0;
        for (v = 0; !A.isZero(); v++)
          M = A.andln(255), A.iushrn(8), P[B - v - 1] = M;
      }
      return P;
    }, Math.clz32 ? o.prototype._countBits = function(_) {
      return 32 - Math.clz32(_);
    } : o.prototype._countBits = function(_) {
      var w = _, d = 0;
      return w >= 4096 && (d += 13, w >>>= 13), w >= 64 && (d += 7, w >>>= 7), w >= 8 && (d += 4, w >>>= 4), w >= 2 && (d += 2, w >>>= 2), d + w;
    }, o.prototype._zeroBits = function(_) {
      if (_ === 0)
        return 26;
      var w = _, d = 0;
      return w & 8191 || (d += 13, w >>>= 13), w & 127 || (d += 7, w >>>= 7), w & 15 || (d += 4, w >>>= 4), w & 3 || (d += 2, w >>>= 2), w & 1 || d++, d;
    }, o.prototype.bitLength = function() {
      var _ = this.words[this.length - 1], w = this._countBits(_);
      return (this.length - 1) * 26 + w;
    };
    function C(V) {
      for (var _ = new Array(V.bitLength()), w = 0; w < _.length; w++) {
        var d = w / 26 | 0, m = w % 26;
        _[w] = (V.words[d] & 1 << m) >>> m;
      }
      return _;
    }
    o.prototype.zeroBits = function() {
      if (this.isZero())
        return 0;
      for (var _ = 0, w = 0; w < this.length; w++) {
        var d = this._zeroBits(this.words[w]);
        if (_ += d, d !== 26)
          break;
      }
      return _;
    }, o.prototype.byteLength = function() {
      return Math.ceil(this.bitLength() / 8);
    }, o.prototype.toTwos = function(_) {
      return this.negative !== 0 ? this.abs().inotn(_).iaddn(1) : this.clone();
    }, o.prototype.fromTwos = function(_) {
      return this.testn(_ - 1) ? this.notn(_).iaddn(1).ineg() : this.clone();
    }, o.prototype.isNeg = function() {
      return this.negative !== 0;
    }, o.prototype.neg = function() {
      return this.clone().ineg();
    }, o.prototype.ineg = function() {
      return this.isZero() || (this.negative ^= 1), this;
    }, o.prototype.iuor = function(_) {
      for (; this.length < _.length; )
        this.words[this.length++] = 0;
      for (var w = 0; w < _.length; w++)
        this.words[w] = this.words[w] | _.words[w];
      return this.strip();
    }, o.prototype.ior = function(_) {
      return a((this.negative | _.negative) === 0), this.iuor(_);
    }, o.prototype.or = function(_) {
      return this.length > _.length ? this.clone().ior(_) : _.clone().ior(this);
    }, o.prototype.uor = function(_) {
      return this.length > _.length ? this.clone().iuor(_) : _.clone().iuor(this);
    }, o.prototype.iuand = function(_) {
      var w;
      this.length > _.length ? w = _ : w = this;
      for (var d = 0; d < w.length; d++)
        this.words[d] = this.words[d] & _.words[d];
      return this.length = w.length, this.strip();
    }, o.prototype.iand = function(_) {
      return a((this.negative | _.negative) === 0), this.iuand(_);
    }, o.prototype.and = function(_) {
      return this.length > _.length ? this.clone().iand(_) : _.clone().iand(this);
    }, o.prototype.uand = function(_) {
      return this.length > _.length ? this.clone().iuand(_) : _.clone().iuand(this);
    }, o.prototype.iuxor = function(_) {
      var w, d;
      this.length > _.length ? (w = this, d = _) : (w = _, d = this);
      for (var m = 0; m < d.length; m++)
        this.words[m] = w.words[m] ^ d.words[m];
      if (this !== w)
        for (; m < w.length; m++)
          this.words[m] = w.words[m];
      return this.length = w.length, this.strip();
    }, o.prototype.ixor = function(_) {
      return a((this.negative | _.negative) === 0), this.iuxor(_);
    }, o.prototype.xor = function(_) {
      return this.length > _.length ? this.clone().ixor(_) : _.clone().ixor(this);
    }, o.prototype.uxor = function(_) {
      return this.length > _.length ? this.clone().iuxor(_) : _.clone().iuxor(this);
    }, o.prototype.inotn = function(_) {
      a(typeof _ == "number" && _ >= 0);
      var w = Math.ceil(_ / 26) | 0, d = _ % 26;
      this._expand(w), d > 0 && w--;
      for (var m = 0; m < w; m++)
        this.words[m] = ~this.words[m] & 67108863;
      return d > 0 && (this.words[m] = ~this.words[m] & 67108863 >> 26 - d), this.strip();
    }, o.prototype.notn = function(_) {
      return this.clone().inotn(_);
    }, o.prototype.setn = function(_, w) {
      a(typeof _ == "number" && _ >= 0);
      var d = _ / 26 | 0, m = _ % 26;
      return this._expand(d + 1), w ? this.words[d] = this.words[d] | 1 << m : this.words[d] = this.words[d] & ~(1 << m), this.strip();
    }, o.prototype.iadd = function(_) {
      var w;
      if (this.negative !== 0 && _.negative === 0)
        return this.negative = 0, w = this.isub(_), this.negative ^= 1, this._normSign();
      if (this.negative === 0 && _.negative !== 0)
        return _.negative = 0, w = this.isub(_), _.negative = 1, w._normSign();
      var d, m;
      this.length > _.length ? (d = this, m = _) : (d = _, m = this);
      for (var B = 0, $ = 0; $ < m.length; $++)
        w = (d.words[$] | 0) + (m.words[$] | 0) + B, this.words[$] = w & 67108863, B = w >>> 26;
      for (; B !== 0 && $ < d.length; $++)
        w = (d.words[$] | 0) + B, this.words[$] = w & 67108863, B = w >>> 26;
      if (this.length = d.length, B !== 0)
        this.words[this.length] = B, this.length++;
      else if (d !== this)
        for (; $ < d.length; $++)
          this.words[$] = d.words[$];
      return this;
    }, o.prototype.add = function(_) {
      var w;
      return _.negative !== 0 && this.negative === 0 ? (_.negative = 0, w = this.sub(_), _.negative ^= 1, w) : _.negative === 0 && this.negative !== 0 ? (this.negative = 0, w = _.sub(this), this.negative = 1, w) : this.length > _.length ? this.clone().iadd(_) : _.clone().iadd(this);
    }, o.prototype.isub = function(_) {
      if (_.negative !== 0) {
        _.negative = 0;
        var w = this.iadd(_);
        return _.negative = 1, w._normSign();
      } else if (this.negative !== 0)
        return this.negative = 0, this.iadd(_), this.negative = 1, this._normSign();
      var d = this.cmp(_);
      if (d === 0)
        return this.negative = 0, this.length = 1, this.words[0] = 0, this;
      var m, B;
      d > 0 ? (m = this, B = _) : (m = _, B = this);
      for (var $ = 0, P = 0; P < B.length; P++)
        w = (m.words[P] | 0) - (B.words[P] | 0) + $, $ = w >> 26, this.words[P] = w & 67108863;
      for (; $ !== 0 && P < m.length; P++)
        w = (m.words[P] | 0) + $, $ = w >> 26, this.words[P] = w & 67108863;
      if ($ === 0 && P < m.length && m !== this)
        for (; P < m.length; P++)
          this.words[P] = m.words[P];
      return this.length = Math.max(this.length, P), m !== this && (this.negative = 1), this.strip();
    }, o.prototype.sub = function(_) {
      return this.clone().isub(_);
    };
    function q(V, _, w) {
      w.negative = _.negative ^ V.negative;
      var d = V.length + _.length | 0;
      w.length = d, d = d - 1 | 0;
      var m = V.words[0] | 0, B = _.words[0] | 0, $ = m * B, P = $ & 67108863, M = $ / 67108864 | 0;
      w.words[0] = P;
      for (var v = 1; v < d; v++) {
        for (var A = M >>> 26, y = M & 67108863, T = Math.min(v, _.length - 1), Z = Math.max(0, v - V.length + 1); Z <= T; Z++) {
          var ie = v - Z | 0;
          m = V.words[ie] | 0, B = _.words[Z] | 0, $ = m * B + y, A += $ / 67108864 | 0, y = $ & 67108863;
        }
        w.words[v] = y | 0, M = A | 0;
      }
      return M !== 0 ? w.words[v] = M | 0 : w.length--, w.strip();
    }
    var F = function(_, w, d) {
      var m = _.words, B = w.words, $ = d.words, P = 0, M, v, A, y = m[0] | 0, T = y & 8191, Z = y >>> 13, ie = m[1] | 0, J = ie & 8191, k = ie >>> 13, D = m[2] | 0, X = D & 8191, te = D >>> 13, N = m[3] | 0, O = N & 8191, ne = N >>> 13, de = m[4] | 0, le = de & 8191, he = de >>> 13, me = m[5] | 0, ge = me & 8191, oe = me >>> 13, qe = m[6] | 0, _e = qe & 8191, Oe = qe >>> 13, De = m[7] | 0, ye = De & 8191, Be = De >>> 13, Le = m[8] | 0, xe = Le & 8191, Te = Le >>> 13, Ne = m[9] | 0, L = Ne & 8191, S = Ne >>> 13, I = B[0] | 0, j = I & 8191, Q = I >>> 13, re = B[1] | 0, ae = re & 8191, ve = re >>> 13, Se = B[2] | 0, be = Se & 8191, Ee = Se >>> 13, we = B[3] | 0, Ae = we & 8191, He = we >>> 13, Ue = B[4] | 0, Me = Ue & 8191, ze = Ue >>> 13, Ke = B[5] | 0, Ie = Ke & 8191, Ge = Ke >>> 13, We = B[6] | 0, Ce = We & 8191, Ve = We >>> 13, Je = B[7] | 0, Re = Je & 8191, Ze = Je >>> 13, Xe = B[8] | 0, Pe = Xe & 8191, Ye = Xe >>> 13, Qe = B[9] | 0, ke = Qe & 8191, et = Qe >>> 13;
      d.negative = _.negative ^ w.negative, d.length = 19, M = Math.imul(T, j), v = Math.imul(T, Q), v = v + Math.imul(Z, j) | 0, A = Math.imul(Z, Q);
      var Fe = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (Fe >>> 26) | 0, Fe &= 67108863, M = Math.imul(J, j), v = Math.imul(J, Q), v = v + Math.imul(k, j) | 0, A = Math.imul(k, Q), M = M + Math.imul(T, ae) | 0, v = v + Math.imul(T, ve) | 0, v = v + Math.imul(Z, ae) | 0, A = A + Math.imul(Z, ve) | 0;
      var je = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (je >>> 26) | 0, je &= 67108863, M = Math.imul(X, j), v = Math.imul(X, Q), v = v + Math.imul(te, j) | 0, A = Math.imul(te, Q), M = M + Math.imul(J, ae) | 0, v = v + Math.imul(J, ve) | 0, v = v + Math.imul(k, ae) | 0, A = A + Math.imul(k, ve) | 0, M = M + Math.imul(T, be) | 0, v = v + Math.imul(T, Ee) | 0, v = v + Math.imul(Z, be) | 0, A = A + Math.imul(Z, Ee) | 0;
      var tt = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (tt >>> 26) | 0, tt &= 67108863, M = Math.imul(O, j), v = Math.imul(O, Q), v = v + Math.imul(ne, j) | 0, A = Math.imul(ne, Q), M = M + Math.imul(X, ae) | 0, v = v + Math.imul(X, ve) | 0, v = v + Math.imul(te, ae) | 0, A = A + Math.imul(te, ve) | 0, M = M + Math.imul(J, be) | 0, v = v + Math.imul(J, Ee) | 0, v = v + Math.imul(k, be) | 0, A = A + Math.imul(k, Ee) | 0, M = M + Math.imul(T, Ae) | 0, v = v + Math.imul(T, He) | 0, v = v + Math.imul(Z, Ae) | 0, A = A + Math.imul(Z, He) | 0;
      var rt = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (rt >>> 26) | 0, rt &= 67108863, M = Math.imul(le, j), v = Math.imul(le, Q), v = v + Math.imul(he, j) | 0, A = Math.imul(he, Q), M = M + Math.imul(O, ae) | 0, v = v + Math.imul(O, ve) | 0, v = v + Math.imul(ne, ae) | 0, A = A + Math.imul(ne, ve) | 0, M = M + Math.imul(X, be) | 0, v = v + Math.imul(X, Ee) | 0, v = v + Math.imul(te, be) | 0, A = A + Math.imul(te, Ee) | 0, M = M + Math.imul(J, Ae) | 0, v = v + Math.imul(J, He) | 0, v = v + Math.imul(k, Ae) | 0, A = A + Math.imul(k, He) | 0, M = M + Math.imul(T, Me) | 0, v = v + Math.imul(T, ze) | 0, v = v + Math.imul(Z, Me) | 0, A = A + Math.imul(Z, ze) | 0;
      var nt = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (nt >>> 26) | 0, nt &= 67108863, M = Math.imul(ge, j), v = Math.imul(ge, Q), v = v + Math.imul(oe, j) | 0, A = Math.imul(oe, Q), M = M + Math.imul(le, ae) | 0, v = v + Math.imul(le, ve) | 0, v = v + Math.imul(he, ae) | 0, A = A + Math.imul(he, ve) | 0, M = M + Math.imul(O, be) | 0, v = v + Math.imul(O, Ee) | 0, v = v + Math.imul(ne, be) | 0, A = A + Math.imul(ne, Ee) | 0, M = M + Math.imul(X, Ae) | 0, v = v + Math.imul(X, He) | 0, v = v + Math.imul(te, Ae) | 0, A = A + Math.imul(te, He) | 0, M = M + Math.imul(J, Me) | 0, v = v + Math.imul(J, ze) | 0, v = v + Math.imul(k, Me) | 0, A = A + Math.imul(k, ze) | 0, M = M + Math.imul(T, Ie) | 0, v = v + Math.imul(T, Ge) | 0, v = v + Math.imul(Z, Ie) | 0, A = A + Math.imul(Z, Ge) | 0;
      var it = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (it >>> 26) | 0, it &= 67108863, M = Math.imul(_e, j), v = Math.imul(_e, Q), v = v + Math.imul(Oe, j) | 0, A = Math.imul(Oe, Q), M = M + Math.imul(ge, ae) | 0, v = v + Math.imul(ge, ve) | 0, v = v + Math.imul(oe, ae) | 0, A = A + Math.imul(oe, ve) | 0, M = M + Math.imul(le, be) | 0, v = v + Math.imul(le, Ee) | 0, v = v + Math.imul(he, be) | 0, A = A + Math.imul(he, Ee) | 0, M = M + Math.imul(O, Ae) | 0, v = v + Math.imul(O, He) | 0, v = v + Math.imul(ne, Ae) | 0, A = A + Math.imul(ne, He) | 0, M = M + Math.imul(X, Me) | 0, v = v + Math.imul(X, ze) | 0, v = v + Math.imul(te, Me) | 0, A = A + Math.imul(te, ze) | 0, M = M + Math.imul(J, Ie) | 0, v = v + Math.imul(J, Ge) | 0, v = v + Math.imul(k, Ie) | 0, A = A + Math.imul(k, Ge) | 0, M = M + Math.imul(T, Ce) | 0, v = v + Math.imul(T, Ve) | 0, v = v + Math.imul(Z, Ce) | 0, A = A + Math.imul(Z, Ve) | 0;
      var at = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (at >>> 26) | 0, at &= 67108863, M = Math.imul(ye, j), v = Math.imul(ye, Q), v = v + Math.imul(Be, j) | 0, A = Math.imul(Be, Q), M = M + Math.imul(_e, ae) | 0, v = v + Math.imul(_e, ve) | 0, v = v + Math.imul(Oe, ae) | 0, A = A + Math.imul(Oe, ve) | 0, M = M + Math.imul(ge, be) | 0, v = v + Math.imul(ge, Ee) | 0, v = v + Math.imul(oe, be) | 0, A = A + Math.imul(oe, Ee) | 0, M = M + Math.imul(le, Ae) | 0, v = v + Math.imul(le, He) | 0, v = v + Math.imul(he, Ae) | 0, A = A + Math.imul(he, He) | 0, M = M + Math.imul(O, Me) | 0, v = v + Math.imul(O, ze) | 0, v = v + Math.imul(ne, Me) | 0, A = A + Math.imul(ne, ze) | 0, M = M + Math.imul(X, Ie) | 0, v = v + Math.imul(X, Ge) | 0, v = v + Math.imul(te, Ie) | 0, A = A + Math.imul(te, Ge) | 0, M = M + Math.imul(J, Ce) | 0, v = v + Math.imul(J, Ve) | 0, v = v + Math.imul(k, Ce) | 0, A = A + Math.imul(k, Ve) | 0, M = M + Math.imul(T, Re) | 0, v = v + Math.imul(T, Ze) | 0, v = v + Math.imul(Z, Re) | 0, A = A + Math.imul(Z, Ze) | 0;
      var ot = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (ot >>> 26) | 0, ot &= 67108863, M = Math.imul(xe, j), v = Math.imul(xe, Q), v = v + Math.imul(Te, j) | 0, A = Math.imul(Te, Q), M = M + Math.imul(ye, ae) | 0, v = v + Math.imul(ye, ve) | 0, v = v + Math.imul(Be, ae) | 0, A = A + Math.imul(Be, ve) | 0, M = M + Math.imul(_e, be) | 0, v = v + Math.imul(_e, Ee) | 0, v = v + Math.imul(Oe, be) | 0, A = A + Math.imul(Oe, Ee) | 0, M = M + Math.imul(ge, Ae) | 0, v = v + Math.imul(ge, He) | 0, v = v + Math.imul(oe, Ae) | 0, A = A + Math.imul(oe, He) | 0, M = M + Math.imul(le, Me) | 0, v = v + Math.imul(le, ze) | 0, v = v + Math.imul(he, Me) | 0, A = A + Math.imul(he, ze) | 0, M = M + Math.imul(O, Ie) | 0, v = v + Math.imul(O, Ge) | 0, v = v + Math.imul(ne, Ie) | 0, A = A + Math.imul(ne, Ge) | 0, M = M + Math.imul(X, Ce) | 0, v = v + Math.imul(X, Ve) | 0, v = v + Math.imul(te, Ce) | 0, A = A + Math.imul(te, Ve) | 0, M = M + Math.imul(J, Re) | 0, v = v + Math.imul(J, Ze) | 0, v = v + Math.imul(k, Re) | 0, A = A + Math.imul(k, Ze) | 0, M = M + Math.imul(T, Pe) | 0, v = v + Math.imul(T, Ye) | 0, v = v + Math.imul(Z, Pe) | 0, A = A + Math.imul(Z, Ye) | 0;
      var st = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (st >>> 26) | 0, st &= 67108863, M = Math.imul(L, j), v = Math.imul(L, Q), v = v + Math.imul(S, j) | 0, A = Math.imul(S, Q), M = M + Math.imul(xe, ae) | 0, v = v + Math.imul(xe, ve) | 0, v = v + Math.imul(Te, ae) | 0, A = A + Math.imul(Te, ve) | 0, M = M + Math.imul(ye, be) | 0, v = v + Math.imul(ye, Ee) | 0, v = v + Math.imul(Be, be) | 0, A = A + Math.imul(Be, Ee) | 0, M = M + Math.imul(_e, Ae) | 0, v = v + Math.imul(_e, He) | 0, v = v + Math.imul(Oe, Ae) | 0, A = A + Math.imul(Oe, He) | 0, M = M + Math.imul(ge, Me) | 0, v = v + Math.imul(ge, ze) | 0, v = v + Math.imul(oe, Me) | 0, A = A + Math.imul(oe, ze) | 0, M = M + Math.imul(le, Ie) | 0, v = v + Math.imul(le, Ge) | 0, v = v + Math.imul(he, Ie) | 0, A = A + Math.imul(he, Ge) | 0, M = M + Math.imul(O, Ce) | 0, v = v + Math.imul(O, Ve) | 0, v = v + Math.imul(ne, Ce) | 0, A = A + Math.imul(ne, Ve) | 0, M = M + Math.imul(X, Re) | 0, v = v + Math.imul(X, Ze) | 0, v = v + Math.imul(te, Re) | 0, A = A + Math.imul(te, Ze) | 0, M = M + Math.imul(J, Pe) | 0, v = v + Math.imul(J, Ye) | 0, v = v + Math.imul(k, Pe) | 0, A = A + Math.imul(k, Ye) | 0, M = M + Math.imul(T, ke) | 0, v = v + Math.imul(T, et) | 0, v = v + Math.imul(Z, ke) | 0, A = A + Math.imul(Z, et) | 0;
      var ct = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (ct >>> 26) | 0, ct &= 67108863, M = Math.imul(L, ae), v = Math.imul(L, ve), v = v + Math.imul(S, ae) | 0, A = Math.imul(S, ve), M = M + Math.imul(xe, be) | 0, v = v + Math.imul(xe, Ee) | 0, v = v + Math.imul(Te, be) | 0, A = A + Math.imul(Te, Ee) | 0, M = M + Math.imul(ye, Ae) | 0, v = v + Math.imul(ye, He) | 0, v = v + Math.imul(Be, Ae) | 0, A = A + Math.imul(Be, He) | 0, M = M + Math.imul(_e, Me) | 0, v = v + Math.imul(_e, ze) | 0, v = v + Math.imul(Oe, Me) | 0, A = A + Math.imul(Oe, ze) | 0, M = M + Math.imul(ge, Ie) | 0, v = v + Math.imul(ge, Ge) | 0, v = v + Math.imul(oe, Ie) | 0, A = A + Math.imul(oe, Ge) | 0, M = M + Math.imul(le, Ce) | 0, v = v + Math.imul(le, Ve) | 0, v = v + Math.imul(he, Ce) | 0, A = A + Math.imul(he, Ve) | 0, M = M + Math.imul(O, Re) | 0, v = v + Math.imul(O, Ze) | 0, v = v + Math.imul(ne, Re) | 0, A = A + Math.imul(ne, Ze) | 0, M = M + Math.imul(X, Pe) | 0, v = v + Math.imul(X, Ye) | 0, v = v + Math.imul(te, Pe) | 0, A = A + Math.imul(te, Ye) | 0, M = M + Math.imul(J, ke) | 0, v = v + Math.imul(J, et) | 0, v = v + Math.imul(k, ke) | 0, A = A + Math.imul(k, et) | 0;
      var ut = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (ut >>> 26) | 0, ut &= 67108863, M = Math.imul(L, be), v = Math.imul(L, Ee), v = v + Math.imul(S, be) | 0, A = Math.imul(S, Ee), M = M + Math.imul(xe, Ae) | 0, v = v + Math.imul(xe, He) | 0, v = v + Math.imul(Te, Ae) | 0, A = A + Math.imul(Te, He) | 0, M = M + Math.imul(ye, Me) | 0, v = v + Math.imul(ye, ze) | 0, v = v + Math.imul(Be, Me) | 0, A = A + Math.imul(Be, ze) | 0, M = M + Math.imul(_e, Ie) | 0, v = v + Math.imul(_e, Ge) | 0, v = v + Math.imul(Oe, Ie) | 0, A = A + Math.imul(Oe, Ge) | 0, M = M + Math.imul(ge, Ce) | 0, v = v + Math.imul(ge, Ve) | 0, v = v + Math.imul(oe, Ce) | 0, A = A + Math.imul(oe, Ve) | 0, M = M + Math.imul(le, Re) | 0, v = v + Math.imul(le, Ze) | 0, v = v + Math.imul(he, Re) | 0, A = A + Math.imul(he, Ze) | 0, M = M + Math.imul(O, Pe) | 0, v = v + Math.imul(O, Ye) | 0, v = v + Math.imul(ne, Pe) | 0, A = A + Math.imul(ne, Ye) | 0, M = M + Math.imul(X, ke) | 0, v = v + Math.imul(X, et) | 0, v = v + Math.imul(te, ke) | 0, A = A + Math.imul(te, et) | 0;
      var dt = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (dt >>> 26) | 0, dt &= 67108863, M = Math.imul(L, Ae), v = Math.imul(L, He), v = v + Math.imul(S, Ae) | 0, A = Math.imul(S, He), M = M + Math.imul(xe, Me) | 0, v = v + Math.imul(xe, ze) | 0, v = v + Math.imul(Te, Me) | 0, A = A + Math.imul(Te, ze) | 0, M = M + Math.imul(ye, Ie) | 0, v = v + Math.imul(ye, Ge) | 0, v = v + Math.imul(Be, Ie) | 0, A = A + Math.imul(Be, Ge) | 0, M = M + Math.imul(_e, Ce) | 0, v = v + Math.imul(_e, Ve) | 0, v = v + Math.imul(Oe, Ce) | 0, A = A + Math.imul(Oe, Ve) | 0, M = M + Math.imul(ge, Re) | 0, v = v + Math.imul(ge, Ze) | 0, v = v + Math.imul(oe, Re) | 0, A = A + Math.imul(oe, Ze) | 0, M = M + Math.imul(le, Pe) | 0, v = v + Math.imul(le, Ye) | 0, v = v + Math.imul(he, Pe) | 0, A = A + Math.imul(he, Ye) | 0, M = M + Math.imul(O, ke) | 0, v = v + Math.imul(O, et) | 0, v = v + Math.imul(ne, ke) | 0, A = A + Math.imul(ne, et) | 0;
      var lt = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (lt >>> 26) | 0, lt &= 67108863, M = Math.imul(L, Me), v = Math.imul(L, ze), v = v + Math.imul(S, Me) | 0, A = Math.imul(S, ze), M = M + Math.imul(xe, Ie) | 0, v = v + Math.imul(xe, Ge) | 0, v = v + Math.imul(Te, Ie) | 0, A = A + Math.imul(Te, Ge) | 0, M = M + Math.imul(ye, Ce) | 0, v = v + Math.imul(ye, Ve) | 0, v = v + Math.imul(Be, Ce) | 0, A = A + Math.imul(Be, Ve) | 0, M = M + Math.imul(_e, Re) | 0, v = v + Math.imul(_e, Ze) | 0, v = v + Math.imul(Oe, Re) | 0, A = A + Math.imul(Oe, Ze) | 0, M = M + Math.imul(ge, Pe) | 0, v = v + Math.imul(ge, Ye) | 0, v = v + Math.imul(oe, Pe) | 0, A = A + Math.imul(oe, Ye) | 0, M = M + Math.imul(le, ke) | 0, v = v + Math.imul(le, et) | 0, v = v + Math.imul(he, ke) | 0, A = A + Math.imul(he, et) | 0;
      var ht = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (ht >>> 26) | 0, ht &= 67108863, M = Math.imul(L, Ie), v = Math.imul(L, Ge), v = v + Math.imul(S, Ie) | 0, A = Math.imul(S, Ge), M = M + Math.imul(xe, Ce) | 0, v = v + Math.imul(xe, Ve) | 0, v = v + Math.imul(Te, Ce) | 0, A = A + Math.imul(Te, Ve) | 0, M = M + Math.imul(ye, Re) | 0, v = v + Math.imul(ye, Ze) | 0, v = v + Math.imul(Be, Re) | 0, A = A + Math.imul(Be, Ze) | 0, M = M + Math.imul(_e, Pe) | 0, v = v + Math.imul(_e, Ye) | 0, v = v + Math.imul(Oe, Pe) | 0, A = A + Math.imul(Oe, Ye) | 0, M = M + Math.imul(ge, ke) | 0, v = v + Math.imul(ge, et) | 0, v = v + Math.imul(oe, ke) | 0, A = A + Math.imul(oe, et) | 0;
      var pt = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (pt >>> 26) | 0, pt &= 67108863, M = Math.imul(L, Ce), v = Math.imul(L, Ve), v = v + Math.imul(S, Ce) | 0, A = Math.imul(S, Ve), M = M + Math.imul(xe, Re) | 0, v = v + Math.imul(xe, Ze) | 0, v = v + Math.imul(Te, Re) | 0, A = A + Math.imul(Te, Ze) | 0, M = M + Math.imul(ye, Pe) | 0, v = v + Math.imul(ye, Ye) | 0, v = v + Math.imul(Be, Pe) | 0, A = A + Math.imul(Be, Ye) | 0, M = M + Math.imul(_e, ke) | 0, v = v + Math.imul(_e, et) | 0, v = v + Math.imul(Oe, ke) | 0, A = A + Math.imul(Oe, et) | 0;
      var bt = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (bt >>> 26) | 0, bt &= 67108863, M = Math.imul(L, Re), v = Math.imul(L, Ze), v = v + Math.imul(S, Re) | 0, A = Math.imul(S, Ze), M = M + Math.imul(xe, Pe) | 0, v = v + Math.imul(xe, Ye) | 0, v = v + Math.imul(Te, Pe) | 0, A = A + Math.imul(Te, Ye) | 0, M = M + Math.imul(ye, ke) | 0, v = v + Math.imul(ye, et) | 0, v = v + Math.imul(Be, ke) | 0, A = A + Math.imul(Be, et) | 0;
      var vt = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (vt >>> 26) | 0, vt &= 67108863, M = Math.imul(L, Pe), v = Math.imul(L, Ye), v = v + Math.imul(S, Pe) | 0, A = Math.imul(S, Ye), M = M + Math.imul(xe, ke) | 0, v = v + Math.imul(xe, et) | 0, v = v + Math.imul(Te, ke) | 0, A = A + Math.imul(Te, et) | 0;
      var mt = (P + M | 0) + ((v & 8191) << 13) | 0;
      P = (A + (v >>> 13) | 0) + (mt >>> 26) | 0, mt &= 67108863, M = Math.imul(L, ke), v = Math.imul(L, et), v = v + Math.imul(S, ke) | 0, A = Math.imul(S, et);
      var yt = (P + M | 0) + ((v & 8191) << 13) | 0;
      return P = (A + (v >>> 13) | 0) + (yt >>> 26) | 0, yt &= 67108863, $[0] = Fe, $[1] = je, $[2] = tt, $[3] = rt, $[4] = nt, $[5] = it, $[6] = at, $[7] = ot, $[8] = st, $[9] = ct, $[10] = ut, $[11] = dt, $[12] = lt, $[13] = ht, $[14] = pt, $[15] = bt, $[16] = vt, $[17] = mt, $[18] = yt, P !== 0 && ($[19] = P, d.length++), d;
    };
    Math.imul || (F = q);
    function z(V, _, w) {
      w.negative = _.negative ^ V.negative, w.length = V.length + _.length;
      for (var d = 0, m = 0, B = 0; B < w.length - 1; B++) {
        var $ = m;
        m = 0;
        for (var P = d & 67108863, M = Math.min(B, _.length - 1), v = Math.max(0, B - V.length + 1); v <= M; v++) {
          var A = B - v, y = V.words[A] | 0, T = _.words[v] | 0, Z = y * T, ie = Z & 67108863;
          $ = $ + (Z / 67108864 | 0) | 0, ie = ie + P | 0, P = ie & 67108863, $ = $ + (ie >>> 26) | 0, m += $ >>> 26, $ &= 67108863;
        }
        w.words[B] = P, d = $, $ = m;
      }
      return d !== 0 ? w.words[B] = d : w.length--, w.strip();
    }
    function H(V, _, w) {
      var d = new U();
      return d.mulp(V, _, w);
    }
    o.prototype.mulTo = function(_, w) {
      var d, m = this.length + _.length;
      return this.length === 10 && _.length === 10 ? d = F(this, _, w) : m < 63 ? d = q(this, _, w) : m < 1024 ? d = z(this, _, w) : d = H(this, _, w), d;
    };
    function U(V, _) {
      this.x = V, this.y = _;
    }
    U.prototype.makeRBT = function(_) {
      for (var w = new Array(_), d = o.prototype._countBits(_) - 1, m = 0; m < _; m++)
        w[m] = this.revBin(m, d, _);
      return w;
    }, U.prototype.revBin = function(_, w, d) {
      if (_ === 0 || _ === d - 1)
        return _;
      for (var m = 0, B = 0; B < w; B++)
        m |= (_ & 1) << w - B - 1, _ >>= 1;
      return m;
    }, U.prototype.permute = function(_, w, d, m, B, $) {
      for (var P = 0; P < $; P++)
        m[P] = w[_[P]], B[P] = d[_[P]];
    }, U.prototype.transform = function(_, w, d, m, B, $) {
      this.permute($, _, w, d, m, B);
      for (var P = 1; P < B; P <<= 1)
        for (var M = P << 1, v = Math.cos(2 * Math.PI / M), A = Math.sin(2 * Math.PI / M), y = 0; y < B; y += M)
          for (var T = v, Z = A, ie = 0; ie < P; ie++) {
            var J = d[y + ie], k = m[y + ie], D = d[y + ie + P], X = m[y + ie + P], te = T * D - Z * X;
            X = T * X + Z * D, D = te, d[y + ie] = J + D, m[y + ie] = k + X, d[y + ie + P] = J - D, m[y + ie + P] = k - X, ie !== M && (te = v * T - A * Z, Z = v * Z + A * T, T = te);
          }
    }, U.prototype.guessLen13b = function(_, w) {
      var d = Math.max(w, _) | 1, m = d & 1, B = 0;
      for (d = d / 2 | 0; d; d = d >>> 1)
        B++;
      return 1 << B + 1 + m;
    }, U.prototype.conjugate = function(_, w, d) {
      if (!(d <= 1))
        for (var m = 0; m < d / 2; m++) {
          var B = _[m];
          _[m] = _[d - m - 1], _[d - m - 1] = B, B = w[m], w[m] = -w[d - m - 1], w[d - m - 1] = -B;
        }
    }, U.prototype.normalize13b = function(_, w) {
      for (var d = 0, m = 0; m < w / 2; m++) {
        var B = Math.round(_[2 * m + 1] / w) * 8192 + Math.round(_[2 * m] / w) + d;
        _[m] = B & 67108863, B < 67108864 ? d = 0 : d = B / 67108864 | 0;
      }
      return _;
    }, U.prototype.convert13b = function(_, w, d, m) {
      for (var B = 0, $ = 0; $ < w; $++)
        B = B + (_[$] | 0), d[2 * $] = B & 8191, B = B >>> 13, d[2 * $ + 1] = B & 8191, B = B >>> 13;
      for ($ = 2 * w; $ < m; ++$)
        d[$] = 0;
      a(B === 0), a((B & -8192) === 0);
    }, U.prototype.stub = function(_) {
      for (var w = new Array(_), d = 0; d < _; d++)
        w[d] = 0;
      return w;
    }, U.prototype.mulp = function(_, w, d) {
      var m = 2 * this.guessLen13b(_.length, w.length), B = this.makeRBT(m), $ = this.stub(m), P = new Array(m), M = new Array(m), v = new Array(m), A = new Array(m), y = new Array(m), T = new Array(m), Z = d.words;
      Z.length = m, this.convert13b(_.words, _.length, P, m), this.convert13b(w.words, w.length, A, m), this.transform(P, $, M, v, m, B), this.transform(A, $, y, T, m, B);
      for (var ie = 0; ie < m; ie++) {
        var J = M[ie] * y[ie] - v[ie] * T[ie];
        v[ie] = M[ie] * T[ie] + v[ie] * y[ie], M[ie] = J;
      }
      return this.conjugate(M, v, m), this.transform(M, v, Z, $, m, B), this.conjugate(Z, $, m), this.normalize13b(Z, m), d.negative = _.negative ^ w.negative, d.length = _.length + w.length, d.strip();
    }, o.prototype.mul = function(_) {
      var w = new o(null);
      return w.words = new Array(this.length + _.length), this.mulTo(_, w);
    }, o.prototype.mulf = function(_) {
      var w = new o(null);
      return w.words = new Array(this.length + _.length), H(this, _, w);
    }, o.prototype.imul = function(_) {
      return this.clone().mulTo(_, this);
    }, o.prototype.imuln = function(_) {
      a(typeof _ == "number"), a(_ < 67108864);
      for (var w = 0, d = 0; d < this.length; d++) {
        var m = (this.words[d] | 0) * _, B = (m & 67108863) + (w & 67108863);
        w >>= 26, w += m / 67108864 | 0, w += B >>> 26, this.words[d] = B & 67108863;
      }
      return w !== 0 && (this.words[d] = w, this.length++), this;
    }, o.prototype.muln = function(_) {
      return this.clone().imuln(_);
    }, o.prototype.sqr = function() {
      return this.mul(this);
    }, o.prototype.isqr = function() {
      return this.imul(this.clone());
    }, o.prototype.pow = function(_) {
      var w = C(_);
      if (w.length === 0)
        return new o(1);
      for (var d = this, m = 0; m < w.length && w[m] === 0; m++, d = d.sqr())
        ;
      if (++m < w.length)
        for (var B = d.sqr(); m < w.length; m++, B = B.sqr())
          w[m] !== 0 && (d = d.mul(B));
      return d;
    }, o.prototype.iushln = function(_) {
      a(typeof _ == "number" && _ >= 0);
      var w = _ % 26, d = (_ - w) / 26, m = 67108863 >>> 26 - w << 26 - w, B;
      if (w !== 0) {
        var $ = 0;
        for (B = 0; B < this.length; B++) {
          var P = this.words[B] & m, M = (this.words[B] | 0) - P << w;
          this.words[B] = M | $, $ = P >>> 26 - w;
        }
        $ && (this.words[B] = $, this.length++);
      }
      if (d !== 0) {
        for (B = this.length - 1; B >= 0; B--)
          this.words[B + d] = this.words[B];
        for (B = 0; B < d; B++)
          this.words[B] = 0;
        this.length += d;
      }
      return this.strip();
    }, o.prototype.ishln = function(_) {
      return a(this.negative === 0), this.iushln(_);
    }, o.prototype.iushrn = function(_, w, d) {
      a(typeof _ == "number" && _ >= 0);
      var m;
      w ? m = (w - w % 26) / 26 : m = 0;
      var B = _ % 26, $ = Math.min((_ - B) / 26, this.length), P = 67108863 ^ 67108863 >>> B << B, M = d;
      if (m -= $, m = Math.max(0, m), M) {
        for (var v = 0; v < $; v++)
          M.words[v] = this.words[v];
        M.length = $;
      }
      if ($ !== 0)
        if (this.length > $)
          for (this.length -= $, v = 0; v < this.length; v++)
            this.words[v] = this.words[v + $];
        else
          this.words[0] = 0, this.length = 1;
      var A = 0;
      for (v = this.length - 1; v >= 0 && (A !== 0 || v >= m); v--) {
        var y = this.words[v] | 0;
        this.words[v] = A << 26 - B | y >>> B, A = y & P;
      }
      return M && A !== 0 && (M.words[M.length++] = A), this.length === 0 && (this.words[0] = 0, this.length = 1), this.strip();
    }, o.prototype.ishrn = function(_, w, d) {
      return a(this.negative === 0), this.iushrn(_, w, d);
    }, o.prototype.shln = function(_) {
      return this.clone().ishln(_);
    }, o.prototype.ushln = function(_) {
      return this.clone().iushln(_);
    }, o.prototype.shrn = function(_) {
      return this.clone().ishrn(_);
    }, o.prototype.ushrn = function(_) {
      return this.clone().iushrn(_);
    }, o.prototype.testn = function(_) {
      a(typeof _ == "number" && _ >= 0);
      var w = _ % 26, d = (_ - w) / 26, m = 1 << w;
      if (this.length <= d)
        return !1;
      var B = this.words[d];
      return !!(B & m);
    }, o.prototype.imaskn = function(_) {
      a(typeof _ == "number" && _ >= 0);
      var w = _ % 26, d = (_ - w) / 26;
      if (a(this.negative === 0, "imaskn works only with positive numbers"), this.length <= d)
        return this;
      if (w !== 0 && d++, this.length = Math.min(d, this.length), w !== 0) {
        var m = 67108863 ^ 67108863 >>> w << w;
        this.words[this.length - 1] &= m;
      }
      return this.strip();
    }, o.prototype.maskn = function(_) {
      return this.clone().imaskn(_);
    }, o.prototype.iaddn = function(_) {
      return a(typeof _ == "number"), a(_ < 67108864), _ < 0 ? this.isubn(-_) : this.negative !== 0 ? this.length === 1 && (this.words[0] | 0) < _ ? (this.words[0] = _ - (this.words[0] | 0), this.negative = 0, this) : (this.negative = 0, this.isubn(_), this.negative = 1, this) : this._iaddn(_);
    }, o.prototype._iaddn = function(_) {
      this.words[0] += _;
      for (var w = 0; w < this.length && this.words[w] >= 67108864; w++)
        this.words[w] -= 67108864, w === this.length - 1 ? this.words[w + 1] = 1 : this.words[w + 1]++;
      return this.length = Math.max(this.length, w + 1), this;
    }, o.prototype.isubn = function(_) {
      if (a(typeof _ == "number"), a(_ < 67108864), _ < 0)
        return this.iaddn(-_);
      if (this.negative !== 0)
        return this.negative = 0, this.iaddn(_), this.negative = 1, this;
      if (this.words[0] -= _, this.length === 1 && this.words[0] < 0)
        this.words[0] = -this.words[0], this.negative = 1;
      else
        for (var w = 0; w < this.length && this.words[w] < 0; w++)
          this.words[w] += 67108864, this.words[w + 1] -= 1;
      return this.strip();
    }, o.prototype.addn = function(_) {
      return this.clone().iaddn(_);
    }, o.prototype.subn = function(_) {
      return this.clone().isubn(_);
    }, o.prototype.iabs = function() {
      return this.negative = 0, this;
    }, o.prototype.abs = function() {
      return this.clone().iabs();
    }, o.prototype._ishlnsubmul = function(_, w, d) {
      var m = _.length + d, B;
      this._expand(m);
      var $, P = 0;
      for (B = 0; B < _.length; B++) {
        $ = (this.words[B + d] | 0) + P;
        var M = (_.words[B] | 0) * w;
        $ -= M & 67108863, P = ($ >> 26) - (M / 67108864 | 0), this.words[B + d] = $ & 67108863;
      }
      for (; B < this.length - d; B++)
        $ = (this.words[B + d] | 0) + P, P = $ >> 26, this.words[B + d] = $ & 67108863;
      if (P === 0)
        return this.strip();
      for (a(P === -1), P = 0, B = 0; B < this.length; B++)
        $ = -(this.words[B] | 0) + P, P = $ >> 26, this.words[B] = $ & 67108863;
      return this.negative = 1, this.strip();
    }, o.prototype._wordDiv = function(_, w) {
      var d = this.length - _.length, m = this.clone(), B = _, $ = B.words[B.length - 1] | 0, P = this._countBits($);
      d = 26 - P, d !== 0 && (B = B.ushln(d), m.iushln(d), $ = B.words[B.length - 1] | 0);
      var M = m.length - B.length, v;
      if (w !== "mod") {
        v = new o(null), v.length = M + 1, v.words = new Array(v.length);
        for (var A = 0; A < v.length; A++)
          v.words[A] = 0;
      }
      var y = m.clone()._ishlnsubmul(B, 1, M);
      y.negative === 0 && (m = y, v && (v.words[M] = 1));
      for (var T = M - 1; T >= 0; T--) {
        var Z = (m.words[B.length + T] | 0) * 67108864 + (m.words[B.length + T - 1] | 0);
        for (Z = Math.min(Z / $ | 0, 67108863), m._ishlnsubmul(B, Z, T); m.negative !== 0; )
          Z--, m.negative = 0, m._ishlnsubmul(B, 1, T), m.isZero() || (m.negative ^= 1);
        v && (v.words[T] = Z);
      }
      return v && v.strip(), m.strip(), w !== "div" && d !== 0 && m.iushrn(d), {
        div: v || null,
        mod: m
      };
    }, o.prototype.divmod = function(_, w, d) {
      if (a(!_.isZero()), this.isZero())
        return {
          div: new o(0),
          mod: new o(0)
        };
      var m, B, $;
      return this.negative !== 0 && _.negative === 0 ? ($ = this.neg().divmod(_, w), w !== "mod" && (m = $.div.neg()), w !== "div" && (B = $.mod.neg(), d && B.negative !== 0 && B.iadd(_)), {
        div: m,
        mod: B
      }) : this.negative === 0 && _.negative !== 0 ? ($ = this.divmod(_.neg(), w), w !== "mod" && (m = $.div.neg()), {
        div: m,
        mod: $.mod
      }) : this.negative & _.negative ? ($ = this.neg().divmod(_.neg(), w), w !== "div" && (B = $.mod.neg(), d && B.negative !== 0 && B.isub(_)), {
        div: $.div,
        mod: B
      }) : _.length > this.length || this.cmp(_) < 0 ? {
        div: new o(0),
        mod: this
      } : _.length === 1 ? w === "div" ? {
        div: this.divn(_.words[0]),
        mod: null
      } : w === "mod" ? {
        div: null,
        mod: new o(this.modn(_.words[0]))
      } : {
        div: this.divn(_.words[0]),
        mod: new o(this.modn(_.words[0]))
      } : this._wordDiv(_, w);
    }, o.prototype.div = function(_) {
      return this.divmod(_, "div", !1).div;
    }, o.prototype.mod = function(_) {
      return this.divmod(_, "mod", !1).mod;
    }, o.prototype.umod = function(_) {
      return this.divmod(_, "mod", !0).mod;
    }, o.prototype.divRound = function(_) {
      var w = this.divmod(_);
      if (w.mod.isZero())
        return w.div;
      var d = w.div.negative !== 0 ? w.mod.isub(_) : w.mod, m = _.ushrn(1), B = _.andln(1), $ = d.cmp(m);
      return $ < 0 || B === 1 && $ === 0 ? w.div : w.div.negative !== 0 ? w.div.isubn(1) : w.div.iaddn(1);
    }, o.prototype.modn = function(_) {
      a(_ <= 67108863);
      for (var w = (1 << 26) % _, d = 0, m = this.length - 1; m >= 0; m--)
        d = (w * d + (this.words[m] | 0)) % _;
      return d;
    }, o.prototype.idivn = function(_) {
      a(_ <= 67108863);
      for (var w = 0, d = this.length - 1; d >= 0; d--) {
        var m = (this.words[d] | 0) + w * 67108864;
        this.words[d] = m / _ | 0, w = m % _;
      }
      return this.strip();
    }, o.prototype.divn = function(_) {
      return this.clone().idivn(_);
    }, o.prototype.egcd = function(_) {
      a(_.negative === 0), a(!_.isZero());
      var w = this, d = _.clone();
      w.negative !== 0 ? w = w.umod(_) : w = w.clone();
      for (var m = new o(1), B = new o(0), $ = new o(0), P = new o(1), M = 0; w.isEven() && d.isEven(); )
        w.iushrn(1), d.iushrn(1), ++M;
      for (var v = d.clone(), A = w.clone(); !w.isZero(); ) {
        for (var y = 0, T = 1; !(w.words[0] & T) && y < 26; ++y, T <<= 1)
          ;
        if (y > 0)
          for (w.iushrn(y); y-- > 0; )
            (m.isOdd() || B.isOdd()) && (m.iadd(v), B.isub(A)), m.iushrn(1), B.iushrn(1);
        for (var Z = 0, ie = 1; !(d.words[0] & ie) && Z < 26; ++Z, ie <<= 1)
          ;
        if (Z > 0)
          for (d.iushrn(Z); Z-- > 0; )
            ($.isOdd() || P.isOdd()) && ($.iadd(v), P.isub(A)), $.iushrn(1), P.iushrn(1);
        w.cmp(d) >= 0 ? (w.isub(d), m.isub($), B.isub(P)) : (d.isub(w), $.isub(m), P.isub(B));
      }
      return {
        a: $,
        b: P,
        gcd: d.iushln(M)
      };
    }, o.prototype._invmp = function(_) {
      a(_.negative === 0), a(!_.isZero());
      var w = this, d = _.clone();
      w.negative !== 0 ? w = w.umod(_) : w = w.clone();
      for (var m = new o(1), B = new o(0), $ = d.clone(); w.cmpn(1) > 0 && d.cmpn(1) > 0; ) {
        for (var P = 0, M = 1; !(w.words[0] & M) && P < 26; ++P, M <<= 1)
          ;
        if (P > 0)
          for (w.iushrn(P); P-- > 0; )
            m.isOdd() && m.iadd($), m.iushrn(1);
        for (var v = 0, A = 1; !(d.words[0] & A) && v < 26; ++v, A <<= 1)
          ;
        if (v > 0)
          for (d.iushrn(v); v-- > 0; )
            B.isOdd() && B.iadd($), B.iushrn(1);
        w.cmp(d) >= 0 ? (w.isub(d), m.isub(B)) : (d.isub(w), B.isub(m));
      }
      var y;
      return w.cmpn(1) === 0 ? y = m : y = B, y.cmpn(0) < 0 && y.iadd(_), y;
    }, o.prototype.gcd = function(_) {
      if (this.isZero())
        return _.abs();
      if (_.isZero())
        return this.abs();
      var w = this.clone(), d = _.clone();
      w.negative = 0, d.negative = 0;
      for (var m = 0; w.isEven() && d.isEven(); m++)
        w.iushrn(1), d.iushrn(1);
      do {
        for (; w.isEven(); )
          w.iushrn(1);
        for (; d.isEven(); )
          d.iushrn(1);
        var B = w.cmp(d);
        if (B < 0) {
          var $ = w;
          w = d, d = $;
        } else if (B === 0 || d.cmpn(1) === 0)
          break;
        w.isub(d);
      } while (!0);
      return d.iushln(m);
    }, o.prototype.invm = function(_) {
      return this.egcd(_).a.umod(_);
    }, o.prototype.isEven = function() {
      return (this.words[0] & 1) === 0;
    }, o.prototype.isOdd = function() {
      return (this.words[0] & 1) === 1;
    }, o.prototype.andln = function(_) {
      return this.words[0] & _;
    }, o.prototype.bincn = function(_) {
      a(typeof _ == "number");
      var w = _ % 26, d = (_ - w) / 26, m = 1 << w;
      if (this.length <= d)
        return this._expand(d + 1), this.words[d] |= m, this;
      for (var B = m, $ = d; B !== 0 && $ < this.length; $++) {
        var P = this.words[$] | 0;
        P += B, B = P >>> 26, P &= 67108863, this.words[$] = P;
      }
      return B !== 0 && (this.words[$] = B, this.length++), this;
    }, o.prototype.isZero = function() {
      return this.length === 1 && this.words[0] === 0;
    }, o.prototype.cmpn = function(_) {
      var w = _ < 0;
      if (this.negative !== 0 && !w)
        return -1;
      if (this.negative === 0 && w)
        return 1;
      this.strip();
      var d;
      if (this.length > 1)
        d = 1;
      else {
        w && (_ = -_), a(_ <= 67108863, "Number is too big");
        var m = this.words[0] | 0;
        d = m === _ ? 0 : m < _ ? -1 : 1;
      }
      return this.negative !== 0 ? -d | 0 : d;
    }, o.prototype.cmp = function(_) {
      if (this.negative !== 0 && _.negative === 0)
        return -1;
      if (this.negative === 0 && _.negative !== 0)
        return 1;
      var w = this.ucmp(_);
      return this.negative !== 0 ? -w | 0 : w;
    }, o.prototype.ucmp = function(_) {
      if (this.length > _.length)
        return 1;
      if (this.length < _.length)
        return -1;
      for (var w = 0, d = this.length - 1; d >= 0; d--) {
        var m = this.words[d] | 0, B = _.words[d] | 0;
        if (m !== B) {
          m < B ? w = -1 : m > B && (w = 1);
          break;
        }
      }
      return w;
    }, o.prototype.gtn = function(_) {
      return this.cmpn(_) === 1;
    }, o.prototype.gt = function(_) {
      return this.cmp(_) === 1;
    }, o.prototype.gten = function(_) {
      return this.cmpn(_) >= 0;
    }, o.prototype.gte = function(_) {
      return this.cmp(_) >= 0;
    }, o.prototype.ltn = function(_) {
      return this.cmpn(_) === -1;
    }, o.prototype.lt = function(_) {
      return this.cmp(_) === -1;
    }, o.prototype.lten = function(_) {
      return this.cmpn(_) <= 0;
    }, o.prototype.lte = function(_) {
      return this.cmp(_) <= 0;
    }, o.prototype.eqn = function(_) {
      return this.cmpn(_) === 0;
    }, o.prototype.eq = function(_) {
      return this.cmp(_) === 0;
    }, o.red = function(_) {
      return new ce(_);
    }, o.prototype.toRed = function(_) {
      return a(!this.red, "Already a number in reduction context"), a(this.negative === 0, "red works only with positives"), _.convertTo(this)._forceRed(_);
    }, o.prototype.fromRed = function() {
      return a(this.red, "fromRed works only with numbers in reduction context"), this.red.convertFrom(this);
    }, o.prototype._forceRed = function(_) {
      return this.red = _, this;
    }, o.prototype.forceRed = function(_) {
      return a(!this.red, "Already a number in reduction context"), this._forceRed(_);
    }, o.prototype.redAdd = function(_) {
      return a(this.red, "redAdd works only with red numbers"), this.red.add(this, _);
    }, o.prototype.redIAdd = function(_) {
      return a(this.red, "redIAdd works only with red numbers"), this.red.iadd(this, _);
    }, o.prototype.redSub = function(_) {
      return a(this.red, "redSub works only with red numbers"), this.red.sub(this, _);
    }, o.prototype.redISub = function(_) {
      return a(this.red, "redISub works only with red numbers"), this.red.isub(this, _);
    }, o.prototype.redShl = function(_) {
      return a(this.red, "redShl works only with red numbers"), this.red.shl(this, _);
    }, o.prototype.redMul = function(_) {
      return a(this.red, "redMul works only with red numbers"), this.red._verify2(this, _), this.red.mul(this, _);
    }, o.prototype.redIMul = function(_) {
      return a(this.red, "redMul works only with red numbers"), this.red._verify2(this, _), this.red.imul(this, _);
    }, o.prototype.redSqr = function() {
      return a(this.red, "redSqr works only with red numbers"), this.red._verify1(this), this.red.sqr(this);
    }, o.prototype.redISqr = function() {
      return a(this.red, "redISqr works only with red numbers"), this.red._verify1(this), this.red.isqr(this);
    }, o.prototype.redSqrt = function() {
      return a(this.red, "redSqrt works only with red numbers"), this.red._verify1(this), this.red.sqrt(this);
    }, o.prototype.redInvm = function() {
      return a(this.red, "redInvm works only with red numbers"), this.red._verify1(this), this.red.invm(this);
    }, o.prototype.redNeg = function() {
      return a(this.red, "redNeg works only with red numbers"), this.red._verify1(this), this.red.neg(this);
    }, o.prototype.redPow = function(_) {
      return a(this.red && !_.red, "redPow(normalNum)"), this.red._verify1(this), this.red.pow(this, _);
    };
    var Y = {
      k256: null,
      p224: null,
      p192: null,
      p25519: null
    };
    function ee(V, _) {
      this.name = V, this.p = new o(_, 16), this.n = this.p.bitLength(), this.k = new o(1).iushln(this.n).isub(this.p), this.tmp = this._tmp();
    }
    ee.prototype._tmp = function() {
      var _ = new o(null);
      return _.words = new Array(Math.ceil(this.n / 13)), _;
    }, ee.prototype.ireduce = function(_) {
      var w = _, d;
      do
        this.split(w, this.tmp), w = this.imulK(w), w = w.iadd(this.tmp), d = w.bitLength();
      while (d > this.n);
      var m = d < this.n ? -1 : w.ucmp(this.p);
      return m === 0 ? (w.words[0] = 0, w.length = 1) : m > 0 ? w.isub(this.p) : w.strip !== void 0 ? w.strip() : w._strip(), w;
    }, ee.prototype.split = function(_, w) {
      _.iushrn(this.n, 0, w);
    }, ee.prototype.imulK = function(_) {
      return _.imul(this.k);
    };
    function se() {
      ee.call(
        this,
        "k256",
        "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f"
      );
    }
    c(se, ee), se.prototype.split = function(_, w) {
      for (var d = 4194303, m = Math.min(_.length, 9), B = 0; B < m; B++)
        w.words[B] = _.words[B];
      if (w.length = m, _.length <= 9) {
        _.words[0] = 0, _.length = 1;
        return;
      }
      var $ = _.words[9];
      for (w.words[w.length++] = $ & d, B = 10; B < _.length; B++) {
        var P = _.words[B] | 0;
        _.words[B - 10] = (P & d) << 4 | $ >>> 22, $ = P;
      }
      $ >>>= 22, _.words[B - 10] = $, $ === 0 && _.length > 10 ? _.length -= 10 : _.length -= 9;
    }, se.prototype.imulK = function(_) {
      _.words[_.length] = 0, _.words[_.length + 1] = 0, _.length += 2;
      for (var w = 0, d = 0; d < _.length; d++) {
        var m = _.words[d] | 0;
        w += m * 977, _.words[d] = w & 67108863, w = m * 64 + (w / 67108864 | 0);
      }
      return _.words[_.length - 1] === 0 && (_.length--, _.words[_.length - 1] === 0 && _.length--), _;
    };
    function fe() {
      ee.call(
        this,
        "p224",
        "ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001"
      );
    }
    c(fe, ee);
    function pe() {
      ee.call(
        this,
        "p192",
        "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff"
      );
    }
    c(pe, ee);
    function ue() {
      ee.call(
        this,
        "25519",
        "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed"
      );
    }
    c(ue, ee), ue.prototype.imulK = function(_) {
      for (var w = 0, d = 0; d < _.length; d++) {
        var m = (_.words[d] | 0) * 19 + w, B = m & 67108863;
        m >>>= 26, _.words[d] = B, w = m;
      }
      return w !== 0 && (_.words[_.length++] = w), _;
    }, o._prime = function(_) {
      if (Y[_])
        return Y[_];
      var w;
      if (_ === "k256")
        w = new se();
      else if (_ === "p224")
        w = new fe();
      else if (_ === "p192")
        w = new pe();
      else if (_ === "p25519")
        w = new ue();
      else
        throw new Error("Unknown prime " + _);
      return Y[_] = w, w;
    };
    function ce(V) {
      if (typeof V == "string") {
        var _ = o._prime(V);
        this.m = _.p, this.prime = _;
      } else
        a(V.gtn(1), "modulus must be greater than 1"), this.m = V, this.prime = null;
    }
    ce.prototype._verify1 = function(_) {
      a(_.negative === 0, "red works only with positives"), a(_.red, "red works only with red numbers");
    }, ce.prototype._verify2 = function(_, w) {
      a((_.negative | w.negative) === 0, "red works only with positives"), a(
        _.red && _.red === w.red,
        "red works only with red numbers"
      );
    }, ce.prototype.imod = function(_) {
      return this.prime ? this.prime.ireduce(_)._forceRed(this) : _.umod(this.m)._forceRed(this);
    }, ce.prototype.neg = function(_) {
      return _.isZero() ? _.clone() : this.m.sub(_)._forceRed(this);
    }, ce.prototype.add = function(_, w) {
      this._verify2(_, w);
      var d = _.add(w);
      return d.cmp(this.m) >= 0 && d.isub(this.m), d._forceRed(this);
    }, ce.prototype.iadd = function(_, w) {
      this._verify2(_, w);
      var d = _.iadd(w);
      return d.cmp(this.m) >= 0 && d.isub(this.m), d;
    }, ce.prototype.sub = function(_, w) {
      this._verify2(_, w);
      var d = _.sub(w);
      return d.cmpn(0) < 0 && d.iadd(this.m), d._forceRed(this);
    }, ce.prototype.isub = function(_, w) {
      this._verify2(_, w);
      var d = _.isub(w);
      return d.cmpn(0) < 0 && d.iadd(this.m), d;
    }, ce.prototype.shl = function(_, w) {
      return this._verify1(_), this.imod(_.ushln(w));
    }, ce.prototype.imul = function(_, w) {
      return this._verify2(_, w), this.imod(_.imul(w));
    }, ce.prototype.mul = function(_, w) {
      return this._verify2(_, w), this.imod(_.mul(w));
    }, ce.prototype.isqr = function(_) {
      return this.imul(_, _.clone());
    }, ce.prototype.sqr = function(_) {
      return this.mul(_, _);
    }, ce.prototype.sqrt = function(_) {
      if (_.isZero())
        return _.clone();
      var w = this.m.andln(3);
      if (a(w % 2 === 1), w === 3) {
        var d = this.m.add(new o(1)).iushrn(2);
        return this.pow(_, d);
      }
      for (var m = this.m.subn(1), B = 0; !m.isZero() && m.andln(1) === 0; )
        B++, m.iushrn(1);
      a(!m.isZero());
      var $ = new o(1).toRed(this), P = $.redNeg(), M = this.m.subn(1).iushrn(1), v = this.m.bitLength();
      for (v = new o(2 * v * v).toRed(this); this.pow(v, M).cmp(P) !== 0; )
        v.redIAdd(P);
      for (var A = this.pow(v, m), y = this.pow(_, m.addn(1).iushrn(1)), T = this.pow(_, m), Z = B; T.cmp($) !== 0; ) {
        for (var ie = T, J = 0; ie.cmp($) !== 0; J++)
          ie = ie.redSqr();
        a(J < Z);
        var k = this.pow(A, new o(1).iushln(Z - J - 1));
        y = y.redMul(k), A = k.redSqr(), T = T.redMul(A), Z = J;
      }
      return y;
    }, ce.prototype.invm = function(_) {
      var w = _._invmp(this.m);
      return w.negative !== 0 ? (w.negative = 0, this.imod(w).redNeg()) : this.imod(w);
    }, ce.prototype.pow = function(_, w) {
      if (w.isZero())
        return new o(1).toRed(this);
      if (w.cmpn(1) === 0)
        return _.clone();
      var d = 4, m = new Array(1 << d);
      m[0] = new o(1).toRed(this), m[1] = _;
      for (var B = 2; B < m.length; B++)
        m[B] = this.mul(m[B - 1], _);
      var $ = m[0], P = 0, M = 0, v = w.bitLength() % 26;
      for (v === 0 && (v = 26), B = w.length - 1; B >= 0; B--) {
        for (var A = w.words[B], y = v - 1; y >= 0; y--) {
          var T = A >> y & 1;
          if ($ !== m[0] && ($ = this.sqr($)), T === 0 && P === 0) {
            M = 0;
            continue;
          }
          P <<= 1, P |= T, M++, !(M !== d && (B !== 0 || y !== 0)) && ($ = this.mul($, m[P]), M = 0, P = 0);
        }
        v = 26;
      }
      return $;
    }, ce.prototype.convertTo = function(_) {
      var w = _.umod(this.m);
      return w === _ ? w.clone() : w;
    }, ce.prototype.convertFrom = function(_) {
      var w = _.clone();
      return w.red = null, w;
    }, o.mont = function(_) {
      return new $e(_);
    };
    function $e(V) {
      ce.call(this, V), this.shift = this.m.bitLength(), this.shift % 26 !== 0 && (this.shift += 26 - this.shift % 26), this.r = new o(1).iushln(this.shift), this.r2 = this.imod(this.r.sqr()), this.rinv = this.r._invmp(this.m), this.minv = this.rinv.mul(this.r).isubn(1).div(this.m), this.minv = this.minv.umod(this.r), this.minv = this.r.sub(this.minv);
    }
    c($e, ce), $e.prototype.convertTo = function(_) {
      return this.imod(_.ushln(this.shift));
    }, $e.prototype.convertFrom = function(_) {
      var w = this.imod(_.mul(this.rinv));
      return w.red = null, w;
    }, $e.prototype.imul = function(_, w) {
      if (_.isZero() || w.isZero())
        return _.words[0] = 0, _.length = 1, _;
      var d = _.imul(w), m = d.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m), B = d.isub(m).iushrn(this.shift), $ = B;
      return B.cmp(this.m) >= 0 ? $ = B.isub(this.m) : B.cmpn(0) < 0 && ($ = B.iadd(this.m)), $._forceRed(this);
    }, $e.prototype.mul = function(_, w) {
      if (_.isZero() || w.isZero())
        return new o(0)._forceRed(this);
      var d = _.mul(w), m = d.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m), B = d.isub(m).iushrn(this.shift), $ = B;
      return B.cmp(this.m) >= 0 ? $ = B.isub(this.m) : B.cmpn(0) < 0 && ($ = B.iadd(this.m)), $._forceRed(this);
    }, $e.prototype.invm = function(_) {
      var w = this.imod(_._invmp(this.m).mul(this.r2));
      return w._forceRed(this);
    };
  })(t, commonjsGlobal);
})(bn$1);
var bnExports$1 = bn$1.exports, brorand = { exports: {} }, hasRequiredBrorand;
function requireBrorand() {
  if (hasRequiredBrorand)
    return brorand.exports;
  hasRequiredBrorand = 1;
  var t;
  brorand.exports = function(c) {
    return t || (t = new e(null)), t.generate(c);
  };
  function e(a) {
    this.rand = a;
  }
  if (brorand.exports.Rand = e, e.prototype.generate = function(c) {
    return this._rand(c);
  }, e.prototype._rand = function(c) {
    if (this.rand.getBytes)
      return this.rand.getBytes(c);
    for (var o = new Uint8Array(c), u = 0; u < o.length; u++)
      o[u] = this.rand.getByte();
    return o;
  }, typeof self == "object")
    self.crypto && self.crypto.getRandomValues ? e.prototype._rand = function(c) {
      var o = new Uint8Array(c);
      return self.crypto.getRandomValues(o), o;
    } : self.msCrypto && self.msCrypto.getRandomValues ? e.prototype._rand = function(c) {
      var o = new Uint8Array(c);
      return self.msCrypto.getRandomValues(o), o;
    } : typeof window == "object" && (e.prototype._rand = function() {
      throw new Error("Not implemented yet");
    });
  else
    try {
      var n = requireCryptoBrowserify();
      if (typeof n.randomBytes != "function")
        throw new Error("Not supported");
      e.prototype._rand = function(c) {
        return n.randomBytes(c);
      };
    } catch {
    }
  return brorand.exports;
}
var mr, hasRequiredMr;
function requireMr() {
  if (hasRequiredMr)
    return mr;
  hasRequiredMr = 1;
  var t = bnExports$1, e = requireBrorand();
  function n(a) {
    this.rand = a || new e.Rand();
  }
  return mr = n, n.create = function(c) {
    return new n(c);
  }, n.prototype._randbelow = function(c) {
    var o = c.bitLength(), u = Math.ceil(o / 8);
    do
      var h = new t(this.rand.generate(u));
    while (h.cmp(c) >= 0);
    return h;
  }, n.prototype._randrange = function(c, o) {
    var u = o.sub(c);
    return c.add(this._randbelow(u));
  }, n.prototype.test = function(c, o, u) {
    var h = c.bitLength(), p = t.mont(c), x = new t(1).toRed(p);
    o || (o = Math.max(1, h / 48 | 0));
    for (var l = c.subn(1), b = 0; !l.testn(b); b++)
      ;
    for (var E = c.shrn(b), C = l.toRed(p), q = !0; o > 0; o--) {
      var F = this._randrange(new t(2), l);
      u && u(F);
      var z = F.toRed(p).redPow(E);
      if (!(z.cmp(x) === 0 || z.cmp(C) === 0)) {
        for (var H = 1; H < b; H++) {
          if (z = z.redSqr(), z.cmp(x) === 0)
            return !1;
          if (z.cmp(C) === 0)
            break;
        }
        if (H === b)
          return !1;
      }
    }
    return q;
  }, n.prototype.getDivisor = function(c, o) {
    var u = c.bitLength(), h = t.mont(c), p = new t(1).toRed(h);
    o || (o = Math.max(1, u / 48 | 0));
    for (var x = c.subn(1), l = 0; !x.testn(l); l++)
      ;
    for (var b = c.shrn(l), E = x.toRed(h); o > 0; o--) {
      var C = this._randrange(new t(2), x), q = c.gcd(C);
      if (q.cmpn(1) !== 0)
        return q;
      var F = C.toRed(h).redPow(b);
      if (!(F.cmp(p) === 0 || F.cmp(E) === 0)) {
        for (var z = 1; z < l; z++) {
          if (F = F.redSqr(), F.cmp(p) === 0)
            return F.fromRed().subn(1).gcd(c);
          if (F.cmp(E) === 0)
            break;
        }
        if (z === l)
          return F = F.redSqr(), F.fromRed().subn(1).gcd(c);
      }
    }
    return !1;
  }, mr;
}
var generatePrime, hasRequiredGeneratePrime;
function requireGeneratePrime() {
  if (hasRequiredGeneratePrime)
    return generatePrime;
  hasRequiredGeneratePrime = 1;
  var t = browserExports;
  generatePrime = z, z.simpleSieve = q, z.fermatTest = F;
  var e = bnExports$1, n = new e(24), a = requireMr(), c = new a(), o = new e(1), u = new e(2), h = new e(5);
  new e(16), new e(8);
  var p = new e(10), x = new e(3);
  new e(7);
  var l = new e(11), b = new e(4);
  new e(12);
  var E = null;
  function C() {
    if (E !== null)
      return E;
    var H = 1048576, U = [];
    U[0] = 2;
    for (var Y = 1, ee = 3; ee < H; ee += 2) {
      for (var se = Math.ceil(Math.sqrt(ee)), fe = 0; fe < Y && U[fe] <= se && ee % U[fe] !== 0; fe++)
        ;
      Y !== fe && U[fe] <= se || (U[Y++] = ee);
    }
    return E = U, U;
  }
  function q(H) {
    for (var U = C(), Y = 0; Y < U.length; Y++)
      if (H.modn(U[Y]) === 0)
        return H.cmpn(U[Y]) === 0;
    return !0;
  }
  function F(H) {
    var U = e.mont(H);
    return u.toRed(U).redPow(H.subn(1)).fromRed().cmpn(1) === 0;
  }
  function z(H, U) {
    if (H < 16)
      return U === 2 || U === 5 ? new e([140, 123]) : new e([140, 39]);
    U = new e(U);
    for (var Y, ee; ; ) {
      for (Y = new e(t(Math.ceil(H / 8))); Y.bitLength() > H; )
        Y.ishrn(1);
      if (Y.isEven() && Y.iadd(o), Y.testn(1) || Y.iadd(u), U.cmp(u)) {
        if (!U.cmp(h))
          for (; Y.mod(p).cmp(x); )
            Y.iadd(b);
      } else
        for (; Y.mod(n).cmp(l); )
          Y.iadd(b);
      if (ee = Y.shrn(1), q(ee) && q(Y) && F(ee) && F(Y) && c.test(ee) && c.test(Y))
        return Y;
    }
  }
  return generatePrime;
}
const modp1 = {
  gen: "02",
  prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a63a3620ffffffffffffffff"
}, modp2 = {
  gen: "02",
  prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece65381ffffffffffffffff"
}, modp5 = {
  gen: "02",
  prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca237327ffffffffffffffff"
}, modp14 = {
  gen: "02",
  prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aacaa68ffffffffffffffff"
}, modp15 = {
  gen: "02",
  prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a93ad2caffffffffffffffff"
}, modp16 = {
  gen: "02",
  prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c934063199ffffffffffffffff"
}, modp17 = {
  gen: "02",
  prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c93402849236c3fab4d27c7026c1d4dcb2602646dec9751e763dba37bdf8ff9406ad9e530ee5db382f413001aeb06a53ed9027d831179727b0865a8918da3edbebcf9b14ed44ce6cbaced4bb1bdb7f1447e6cc254b332051512bd7af426fb8f401378cd2bf5983ca01c64b92ecf032ea15d1721d03f482d7ce6e74fef6d55e702f46980c82b5a84031900b1c9e59e7c97fbec7e8f323a97a7e36cc88be0f1d45b7ff585ac54bd407b22b4154aacc8f6d7ebf48e1d814cc5ed20f8037e0a79715eef29be32806a1d58bb7c5da76f550aa3d8a1fbff0eb19ccb1a313d55cda56c9ec2ef29632387fe8d76e3c0468043e8f663f4860ee12bf2d5b0b7474d6e694f91e6dcc4024ffffffffffffffff"
}, modp18 = {
  gen: "02",
  prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c93402849236c3fab4d27c7026c1d4dcb2602646dec9751e763dba37bdf8ff9406ad9e530ee5db382f413001aeb06a53ed9027d831179727b0865a8918da3edbebcf9b14ed44ce6cbaced4bb1bdb7f1447e6cc254b332051512bd7af426fb8f401378cd2bf5983ca01c64b92ecf032ea15d1721d03f482d7ce6e74fef6d55e702f46980c82b5a84031900b1c9e59e7c97fbec7e8f323a97a7e36cc88be0f1d45b7ff585ac54bd407b22b4154aacc8f6d7ebf48e1d814cc5ed20f8037e0a79715eef29be32806a1d58bb7c5da76f550aa3d8a1fbff0eb19ccb1a313d55cda56c9ec2ef29632387fe8d76e3c0468043e8f663f4860ee12bf2d5b0b7474d6e694f91e6dbe115974a3926f12fee5e438777cb6a932df8cd8bec4d073b931ba3bc832b68d9dd300741fa7bf8afc47ed2576f6936ba424663aab639c5ae4f5683423b4742bf1c978238f16cbe39d652de3fdb8befc848ad922222e04a4037c0713eb57a81a23f0c73473fc646cea306b4bcbc8862f8385ddfa9d4b7fa2c087e879683303ed5bdd3a062b3cf5b3a278a66d2a13f83f44f82ddf310ee074ab6a364597e899a0255dc164f31cc50846851df9ab48195ded7ea1b1d510bd7ee74d73faf36bc31ecfa268359046f4eb879f924009438b481c6cd7889a002ed5ee382bc9190da6fc026e479558e4475677e9aa9e3050e2765694dfc81f56e880b96e7160c980dd98edd3dfffffffffffffffff"
}, require$$1$1 = {
  modp1,
  modp2,
  modp5,
  modp14,
  modp15,
  modp16,
  modp17,
  modp18
};
var dh, hasRequiredDh;
function requireDh() {
  if (hasRequiredDh)
    return dh;
  hasRequiredDh = 1;
  var t = bnExports$1, e = requireMr(), n = new e(), a = new t(24), c = new t(11), o = new t(10), u = new t(3), h = new t(7), p = requireGeneratePrime(), x = browserExports;
  dh = q;
  function l(z, H) {
    return H = H || "utf8", Buffer$B.isBuffer(z) || (z = new Buffer$B(z, H)), this._pub = new t(z), this;
  }
  function b(z, H) {
    return H = H || "utf8", Buffer$B.isBuffer(z) || (z = new Buffer$B(z, H)), this._priv = new t(z), this;
  }
  var E = {};
  function C(z, H) {
    var U = H.toString("hex"), Y = [U, z.toString(16)].join("_");
    if (Y in E)
      return E[Y];
    var ee = 0;
    if (z.isEven() || !p.simpleSieve || !p.fermatTest(z) || !n.test(z))
      return ee += 1, U === "02" || U === "05" ? ee += 8 : ee += 4, E[Y] = ee, ee;
    n.test(z.shrn(1)) || (ee += 2);
    var se;
    switch (U) {
      case "02":
        z.mod(a).cmp(c) && (ee += 8);
        break;
      case "05":
        se = z.mod(o), se.cmp(u) && se.cmp(h) && (ee += 8);
        break;
      default:
        ee += 4;
    }
    return E[Y] = ee, ee;
  }
  function q(z, H, U) {
    this.setGenerator(H), this.__prime = new t(z), this._prime = t.mont(this.__prime), this._primeLen = z.length, this._pub = void 0, this._priv = void 0, this._primeCode = void 0, U ? (this.setPublicKey = l, this.setPrivateKey = b) : this._primeCode = 8;
  }
  Object.defineProperty(q.prototype, "verifyError", {
    enumerable: !0,
    get: function() {
      return typeof this._primeCode != "number" && (this._primeCode = C(this.__prime, this.__gen)), this._primeCode;
    }
  }), q.prototype.generateKeys = function() {
    return this._priv || (this._priv = new t(x(this._primeLen))), this._pub = this._gen.toRed(this._prime).redPow(this._priv).fromRed(), this.getPublicKey();
  }, q.prototype.computeSecret = function(z) {
    z = new t(z), z = z.toRed(this._prime);
    var H = z.redPow(this._priv).fromRed(), U = new Buffer$B(H.toArray()), Y = this.getPrime();
    if (U.length < Y.length) {
      var ee = new Buffer$B(Y.length - U.length);
      ee.fill(0), U = Buffer$B.concat([ee, U]);
    }
    return U;
  }, q.prototype.getPublicKey = function(H) {
    return F(this._pub, H);
  }, q.prototype.getPrivateKey = function(H) {
    return F(this._priv, H);
  }, q.prototype.getPrime = function(z) {
    return F(this.__prime, z);
  }, q.prototype.getGenerator = function(z) {
    return F(this._gen, z);
  }, q.prototype.setGenerator = function(z, H) {
    return H = H || "utf8", Buffer$B.isBuffer(z) || (z = new Buffer$B(z, H)), this.__gen = z, this._gen = new t(z), this;
  };
  function F(z, H) {
    var U = new Buffer$B(z.toArray());
    return H ? U.toString(H) : U;
  }
  return dh;
}
var hasRequiredBrowser$2;
function requireBrowser$2() {
  if (hasRequiredBrowser$2)
    return browser$4;
  hasRequiredBrowser$2 = 1;
  var t = requireGeneratePrime(), e = require$$1$1, n = requireDh();
  function a(u) {
    var h = new Buffer$B(e[u].prime, "hex"), p = new Buffer$B(e[u].gen, "hex");
    return new n(h, p);
  }
  var c = {
    binary: !0,
    hex: !0,
    base64: !0
  };
  function o(u, h, p, x) {
    return Buffer$B.isBuffer(h) || c[h] === void 0 ? o(u, "binary", h, p) : (h = h || "binary", x = x || "binary", p = p || new Buffer$B([2]), Buffer$B.isBuffer(p) || (p = new Buffer$B(p, x)), typeof u == "number" ? new n(t(u, p), p, !0) : (Buffer$B.isBuffer(u) || (u = new Buffer$B(u, h)), new n(u, p, !0)));
  }
  return browser$4.DiffieHellmanGroup = browser$4.createDiffieHellmanGroup = browser$4.getDiffieHellman = a, browser$4.createDiffieHellman = browser$4.DiffieHellman = o, browser$4;
}
var readableBrowser = { exports: {} }, processNextickArgs = { exports: {} };
typeof process$1 > "u" || !process$1.version || process$1.version.indexOf("v0.") === 0 || process$1.version.indexOf("v1.") === 0 && process$1.version.indexOf("v1.8.") !== 0 ? processNextickArgs.exports = { nextTick } : processNextickArgs.exports = process$1;
function nextTick(t, e, n, a) {
  if (typeof t != "function")
    throw new TypeError('"callback" argument must be a function');
  var c = arguments.length, o, u;
  switch (c) {
    case 0:
    case 1:
      return process$1.nextTick(t);
    case 2:
      return process$1.nextTick(function() {
        t.call(null, e);
      });
    case 3:
      return process$1.nextTick(function() {
        t.call(null, e, n);
      });
    case 4:
      return process$1.nextTick(function() {
        t.call(null, e, n, a);
      });
    default:
      for (o = new Array(c - 1), u = 0; u < o.length; )
        o[u++] = arguments[u];
      return process$1.nextTick(function() {
        t.apply(null, o);
      });
  }
}
var processNextickArgsExports = processNextickArgs.exports, toString = {}.toString, isarray = Array.isArray || function(t) {
  return toString.call(t) == "[object Array]";
}, streamBrowser = eventsExports.EventEmitter, util$2 = {};
function isArray(t) {
  return Array.isArray ? Array.isArray(t) : objectToString(t) === "[object Array]";
}
util$2.isArray = isArray;
function isBoolean(t) {
  return typeof t == "boolean";
}
util$2.isBoolean = isBoolean;
function isNull(t) {
  return t === null;
}
util$2.isNull = isNull;
function isNullOrUndefined(t) {
  return t == null;
}
util$2.isNullOrUndefined = isNullOrUndefined;
function isNumber(t) {
  return typeof t == "number";
}
util$2.isNumber = isNumber;
function isString(t) {
  return typeof t == "string";
}
util$2.isString = isString;
function isSymbol(t) {
  return typeof t == "symbol";
}
util$2.isSymbol = isSymbol;
function isUndefined(t) {
  return t === void 0;
}
util$2.isUndefined = isUndefined;
function isRegExp(t) {
  return objectToString(t) === "[object RegExp]";
}
util$2.isRegExp = isRegExp;
function isObject(t) {
  return typeof t == "object" && t !== null;
}
util$2.isObject = isObject;
function isDate(t) {
  return objectToString(t) === "[object Date]";
}
util$2.isDate = isDate;
function isError(t) {
  return objectToString(t) === "[object Error]" || t instanceof Error;
}
util$2.isError = isError;
function isFunction(t) {
  return typeof t == "function";
}
util$2.isFunction = isFunction;
function isPrimitive(t) {
  return t === null || typeof t == "boolean" || typeof t == "number" || typeof t == "string" || typeof t == "symbol" || // ES6 symbol
  typeof t > "u";
}
util$2.isPrimitive = isPrimitive;
util$2.isBuffer = require$$1$2.Buffer.isBuffer;
function objectToString(t) {
  return Object.prototype.toString.call(t);
}
var BufferList = { exports: {} }, hasRequiredBufferList;
function requireBufferList() {
  return hasRequiredBufferList || (hasRequiredBufferList = 1, function(t) {
    function e(o, u) {
      if (!(o instanceof u))
        throw new TypeError("Cannot call a class as a function");
    }
    var n = safeBufferExports$1.Buffer, a = util$3;
    function c(o, u, h) {
      o.copy(u, h);
    }
    t.exports = function() {
      function o() {
        e(this, o), this.head = null, this.tail = null, this.length = 0;
      }
      return o.prototype.push = function(h) {
        var p = { data: h, next: null };
        this.length > 0 ? this.tail.next = p : this.head = p, this.tail = p, ++this.length;
      }, o.prototype.unshift = function(h) {
        var p = { data: h, next: this.head };
        this.length === 0 && (this.tail = p), this.head = p, ++this.length;
      }, o.prototype.shift = function() {
        if (this.length !== 0) {
          var h = this.head.data;
          return this.length === 1 ? this.head = this.tail = null : this.head = this.head.next, --this.length, h;
        }
      }, o.prototype.clear = function() {
        this.head = this.tail = null, this.length = 0;
      }, o.prototype.join = function(h) {
        if (this.length === 0)
          return "";
        for (var p = this.head, x = "" + p.data; p = p.next; )
          x += h + p.data;
        return x;
      }, o.prototype.concat = function(h) {
        if (this.length === 0)
          return n.alloc(0);
        for (var p = n.allocUnsafe(h >>> 0), x = this.head, l = 0; x; )
          c(x.data, p, l), l += x.data.length, x = x.next;
        return p;
      }, o;
    }(), a && a.inspect && a.inspect.custom && (t.exports.prototype[a.inspect.custom] = function() {
      var o = a.inspect({ length: this.length });
      return this.constructor.name + " " + o;
    });
  }(BufferList)), BufferList.exports;
}
var pna = processNextickArgsExports;
function destroy(t, e) {
  var n = this, a = this._readableState && this._readableState.destroyed, c = this._writableState && this._writableState.destroyed;
  return a || c ? (e ? e(t) : t && (this._writableState ? this._writableState.errorEmitted || (this._writableState.errorEmitted = !0, pna.nextTick(emitErrorNT, this, t)) : pna.nextTick(emitErrorNT, this, t)), this) : (this._readableState && (this._readableState.destroyed = !0), this._writableState && (this._writableState.destroyed = !0), this._destroy(t || null, function(o) {
    !e && o ? n._writableState ? n._writableState.errorEmitted || (n._writableState.errorEmitted = !0, pna.nextTick(emitErrorNT, n, o)) : pna.nextTick(emitErrorNT, n, o) : e && e(o);
  }), this);
}
function undestroy() {
  this._readableState && (this._readableState.destroyed = !1, this._readableState.reading = !1, this._readableState.ended = !1, this._readableState.endEmitted = !1), this._writableState && (this._writableState.destroyed = !1, this._writableState.ended = !1, this._writableState.ending = !1, this._writableState.finalCalled = !1, this._writableState.prefinished = !1, this._writableState.finished = !1, this._writableState.errorEmitted = !1);
}
function emitErrorNT(t, e) {
  t.emit("error", e);
}
var destroy_1 = {
  destroy,
  undestroy
}, _stream_writable, hasRequired_stream_writable;
function require_stream_writable() {
  if (hasRequired_stream_writable)
    return _stream_writable;
  hasRequired_stream_writable = 1;
  var t = processNextickArgsExports;
  _stream_writable = F;
  function e($) {
    var P = this;
    this.next = null, this.entry = null, this.finish = function() {
      B(P, $);
    };
  }
  var n = !process$1.browser && ["v0.10", "v0.9."].indexOf(process$1.version.slice(0, 5)) > -1 ? setImmediate : t.nextTick, a;
  F.WritableState = C;
  var c = Object.create(util$2);
  c.inherits = inherits_browserExports;
  var o = {
    deprecate: browser$a
  }, u = streamBrowser, h = safeBufferExports$1.Buffer, p = (typeof commonjsGlobal < "u" ? commonjsGlobal : typeof window < "u" ? window : typeof self < "u" ? self : {}).Uint8Array || function() {
  };
  function x($) {
    return h.from($);
  }
  function l($) {
    return h.isBuffer($) || $ instanceof p;
  }
  var b = destroy_1;
  c.inherits(F, u);
  function E() {
  }
  function C($, P) {
    a = a || require_stream_duplex(), $ = $ || {};
    var M = P instanceof a;
    this.objectMode = !!$.objectMode, M && (this.objectMode = this.objectMode || !!$.writableObjectMode);
    var v = $.highWaterMark, A = $.writableHighWaterMark, y = this.objectMode ? 16 : 16 * 1024;
    v || v === 0 ? this.highWaterMark = v : M && (A || A === 0) ? this.highWaterMark = A : this.highWaterMark = y, this.highWaterMark = Math.floor(this.highWaterMark), this.finalCalled = !1, this.needDrain = !1, this.ending = !1, this.ended = !1, this.finished = !1, this.destroyed = !1;
    var T = $.decodeStrings === !1;
    this.decodeStrings = !T, this.defaultEncoding = $.defaultEncoding || "utf8", this.length = 0, this.writing = !1, this.corked = 0, this.sync = !0, this.bufferProcessing = !1, this.onwrite = function(Z) {
      pe(P, Z);
    }, this.writecb = null, this.writelen = 0, this.bufferedRequest = null, this.lastBufferedRequest = null, this.pendingcb = 0, this.prefinished = !1, this.errorEmitted = !1, this.bufferedRequestCount = 0, this.corkedRequestsFree = new e(this);
  }
  C.prototype.getBuffer = function() {
    for (var P = this.bufferedRequest, M = []; P; )
      M.push(P), P = P.next;
    return M;
  }, function() {
    try {
      Object.defineProperty(C.prototype, "buffer", {
        get: o.deprecate(function() {
          return this.getBuffer();
        }, "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003")
      });
    } catch {
    }
  }();
  var q;
  typeof Symbol == "function" && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] == "function" ? (q = Function.prototype[Symbol.hasInstance], Object.defineProperty(F, Symbol.hasInstance, {
    value: function($) {
      return q.call(this, $) ? !0 : this !== F ? !1 : $ && $._writableState instanceof C;
    }
  })) : q = function($) {
    return $ instanceof this;
  };
  function F($) {
    if (a = a || require_stream_duplex(), !q.call(F, this) && !(this instanceof a))
      return new F($);
    this._writableState = new C($, this), this.writable = !0, $ && (typeof $.write == "function" && (this._write = $.write), typeof $.writev == "function" && (this._writev = $.writev), typeof $.destroy == "function" && (this._destroy = $.destroy), typeof $.final == "function" && (this._final = $.final)), u.call(this);
  }
  F.prototype.pipe = function() {
    this.emit("error", new Error("Cannot pipe, not readable"));
  };
  function z($, P) {
    var M = new Error("write after end");
    $.emit("error", M), t.nextTick(P, M);
  }
  function H($, P, M, v) {
    var A = !0, y = !1;
    return M === null ? y = new TypeError("May not write null values to stream") : typeof M != "string" && M !== void 0 && !P.objectMode && (y = new TypeError("Invalid non-string/buffer chunk")), y && ($.emit("error", y), t.nextTick(v, y), A = !1), A;
  }
  F.prototype.write = function($, P, M) {
    var v = this._writableState, A = !1, y = !v.objectMode && l($);
    return y && !h.isBuffer($) && ($ = x($)), typeof P == "function" && (M = P, P = null), y ? P = "buffer" : P || (P = v.defaultEncoding), typeof M != "function" && (M = E), v.ended ? z(this, M) : (y || H(this, v, $, M)) && (v.pendingcb++, A = Y(this, v, y, $, P, M)), A;
  }, F.prototype.cork = function() {
    var $ = this._writableState;
    $.corked++;
  }, F.prototype.uncork = function() {
    var $ = this._writableState;
    $.corked && ($.corked--, !$.writing && !$.corked && !$.bufferProcessing && $.bufferedRequest && $e(this, $));
  }, F.prototype.setDefaultEncoding = function(P) {
    if (typeof P == "string" && (P = P.toLowerCase()), !(["hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw"].indexOf((P + "").toLowerCase()) > -1))
      throw new TypeError("Unknown encoding: " + P);
    return this._writableState.defaultEncoding = P, this;
  };
  function U($, P, M) {
    return !$.objectMode && $.decodeStrings !== !1 && typeof P == "string" && (P = h.from(P, M)), P;
  }
  Object.defineProperty(F.prototype, "writableHighWaterMark", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._writableState.highWaterMark;
    }
  });
  function Y($, P, M, v, A, y) {
    if (!M) {
      var T = U(P, v, A);
      v !== T && (M = !0, A = "buffer", v = T);
    }
    var Z = P.objectMode ? 1 : v.length;
    P.length += Z;
    var ie = P.length < P.highWaterMark;
    if (ie || (P.needDrain = !0), P.writing || P.corked) {
      var J = P.lastBufferedRequest;
      P.lastBufferedRequest = {
        chunk: v,
        encoding: A,
        isBuf: M,
        callback: y,
        next: null
      }, J ? J.next = P.lastBufferedRequest : P.bufferedRequest = P.lastBufferedRequest, P.bufferedRequestCount += 1;
    } else
      ee($, P, !1, Z, v, A, y);
    return ie;
  }
  function ee($, P, M, v, A, y, T) {
    P.writelen = v, P.writecb = T, P.writing = !0, P.sync = !0, M ? $._writev(A, P.onwrite) : $._write(A, y, P.onwrite), P.sync = !1;
  }
  function se($, P, M, v, A) {
    --P.pendingcb, M ? (t.nextTick(A, v), t.nextTick(d, $, P), $._writableState.errorEmitted = !0, $.emit("error", v)) : (A(v), $._writableState.errorEmitted = !0, $.emit("error", v), d($, P));
  }
  function fe($) {
    $.writing = !1, $.writecb = null, $.length -= $.writelen, $.writelen = 0;
  }
  function pe($, P) {
    var M = $._writableState, v = M.sync, A = M.writecb;
    if (fe(M), P)
      se($, M, v, P, A);
    else {
      var y = V(M);
      !y && !M.corked && !M.bufferProcessing && M.bufferedRequest && $e($, M), v ? n(ue, $, M, y, A) : ue($, M, y, A);
    }
  }
  function ue($, P, M, v) {
    M || ce($, P), P.pendingcb--, v(), d($, P);
  }
  function ce($, P) {
    P.length === 0 && P.needDrain && (P.needDrain = !1, $.emit("drain"));
  }
  function $e($, P) {
    P.bufferProcessing = !0;
    var M = P.bufferedRequest;
    if ($._writev && M && M.next) {
      var v = P.bufferedRequestCount, A = new Array(v), y = P.corkedRequestsFree;
      y.entry = M;
      for (var T = 0, Z = !0; M; )
        A[T] = M, M.isBuf || (Z = !1), M = M.next, T += 1;
      A.allBuffers = Z, ee($, P, !0, P.length, A, "", y.finish), P.pendingcb++, P.lastBufferedRequest = null, y.next ? (P.corkedRequestsFree = y.next, y.next = null) : P.corkedRequestsFree = new e(P), P.bufferedRequestCount = 0;
    } else {
      for (; M; ) {
        var ie = M.chunk, J = M.encoding, k = M.callback, D = P.objectMode ? 1 : ie.length;
        if (ee($, P, !1, D, ie, J, k), M = M.next, P.bufferedRequestCount--, P.writing)
          break;
      }
      M === null && (P.lastBufferedRequest = null);
    }
    P.bufferedRequest = M, P.bufferProcessing = !1;
  }
  F.prototype._write = function($, P, M) {
    M(new Error("_write() is not implemented"));
  }, F.prototype._writev = null, F.prototype.end = function($, P, M) {
    var v = this._writableState;
    typeof $ == "function" ? (M = $, $ = null, P = null) : typeof P == "function" && (M = P, P = null), $ != null && this.write($, P), v.corked && (v.corked = 1, this.uncork()), v.ending || m(this, v, M);
  };
  function V($) {
    return $.ending && $.length === 0 && $.bufferedRequest === null && !$.finished && !$.writing;
  }
  function _($, P) {
    $._final(function(M) {
      P.pendingcb--, M && $.emit("error", M), P.prefinished = !0, $.emit("prefinish"), d($, P);
    });
  }
  function w($, P) {
    !P.prefinished && !P.finalCalled && (typeof $._final == "function" ? (P.pendingcb++, P.finalCalled = !0, t.nextTick(_, $, P)) : (P.prefinished = !0, $.emit("prefinish")));
  }
  function d($, P) {
    var M = V(P);
    return M && (w($, P), P.pendingcb === 0 && (P.finished = !0, $.emit("finish"))), M;
  }
  function m($, P, M) {
    P.ending = !0, d($, P), M && (P.finished ? t.nextTick(M) : $.once("finish", M)), P.ended = !0, $.writable = !1;
  }
  function B($, P, M) {
    var v = $.entry;
    for ($.entry = null; v; ) {
      var A = v.callback;
      P.pendingcb--, A(M), v = v.next;
    }
    P.corkedRequestsFree.next = $;
  }
  return Object.defineProperty(F.prototype, "destroyed", {
    get: function() {
      return this._writableState === void 0 ? !1 : this._writableState.destroyed;
    },
    set: function($) {
      this._writableState && (this._writableState.destroyed = $);
    }
  }), F.prototype.destroy = b.destroy, F.prototype._undestroy = b.undestroy, F.prototype._destroy = function($, P) {
    this.end(), P($);
  }, _stream_writable;
}
var _stream_duplex, hasRequired_stream_duplex;
function require_stream_duplex() {
  if (hasRequired_stream_duplex)
    return _stream_duplex;
  hasRequired_stream_duplex = 1;
  var t = processNextickArgsExports, e = Object.keys || function(b) {
    var E = [];
    for (var C in b)
      E.push(C);
    return E;
  };
  _stream_duplex = p;
  var n = Object.create(util$2);
  n.inherits = inherits_browserExports;
  var a = require_stream_readable(), c = require_stream_writable();
  n.inherits(p, a);
  for (var o = e(c.prototype), u = 0; u < o.length; u++) {
    var h = o[u];
    p.prototype[h] || (p.prototype[h] = c.prototype[h]);
  }
  function p(b) {
    if (!(this instanceof p))
      return new p(b);
    a.call(this, b), c.call(this, b), b && b.readable === !1 && (this.readable = !1), b && b.writable === !1 && (this.writable = !1), this.allowHalfOpen = !0, b && b.allowHalfOpen === !1 && (this.allowHalfOpen = !1), this.once("end", x);
  }
  Object.defineProperty(p.prototype, "writableHighWaterMark", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._writableState.highWaterMark;
    }
  });
  function x() {
    this.allowHalfOpen || this._writableState.ended || t.nextTick(l, this);
  }
  function l(b) {
    b.end();
  }
  return Object.defineProperty(p.prototype, "destroyed", {
    get: function() {
      return this._readableState === void 0 || this._writableState === void 0 ? !1 : this._readableState.destroyed && this._writableState.destroyed;
    },
    set: function(b) {
      this._readableState === void 0 || this._writableState === void 0 || (this._readableState.destroyed = b, this._writableState.destroyed = b);
    }
  }), p.prototype._destroy = function(b, E) {
    this.push(null), this.end(), t.nextTick(E, b);
  }, _stream_duplex;
}
var _stream_readable, hasRequired_stream_readable;
function require_stream_readable() {
  if (hasRequired_stream_readable)
    return _stream_readable;
  hasRequired_stream_readable = 1;
  var t = processNextickArgsExports;
  _stream_readable = U;
  var e = isarray, n;
  U.ReadableState = H, eventsExports.EventEmitter;
  var a = function(k, D) {
    return k.listeners(D).length;
  }, c = streamBrowser, o = safeBufferExports$1.Buffer, u = (typeof commonjsGlobal < "u" ? commonjsGlobal : typeof window < "u" ? window : typeof self < "u" ? self : {}).Uint8Array || function() {
  };
  function h(k) {
    return o.from(k);
  }
  function p(k) {
    return o.isBuffer(k) || k instanceof u;
  }
  var x = Object.create(util$2);
  x.inherits = inherits_browserExports;
  var l = util$3, b = void 0;
  l && l.debuglog ? b = l.debuglog("stream") : b = function() {
  };
  var E = requireBufferList(), C = destroy_1, q;
  x.inherits(U, c);
  var F = ["error", "close", "destroy", "pause", "resume"];
  function z(k, D, X) {
    if (typeof k.prependListener == "function")
      return k.prependListener(D, X);
    !k._events || !k._events[D] ? k.on(D, X) : e(k._events[D]) ? k._events[D].unshift(X) : k._events[D] = [X, k._events[D]];
  }
  function H(k, D) {
    n = n || require_stream_duplex(), k = k || {};
    var X = D instanceof n;
    this.objectMode = !!k.objectMode, X && (this.objectMode = this.objectMode || !!k.readableObjectMode);
    var te = k.highWaterMark, N = k.readableHighWaterMark, O = this.objectMode ? 16 : 16 * 1024;
    te || te === 0 ? this.highWaterMark = te : X && (N || N === 0) ? this.highWaterMark = N : this.highWaterMark = O, this.highWaterMark = Math.floor(this.highWaterMark), this.buffer = new E(), this.length = 0, this.pipes = null, this.pipesCount = 0, this.flowing = null, this.ended = !1, this.endEmitted = !1, this.reading = !1, this.sync = !0, this.needReadable = !1, this.emittedReadable = !1, this.readableListening = !1, this.resumeScheduled = !1, this.destroyed = !1, this.defaultEncoding = k.defaultEncoding || "utf8", this.awaitDrain = 0, this.readingMore = !1, this.decoder = null, this.encoding = null, k.encoding && (q || (q = string_decoder.StringDecoder), this.decoder = new q(k.encoding), this.encoding = k.encoding);
  }
  function U(k) {
    if (n = n || require_stream_duplex(), !(this instanceof U))
      return new U(k);
    this._readableState = new H(k, this), this.readable = !0, k && (typeof k.read == "function" && (this._read = k.read), typeof k.destroy == "function" && (this._destroy = k.destroy)), c.call(this);
  }
  Object.defineProperty(U.prototype, "destroyed", {
    get: function() {
      return this._readableState === void 0 ? !1 : this._readableState.destroyed;
    },
    set: function(k) {
      this._readableState && (this._readableState.destroyed = k);
    }
  }), U.prototype.destroy = C.destroy, U.prototype._undestroy = C.undestroy, U.prototype._destroy = function(k, D) {
    this.push(null), D(k);
  }, U.prototype.push = function(k, D) {
    var X = this._readableState, te;
    return X.objectMode ? te = !0 : typeof k == "string" && (D = D || X.defaultEncoding, D !== X.encoding && (k = o.from(k, D), D = ""), te = !0), Y(this, k, D, !1, te);
  }, U.prototype.unshift = function(k) {
    return Y(this, k, null, !0, !1);
  };
  function Y(k, D, X, te, N) {
    var O = k._readableState;
    if (D === null)
      O.reading = !1, $e(k, O);
    else {
      var ne;
      N || (ne = se(O, D)), ne ? k.emit("error", ne) : O.objectMode || D && D.length > 0 ? (typeof D != "string" && !O.objectMode && Object.getPrototypeOf(D) !== o.prototype && (D = h(D)), te ? O.endEmitted ? k.emit("error", new Error("stream.unshift() after end event")) : ee(k, O, D, !0) : O.ended ? k.emit("error", new Error("stream.push() after EOF")) : (O.reading = !1, O.decoder && !X ? (D = O.decoder.write(D), O.objectMode || D.length !== 0 ? ee(k, O, D, !1) : w(k, O)) : ee(k, O, D, !1))) : te || (O.reading = !1);
    }
    return fe(O);
  }
  function ee(k, D, X, te) {
    D.flowing && D.length === 0 && !D.sync ? (k.emit("data", X), k.read(0)) : (D.length += D.objectMode ? 1 : X.length, te ? D.buffer.unshift(X) : D.buffer.push(X), D.needReadable && V(k)), w(k, D);
  }
  function se(k, D) {
    var X;
    return !p(D) && typeof D != "string" && D !== void 0 && !k.objectMode && (X = new TypeError("Invalid non-string/buffer chunk")), X;
  }
  function fe(k) {
    return !k.ended && (k.needReadable || k.length < k.highWaterMark || k.length === 0);
  }
  U.prototype.isPaused = function() {
    return this._readableState.flowing === !1;
  }, U.prototype.setEncoding = function(k) {
    return q || (q = string_decoder.StringDecoder), this._readableState.decoder = new q(k), this._readableState.encoding = k, this;
  };
  var pe = 8388608;
  function ue(k) {
    return k >= pe ? k = pe : (k--, k |= k >>> 1, k |= k >>> 2, k |= k >>> 4, k |= k >>> 8, k |= k >>> 16, k++), k;
  }
  function ce(k, D) {
    return k <= 0 || D.length === 0 && D.ended ? 0 : D.objectMode ? 1 : k !== k ? D.flowing && D.length ? D.buffer.head.data.length : D.length : (k > D.highWaterMark && (D.highWaterMark = ue(k)), k <= D.length ? k : D.ended ? D.length : (D.needReadable = !0, 0));
  }
  U.prototype.read = function(k) {
    b("read", k), k = parseInt(k, 10);
    var D = this._readableState, X = k;
    if (k !== 0 && (D.emittedReadable = !1), k === 0 && D.needReadable && (D.length >= D.highWaterMark || D.ended))
      return b("read: emitReadable", D.length, D.ended), D.length === 0 && D.ended ? Z(this) : V(this), null;
    if (k = ce(k, D), k === 0 && D.ended)
      return D.length === 0 && Z(this), null;
    var te = D.needReadable;
    b("need readable", te), (D.length === 0 || D.length - k < D.highWaterMark) && (te = !0, b("length less than watermark", te)), D.ended || D.reading ? (te = !1, b("reading or ended", te)) : te && (b("do read"), D.reading = !0, D.sync = !0, D.length === 0 && (D.needReadable = !0), this._read(D.highWaterMark), D.sync = !1, D.reading || (k = ce(X, D)));
    var N;
    return k > 0 ? N = v(k, D) : N = null, N === null ? (D.needReadable = !0, k = 0) : D.length -= k, D.length === 0 && (D.ended || (D.needReadable = !0), X !== k && D.ended && Z(this)), N !== null && this.emit("data", N), N;
  };
  function $e(k, D) {
    if (!D.ended) {
      if (D.decoder) {
        var X = D.decoder.end();
        X && X.length && (D.buffer.push(X), D.length += D.objectMode ? 1 : X.length);
      }
      D.ended = !0, V(k);
    }
  }
  function V(k) {
    var D = k._readableState;
    D.needReadable = !1, D.emittedReadable || (b("emitReadable", D.flowing), D.emittedReadable = !0, D.sync ? t.nextTick(_, k) : _(k));
  }
  function _(k) {
    b("emit readable"), k.emit("readable"), M(k);
  }
  function w(k, D) {
    D.readingMore || (D.readingMore = !0, t.nextTick(d, k, D));
  }
  function d(k, D) {
    for (var X = D.length; !D.reading && !D.flowing && !D.ended && D.length < D.highWaterMark && (b("maybeReadMore read 0"), k.read(0), X !== D.length); )
      X = D.length;
    D.readingMore = !1;
  }
  U.prototype._read = function(k) {
    this.emit("error", new Error("_read() is not implemented"));
  }, U.prototype.pipe = function(k, D) {
    var X = this, te = this._readableState;
    switch (te.pipesCount) {
      case 0:
        te.pipes = k;
        break;
      case 1:
        te.pipes = [te.pipes, k];
        break;
      default:
        te.pipes.push(k);
        break;
    }
    te.pipesCount += 1, b("pipe count=%d opts=%j", te.pipesCount, D);
    var N = (!D || D.end !== !1) && k !== process$1.stdout && k !== process$1.stderr, O = N ? de : De;
    te.endEmitted ? t.nextTick(O) : X.once("end", O), k.on("unpipe", ne);
    function ne(ye, Be) {
      b("onunpipe"), ye === X && Be && Be.hasUnpiped === !1 && (Be.hasUnpiped = !0, me());
    }
    function de() {
      b("onend"), k.end();
    }
    var le = m(X);
    k.on("drain", le);
    var he = !1;
    function me() {
      b("cleanup"), k.removeListener("close", _e), k.removeListener("finish", Oe), k.removeListener("drain", le), k.removeListener("error", qe), k.removeListener("unpipe", ne), X.removeListener("end", de), X.removeListener("end", De), X.removeListener("data", oe), he = !0, te.awaitDrain && (!k._writableState || k._writableState.needDrain) && le();
    }
    var ge = !1;
    X.on("data", oe);
    function oe(ye) {
      b("ondata"), ge = !1;
      var Be = k.write(ye);
      Be === !1 && !ge && ((te.pipesCount === 1 && te.pipes === k || te.pipesCount > 1 && J(te.pipes, k) !== -1) && !he && (b("false write response, pause", te.awaitDrain), te.awaitDrain++, ge = !0), X.pause());
    }
    function qe(ye) {
      b("onerror", ye), De(), k.removeListener("error", qe), a(k, "error") === 0 && k.emit("error", ye);
    }
    z(k, "error", qe);
    function _e() {
      k.removeListener("finish", Oe), De();
    }
    k.once("close", _e);
    function Oe() {
      b("onfinish"), k.removeListener("close", _e), De();
    }
    k.once("finish", Oe);
    function De() {
      b("unpipe"), X.unpipe(k);
    }
    return k.emit("pipe", X), te.flowing || (b("pipe resume"), X.resume()), k;
  };
  function m(k) {
    return function() {
      var D = k._readableState;
      b("pipeOnDrain", D.awaitDrain), D.awaitDrain && D.awaitDrain--, D.awaitDrain === 0 && a(k, "data") && (D.flowing = !0, M(k));
    };
  }
  U.prototype.unpipe = function(k) {
    var D = this._readableState, X = { hasUnpiped: !1 };
    if (D.pipesCount === 0)
      return this;
    if (D.pipesCount === 1)
      return k && k !== D.pipes ? this : (k || (k = D.pipes), D.pipes = null, D.pipesCount = 0, D.flowing = !1, k && k.emit("unpipe", this, X), this);
    if (!k) {
      var te = D.pipes, N = D.pipesCount;
      D.pipes = null, D.pipesCount = 0, D.flowing = !1;
      for (var O = 0; O < N; O++)
        te[O].emit("unpipe", this, { hasUnpiped: !1 });
      return this;
    }
    var ne = J(D.pipes, k);
    return ne === -1 ? this : (D.pipes.splice(ne, 1), D.pipesCount -= 1, D.pipesCount === 1 && (D.pipes = D.pipes[0]), k.emit("unpipe", this, X), this);
  }, U.prototype.on = function(k, D) {
    var X = c.prototype.on.call(this, k, D);
    if (k === "data")
      this._readableState.flowing !== !1 && this.resume();
    else if (k === "readable") {
      var te = this._readableState;
      !te.endEmitted && !te.readableListening && (te.readableListening = te.needReadable = !0, te.emittedReadable = !1, te.reading ? te.length && V(this) : t.nextTick(B, this));
    }
    return X;
  }, U.prototype.addListener = U.prototype.on;
  function B(k) {
    b("readable nexttick read 0"), k.read(0);
  }
  U.prototype.resume = function() {
    var k = this._readableState;
    return k.flowing || (b("resume"), k.flowing = !0, $(this, k)), this;
  };
  function $(k, D) {
    D.resumeScheduled || (D.resumeScheduled = !0, t.nextTick(P, k, D));
  }
  function P(k, D) {
    D.reading || (b("resume read 0"), k.read(0)), D.resumeScheduled = !1, D.awaitDrain = 0, k.emit("resume"), M(k), D.flowing && !D.reading && k.read(0);
  }
  U.prototype.pause = function() {
    return b("call pause flowing=%j", this._readableState.flowing), this._readableState.flowing !== !1 && (b("pause"), this._readableState.flowing = !1, this.emit("pause")), this;
  };
  function M(k) {
    var D = k._readableState;
    for (b("flow", D.flowing); D.flowing && k.read() !== null; )
      ;
  }
  U.prototype.wrap = function(k) {
    var D = this, X = this._readableState, te = !1;
    k.on("end", function() {
      if (b("wrapped end"), X.decoder && !X.ended) {
        var ne = X.decoder.end();
        ne && ne.length && D.push(ne);
      }
      D.push(null);
    }), k.on("data", function(ne) {
      if (b("wrapped data"), X.decoder && (ne = X.decoder.write(ne)), !(X.objectMode && ne == null) && !(!X.objectMode && (!ne || !ne.length))) {
        var de = D.push(ne);
        de || (te = !0, k.pause());
      }
    });
    for (var N in k)
      this[N] === void 0 && typeof k[N] == "function" && (this[N] = /* @__PURE__ */ function(ne) {
        return function() {
          return k[ne].apply(k, arguments);
        };
      }(N));
    for (var O = 0; O < F.length; O++)
      k.on(F[O], this.emit.bind(this, F[O]));
    return this._read = function(ne) {
      b("wrapped _read", ne), te && (te = !1, k.resume());
    }, this;
  }, Object.defineProperty(U.prototype, "readableHighWaterMark", {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: !1,
    get: function() {
      return this._readableState.highWaterMark;
    }
  }), U._fromList = v;
  function v(k, D) {
    if (D.length === 0)
      return null;
    var X;
    return D.objectMode ? X = D.buffer.shift() : !k || k >= D.length ? (D.decoder ? X = D.buffer.join("") : D.buffer.length === 1 ? X = D.buffer.head.data : X = D.buffer.concat(D.length), D.buffer.clear()) : X = A(k, D.buffer, D.decoder), X;
  }
  function A(k, D, X) {
    var te;
    return k < D.head.data.length ? (te = D.head.data.slice(0, k), D.head.data = D.head.data.slice(k)) : k === D.head.data.length ? te = D.shift() : te = X ? y(k, D) : T(k, D), te;
  }
  function y(k, D) {
    var X = D.head, te = 1, N = X.data;
    for (k -= N.length; X = X.next; ) {
      var O = X.data, ne = k > O.length ? O.length : k;
      if (ne === O.length ? N += O : N += O.slice(0, k), k -= ne, k === 0) {
        ne === O.length ? (++te, X.next ? D.head = X.next : D.head = D.tail = null) : (D.head = X, X.data = O.slice(ne));
        break;
      }
      ++te;
    }
    return D.length -= te, N;
  }
  function T(k, D) {
    var X = o.allocUnsafe(k), te = D.head, N = 1;
    for (te.data.copy(X), k -= te.data.length; te = te.next; ) {
      var O = te.data, ne = k > O.length ? O.length : k;
      if (O.copy(X, X.length - k, 0, ne), k -= ne, k === 0) {
        ne === O.length ? (++N, te.next ? D.head = te.next : D.head = D.tail = null) : (D.head = te, te.data = O.slice(ne));
        break;
      }
      ++N;
    }
    return D.length -= N, X;
  }
  function Z(k) {
    var D = k._readableState;
    if (D.length > 0)
      throw new Error('"endReadable()" called on non-empty stream');
    D.endEmitted || (D.ended = !0, t.nextTick(ie, D, k));
  }
  function ie(k, D) {
    !k.endEmitted && k.length === 0 && (k.endEmitted = !0, D.readable = !1, D.emit("end"));
  }
  function J(k, D) {
    for (var X = 0, te = k.length; X < te; X++)
      if (k[X] === D)
        return X;
    return -1;
  }
  return _stream_readable;
}
var _stream_transform = Transform$1, Duplex = require_stream_duplex(), util$1 = Object.create(util$2);
util$1.inherits = inherits_browserExports;
util$1.inherits(Transform$1, Duplex);
function afterTransform(t, e) {
  var n = this._transformState;
  n.transforming = !1;
  var a = n.writecb;
  if (!a)
    return this.emit("error", new Error("write callback called multiple times"));
  n.writechunk = null, n.writecb = null, e != null && this.push(e), a(t);
  var c = this._readableState;
  c.reading = !1, (c.needReadable || c.length < c.highWaterMark) && this._read(c.highWaterMark);
}
function Transform$1(t) {
  if (!(this instanceof Transform$1))
    return new Transform$1(t);
  Duplex.call(this, t), this._transformState = {
    afterTransform: afterTransform.bind(this),
    needTransform: !1,
    transforming: !1,
    writecb: null,
    writechunk: null,
    writeencoding: null
  }, this._readableState.needReadable = !0, this._readableState.sync = !1, t && (typeof t.transform == "function" && (this._transform = t.transform), typeof t.flush == "function" && (this._flush = t.flush)), this.on("prefinish", prefinish);
}
function prefinish() {
  var t = this;
  typeof this._flush == "function" ? this._flush(function(e, n) {
    done(t, e, n);
  }) : done(this, null, null);
}
Transform$1.prototype.push = function(t, e) {
  return this._transformState.needTransform = !1, Duplex.prototype.push.call(this, t, e);
};
Transform$1.prototype._transform = function(t, e, n) {
  throw new Error("_transform() is not implemented");
};
Transform$1.prototype._write = function(t, e, n) {
  var a = this._transformState;
  if (a.writecb = n, a.writechunk = t, a.writeencoding = e, !a.transforming) {
    var c = this._readableState;
    (a.needTransform || c.needReadable || c.length < c.highWaterMark) && this._read(c.highWaterMark);
  }
};
Transform$1.prototype._read = function(t) {
  var e = this._transformState;
  e.writechunk !== null && e.writecb && !e.transforming ? (e.transforming = !0, this._transform(e.writechunk, e.writeencoding, e.afterTransform)) : e.needTransform = !0;
};
Transform$1.prototype._destroy = function(t, e) {
  var n = this;
  Duplex.prototype._destroy.call(this, t, function(a) {
    e(a), n.emit("close");
  });
};
function done(t, e, n) {
  if (e)
    return t.emit("error", e);
  if (n != null && t.push(n), t._writableState.length)
    throw new Error("Calling transform done when ws.length != 0");
  if (t._transformState.transforming)
    throw new Error("Calling transform done when still transforming");
  return t.push(null);
}
var _stream_passthrough = PassThrough, Transform = _stream_transform, util = Object.create(util$2);
util.inherits = inherits_browserExports;
util.inherits(PassThrough, Transform);
function PassThrough(t) {
  if (!(this instanceof PassThrough))
    return new PassThrough(t);
  Transform.call(this, t);
}
PassThrough.prototype._transform = function(t, e, n) {
  n(null, t);
};
(function(t, e) {
  e = t.exports = require_stream_readable(), e.Stream = e, e.Readable = e, e.Writable = require_stream_writable(), e.Duplex = require_stream_duplex(), e.Transform = _stream_transform, e.PassThrough = _stream_passthrough;
})(readableBrowser, readableBrowser.exports);
var readableBrowserExports = readableBrowser.exports, sign = { exports: {} }, bn = { exports: {} };
bn.exports;
(function(t) {
  (function(e, n) {
    function a(w, d) {
      if (!w)
        throw new Error(d || "Assertion failed");
    }
    function c(w, d) {
      w.super_ = d;
      var m = function() {
      };
      m.prototype = d.prototype, w.prototype = new m(), w.prototype.constructor = w;
    }
    function o(w, d, m) {
      if (o.isBN(w))
        return w;
      this.negative = 0, this.words = null, this.length = 0, this.red = null, w !== null && ((d === "le" || d === "be") && (m = d, d = 10), this._init(w || 0, d || 10, m || "be"));
    }
    typeof e == "object" ? e.exports = o : n.BN = o, o.BN = o, o.wordSize = 26;
    var u;
    try {
      typeof window < "u" && typeof window.Buffer < "u" ? u = window.Buffer : u = require$$1$2.Buffer;
    } catch {
    }
    o.isBN = function(d) {
      return d instanceof o ? !0 : d !== null && typeof d == "object" && d.constructor.wordSize === o.wordSize && Array.isArray(d.words);
    }, o.max = function(d, m) {
      return d.cmp(m) > 0 ? d : m;
    }, o.min = function(d, m) {
      return d.cmp(m) < 0 ? d : m;
    }, o.prototype._init = function(d, m, B) {
      if (typeof d == "number")
        return this._initNumber(d, m, B);
      if (typeof d == "object")
        return this._initArray(d, m, B);
      m === "hex" && (m = 16), a(m === (m | 0) && m >= 2 && m <= 36), d = d.toString().replace(/\s+/g, "");
      var $ = 0;
      d[0] === "-" && ($++, this.negative = 1), $ < d.length && (m === 16 ? this._parseHex(d, $, B) : (this._parseBase(d, m, $), B === "le" && this._initArray(this.toArray(), m, B)));
    }, o.prototype._initNumber = function(d, m, B) {
      d < 0 && (this.negative = 1, d = -d), d < 67108864 ? (this.words = [d & 67108863], this.length = 1) : d < 4503599627370496 ? (this.words = [
        d & 67108863,
        d / 67108864 & 67108863
      ], this.length = 2) : (a(d < 9007199254740992), this.words = [
        d & 67108863,
        d / 67108864 & 67108863,
        1
      ], this.length = 3), B === "le" && this._initArray(this.toArray(), m, B);
    }, o.prototype._initArray = function(d, m, B) {
      if (a(typeof d.length == "number"), d.length <= 0)
        return this.words = [0], this.length = 1, this;
      this.length = Math.ceil(d.length / 3), this.words = new Array(this.length);
      for (var $ = 0; $ < this.length; $++)
        this.words[$] = 0;
      var P, M, v = 0;
      if (B === "be")
        for ($ = d.length - 1, P = 0; $ >= 0; $ -= 3)
          M = d[$] | d[$ - 1] << 8 | d[$ - 2] << 16, this.words[P] |= M << v & 67108863, this.words[P + 1] = M >>> 26 - v & 67108863, v += 24, v >= 26 && (v -= 26, P++);
      else if (B === "le")
        for ($ = 0, P = 0; $ < d.length; $ += 3)
          M = d[$] | d[$ + 1] << 8 | d[$ + 2] << 16, this.words[P] |= M << v & 67108863, this.words[P + 1] = M >>> 26 - v & 67108863, v += 24, v >= 26 && (v -= 26, P++);
      return this._strip();
    };
    function h(w, d) {
      var m = w.charCodeAt(d);
      if (m >= 48 && m <= 57)
        return m - 48;
      if (m >= 65 && m <= 70)
        return m - 55;
      if (m >= 97 && m <= 102)
        return m - 87;
      a(!1, "Invalid character in " + w);
    }
    function p(w, d, m) {
      var B = h(w, m);
      return m - 1 >= d && (B |= h(w, m - 1) << 4), B;
    }
    o.prototype._parseHex = function(d, m, B) {
      this.length = Math.ceil((d.length - m) / 6), this.words = new Array(this.length);
      for (var $ = 0; $ < this.length; $++)
        this.words[$] = 0;
      var P = 0, M = 0, v;
      if (B === "be")
        for ($ = d.length - 1; $ >= m; $ -= 2)
          v = p(d, m, $) << P, this.words[M] |= v & 67108863, P >= 18 ? (P -= 18, M += 1, this.words[M] |= v >>> 26) : P += 8;
      else {
        var A = d.length - m;
        for ($ = A % 2 === 0 ? m + 1 : m; $ < d.length; $ += 2)
          v = p(d, m, $) << P, this.words[M] |= v & 67108863, P >= 18 ? (P -= 18, M += 1, this.words[M] |= v >>> 26) : P += 8;
      }
      this._strip();
    };
    function x(w, d, m, B) {
      for (var $ = 0, P = 0, M = Math.min(w.length, m), v = d; v < M; v++) {
        var A = w.charCodeAt(v) - 48;
        $ *= B, A >= 49 ? P = A - 49 + 10 : A >= 17 ? P = A - 17 + 10 : P = A, a(A >= 0 && P < B, "Invalid character"), $ += P;
      }
      return $;
    }
    o.prototype._parseBase = function(d, m, B) {
      this.words = [0], this.length = 1;
      for (var $ = 0, P = 1; P <= 67108863; P *= m)
        $++;
      $--, P = P / m | 0;
      for (var M = d.length - B, v = M % $, A = Math.min(M, M - v) + B, y = 0, T = B; T < A; T += $)
        y = x(d, T, T + $, m), this.imuln(P), this.words[0] + y < 67108864 ? this.words[0] += y : this._iaddn(y);
      if (v !== 0) {
        var Z = 1;
        for (y = x(d, T, d.length, m), T = 0; T < v; T++)
          Z *= m;
        this.imuln(Z), this.words[0] + y < 67108864 ? this.words[0] += y : this._iaddn(y);
      }
      this._strip();
    }, o.prototype.copy = function(d) {
      d.words = new Array(this.length);
      for (var m = 0; m < this.length; m++)
        d.words[m] = this.words[m];
      d.length = this.length, d.negative = this.negative, d.red = this.red;
    };
    function l(w, d) {
      w.words = d.words, w.length = d.length, w.negative = d.negative, w.red = d.red;
    }
    if (o.prototype._move = function(d) {
      l(d, this);
    }, o.prototype.clone = function() {
      var d = new o(null);
      return this.copy(d), d;
    }, o.prototype._expand = function(d) {
      for (; this.length < d; )
        this.words[this.length++] = 0;
      return this;
    }, o.prototype._strip = function() {
      for (; this.length > 1 && this.words[this.length - 1] === 0; )
        this.length--;
      return this._normSign();
    }, o.prototype._normSign = function() {
      return this.length === 1 && this.words[0] === 0 && (this.negative = 0), this;
    }, typeof Symbol < "u" && typeof Symbol.for == "function")
      try {
        o.prototype[Symbol.for("nodejs.util.inspect.custom")] = b;
      } catch {
        o.prototype.inspect = b;
      }
    else
      o.prototype.inspect = b;
    function b() {
      return (this.red ? "<BN-R: " : "<BN: ") + this.toString(16) + ">";
    }
    var E = [
      "",
      "0",
      "00",
      "000",
      "0000",
      "00000",
      "000000",
      "0000000",
      "00000000",
      "000000000",
      "0000000000",
      "00000000000",
      "000000000000",
      "0000000000000",
      "00000000000000",
      "000000000000000",
      "0000000000000000",
      "00000000000000000",
      "000000000000000000",
      "0000000000000000000",
      "00000000000000000000",
      "000000000000000000000",
      "0000000000000000000000",
      "00000000000000000000000",
      "000000000000000000000000",
      "0000000000000000000000000"
    ], C = [
      0,
      0,
      25,
      16,
      12,
      11,
      10,
      9,
      8,
      8,
      7,
      7,
      7,
      7,
      6,
      6,
      6,
      6,
      6,
      6,
      6,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5,
      5
    ], q = [
      0,
      0,
      33554432,
      43046721,
      16777216,
      48828125,
      60466176,
      40353607,
      16777216,
      43046721,
      1e7,
      19487171,
      35831808,
      62748517,
      7529536,
      11390625,
      16777216,
      24137569,
      34012224,
      47045881,
      64e6,
      4084101,
      5153632,
      6436343,
      7962624,
      9765625,
      11881376,
      14348907,
      17210368,
      20511149,
      243e5,
      28629151,
      33554432,
      39135393,
      45435424,
      52521875,
      60466176
    ];
    o.prototype.toString = function(d, m) {
      d = d || 10, m = m | 0 || 1;
      var B;
      if (d === 16 || d === "hex") {
        B = "";
        for (var $ = 0, P = 0, M = 0; M < this.length; M++) {
          var v = this.words[M], A = ((v << $ | P) & 16777215).toString(16);
          P = v >>> 24 - $ & 16777215, $ += 2, $ >= 26 && ($ -= 26, M--), P !== 0 || M !== this.length - 1 ? B = E[6 - A.length] + A + B : B = A + B;
        }
        for (P !== 0 && (B = P.toString(16) + B); B.length % m !== 0; )
          B = "0" + B;
        return this.negative !== 0 && (B = "-" + B), B;
      }
      if (d === (d | 0) && d >= 2 && d <= 36) {
        var y = C[d], T = q[d];
        B = "";
        var Z = this.clone();
        for (Z.negative = 0; !Z.isZero(); ) {
          var ie = Z.modrn(T).toString(d);
          Z = Z.idivn(T), Z.isZero() ? B = ie + B : B = E[y - ie.length] + ie + B;
        }
        for (this.isZero() && (B = "0" + B); B.length % m !== 0; )
          B = "0" + B;
        return this.negative !== 0 && (B = "-" + B), B;
      }
      a(!1, "Base should be between 2 and 36");
    }, o.prototype.toNumber = function() {
      var d = this.words[0];
      return this.length === 2 ? d += this.words[1] * 67108864 : this.length === 3 && this.words[2] === 1 ? d += 4503599627370496 + this.words[1] * 67108864 : this.length > 2 && a(!1, "Number can only safely store up to 53 bits"), this.negative !== 0 ? -d : d;
    }, o.prototype.toJSON = function() {
      return this.toString(16, 2);
    }, u && (o.prototype.toBuffer = function(d, m) {
      return this.toArrayLike(u, d, m);
    }), o.prototype.toArray = function(d, m) {
      return this.toArrayLike(Array, d, m);
    };
    var F = function(d, m) {
      return d.allocUnsafe ? d.allocUnsafe(m) : new d(m);
    };
    o.prototype.toArrayLike = function(d, m, B) {
      this._strip();
      var $ = this.byteLength(), P = B || Math.max(1, $);
      a($ <= P, "byte array longer than desired length"), a(P > 0, "Requested array length <= 0");
      var M = F(d, P), v = m === "le" ? "LE" : "BE";
      return this["_toArrayLike" + v](M, $), M;
    }, o.prototype._toArrayLikeLE = function(d, m) {
      for (var B = 0, $ = 0, P = 0, M = 0; P < this.length; P++) {
        var v = this.words[P] << M | $;
        d[B++] = v & 255, B < d.length && (d[B++] = v >> 8 & 255), B < d.length && (d[B++] = v >> 16 & 255), M === 6 ? (B < d.length && (d[B++] = v >> 24 & 255), $ = 0, M = 0) : ($ = v >>> 24, M += 2);
      }
      if (B < d.length)
        for (d[B++] = $; B < d.length; )
          d[B++] = 0;
    }, o.prototype._toArrayLikeBE = function(d, m) {
      for (var B = d.length - 1, $ = 0, P = 0, M = 0; P < this.length; P++) {
        var v = this.words[P] << M | $;
        d[B--] = v & 255, B >= 0 && (d[B--] = v >> 8 & 255), B >= 0 && (d[B--] = v >> 16 & 255), M === 6 ? (B >= 0 && (d[B--] = v >> 24 & 255), $ = 0, M = 0) : ($ = v >>> 24, M += 2);
      }
      if (B >= 0)
        for (d[B--] = $; B >= 0; )
          d[B--] = 0;
    }, Math.clz32 ? o.prototype._countBits = function(d) {
      return 32 - Math.clz32(d);
    } : o.prototype._countBits = function(d) {
      var m = d, B = 0;
      return m >= 4096 && (B += 13, m >>>= 13), m >= 64 && (B += 7, m >>>= 7), m >= 8 && (B += 4, m >>>= 4), m >= 2 && (B += 2, m >>>= 2), B + m;
    }, o.prototype._zeroBits = function(d) {
      if (d === 0)
        return 26;
      var m = d, B = 0;
      return m & 8191 || (B += 13, m >>>= 13), m & 127 || (B += 7, m >>>= 7), m & 15 || (B += 4, m >>>= 4), m & 3 || (B += 2, m >>>= 2), m & 1 || B++, B;
    }, o.prototype.bitLength = function() {
      var d = this.words[this.length - 1], m = this._countBits(d);
      return (this.length - 1) * 26 + m;
    };
    function z(w) {
      for (var d = new Array(w.bitLength()), m = 0; m < d.length; m++) {
        var B = m / 26 | 0, $ = m % 26;
        d[m] = w.words[B] >>> $ & 1;
      }
      return d;
    }
    o.prototype.zeroBits = function() {
      if (this.isZero())
        return 0;
      for (var d = 0, m = 0; m < this.length; m++) {
        var B = this._zeroBits(this.words[m]);
        if (d += B, B !== 26)
          break;
      }
      return d;
    }, o.prototype.byteLength = function() {
      return Math.ceil(this.bitLength() / 8);
    }, o.prototype.toTwos = function(d) {
      return this.negative !== 0 ? this.abs().inotn(d).iaddn(1) : this.clone();
    }, o.prototype.fromTwos = function(d) {
      return this.testn(d - 1) ? this.notn(d).iaddn(1).ineg() : this.clone();
    }, o.prototype.isNeg = function() {
      return this.negative !== 0;
    }, o.prototype.neg = function() {
      return this.clone().ineg();
    }, o.prototype.ineg = function() {
      return this.isZero() || (this.negative ^= 1), this;
    }, o.prototype.iuor = function(d) {
      for (; this.length < d.length; )
        this.words[this.length++] = 0;
      for (var m = 0; m < d.length; m++)
        this.words[m] = this.words[m] | d.words[m];
      return this._strip();
    }, o.prototype.ior = function(d) {
      return a((this.negative | d.negative) === 0), this.iuor(d);
    }, o.prototype.or = function(d) {
      return this.length > d.length ? this.clone().ior(d) : d.clone().ior(this);
    }, o.prototype.uor = function(d) {
      return this.length > d.length ? this.clone().iuor(d) : d.clone().iuor(this);
    }, o.prototype.iuand = function(d) {
      var m;
      this.length > d.length ? m = d : m = this;
      for (var B = 0; B < m.length; B++)
        this.words[B] = this.words[B] & d.words[B];
      return this.length = m.length, this._strip();
    }, o.prototype.iand = function(d) {
      return a((this.negative | d.negative) === 0), this.iuand(d);
    }, o.prototype.and = function(d) {
      return this.length > d.length ? this.clone().iand(d) : d.clone().iand(this);
    }, o.prototype.uand = function(d) {
      return this.length > d.length ? this.clone().iuand(d) : d.clone().iuand(this);
    }, o.prototype.iuxor = function(d) {
      var m, B;
      this.length > d.length ? (m = this, B = d) : (m = d, B = this);
      for (var $ = 0; $ < B.length; $++)
        this.words[$] = m.words[$] ^ B.words[$];
      if (this !== m)
        for (; $ < m.length; $++)
          this.words[$] = m.words[$];
      return this.length = m.length, this._strip();
    }, o.prototype.ixor = function(d) {
      return a((this.negative | d.negative) === 0), this.iuxor(d);
    }, o.prototype.xor = function(d) {
      return this.length > d.length ? this.clone().ixor(d) : d.clone().ixor(this);
    }, o.prototype.uxor = function(d) {
      return this.length > d.length ? this.clone().iuxor(d) : d.clone().iuxor(this);
    }, o.prototype.inotn = function(d) {
      a(typeof d == "number" && d >= 0);
      var m = Math.ceil(d / 26) | 0, B = d % 26;
      this._expand(m), B > 0 && m--;
      for (var $ = 0; $ < m; $++)
        this.words[$] = ~this.words[$] & 67108863;
      return B > 0 && (this.words[$] = ~this.words[$] & 67108863 >> 26 - B), this._strip();
    }, o.prototype.notn = function(d) {
      return this.clone().inotn(d);
    }, o.prototype.setn = function(d, m) {
      a(typeof d == "number" && d >= 0);
      var B = d / 26 | 0, $ = d % 26;
      return this._expand(B + 1), m ? this.words[B] = this.words[B] | 1 << $ : this.words[B] = this.words[B] & ~(1 << $), this._strip();
    }, o.prototype.iadd = function(d) {
      var m;
      if (this.negative !== 0 && d.negative === 0)
        return this.negative = 0, m = this.isub(d), this.negative ^= 1, this._normSign();
      if (this.negative === 0 && d.negative !== 0)
        return d.negative = 0, m = this.isub(d), d.negative = 1, m._normSign();
      var B, $;
      this.length > d.length ? (B = this, $ = d) : (B = d, $ = this);
      for (var P = 0, M = 0; M < $.length; M++)
        m = (B.words[M] | 0) + ($.words[M] | 0) + P, this.words[M] = m & 67108863, P = m >>> 26;
      for (; P !== 0 && M < B.length; M++)
        m = (B.words[M] | 0) + P, this.words[M] = m & 67108863, P = m >>> 26;
      if (this.length = B.length, P !== 0)
        this.words[this.length] = P, this.length++;
      else if (B !== this)
        for (; M < B.length; M++)
          this.words[M] = B.words[M];
      return this;
    }, o.prototype.add = function(d) {
      var m;
      return d.negative !== 0 && this.negative === 0 ? (d.negative = 0, m = this.sub(d), d.negative ^= 1, m) : d.negative === 0 && this.negative !== 0 ? (this.negative = 0, m = d.sub(this), this.negative = 1, m) : this.length > d.length ? this.clone().iadd(d) : d.clone().iadd(this);
    }, o.prototype.isub = function(d) {
      if (d.negative !== 0) {
        d.negative = 0;
        var m = this.iadd(d);
        return d.negative = 1, m._normSign();
      } else if (this.negative !== 0)
        return this.negative = 0, this.iadd(d), this.negative = 1, this._normSign();
      var B = this.cmp(d);
      if (B === 0)
        return this.negative = 0, this.length = 1, this.words[0] = 0, this;
      var $, P;
      B > 0 ? ($ = this, P = d) : ($ = d, P = this);
      for (var M = 0, v = 0; v < P.length; v++)
        m = ($.words[v] | 0) - (P.words[v] | 0) + M, M = m >> 26, this.words[v] = m & 67108863;
      for (; M !== 0 && v < $.length; v++)
        m = ($.words[v] | 0) + M, M = m >> 26, this.words[v] = m & 67108863;
      if (M === 0 && v < $.length && $ !== this)
        for (; v < $.length; v++)
          this.words[v] = $.words[v];
      return this.length = Math.max(this.length, v), $ !== this && (this.negative = 1), this._strip();
    }, o.prototype.sub = function(d) {
      return this.clone().isub(d);
    };
    function H(w, d, m) {
      m.negative = d.negative ^ w.negative;
      var B = w.length + d.length | 0;
      m.length = B, B = B - 1 | 0;
      var $ = w.words[0] | 0, P = d.words[0] | 0, M = $ * P, v = M & 67108863, A = M / 67108864 | 0;
      m.words[0] = v;
      for (var y = 1; y < B; y++) {
        for (var T = A >>> 26, Z = A & 67108863, ie = Math.min(y, d.length - 1), J = Math.max(0, y - w.length + 1); J <= ie; J++) {
          var k = y - J | 0;
          $ = w.words[k] | 0, P = d.words[J] | 0, M = $ * P + Z, T += M / 67108864 | 0, Z = M & 67108863;
        }
        m.words[y] = Z | 0, A = T | 0;
      }
      return A !== 0 ? m.words[y] = A | 0 : m.length--, m._strip();
    }
    var U = function(d, m, B) {
      var $ = d.words, P = m.words, M = B.words, v = 0, A, y, T, Z = $[0] | 0, ie = Z & 8191, J = Z >>> 13, k = $[1] | 0, D = k & 8191, X = k >>> 13, te = $[2] | 0, N = te & 8191, O = te >>> 13, ne = $[3] | 0, de = ne & 8191, le = ne >>> 13, he = $[4] | 0, me = he & 8191, ge = he >>> 13, oe = $[5] | 0, qe = oe & 8191, _e = oe >>> 13, Oe = $[6] | 0, De = Oe & 8191, ye = Oe >>> 13, Be = $[7] | 0, Le = Be & 8191, xe = Be >>> 13, Te = $[8] | 0, Ne = Te & 8191, L = Te >>> 13, S = $[9] | 0, I = S & 8191, j = S >>> 13, Q = P[0] | 0, re = Q & 8191, ae = Q >>> 13, ve = P[1] | 0, Se = ve & 8191, be = ve >>> 13, Ee = P[2] | 0, we = Ee & 8191, Ae = Ee >>> 13, He = P[3] | 0, Ue = He & 8191, Me = He >>> 13, ze = P[4] | 0, Ke = ze & 8191, Ie = ze >>> 13, Ge = P[5] | 0, We = Ge & 8191, Ce = Ge >>> 13, Ve = P[6] | 0, Je = Ve & 8191, Re = Ve >>> 13, Ze = P[7] | 0, Xe = Ze & 8191, Pe = Ze >>> 13, Ye = P[8] | 0, Qe = Ye & 8191, ke = Ye >>> 13, et = P[9] | 0, Fe = et & 8191, je = et >>> 13;
      B.negative = d.negative ^ m.negative, B.length = 19, A = Math.imul(ie, re), y = Math.imul(ie, ae), y = y + Math.imul(J, re) | 0, T = Math.imul(J, ae);
      var tt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (tt >>> 26) | 0, tt &= 67108863, A = Math.imul(D, re), y = Math.imul(D, ae), y = y + Math.imul(X, re) | 0, T = Math.imul(X, ae), A = A + Math.imul(ie, Se) | 0, y = y + Math.imul(ie, be) | 0, y = y + Math.imul(J, Se) | 0, T = T + Math.imul(J, be) | 0;
      var rt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (rt >>> 26) | 0, rt &= 67108863, A = Math.imul(N, re), y = Math.imul(N, ae), y = y + Math.imul(O, re) | 0, T = Math.imul(O, ae), A = A + Math.imul(D, Se) | 0, y = y + Math.imul(D, be) | 0, y = y + Math.imul(X, Se) | 0, T = T + Math.imul(X, be) | 0, A = A + Math.imul(ie, we) | 0, y = y + Math.imul(ie, Ae) | 0, y = y + Math.imul(J, we) | 0, T = T + Math.imul(J, Ae) | 0;
      var nt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (nt >>> 26) | 0, nt &= 67108863, A = Math.imul(de, re), y = Math.imul(de, ae), y = y + Math.imul(le, re) | 0, T = Math.imul(le, ae), A = A + Math.imul(N, Se) | 0, y = y + Math.imul(N, be) | 0, y = y + Math.imul(O, Se) | 0, T = T + Math.imul(O, be) | 0, A = A + Math.imul(D, we) | 0, y = y + Math.imul(D, Ae) | 0, y = y + Math.imul(X, we) | 0, T = T + Math.imul(X, Ae) | 0, A = A + Math.imul(ie, Ue) | 0, y = y + Math.imul(ie, Me) | 0, y = y + Math.imul(J, Ue) | 0, T = T + Math.imul(J, Me) | 0;
      var it = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (it >>> 26) | 0, it &= 67108863, A = Math.imul(me, re), y = Math.imul(me, ae), y = y + Math.imul(ge, re) | 0, T = Math.imul(ge, ae), A = A + Math.imul(de, Se) | 0, y = y + Math.imul(de, be) | 0, y = y + Math.imul(le, Se) | 0, T = T + Math.imul(le, be) | 0, A = A + Math.imul(N, we) | 0, y = y + Math.imul(N, Ae) | 0, y = y + Math.imul(O, we) | 0, T = T + Math.imul(O, Ae) | 0, A = A + Math.imul(D, Ue) | 0, y = y + Math.imul(D, Me) | 0, y = y + Math.imul(X, Ue) | 0, T = T + Math.imul(X, Me) | 0, A = A + Math.imul(ie, Ke) | 0, y = y + Math.imul(ie, Ie) | 0, y = y + Math.imul(J, Ke) | 0, T = T + Math.imul(J, Ie) | 0;
      var at = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (at >>> 26) | 0, at &= 67108863, A = Math.imul(qe, re), y = Math.imul(qe, ae), y = y + Math.imul(_e, re) | 0, T = Math.imul(_e, ae), A = A + Math.imul(me, Se) | 0, y = y + Math.imul(me, be) | 0, y = y + Math.imul(ge, Se) | 0, T = T + Math.imul(ge, be) | 0, A = A + Math.imul(de, we) | 0, y = y + Math.imul(de, Ae) | 0, y = y + Math.imul(le, we) | 0, T = T + Math.imul(le, Ae) | 0, A = A + Math.imul(N, Ue) | 0, y = y + Math.imul(N, Me) | 0, y = y + Math.imul(O, Ue) | 0, T = T + Math.imul(O, Me) | 0, A = A + Math.imul(D, Ke) | 0, y = y + Math.imul(D, Ie) | 0, y = y + Math.imul(X, Ke) | 0, T = T + Math.imul(X, Ie) | 0, A = A + Math.imul(ie, We) | 0, y = y + Math.imul(ie, Ce) | 0, y = y + Math.imul(J, We) | 0, T = T + Math.imul(J, Ce) | 0;
      var ot = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (ot >>> 26) | 0, ot &= 67108863, A = Math.imul(De, re), y = Math.imul(De, ae), y = y + Math.imul(ye, re) | 0, T = Math.imul(ye, ae), A = A + Math.imul(qe, Se) | 0, y = y + Math.imul(qe, be) | 0, y = y + Math.imul(_e, Se) | 0, T = T + Math.imul(_e, be) | 0, A = A + Math.imul(me, we) | 0, y = y + Math.imul(me, Ae) | 0, y = y + Math.imul(ge, we) | 0, T = T + Math.imul(ge, Ae) | 0, A = A + Math.imul(de, Ue) | 0, y = y + Math.imul(de, Me) | 0, y = y + Math.imul(le, Ue) | 0, T = T + Math.imul(le, Me) | 0, A = A + Math.imul(N, Ke) | 0, y = y + Math.imul(N, Ie) | 0, y = y + Math.imul(O, Ke) | 0, T = T + Math.imul(O, Ie) | 0, A = A + Math.imul(D, We) | 0, y = y + Math.imul(D, Ce) | 0, y = y + Math.imul(X, We) | 0, T = T + Math.imul(X, Ce) | 0, A = A + Math.imul(ie, Je) | 0, y = y + Math.imul(ie, Re) | 0, y = y + Math.imul(J, Je) | 0, T = T + Math.imul(J, Re) | 0;
      var st = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (st >>> 26) | 0, st &= 67108863, A = Math.imul(Le, re), y = Math.imul(Le, ae), y = y + Math.imul(xe, re) | 0, T = Math.imul(xe, ae), A = A + Math.imul(De, Se) | 0, y = y + Math.imul(De, be) | 0, y = y + Math.imul(ye, Se) | 0, T = T + Math.imul(ye, be) | 0, A = A + Math.imul(qe, we) | 0, y = y + Math.imul(qe, Ae) | 0, y = y + Math.imul(_e, we) | 0, T = T + Math.imul(_e, Ae) | 0, A = A + Math.imul(me, Ue) | 0, y = y + Math.imul(me, Me) | 0, y = y + Math.imul(ge, Ue) | 0, T = T + Math.imul(ge, Me) | 0, A = A + Math.imul(de, Ke) | 0, y = y + Math.imul(de, Ie) | 0, y = y + Math.imul(le, Ke) | 0, T = T + Math.imul(le, Ie) | 0, A = A + Math.imul(N, We) | 0, y = y + Math.imul(N, Ce) | 0, y = y + Math.imul(O, We) | 0, T = T + Math.imul(O, Ce) | 0, A = A + Math.imul(D, Je) | 0, y = y + Math.imul(D, Re) | 0, y = y + Math.imul(X, Je) | 0, T = T + Math.imul(X, Re) | 0, A = A + Math.imul(ie, Xe) | 0, y = y + Math.imul(ie, Pe) | 0, y = y + Math.imul(J, Xe) | 0, T = T + Math.imul(J, Pe) | 0;
      var ct = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (ct >>> 26) | 0, ct &= 67108863, A = Math.imul(Ne, re), y = Math.imul(Ne, ae), y = y + Math.imul(L, re) | 0, T = Math.imul(L, ae), A = A + Math.imul(Le, Se) | 0, y = y + Math.imul(Le, be) | 0, y = y + Math.imul(xe, Se) | 0, T = T + Math.imul(xe, be) | 0, A = A + Math.imul(De, we) | 0, y = y + Math.imul(De, Ae) | 0, y = y + Math.imul(ye, we) | 0, T = T + Math.imul(ye, Ae) | 0, A = A + Math.imul(qe, Ue) | 0, y = y + Math.imul(qe, Me) | 0, y = y + Math.imul(_e, Ue) | 0, T = T + Math.imul(_e, Me) | 0, A = A + Math.imul(me, Ke) | 0, y = y + Math.imul(me, Ie) | 0, y = y + Math.imul(ge, Ke) | 0, T = T + Math.imul(ge, Ie) | 0, A = A + Math.imul(de, We) | 0, y = y + Math.imul(de, Ce) | 0, y = y + Math.imul(le, We) | 0, T = T + Math.imul(le, Ce) | 0, A = A + Math.imul(N, Je) | 0, y = y + Math.imul(N, Re) | 0, y = y + Math.imul(O, Je) | 0, T = T + Math.imul(O, Re) | 0, A = A + Math.imul(D, Xe) | 0, y = y + Math.imul(D, Pe) | 0, y = y + Math.imul(X, Xe) | 0, T = T + Math.imul(X, Pe) | 0, A = A + Math.imul(ie, Qe) | 0, y = y + Math.imul(ie, ke) | 0, y = y + Math.imul(J, Qe) | 0, T = T + Math.imul(J, ke) | 0;
      var ut = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (ut >>> 26) | 0, ut &= 67108863, A = Math.imul(I, re), y = Math.imul(I, ae), y = y + Math.imul(j, re) | 0, T = Math.imul(j, ae), A = A + Math.imul(Ne, Se) | 0, y = y + Math.imul(Ne, be) | 0, y = y + Math.imul(L, Se) | 0, T = T + Math.imul(L, be) | 0, A = A + Math.imul(Le, we) | 0, y = y + Math.imul(Le, Ae) | 0, y = y + Math.imul(xe, we) | 0, T = T + Math.imul(xe, Ae) | 0, A = A + Math.imul(De, Ue) | 0, y = y + Math.imul(De, Me) | 0, y = y + Math.imul(ye, Ue) | 0, T = T + Math.imul(ye, Me) | 0, A = A + Math.imul(qe, Ke) | 0, y = y + Math.imul(qe, Ie) | 0, y = y + Math.imul(_e, Ke) | 0, T = T + Math.imul(_e, Ie) | 0, A = A + Math.imul(me, We) | 0, y = y + Math.imul(me, Ce) | 0, y = y + Math.imul(ge, We) | 0, T = T + Math.imul(ge, Ce) | 0, A = A + Math.imul(de, Je) | 0, y = y + Math.imul(de, Re) | 0, y = y + Math.imul(le, Je) | 0, T = T + Math.imul(le, Re) | 0, A = A + Math.imul(N, Xe) | 0, y = y + Math.imul(N, Pe) | 0, y = y + Math.imul(O, Xe) | 0, T = T + Math.imul(O, Pe) | 0, A = A + Math.imul(D, Qe) | 0, y = y + Math.imul(D, ke) | 0, y = y + Math.imul(X, Qe) | 0, T = T + Math.imul(X, ke) | 0, A = A + Math.imul(ie, Fe) | 0, y = y + Math.imul(ie, je) | 0, y = y + Math.imul(J, Fe) | 0, T = T + Math.imul(J, je) | 0;
      var dt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (dt >>> 26) | 0, dt &= 67108863, A = Math.imul(I, Se), y = Math.imul(I, be), y = y + Math.imul(j, Se) | 0, T = Math.imul(j, be), A = A + Math.imul(Ne, we) | 0, y = y + Math.imul(Ne, Ae) | 0, y = y + Math.imul(L, we) | 0, T = T + Math.imul(L, Ae) | 0, A = A + Math.imul(Le, Ue) | 0, y = y + Math.imul(Le, Me) | 0, y = y + Math.imul(xe, Ue) | 0, T = T + Math.imul(xe, Me) | 0, A = A + Math.imul(De, Ke) | 0, y = y + Math.imul(De, Ie) | 0, y = y + Math.imul(ye, Ke) | 0, T = T + Math.imul(ye, Ie) | 0, A = A + Math.imul(qe, We) | 0, y = y + Math.imul(qe, Ce) | 0, y = y + Math.imul(_e, We) | 0, T = T + Math.imul(_e, Ce) | 0, A = A + Math.imul(me, Je) | 0, y = y + Math.imul(me, Re) | 0, y = y + Math.imul(ge, Je) | 0, T = T + Math.imul(ge, Re) | 0, A = A + Math.imul(de, Xe) | 0, y = y + Math.imul(de, Pe) | 0, y = y + Math.imul(le, Xe) | 0, T = T + Math.imul(le, Pe) | 0, A = A + Math.imul(N, Qe) | 0, y = y + Math.imul(N, ke) | 0, y = y + Math.imul(O, Qe) | 0, T = T + Math.imul(O, ke) | 0, A = A + Math.imul(D, Fe) | 0, y = y + Math.imul(D, je) | 0, y = y + Math.imul(X, Fe) | 0, T = T + Math.imul(X, je) | 0;
      var lt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (lt >>> 26) | 0, lt &= 67108863, A = Math.imul(I, we), y = Math.imul(I, Ae), y = y + Math.imul(j, we) | 0, T = Math.imul(j, Ae), A = A + Math.imul(Ne, Ue) | 0, y = y + Math.imul(Ne, Me) | 0, y = y + Math.imul(L, Ue) | 0, T = T + Math.imul(L, Me) | 0, A = A + Math.imul(Le, Ke) | 0, y = y + Math.imul(Le, Ie) | 0, y = y + Math.imul(xe, Ke) | 0, T = T + Math.imul(xe, Ie) | 0, A = A + Math.imul(De, We) | 0, y = y + Math.imul(De, Ce) | 0, y = y + Math.imul(ye, We) | 0, T = T + Math.imul(ye, Ce) | 0, A = A + Math.imul(qe, Je) | 0, y = y + Math.imul(qe, Re) | 0, y = y + Math.imul(_e, Je) | 0, T = T + Math.imul(_e, Re) | 0, A = A + Math.imul(me, Xe) | 0, y = y + Math.imul(me, Pe) | 0, y = y + Math.imul(ge, Xe) | 0, T = T + Math.imul(ge, Pe) | 0, A = A + Math.imul(de, Qe) | 0, y = y + Math.imul(de, ke) | 0, y = y + Math.imul(le, Qe) | 0, T = T + Math.imul(le, ke) | 0, A = A + Math.imul(N, Fe) | 0, y = y + Math.imul(N, je) | 0, y = y + Math.imul(O, Fe) | 0, T = T + Math.imul(O, je) | 0;
      var ht = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (ht >>> 26) | 0, ht &= 67108863, A = Math.imul(I, Ue), y = Math.imul(I, Me), y = y + Math.imul(j, Ue) | 0, T = Math.imul(j, Me), A = A + Math.imul(Ne, Ke) | 0, y = y + Math.imul(Ne, Ie) | 0, y = y + Math.imul(L, Ke) | 0, T = T + Math.imul(L, Ie) | 0, A = A + Math.imul(Le, We) | 0, y = y + Math.imul(Le, Ce) | 0, y = y + Math.imul(xe, We) | 0, T = T + Math.imul(xe, Ce) | 0, A = A + Math.imul(De, Je) | 0, y = y + Math.imul(De, Re) | 0, y = y + Math.imul(ye, Je) | 0, T = T + Math.imul(ye, Re) | 0, A = A + Math.imul(qe, Xe) | 0, y = y + Math.imul(qe, Pe) | 0, y = y + Math.imul(_e, Xe) | 0, T = T + Math.imul(_e, Pe) | 0, A = A + Math.imul(me, Qe) | 0, y = y + Math.imul(me, ke) | 0, y = y + Math.imul(ge, Qe) | 0, T = T + Math.imul(ge, ke) | 0, A = A + Math.imul(de, Fe) | 0, y = y + Math.imul(de, je) | 0, y = y + Math.imul(le, Fe) | 0, T = T + Math.imul(le, je) | 0;
      var pt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (pt >>> 26) | 0, pt &= 67108863, A = Math.imul(I, Ke), y = Math.imul(I, Ie), y = y + Math.imul(j, Ke) | 0, T = Math.imul(j, Ie), A = A + Math.imul(Ne, We) | 0, y = y + Math.imul(Ne, Ce) | 0, y = y + Math.imul(L, We) | 0, T = T + Math.imul(L, Ce) | 0, A = A + Math.imul(Le, Je) | 0, y = y + Math.imul(Le, Re) | 0, y = y + Math.imul(xe, Je) | 0, T = T + Math.imul(xe, Re) | 0, A = A + Math.imul(De, Xe) | 0, y = y + Math.imul(De, Pe) | 0, y = y + Math.imul(ye, Xe) | 0, T = T + Math.imul(ye, Pe) | 0, A = A + Math.imul(qe, Qe) | 0, y = y + Math.imul(qe, ke) | 0, y = y + Math.imul(_e, Qe) | 0, T = T + Math.imul(_e, ke) | 0, A = A + Math.imul(me, Fe) | 0, y = y + Math.imul(me, je) | 0, y = y + Math.imul(ge, Fe) | 0, T = T + Math.imul(ge, je) | 0;
      var bt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (bt >>> 26) | 0, bt &= 67108863, A = Math.imul(I, We), y = Math.imul(I, Ce), y = y + Math.imul(j, We) | 0, T = Math.imul(j, Ce), A = A + Math.imul(Ne, Je) | 0, y = y + Math.imul(Ne, Re) | 0, y = y + Math.imul(L, Je) | 0, T = T + Math.imul(L, Re) | 0, A = A + Math.imul(Le, Xe) | 0, y = y + Math.imul(Le, Pe) | 0, y = y + Math.imul(xe, Xe) | 0, T = T + Math.imul(xe, Pe) | 0, A = A + Math.imul(De, Qe) | 0, y = y + Math.imul(De, ke) | 0, y = y + Math.imul(ye, Qe) | 0, T = T + Math.imul(ye, ke) | 0, A = A + Math.imul(qe, Fe) | 0, y = y + Math.imul(qe, je) | 0, y = y + Math.imul(_e, Fe) | 0, T = T + Math.imul(_e, je) | 0;
      var vt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (vt >>> 26) | 0, vt &= 67108863, A = Math.imul(I, Je), y = Math.imul(I, Re), y = y + Math.imul(j, Je) | 0, T = Math.imul(j, Re), A = A + Math.imul(Ne, Xe) | 0, y = y + Math.imul(Ne, Pe) | 0, y = y + Math.imul(L, Xe) | 0, T = T + Math.imul(L, Pe) | 0, A = A + Math.imul(Le, Qe) | 0, y = y + Math.imul(Le, ke) | 0, y = y + Math.imul(xe, Qe) | 0, T = T + Math.imul(xe, ke) | 0, A = A + Math.imul(De, Fe) | 0, y = y + Math.imul(De, je) | 0, y = y + Math.imul(ye, Fe) | 0, T = T + Math.imul(ye, je) | 0;
      var mt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (mt >>> 26) | 0, mt &= 67108863, A = Math.imul(I, Xe), y = Math.imul(I, Pe), y = y + Math.imul(j, Xe) | 0, T = Math.imul(j, Pe), A = A + Math.imul(Ne, Qe) | 0, y = y + Math.imul(Ne, ke) | 0, y = y + Math.imul(L, Qe) | 0, T = T + Math.imul(L, ke) | 0, A = A + Math.imul(Le, Fe) | 0, y = y + Math.imul(Le, je) | 0, y = y + Math.imul(xe, Fe) | 0, T = T + Math.imul(xe, je) | 0;
      var yt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (yt >>> 26) | 0, yt &= 67108863, A = Math.imul(I, Qe), y = Math.imul(I, ke), y = y + Math.imul(j, Qe) | 0, T = Math.imul(j, ke), A = A + Math.imul(Ne, Fe) | 0, y = y + Math.imul(Ne, je) | 0, y = y + Math.imul(L, Fe) | 0, T = T + Math.imul(L, je) | 0;
      var wt = (v + A | 0) + ((y & 8191) << 13) | 0;
      v = (T + (y >>> 13) | 0) + (wt >>> 26) | 0, wt &= 67108863, A = Math.imul(I, Fe), y = Math.imul(I, je), y = y + Math.imul(j, Fe) | 0, T = Math.imul(j, je);
      var _t = (v + A | 0) + ((y & 8191) << 13) | 0;
      return v = (T + (y >>> 13) | 0) + (_t >>> 26) | 0, _t &= 67108863, M[0] = tt, M[1] = rt, M[2] = nt, M[3] = it, M[4] = at, M[5] = ot, M[6] = st, M[7] = ct, M[8] = ut, M[9] = dt, M[10] = lt, M[11] = ht, M[12] = pt, M[13] = bt, M[14] = vt, M[15] = mt, M[16] = yt, M[17] = wt, M[18] = _t, v !== 0 && (M[19] = v, B.length++), B;
    };
    Math.imul || (U = H);
    function Y(w, d, m) {
      m.negative = d.negative ^ w.negative, m.length = w.length + d.length;
      for (var B = 0, $ = 0, P = 0; P < m.length - 1; P++) {
        var M = $;
        $ = 0;
        for (var v = B & 67108863, A = Math.min(P, d.length - 1), y = Math.max(0, P - w.length + 1); y <= A; y++) {
          var T = P - y, Z = w.words[T] | 0, ie = d.words[y] | 0, J = Z * ie, k = J & 67108863;
          M = M + (J / 67108864 | 0) | 0, k = k + v | 0, v = k & 67108863, M = M + (k >>> 26) | 0, $ += M >>> 26, M &= 67108863;
        }
        m.words[P] = v, B = M, M = $;
      }
      return B !== 0 ? m.words[P] = B : m.length--, m._strip();
    }
    function ee(w, d, m) {
      return Y(w, d, m);
    }
    o.prototype.mulTo = function(d, m) {
      var B, $ = this.length + d.length;
      return this.length === 10 && d.length === 10 ? B = U(this, d, m) : $ < 63 ? B = H(this, d, m) : $ < 1024 ? B = Y(this, d, m) : B = ee(this, d, m), B;
    }, o.prototype.mul = function(d) {
      var m = new o(null);
      return m.words = new Array(this.length + d.length), this.mulTo(d, m);
    }, o.prototype.mulf = function(d) {
      var m = new o(null);
      return m.words = new Array(this.length + d.length), ee(this, d, m);
    }, o.prototype.imul = function(d) {
      return this.clone().mulTo(d, this);
    }, o.prototype.imuln = function(d) {
      var m = d < 0;
      m && (d = -d), a(typeof d == "number"), a(d < 67108864);
      for (var B = 0, $ = 0; $ < this.length; $++) {
        var P = (this.words[$] | 0) * d, M = (P & 67108863) + (B & 67108863);
        B >>= 26, B += P / 67108864 | 0, B += M >>> 26, this.words[$] = M & 67108863;
      }
      return B !== 0 && (this.words[$] = B, this.length++), m ? this.ineg() : this;
    }, o.prototype.muln = function(d) {
      return this.clone().imuln(d);
    }, o.prototype.sqr = function() {
      return this.mul(this);
    }, o.prototype.isqr = function() {
      return this.imul(this.clone());
    }, o.prototype.pow = function(d) {
      var m = z(d);
      if (m.length === 0)
        return new o(1);
      for (var B = this, $ = 0; $ < m.length && m[$] === 0; $++, B = B.sqr())
        ;
      if (++$ < m.length)
        for (var P = B.sqr(); $ < m.length; $++, P = P.sqr())
          m[$] !== 0 && (B = B.mul(P));
      return B;
    }, o.prototype.iushln = function(d) {
      a(typeof d == "number" && d >= 0);
      var m = d % 26, B = (d - m) / 26, $ = 67108863 >>> 26 - m << 26 - m, P;
      if (m !== 0) {
        var M = 0;
        for (P = 0; P < this.length; P++) {
          var v = this.words[P] & $, A = (this.words[P] | 0) - v << m;
          this.words[P] = A | M, M = v >>> 26 - m;
        }
        M && (this.words[P] = M, this.length++);
      }
      if (B !== 0) {
        for (P = this.length - 1; P >= 0; P--)
          this.words[P + B] = this.words[P];
        for (P = 0; P < B; P++)
          this.words[P] = 0;
        this.length += B;
      }
      return this._strip();
    }, o.prototype.ishln = function(d) {
      return a(this.negative === 0), this.iushln(d);
    }, o.prototype.iushrn = function(d, m, B) {
      a(typeof d == "number" && d >= 0);
      var $;
      m ? $ = (m - m % 26) / 26 : $ = 0;
      var P = d % 26, M = Math.min((d - P) / 26, this.length), v = 67108863 ^ 67108863 >>> P << P, A = B;
      if ($ -= M, $ = Math.max(0, $), A) {
        for (var y = 0; y < M; y++)
          A.words[y] = this.words[y];
        A.length = M;
      }
      if (M !== 0)
        if (this.length > M)
          for (this.length -= M, y = 0; y < this.length; y++)
            this.words[y] = this.words[y + M];
        else
          this.words[0] = 0, this.length = 1;
      var T = 0;
      for (y = this.length - 1; y >= 0 && (T !== 0 || y >= $); y--) {
        var Z = this.words[y] | 0;
        this.words[y] = T << 26 - P | Z >>> P, T = Z & v;
      }
      return A && T !== 0 && (A.words[A.length++] = T), this.length === 0 && (this.words[0] = 0, this.length = 1), this._strip();
    }, o.prototype.ishrn = function(d, m, B) {
      return a(this.negative === 0), this.iushrn(d, m, B);
    }, o.prototype.shln = function(d) {
      return this.clone().ishln(d);
    }, o.prototype.ushln = function(d) {
      return this.clone().iushln(d);
    }, o.prototype.shrn = function(d) {
      return this.clone().ishrn(d);
    }, o.prototype.ushrn = function(d) {
      return this.clone().iushrn(d);
    }, o.prototype.testn = function(d) {
      a(typeof d == "number" && d >= 0);
      var m = d % 26, B = (d - m) / 26, $ = 1 << m;
      if (this.length <= B)
        return !1;
      var P = this.words[B];
      return !!(P & $);
    }, o.prototype.imaskn = function(d) {
      a(typeof d == "number" && d >= 0);
      var m = d % 26, B = (d - m) / 26;
      if (a(this.negative === 0, "imaskn works only with positive numbers"), this.length <= B)
        return this;
      if (m !== 0 && B++, this.length = Math.min(B, this.length), m !== 0) {
        var $ = 67108863 ^ 67108863 >>> m << m;
        this.words[this.length - 1] &= $;
      }
      return this._strip();
    }, o.prototype.maskn = function(d) {
      return this.clone().imaskn(d);
    }, o.prototype.iaddn = function(d) {
      return a(typeof d == "number"), a(d < 67108864), d < 0 ? this.isubn(-d) : this.negative !== 0 ? this.length === 1 && (this.words[0] | 0) <= d ? (this.words[0] = d - (this.words[0] | 0), this.negative = 0, this) : (this.negative = 0, this.isubn(d), this.negative = 1, this) : this._iaddn(d);
    }, o.prototype._iaddn = function(d) {
      this.words[0] += d;
      for (var m = 0; m < this.length && this.words[m] >= 67108864; m++)
        this.words[m] -= 67108864, m === this.length - 1 ? this.words[m + 1] = 1 : this.words[m + 1]++;
      return this.length = Math.max(this.length, m + 1), this;
    }, o.prototype.isubn = function(d) {
      if (a(typeof d == "number"), a(d < 67108864), d < 0)
        return this.iaddn(-d);
      if (this.negative !== 0)
        return this.negative = 0, this.iaddn(d), this.negative = 1, this;
      if (this.words[0] -= d, this.length === 1 && this.words[0] < 0)
        this.words[0] = -this.words[0], this.negative = 1;
      else
        for (var m = 0; m < this.length && this.words[m] < 0; m++)
          this.words[m] += 67108864, this.words[m + 1] -= 1;
      return this._strip();
    }, o.prototype.addn = function(d) {
      return this.clone().iaddn(d);
    }, o.prototype.subn = function(d) {
      return this.clone().isubn(d);
    }, o.prototype.iabs = function() {
      return this.negative = 0, this;
    }, o.prototype.abs = function() {
      return this.clone().iabs();
    }, o.prototype._ishlnsubmul = function(d, m, B) {
      var $ = d.length + B, P;
      this._expand($);
      var M, v = 0;
      for (P = 0; P < d.length; P++) {
        M = (this.words[P + B] | 0) + v;
        var A = (d.words[P] | 0) * m;
        M -= A & 67108863, v = (M >> 26) - (A / 67108864 | 0), this.words[P + B] = M & 67108863;
      }
      for (; P < this.length - B; P++)
        M = (this.words[P + B] | 0) + v, v = M >> 26, this.words[P + B] = M & 67108863;
      if (v === 0)
        return this._strip();
      for (a(v === -1), v = 0, P = 0; P < this.length; P++)
        M = -(this.words[P] | 0) + v, v = M >> 26, this.words[P] = M & 67108863;
      return this.negative = 1, this._strip();
    }, o.prototype._wordDiv = function(d, m) {
      var B = this.length - d.length, $ = this.clone(), P = d, M = P.words[P.length - 1] | 0, v = this._countBits(M);
      B = 26 - v, B !== 0 && (P = P.ushln(B), $.iushln(B), M = P.words[P.length - 1] | 0);
      var A = $.length - P.length, y;
      if (m !== "mod") {
        y = new o(null), y.length = A + 1, y.words = new Array(y.length);
        for (var T = 0; T < y.length; T++)
          y.words[T] = 0;
      }
      var Z = $.clone()._ishlnsubmul(P, 1, A);
      Z.negative === 0 && ($ = Z, y && (y.words[A] = 1));
      for (var ie = A - 1; ie >= 0; ie--) {
        var J = ($.words[P.length + ie] | 0) * 67108864 + ($.words[P.length + ie - 1] | 0);
        for (J = Math.min(J / M | 0, 67108863), $._ishlnsubmul(P, J, ie); $.negative !== 0; )
          J--, $.negative = 0, $._ishlnsubmul(P, 1, ie), $.isZero() || ($.negative ^= 1);
        y && (y.words[ie] = J);
      }
      return y && y._strip(), $._strip(), m !== "div" && B !== 0 && $.iushrn(B), {
        div: y || null,
        mod: $
      };
    }, o.prototype.divmod = function(d, m, B) {
      if (a(!d.isZero()), this.isZero())
        return {
          div: new o(0),
          mod: new o(0)
        };
      var $, P, M;
      return this.negative !== 0 && d.negative === 0 ? (M = this.neg().divmod(d, m), m !== "mod" && ($ = M.div.neg()), m !== "div" && (P = M.mod.neg(), B && P.negative !== 0 && P.iadd(d)), {
        div: $,
        mod: P
      }) : this.negative === 0 && d.negative !== 0 ? (M = this.divmod(d.neg(), m), m !== "mod" && ($ = M.div.neg()), {
        div: $,
        mod: M.mod
      }) : this.negative & d.negative ? (M = this.neg().divmod(d.neg(), m), m !== "div" && (P = M.mod.neg(), B && P.negative !== 0 && P.isub(d)), {
        div: M.div,
        mod: P
      }) : d.length > this.length || this.cmp(d) < 0 ? {
        div: new o(0),
        mod: this
      } : d.length === 1 ? m === "div" ? {
        div: this.divn(d.words[0]),
        mod: null
      } : m === "mod" ? {
        div: null,
        mod: new o(this.modrn(d.words[0]))
      } : {
        div: this.divn(d.words[0]),
        mod: new o(this.modrn(d.words[0]))
      } : this._wordDiv(d, m);
    }, o.prototype.div = function(d) {
      return this.divmod(d, "div", !1).div;
    }, o.prototype.mod = function(d) {
      return this.divmod(d, "mod", !1).mod;
    }, o.prototype.umod = function(d) {
      return this.divmod(d, "mod", !0).mod;
    }, o.prototype.divRound = function(d) {
      var m = this.divmod(d);
      if (m.mod.isZero())
        return m.div;
      var B = m.div.negative !== 0 ? m.mod.isub(d) : m.mod, $ = d.ushrn(1), P = d.andln(1), M = B.cmp($);
      return M < 0 || P === 1 && M === 0 ? m.div : m.div.negative !== 0 ? m.div.isubn(1) : m.div.iaddn(1);
    }, o.prototype.modrn = function(d) {
      var m = d < 0;
      m && (d = -d), a(d <= 67108863);
      for (var B = (1 << 26) % d, $ = 0, P = this.length - 1; P >= 0; P--)
        $ = (B * $ + (this.words[P] | 0)) % d;
      return m ? -$ : $;
    }, o.prototype.modn = function(d) {
      return this.modrn(d);
    }, o.prototype.idivn = function(d) {
      var m = d < 0;
      m && (d = -d), a(d <= 67108863);
      for (var B = 0, $ = this.length - 1; $ >= 0; $--) {
        var P = (this.words[$] | 0) + B * 67108864;
        this.words[$] = P / d | 0, B = P % d;
      }
      return this._strip(), m ? this.ineg() : this;
    }, o.prototype.divn = function(d) {
      return this.clone().idivn(d);
    }, o.prototype.egcd = function(d) {
      a(d.negative === 0), a(!d.isZero());
      var m = this, B = d.clone();
      m.negative !== 0 ? m = m.umod(d) : m = m.clone();
      for (var $ = new o(1), P = new o(0), M = new o(0), v = new o(1), A = 0; m.isEven() && B.isEven(); )
        m.iushrn(1), B.iushrn(1), ++A;
      for (var y = B.clone(), T = m.clone(); !m.isZero(); ) {
        for (var Z = 0, ie = 1; !(m.words[0] & ie) && Z < 26; ++Z, ie <<= 1)
          ;
        if (Z > 0)
          for (m.iushrn(Z); Z-- > 0; )
            ($.isOdd() || P.isOdd()) && ($.iadd(y), P.isub(T)), $.iushrn(1), P.iushrn(1);
        for (var J = 0, k = 1; !(B.words[0] & k) && J < 26; ++J, k <<= 1)
          ;
        if (J > 0)
          for (B.iushrn(J); J-- > 0; )
            (M.isOdd() || v.isOdd()) && (M.iadd(y), v.isub(T)), M.iushrn(1), v.iushrn(1);
        m.cmp(B) >= 0 ? (m.isub(B), $.isub(M), P.isub(v)) : (B.isub(m), M.isub($), v.isub(P));
      }
      return {
        a: M,
        b: v,
        gcd: B.iushln(A)
      };
    }, o.prototype._invmp = function(d) {
      a(d.negative === 0), a(!d.isZero());
      var m = this, B = d.clone();
      m.negative !== 0 ? m = m.umod(d) : m = m.clone();
      for (var $ = new o(1), P = new o(0), M = B.clone(); m.cmpn(1) > 0 && B.cmpn(1) > 0; ) {
        for (var v = 0, A = 1; !(m.words[0] & A) && v < 26; ++v, A <<= 1)
          ;
        if (v > 0)
          for (m.iushrn(v); v-- > 0; )
            $.isOdd() && $.iadd(M), $.iushrn(1);
        for (var y = 0, T = 1; !(B.words[0] & T) && y < 26; ++y, T <<= 1)
          ;
        if (y > 0)
          for (B.iushrn(y); y-- > 0; )
            P.isOdd() && P.iadd(M), P.iushrn(1);
        m.cmp(B) >= 0 ? (m.isub(B), $.isub(P)) : (B.isub(m), P.isub($));
      }
      var Z;
      return m.cmpn(1) === 0 ? Z = $ : Z = P, Z.cmpn(0) < 0 && Z.iadd(d), Z;
    }, o.prototype.gcd = function(d) {
      if (this.isZero())
        return d.abs();
      if (d.isZero())
        return this.abs();
      var m = this.clone(), B = d.clone();
      m.negative = 0, B.negative = 0;
      for (var $ = 0; m.isEven() && B.isEven(); $++)
        m.iushrn(1), B.iushrn(1);
      do {
        for (; m.isEven(); )
          m.iushrn(1);
        for (; B.isEven(); )
          B.iushrn(1);
        var P = m.cmp(B);
        if (P < 0) {
          var M = m;
          m = B, B = M;
        } else if (P === 0 || B.cmpn(1) === 0)
          break;
        m.isub(B);
      } while (!0);
      return B.iushln($);
    }, o.prototype.invm = function(d) {
      return this.egcd(d).a.umod(d);
    }, o.prototype.isEven = function() {
      return (this.words[0] & 1) === 0;
    }, o.prototype.isOdd = function() {
      return (this.words[0] & 1) === 1;
    }, o.prototype.andln = function(d) {
      return this.words[0] & d;
    }, o.prototype.bincn = function(d) {
      a(typeof d == "number");
      var m = d % 26, B = (d - m) / 26, $ = 1 << m;
      if (this.length <= B)
        return this._expand(B + 1), this.words[B] |= $, this;
      for (var P = $, M = B; P !== 0 && M < this.length; M++) {
        var v = this.words[M] | 0;
        v += P, P = v >>> 26, v &= 67108863, this.words[M] = v;
      }
      return P !== 0 && (this.words[M] = P, this.length++), this;
    }, o.prototype.isZero = function() {
      return this.length === 1 && this.words[0] === 0;
    }, o.prototype.cmpn = function(d) {
      var m = d < 0;
      if (this.negative !== 0 && !m)
        return -1;
      if (this.negative === 0 && m)
        return 1;
      this._strip();
      var B;
      if (this.length > 1)
        B = 1;
      else {
        m && (d = -d), a(d <= 67108863, "Number is too big");
        var $ = this.words[0] | 0;
        B = $ === d ? 0 : $ < d ? -1 : 1;
      }
      return this.negative !== 0 ? -B | 0 : B;
    }, o.prototype.cmp = function(d) {
      if (this.negative !== 0 && d.negative === 0)
        return -1;
      if (this.negative === 0 && d.negative !== 0)
        return 1;
      var m = this.ucmp(d);
      return this.negative !== 0 ? -m | 0 : m;
    }, o.prototype.ucmp = function(d) {
      if (this.length > d.length)
        return 1;
      if (this.length < d.length)
        return -1;
      for (var m = 0, B = this.length - 1; B >= 0; B--) {
        var $ = this.words[B] | 0, P = d.words[B] | 0;
        if ($ !== P) {
          $ < P ? m = -1 : $ > P && (m = 1);
          break;
        }
      }
      return m;
    }, o.prototype.gtn = function(d) {
      return this.cmpn(d) === 1;
    }, o.prototype.gt = function(d) {
      return this.cmp(d) === 1;
    }, o.prototype.gten = function(d) {
      return this.cmpn(d) >= 0;
    }, o.prototype.gte = function(d) {
      return this.cmp(d) >= 0;
    }, o.prototype.ltn = function(d) {
      return this.cmpn(d) === -1;
    }, o.prototype.lt = function(d) {
      return this.cmp(d) === -1;
    }, o.prototype.lten = function(d) {
      return this.cmpn(d) <= 0;
    }, o.prototype.lte = function(d) {
      return this.cmp(d) <= 0;
    }, o.prototype.eqn = function(d) {
      return this.cmpn(d) === 0;
    }, o.prototype.eq = function(d) {
      return this.cmp(d) === 0;
    }, o.red = function(d) {
      return new V(d);
    }, o.prototype.toRed = function(d) {
      return a(!this.red, "Already a number in reduction context"), a(this.negative === 0, "red works only with positives"), d.convertTo(this)._forceRed(d);
    }, o.prototype.fromRed = function() {
      return a(this.red, "fromRed works only with numbers in reduction context"), this.red.convertFrom(this);
    }, o.prototype._forceRed = function(d) {
      return this.red = d, this;
    }, o.prototype.forceRed = function(d) {
      return a(!this.red, "Already a number in reduction context"), this._forceRed(d);
    }, o.prototype.redAdd = function(d) {
      return a(this.red, "redAdd works only with red numbers"), this.red.add(this, d);
    }, o.prototype.redIAdd = function(d) {
      return a(this.red, "redIAdd works only with red numbers"), this.red.iadd(this, d);
    }, o.prototype.redSub = function(d) {
      return a(this.red, "redSub works only with red numbers"), this.red.sub(this, d);
    }, o.prototype.redISub = function(d) {
      return a(this.red, "redISub works only with red numbers"), this.red.isub(this, d);
    }, o.prototype.redShl = function(d) {
      return a(this.red, "redShl works only with red numbers"), this.red.shl(this, d);
    }, o.prototype.redMul = function(d) {
      return a(this.red, "redMul works only with red numbers"), this.red._verify2(this, d), this.red.mul(this, d);
    }, o.prototype.redIMul = function(d) {
      return a(this.red, "redMul works only with red numbers"), this.red._verify2(this, d), this.red.imul(this, d);
    }, o.prototype.redSqr = function() {
      return a(this.red, "redSqr works only with red numbers"), this.red._verify1(this), this.red.sqr(this);
    }, o.prototype.redISqr = function() {
      return a(this.red, "redISqr works only with red numbers"), this.red._verify1(this), this.red.isqr(this);
    }, o.prototype.redSqrt = function() {
      return a(this.red, "redSqrt works only with red numbers"), this.red._verify1(this), this.red.sqrt(this);
    }, o.prototype.redInvm = function() {
      return a(this.red, "redInvm works only with red numbers"), this.red._verify1(this), this.red.invm(this);
    }, o.prototype.redNeg = function() {
      return a(this.red, "redNeg works only with red numbers"), this.red._verify1(this), this.red.neg(this);
    }, o.prototype.redPow = function(d) {
      return a(this.red && !d.red, "redPow(normalNum)"), this.red._verify1(this), this.red.pow(this, d);
    };
    var se = {
      k256: null,
      p224: null,
      p192: null,
      p25519: null
    };
    function fe(w, d) {
      this.name = w, this.p = new o(d, 16), this.n = this.p.bitLength(), this.k = new o(1).iushln(this.n).isub(this.p), this.tmp = this._tmp();
    }
    fe.prototype._tmp = function() {
      var d = new o(null);
      return d.words = new Array(Math.ceil(this.n / 13)), d;
    }, fe.prototype.ireduce = function(d) {
      var m = d, B;
      do
        this.split(m, this.tmp), m = this.imulK(m), m = m.iadd(this.tmp), B = m.bitLength();
      while (B > this.n);
      var $ = B < this.n ? -1 : m.ucmp(this.p);
      return $ === 0 ? (m.words[0] = 0, m.length = 1) : $ > 0 ? m.isub(this.p) : m.strip !== void 0 ? m.strip() : m._strip(), m;
    }, fe.prototype.split = function(d, m) {
      d.iushrn(this.n, 0, m);
    }, fe.prototype.imulK = function(d) {
      return d.imul(this.k);
    };
    function pe() {
      fe.call(
        this,
        "k256",
        "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f"
      );
    }
    c(pe, fe), pe.prototype.split = function(d, m) {
      for (var B = 4194303, $ = Math.min(d.length, 9), P = 0; P < $; P++)
        m.words[P] = d.words[P];
      if (m.length = $, d.length <= 9) {
        d.words[0] = 0, d.length = 1;
        return;
      }
      var M = d.words[9];
      for (m.words[m.length++] = M & B, P = 10; P < d.length; P++) {
        var v = d.words[P] | 0;
        d.words[P - 10] = (v & B) << 4 | M >>> 22, M = v;
      }
      M >>>= 22, d.words[P - 10] = M, M === 0 && d.length > 10 ? d.length -= 10 : d.length -= 9;
    }, pe.prototype.imulK = function(d) {
      d.words[d.length] = 0, d.words[d.length + 1] = 0, d.length += 2;
      for (var m = 0, B = 0; B < d.length; B++) {
        var $ = d.words[B] | 0;
        m += $ * 977, d.words[B] = m & 67108863, m = $ * 64 + (m / 67108864 | 0);
      }
      return d.words[d.length - 1] === 0 && (d.length--, d.words[d.length - 1] === 0 && d.length--), d;
    };
    function ue() {
      fe.call(
        this,
        "p224",
        "ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001"
      );
    }
    c(ue, fe);
    function ce() {
      fe.call(
        this,
        "p192",
        "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff"
      );
    }
    c(ce, fe);
    function $e() {
      fe.call(
        this,
        "25519",
        "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed"
      );
    }
    c($e, fe), $e.prototype.imulK = function(d) {
      for (var m = 0, B = 0; B < d.length; B++) {
        var $ = (d.words[B] | 0) * 19 + m, P = $ & 67108863;
        $ >>>= 26, d.words[B] = P, m = $;
      }
      return m !== 0 && (d.words[d.length++] = m), d;
    }, o._prime = function(d) {
      if (se[d])
        return se[d];
      var m;
      if (d === "k256")
        m = new pe();
      else if (d === "p224")
        m = new ue();
      else if (d === "p192")
        m = new ce();
      else if (d === "p25519")
        m = new $e();
      else
        throw new Error("Unknown prime " + d);
      return se[d] = m, m;
    };
    function V(w) {
      if (typeof w == "string") {
        var d = o._prime(w);
        this.m = d.p, this.prime = d;
      } else
        a(w.gtn(1), "modulus must be greater than 1"), this.m = w, this.prime = null;
    }
    V.prototype._verify1 = function(d) {
      a(d.negative === 0, "red works only with positives"), a(d.red, "red works only with red numbers");
    }, V.prototype._verify2 = function(d, m) {
      a((d.negative | m.negative) === 0, "red works only with positives"), a(
        d.red && d.red === m.red,
        "red works only with red numbers"
      );
    }, V.prototype.imod = function(d) {
      return this.prime ? this.prime.ireduce(d)._forceRed(this) : (l(d, d.umod(this.m)._forceRed(this)), d);
    }, V.prototype.neg = function(d) {
      return d.isZero() ? d.clone() : this.m.sub(d)._forceRed(this);
    }, V.prototype.add = function(d, m) {
      this._verify2(d, m);
      var B = d.add(m);
      return B.cmp(this.m) >= 0 && B.isub(this.m), B._forceRed(this);
    }, V.prototype.iadd = function(d, m) {
      this._verify2(d, m);
      var B = d.iadd(m);
      return B.cmp(this.m) >= 0 && B.isub(this.m), B;
    }, V.prototype.sub = function(d, m) {
      this._verify2(d, m);
      var B = d.sub(m);
      return B.cmpn(0) < 0 && B.iadd(this.m), B._forceRed(this);
    }, V.prototype.isub = function(d, m) {
      this._verify2(d, m);
      var B = d.isub(m);
      return B.cmpn(0) < 0 && B.iadd(this.m), B;
    }, V.prototype.shl = function(d, m) {
      return this._verify1(d), this.imod(d.ushln(m));
    }, V.prototype.imul = function(d, m) {
      return this._verify2(d, m), this.imod(d.imul(m));
    }, V.prototype.mul = function(d, m) {
      return this._verify2(d, m), this.imod(d.mul(m));
    }, V.prototype.isqr = function(d) {
      return this.imul(d, d.clone());
    }, V.prototype.sqr = function(d) {
      return this.mul(d, d);
    }, V.prototype.sqrt = function(d) {
      if (d.isZero())
        return d.clone();
      var m = this.m.andln(3);
      if (a(m % 2 === 1), m === 3) {
        var B = this.m.add(new o(1)).iushrn(2);
        return this.pow(d, B);
      }
      for (var $ = this.m.subn(1), P = 0; !$.isZero() && $.andln(1) === 0; )
        P++, $.iushrn(1);
      a(!$.isZero());
      var M = new o(1).toRed(this), v = M.redNeg(), A = this.m.subn(1).iushrn(1), y = this.m.bitLength();
      for (y = new o(2 * y * y).toRed(this); this.pow(y, A).cmp(v) !== 0; )
        y.redIAdd(v);
      for (var T = this.pow(y, $), Z = this.pow(d, $.addn(1).iushrn(1)), ie = this.pow(d, $), J = P; ie.cmp(M) !== 0; ) {
        for (var k = ie, D = 0; k.cmp(M) !== 0; D++)
          k = k.redSqr();
        a(D < J);
        var X = this.pow(T, new o(1).iushln(J - D - 1));
        Z = Z.redMul(X), T = X.redSqr(), ie = ie.redMul(T), J = D;
      }
      return Z;
    }, V.prototype.invm = function(d) {
      var m = d._invmp(this.m);
      return m.negative !== 0 ? (m.negative = 0, this.imod(m).redNeg()) : this.imod(m);
    }, V.prototype.pow = function(d, m) {
      if (m.isZero())
        return new o(1).toRed(this);
      if (m.cmpn(1) === 0)
        return d.clone();
      var B = 4, $ = new Array(1 << B);
      $[0] = new o(1).toRed(this), $[1] = d;
      for (var P = 2; P < $.length; P++)
        $[P] = this.mul($[P - 1], d);
      var M = $[0], v = 0, A = 0, y = m.bitLength() % 26;
      for (y === 0 && (y = 26), P = m.length - 1; P >= 0; P--) {
        for (var T = m.words[P], Z = y - 1; Z >= 0; Z--) {
          var ie = T >> Z & 1;
          if (M !== $[0] && (M = this.sqr(M)), ie === 0 && v === 0) {
            A = 0;
            continue;
          }
          v <<= 1, v |= ie, A++, !(A !== B && (P !== 0 || Z !== 0)) && (M = this.mul(M, $[v]), A = 0, v = 0);
        }
        y = 26;
      }
      return M;
    }, V.prototype.convertTo = function(d) {
      var m = d.umod(this.m);
      return m === d ? m.clone() : m;
    }, V.prototype.convertFrom = function(d) {
      var m = d.clone();
      return m.red = null, m;
    }, o.mont = function(d) {
      return new _(d);
    };
    function _(w) {
      V.call(this, w), this.shift = this.m.bitLength(), this.shift % 26 !== 0 && (this.shift += 26 - this.shift % 26), this.r = new o(1).iushln(this.shift), this.r2 = this.imod(this.r.sqr()), this.rinv = this.r._invmp(this.m), this.minv = this.rinv.mul(this.r).isubn(1).div(this.m), this.minv = this.minv.umod(this.r), this.minv = this.r.sub(this.minv);
    }
    c(_, V), _.prototype.convertTo = function(d) {
      return this.imod(d.ushln(this.shift));
    }, _.prototype.convertFrom = function(d) {
      var m = this.imod(d.mul(this.rinv));
      return m.red = null, m;
    }, _.prototype.imul = function(d, m) {
      if (d.isZero() || m.isZero())
        return d.words[0] = 0, d.length = 1, d;
      var B = d.imul(m), $ = B.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m), P = B.isub($).iushrn(this.shift), M = P;
      return P.cmp(this.m) >= 0 ? M = P.isub(this.m) : P.cmpn(0) < 0 && (M = P.iadd(this.m)), M._forceRed(this);
    }, _.prototype.mul = function(d, m) {
      if (d.isZero() || m.isZero())
        return new o(0)._forceRed(this);
      var B = d.mul(m), $ = B.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m), P = B.isub($).iushrn(this.shift), M = P;
      return P.cmp(this.m) >= 0 ? M = P.isub(this.m) : P.cmpn(0) < 0 && (M = P.iadd(this.m)), M._forceRed(this);
    }, _.prototype.invm = function(d) {
      var m = this.imod(d._invmp(this.m).mul(this.r2));
      return m._forceRed(this);
    };
  })(t, commonjsGlobal);
})(bn);
var bnExports = bn.exports, BN$a = bnExports, randomBytes$1 = browserExports;
function blind(t) {
  var e = getr(t), n = e.toRed(BN$a.mont(t.modulus)).redPow(new BN$a(t.publicExponent)).fromRed();
  return { blinder: n, unblinder: e.invm(t.modulus) };
}
function getr(t) {
  var e = t.modulus.byteLength(), n;
  do
    n = new BN$a(randomBytes$1(e));
  while (n.cmp(t.modulus) >= 0 || !n.umod(t.prime1) || !n.umod(t.prime2));
  return n;
}
function crt$2(t, e) {
  var n = blind(e), a = e.modulus.byteLength(), c = new BN$a(t).mul(n.blinder).umod(e.modulus), o = c.toRed(BN$a.mont(e.prime1)), u = c.toRed(BN$a.mont(e.prime2)), h = e.coefficient, p = e.prime1, x = e.prime2, l = o.redPow(e.exponent1).fromRed(), b = u.redPow(e.exponent2).fromRed(), E = l.isub(b).imul(h).umod(p).imul(x);
  return b.iadd(E).imul(n.unblinder).umod(e.modulus).toArrayLike(Buffer$B, "be", a);
}
crt$2.getr = getr;
var browserifyRsa = crt$2, elliptic = {};
const name = "elliptic", version = "6.5.5", description = "EC cryptography", main = "lib/elliptic.js", files = [
  "lib"
], scripts = {
  lint: "eslint lib test",
  "lint:fix": "npm run lint -- --fix",
  unit: "istanbul test _mocha --reporter=spec test/index.js",
  test: "npm run lint && npm run unit",
  version: "grunt dist && git add dist/"
}, repository = {
  type: "git",
  url: "git@github.com:indutny/elliptic"
}, keywords = [
  "EC",
  "Elliptic",
  "curve",
  "Cryptography"
], author = "Fedor Indutny <fedor@indutny.com>", license = "MIT", bugs = {
  url: "https://github.com/indutny/elliptic/issues"
}, homepage = "https://github.com/indutny/elliptic", devDependencies = {
  brfs: "^2.0.2",
  coveralls: "^3.1.0",
  eslint: "^7.6.0",
  grunt: "^1.2.1",
  "grunt-browserify": "^5.3.0",
  "grunt-cli": "^1.3.2",
  "grunt-contrib-connect": "^3.0.0",
  "grunt-contrib-copy": "^1.0.0",
  "grunt-contrib-uglify": "^5.0.0",
  "grunt-mocha-istanbul": "^5.0.2",
  "grunt-saucelabs": "^9.0.1",
  istanbul: "^0.4.5",
  mocha: "^8.0.1"
}, dependencies = {
  "bn.js": "^4.11.9",
  brorand: "^1.1.0",
  "hash.js": "^1.0.0",
  "hmac-drbg": "^1.0.1",
  inherits: "^2.0.4",
  "minimalistic-assert": "^1.0.1",
  "minimalistic-crypto-utils": "^1.0.1"
}, require$$0 = {
  name,
  version,
  description,
  main,
  files,
  scripts,
  repository,
  keywords,
  author,
  license,
  bugs,
  homepage,
  devDependencies,
  dependencies
};
var utils$l = {}, utils$k = {};
(function(t) {
  var e = t;
  function n(o, u) {
    if (Array.isArray(o))
      return o.slice();
    if (!o)
      return [];
    var h = [];
    if (typeof o != "string") {
      for (var p = 0; p < o.length; p++)
        h[p] = o[p] | 0;
      return h;
    }
    if (u === "hex") {
      o = o.replace(/[^a-z0-9]+/ig, ""), o.length % 2 !== 0 && (o = "0" + o);
      for (var p = 0; p < o.length; p += 2)
        h.push(parseInt(o[p] + o[p + 1], 16));
    } else
      for (var p = 0; p < o.length; p++) {
        var x = o.charCodeAt(p), l = x >> 8, b = x & 255;
        l ? h.push(l, b) : h.push(b);
      }
    return h;
  }
  e.toArray = n;
  function a(o) {
    return o.length === 1 ? "0" + o : o;
  }
  e.zero2 = a;
  function c(o) {
    for (var u = "", h = 0; h < o.length; h++)
      u += a(o[h].toString(16));
    return u;
  }
  e.toHex = c, e.encode = function(u, h) {
    return h === "hex" ? c(u) : u;
  };
})(utils$k);
(function(t) {
  var e = t, n = bnExports$1, a = minimalisticAssert, c = utils$k;
  e.assert = a, e.toArray = c.toArray, e.zero2 = c.zero2, e.toHex = c.toHex, e.encode = c.encode;
  function o(l, b, E) {
    var C = new Array(Math.max(l.bitLength(), E) + 1), q;
    for (q = 0; q < C.length; q += 1)
      C[q] = 0;
    var F = 1 << b + 1, z = l.clone();
    for (q = 0; q < C.length; q++) {
      var H, U = z.andln(F - 1);
      z.isOdd() ? (U > (F >> 1) - 1 ? H = (F >> 1) - U : H = U, z.isubn(H)) : H = 0, C[q] = H, z.iushrn(1);
    }
    return C;
  }
  e.getNAF = o;
  function u(l, b) {
    var E = [
      [],
      []
    ];
    l = l.clone(), b = b.clone();
    for (var C = 0, q = 0, F; l.cmpn(-C) > 0 || b.cmpn(-q) > 0; ) {
      var z = l.andln(3) + C & 3, H = b.andln(3) + q & 3;
      z === 3 && (z = -1), H === 3 && (H = -1);
      var U;
      z & 1 ? (F = l.andln(7) + C & 7, (F === 3 || F === 5) && H === 2 ? U = -z : U = z) : U = 0, E[0].push(U);
      var Y;
      H & 1 ? (F = b.andln(7) + q & 7, (F === 3 || F === 5) && z === 2 ? Y = -H : Y = H) : Y = 0, E[1].push(Y), 2 * C === U + 1 && (C = 1 - C), 2 * q === Y + 1 && (q = 1 - q), l.iushrn(1), b.iushrn(1);
    }
    return E;
  }
  e.getJSF = u;
  function h(l, b, E) {
    var C = "_" + b;
    l.prototype[b] = function() {
      return this[C] !== void 0 ? this[C] : this[C] = E.call(this);
    };
  }
  e.cachedProperty = h;
  function p(l) {
    return typeof l == "string" ? e.toArray(l, "hex") : l;
  }
  e.parseBytes = p;
  function x(l) {
    return new n(l, "hex", "le");
  }
  e.intFromLE = x;
})(utils$l);
var curve = {}, BN$9 = bnExports$1, utils$j = utils$l, getNAF = utils$j.getNAF, getJSF = utils$j.getJSF, assert$d = utils$j.assert;
function BaseCurve(t, e) {
  this.type = t, this.p = new BN$9(e.p, 16), this.red = e.prime ? BN$9.red(e.prime) : BN$9.mont(this.p), this.zero = new BN$9(0).toRed(this.red), this.one = new BN$9(1).toRed(this.red), this.two = new BN$9(2).toRed(this.red), this.n = e.n && new BN$9(e.n, 16), this.g = e.g && this.pointFromJSON(e.g, e.gRed), this._wnafT1 = new Array(4), this._wnafT2 = new Array(4), this._wnafT3 = new Array(4), this._wnafT4 = new Array(4), this._bitLength = this.n ? this.n.bitLength() : 0;
  var n = this.n && this.p.div(this.n);
  !n || n.cmpn(100) > 0 ? this.redN = null : (this._maxwellTrick = !0, this.redN = this.n.toRed(this.red));
}
var base$1 = BaseCurve;
BaseCurve.prototype.point = function() {
  throw new Error("Not implemented");
};
BaseCurve.prototype.validate = function() {
  throw new Error("Not implemented");
};
BaseCurve.prototype._fixedNafMul = function(e, n) {
  assert$d(e.precomputed);
  var a = e._getDoubles(), c = getNAF(n, 1, this._bitLength), o = (1 << a.step + 1) - (a.step % 2 === 0 ? 2 : 1);
  o /= 3;
  var u = [], h, p;
  for (h = 0; h < c.length; h += a.step) {
    p = 0;
    for (var x = h + a.step - 1; x >= h; x--)
      p = (p << 1) + c[x];
    u.push(p);
  }
  for (var l = this.jpoint(null, null, null), b = this.jpoint(null, null, null), E = o; E > 0; E--) {
    for (h = 0; h < u.length; h++)
      p = u[h], p === E ? b = b.mixedAdd(a.points[h]) : p === -E && (b = b.mixedAdd(a.points[h].neg()));
    l = l.add(b);
  }
  return l.toP();
};
BaseCurve.prototype._wnafMul = function(e, n) {
  var a = 4, c = e._getNAFPoints(a);
  a = c.wnd;
  for (var o = c.points, u = getNAF(n, a, this._bitLength), h = this.jpoint(null, null, null), p = u.length - 1; p >= 0; p--) {
    for (var x = 0; p >= 0 && u[p] === 0; p--)
      x++;
    if (p >= 0 && x++, h = h.dblp(x), p < 0)
      break;
    var l = u[p];
    assert$d(l !== 0), e.type === "affine" ? l > 0 ? h = h.mixedAdd(o[l - 1 >> 1]) : h = h.mixedAdd(o[-l - 1 >> 1].neg()) : l > 0 ? h = h.add(o[l - 1 >> 1]) : h = h.add(o[-l - 1 >> 1].neg());
  }
  return e.type === "affine" ? h.toP() : h;
};
BaseCurve.prototype._wnafMulAdd = function(e, n, a, c, o) {
  var u = this._wnafT1, h = this._wnafT2, p = this._wnafT3, x = 0, l, b, E;
  for (l = 0; l < c; l++) {
    E = n[l];
    var C = E._getNAFPoints(e);
    u[l] = C.wnd, h[l] = C.points;
  }
  for (l = c - 1; l >= 1; l -= 2) {
    var q = l - 1, F = l;
    if (u[q] !== 1 || u[F] !== 1) {
      p[q] = getNAF(a[q], u[q], this._bitLength), p[F] = getNAF(a[F], u[F], this._bitLength), x = Math.max(p[q].length, x), x = Math.max(p[F].length, x);
      continue;
    }
    var z = [
      n[q],
      /* 1 */
      null,
      /* 3 */
      null,
      /* 5 */
      n[F]
      /* 7 */
    ];
    n[q].y.cmp(n[F].y) === 0 ? (z[1] = n[q].add(n[F]), z[2] = n[q].toJ().mixedAdd(n[F].neg())) : n[q].y.cmp(n[F].y.redNeg()) === 0 ? (z[1] = n[q].toJ().mixedAdd(n[F]), z[2] = n[q].add(n[F].neg())) : (z[1] = n[q].toJ().mixedAdd(n[F]), z[2] = n[q].toJ().mixedAdd(n[F].neg()));
    var H = [
      -3,
      /* -1 -1 */
      -1,
      /* -1 0 */
      -5,
      /* -1 1 */
      -7,
      /* 0 -1 */
      0,
      /* 0 0 */
      7,
      /* 0 1 */
      5,
      /* 1 -1 */
      1,
      /* 1 0 */
      3
      /* 1 1 */
    ], U = getJSF(a[q], a[F]);
    for (x = Math.max(U[0].length, x), p[q] = new Array(x), p[F] = new Array(x), b = 0; b < x; b++) {
      var Y = U[0][b] | 0, ee = U[1][b] | 0;
      p[q][b] = H[(Y + 1) * 3 + (ee + 1)], p[F][b] = 0, h[q] = z;
    }
  }
  var se = this.jpoint(null, null, null), fe = this._wnafT4;
  for (l = x; l >= 0; l--) {
    for (var pe = 0; l >= 0; ) {
      var ue = !0;
      for (b = 0; b < c; b++)
        fe[b] = p[b][l] | 0, fe[b] !== 0 && (ue = !1);
      if (!ue)
        break;
      pe++, l--;
    }
    if (l >= 0 && pe++, se = se.dblp(pe), l < 0)
      break;
    for (b = 0; b < c; b++) {
      var ce = fe[b];
      ce !== 0 && (ce > 0 ? E = h[b][ce - 1 >> 1] : ce < 0 && (E = h[b][-ce - 1 >> 1].neg()), E.type === "affine" ? se = se.mixedAdd(E) : se = se.add(E));
    }
  }
  for (l = 0; l < c; l++)
    h[l] = null;
  return o ? se : se.toP();
};
function BasePoint(t, e) {
  this.curve = t, this.type = e, this.precomputed = null;
}
BaseCurve.BasePoint = BasePoint;
BasePoint.prototype.eq = function() {
  throw new Error("Not implemented");
};
BasePoint.prototype.validate = function() {
  return this.curve.validate(this);
};
BaseCurve.prototype.decodePoint = function(e, n) {
  e = utils$j.toArray(e, n);
  var a = this.p.byteLength();
  if ((e[0] === 4 || e[0] === 6 || e[0] === 7) && e.length - 1 === 2 * a) {
    e[0] === 6 ? assert$d(e[e.length - 1] % 2 === 0) : e[0] === 7 && assert$d(e[e.length - 1] % 2 === 1);
    var c = this.point(
      e.slice(1, 1 + a),
      e.slice(1 + a, 1 + 2 * a)
    );
    return c;
  } else if ((e[0] === 2 || e[0] === 3) && e.length - 1 === a)
    return this.pointFromX(e.slice(1, 1 + a), e[0] === 3);
  throw new Error("Unknown point format");
};
BasePoint.prototype.encodeCompressed = function(e) {
  return this.encode(e, !0);
};
BasePoint.prototype._encode = function(e) {
  var n = this.curve.p.byteLength(), a = this.getX().toArray("be", n);
  return e ? [this.getY().isEven() ? 2 : 3].concat(a) : [4].concat(a, this.getY().toArray("be", n));
};
BasePoint.prototype.encode = function(e, n) {
  return utils$j.encode(this._encode(n), e);
};
BasePoint.prototype.precompute = function(e) {
  if (this.precomputed)
    return this;
  var n = {
    doubles: null,
    naf: null,
    beta: null
  };
  return n.naf = this._getNAFPoints(8), n.doubles = this._getDoubles(4, e), n.beta = this._getBeta(), this.precomputed = n, this;
};
BasePoint.prototype._hasDoubles = function(e) {
  if (!this.precomputed)
    return !1;
  var n = this.precomputed.doubles;
  return n ? n.points.length >= Math.ceil((e.bitLength() + 1) / n.step) : !1;
};
BasePoint.prototype._getDoubles = function(e, n) {
  if (this.precomputed && this.precomputed.doubles)
    return this.precomputed.doubles;
  for (var a = [this], c = this, o = 0; o < n; o += e) {
    for (var u = 0; u < e; u++)
      c = c.dbl();
    a.push(c);
  }
  return {
    step: e,
    points: a
  };
};
BasePoint.prototype._getNAFPoints = function(e) {
  if (this.precomputed && this.precomputed.naf)
    return this.precomputed.naf;
  for (var n = [this], a = (1 << e) - 1, c = a === 1 ? null : this.dbl(), o = 1; o < a; o++)
    n[o] = n[o - 1].add(c);
  return {
    wnd: e,
    points: n
  };
};
BasePoint.prototype._getBeta = function() {
  return null;
};
BasePoint.prototype.dblp = function(e) {
  for (var n = this, a = 0; a < e; a++)
    n = n.dbl();
  return n;
};
var utils$i = utils$l, BN$8 = bnExports$1, inherits$4 = inherits_browserExports, Base$2 = base$1, assert$c = utils$i.assert;
function ShortCurve(t) {
  Base$2.call(this, "short", t), this.a = new BN$8(t.a, 16).toRed(this.red), this.b = new BN$8(t.b, 16).toRed(this.red), this.tinv = this.two.redInvm(), this.zeroA = this.a.fromRed().cmpn(0) === 0, this.threeA = this.a.fromRed().sub(this.p).cmpn(-3) === 0, this.endo = this._getEndomorphism(t), this._endoWnafT1 = new Array(4), this._endoWnafT2 = new Array(4);
}
inherits$4(ShortCurve, Base$2);
var short = ShortCurve;
ShortCurve.prototype._getEndomorphism = function(e) {
  if (!(!this.zeroA || !this.g || !this.n || this.p.modn(3) !== 1)) {
    var n, a;
    if (e.beta)
      n = new BN$8(e.beta, 16).toRed(this.red);
    else {
      var c = this._getEndoRoots(this.p);
      n = c[0].cmp(c[1]) < 0 ? c[0] : c[1], n = n.toRed(this.red);
    }
    if (e.lambda)
      a = new BN$8(e.lambda, 16);
    else {
      var o = this._getEndoRoots(this.n);
      this.g.mul(o[0]).x.cmp(this.g.x.redMul(n)) === 0 ? a = o[0] : (a = o[1], assert$c(this.g.mul(a).x.cmp(this.g.x.redMul(n)) === 0));
    }
    var u;
    return e.basis ? u = e.basis.map(function(h) {
      return {
        a: new BN$8(h.a, 16),
        b: new BN$8(h.b, 16)
      };
    }) : u = this._getEndoBasis(a), {
      beta: n,
      lambda: a,
      basis: u
    };
  }
};
ShortCurve.prototype._getEndoRoots = function(e) {
  var n = e === this.p ? this.red : BN$8.mont(e), a = new BN$8(2).toRed(n).redInvm(), c = a.redNeg(), o = new BN$8(3).toRed(n).redNeg().redSqrt().redMul(a), u = c.redAdd(o).fromRed(), h = c.redSub(o).fromRed();
  return [u, h];
};
ShortCurve.prototype._getEndoBasis = function(e) {
  for (var n = this.n.ushrn(Math.floor(this.n.bitLength() / 2)), a = e, c = this.n.clone(), o = new BN$8(1), u = new BN$8(0), h = new BN$8(0), p = new BN$8(1), x, l, b, E, C, q, F, z = 0, H, U; a.cmpn(0) !== 0; ) {
    var Y = c.div(a);
    H = c.sub(Y.mul(a)), U = h.sub(Y.mul(o));
    var ee = p.sub(Y.mul(u));
    if (!b && H.cmp(n) < 0)
      x = F.neg(), l = o, b = H.neg(), E = U;
    else if (b && ++z === 2)
      break;
    F = H, c = a, a = H, h = o, o = U, p = u, u = ee;
  }
  C = H.neg(), q = U;
  var se = b.sqr().add(E.sqr()), fe = C.sqr().add(q.sqr());
  return fe.cmp(se) >= 0 && (C = x, q = l), b.negative && (b = b.neg(), E = E.neg()), C.negative && (C = C.neg(), q = q.neg()), [
    { a: b, b: E },
    { a: C, b: q }
  ];
};
ShortCurve.prototype._endoSplit = function(e) {
  var n = this.endo.basis, a = n[0], c = n[1], o = c.b.mul(e).divRound(this.n), u = a.b.neg().mul(e).divRound(this.n), h = o.mul(a.a), p = u.mul(c.a), x = o.mul(a.b), l = u.mul(c.b), b = e.sub(h).sub(p), E = x.add(l).neg();
  return { k1: b, k2: E };
};
ShortCurve.prototype.pointFromX = function(e, n) {
  e = new BN$8(e, 16), e.red || (e = e.toRed(this.red));
  var a = e.redSqr().redMul(e).redIAdd(e.redMul(this.a)).redIAdd(this.b), c = a.redSqrt();
  if (c.redSqr().redSub(a).cmp(this.zero) !== 0)
    throw new Error("invalid point");
  var o = c.fromRed().isOdd();
  return (n && !o || !n && o) && (c = c.redNeg()), this.point(e, c);
};
ShortCurve.prototype.validate = function(e) {
  if (e.inf)
    return !0;
  var n = e.x, a = e.y, c = this.a.redMul(n), o = n.redSqr().redMul(n).redIAdd(c).redIAdd(this.b);
  return a.redSqr().redISub(o).cmpn(0) === 0;
};
ShortCurve.prototype._endoWnafMulAdd = function(e, n, a) {
  for (var c = this._endoWnafT1, o = this._endoWnafT2, u = 0; u < e.length; u++) {
    var h = this._endoSplit(n[u]), p = e[u], x = p._getBeta();
    h.k1.negative && (h.k1.ineg(), p = p.neg(!0)), h.k2.negative && (h.k2.ineg(), x = x.neg(!0)), c[u * 2] = p, c[u * 2 + 1] = x, o[u * 2] = h.k1, o[u * 2 + 1] = h.k2;
  }
  for (var l = this._wnafMulAdd(1, c, o, u * 2, a), b = 0; b < u * 2; b++)
    c[b] = null, o[b] = null;
  return l;
};
function Point$2(t, e, n, a) {
  Base$2.BasePoint.call(this, t, "affine"), e === null && n === null ? (this.x = null, this.y = null, this.inf = !0) : (this.x = new BN$8(e, 16), this.y = new BN$8(n, 16), a && (this.x.forceRed(this.curve.red), this.y.forceRed(this.curve.red)), this.x.red || (this.x = this.x.toRed(this.curve.red)), this.y.red || (this.y = this.y.toRed(this.curve.red)), this.inf = !1);
}
inherits$4(Point$2, Base$2.BasePoint);
ShortCurve.prototype.point = function(e, n, a) {
  return new Point$2(this, e, n, a);
};
ShortCurve.prototype.pointFromJSON = function(e, n) {
  return Point$2.fromJSON(this, e, n);
};
Point$2.prototype._getBeta = function() {
  if (this.curve.endo) {
    var e = this.precomputed;
    if (e && e.beta)
      return e.beta;
    var n = this.curve.point(this.x.redMul(this.curve.endo.beta), this.y);
    if (e) {
      var a = this.curve, c = function(o) {
        return a.point(o.x.redMul(a.endo.beta), o.y);
      };
      e.beta = n, n.precomputed = {
        beta: null,
        naf: e.naf && {
          wnd: e.naf.wnd,
          points: e.naf.points.map(c)
        },
        doubles: e.doubles && {
          step: e.doubles.step,
          points: e.doubles.points.map(c)
        }
      };
    }
    return n;
  }
};
Point$2.prototype.toJSON = function() {
  return this.precomputed ? [this.x, this.y, this.precomputed && {
    doubles: this.precomputed.doubles && {
      step: this.precomputed.doubles.step,
      points: this.precomputed.doubles.points.slice(1)
    },
    naf: this.precomputed.naf && {
      wnd: this.precomputed.naf.wnd,
      points: this.precomputed.naf.points.slice(1)
    }
  }] : [this.x, this.y];
};
Point$2.fromJSON = function(e, n, a) {
  typeof n == "string" && (n = JSON.parse(n));
  var c = e.point(n[0], n[1], a);
  if (!n[2])
    return c;
  function o(h) {
    return e.point(h[0], h[1], a);
  }
  var u = n[2];
  return c.precomputed = {
    beta: null,
    doubles: u.doubles && {
      step: u.doubles.step,
      points: [c].concat(u.doubles.points.map(o))
    },
    naf: u.naf && {
      wnd: u.naf.wnd,
      points: [c].concat(u.naf.points.map(o))
    }
  }, c;
};
Point$2.prototype.inspect = function() {
  return this.isInfinity() ? "<EC Point Infinity>" : "<EC Point x: " + this.x.fromRed().toString(16, 2) + " y: " + this.y.fromRed().toString(16, 2) + ">";
};
Point$2.prototype.isInfinity = function() {
  return this.inf;
};
Point$2.prototype.add = function(e) {
  if (this.inf)
    return e;
  if (e.inf)
    return this;
  if (this.eq(e))
    return this.dbl();
  if (this.neg().eq(e))
    return this.curve.point(null, null);
  if (this.x.cmp(e.x) === 0)
    return this.curve.point(null, null);
  var n = this.y.redSub(e.y);
  n.cmpn(0) !== 0 && (n = n.redMul(this.x.redSub(e.x).redInvm()));
  var a = n.redSqr().redISub(this.x).redISub(e.x), c = n.redMul(this.x.redSub(a)).redISub(this.y);
  return this.curve.point(a, c);
};
Point$2.prototype.dbl = function() {
  if (this.inf)
    return this;
  var e = this.y.redAdd(this.y);
  if (e.cmpn(0) === 0)
    return this.curve.point(null, null);
  var n = this.curve.a, a = this.x.redSqr(), c = e.redInvm(), o = a.redAdd(a).redIAdd(a).redIAdd(n).redMul(c), u = o.redSqr().redISub(this.x.redAdd(this.x)), h = o.redMul(this.x.redSub(u)).redISub(this.y);
  return this.curve.point(u, h);
};
Point$2.prototype.getX = function() {
  return this.x.fromRed();
};
Point$2.prototype.getY = function() {
  return this.y.fromRed();
};
Point$2.prototype.mul = function(e) {
  return e = new BN$8(e, 16), this.isInfinity() ? this : this._hasDoubles(e) ? this.curve._fixedNafMul(this, e) : this.curve.endo ? this.curve._endoWnafMulAdd([this], [e]) : this.curve._wnafMul(this, e);
};
Point$2.prototype.mulAdd = function(e, n, a) {
  var c = [this, n], o = [e, a];
  return this.curve.endo ? this.curve._endoWnafMulAdd(c, o) : this.curve._wnafMulAdd(1, c, o, 2);
};
Point$2.prototype.jmulAdd = function(e, n, a) {
  var c = [this, n], o = [e, a];
  return this.curve.endo ? this.curve._endoWnafMulAdd(c, o, !0) : this.curve._wnafMulAdd(1, c, o, 2, !0);
};
Point$2.prototype.eq = function(e) {
  return this === e || this.inf === e.inf && (this.inf || this.x.cmp(e.x) === 0 && this.y.cmp(e.y) === 0);
};
Point$2.prototype.neg = function(e) {
  if (this.inf)
    return this;
  var n = this.curve.point(this.x, this.y.redNeg());
  if (e && this.precomputed) {
    var a = this.precomputed, c = function(o) {
      return o.neg();
    };
    n.precomputed = {
      naf: a.naf && {
        wnd: a.naf.wnd,
        points: a.naf.points.map(c)
      },
      doubles: a.doubles && {
        step: a.doubles.step,
        points: a.doubles.points.map(c)
      }
    };
  }
  return n;
};
Point$2.prototype.toJ = function() {
  if (this.inf)
    return this.curve.jpoint(null, null, null);
  var e = this.curve.jpoint(this.x, this.y, this.curve.one);
  return e;
};
function JPoint(t, e, n, a) {
  Base$2.BasePoint.call(this, t, "jacobian"), e === null && n === null && a === null ? (this.x = this.curve.one, this.y = this.curve.one, this.z = new BN$8(0)) : (this.x = new BN$8(e, 16), this.y = new BN$8(n, 16), this.z = new BN$8(a, 16)), this.x.red || (this.x = this.x.toRed(this.curve.red)), this.y.red || (this.y = this.y.toRed(this.curve.red)), this.z.red || (this.z = this.z.toRed(this.curve.red)), this.zOne = this.z === this.curve.one;
}
inherits$4(JPoint, Base$2.BasePoint);
ShortCurve.prototype.jpoint = function(e, n, a) {
  return new JPoint(this, e, n, a);
};
JPoint.prototype.toP = function() {
  if (this.isInfinity())
    return this.curve.point(null, null);
  var e = this.z.redInvm(), n = e.redSqr(), a = this.x.redMul(n), c = this.y.redMul(n).redMul(e);
  return this.curve.point(a, c);
};
JPoint.prototype.neg = function() {
  return this.curve.jpoint(this.x, this.y.redNeg(), this.z);
};
JPoint.prototype.add = function(e) {
  if (this.isInfinity())
    return e;
  if (e.isInfinity())
    return this;
  var n = e.z.redSqr(), a = this.z.redSqr(), c = this.x.redMul(n), o = e.x.redMul(a), u = this.y.redMul(n.redMul(e.z)), h = e.y.redMul(a.redMul(this.z)), p = c.redSub(o), x = u.redSub(h);
  if (p.cmpn(0) === 0)
    return x.cmpn(0) !== 0 ? this.curve.jpoint(null, null, null) : this.dbl();
  var l = p.redSqr(), b = l.redMul(p), E = c.redMul(l), C = x.redSqr().redIAdd(b).redISub(E).redISub(E), q = x.redMul(E.redISub(C)).redISub(u.redMul(b)), F = this.z.redMul(e.z).redMul(p);
  return this.curve.jpoint(C, q, F);
};
JPoint.prototype.mixedAdd = function(e) {
  if (this.isInfinity())
    return e.toJ();
  if (e.isInfinity())
    return this;
  var n = this.z.redSqr(), a = this.x, c = e.x.redMul(n), o = this.y, u = e.y.redMul(n).redMul(this.z), h = a.redSub(c), p = o.redSub(u);
  if (h.cmpn(0) === 0)
    return p.cmpn(0) !== 0 ? this.curve.jpoint(null, null, null) : this.dbl();
  var x = h.redSqr(), l = x.redMul(h), b = a.redMul(x), E = p.redSqr().redIAdd(l).redISub(b).redISub(b), C = p.redMul(b.redISub(E)).redISub(o.redMul(l)), q = this.z.redMul(h);
  return this.curve.jpoint(E, C, q);
};
JPoint.prototype.dblp = function(e) {
  if (e === 0)
    return this;
  if (this.isInfinity())
    return this;
  if (!e)
    return this.dbl();
  var n;
  if (this.curve.zeroA || this.curve.threeA) {
    var a = this;
    for (n = 0; n < e; n++)
      a = a.dbl();
    return a;
  }
  var c = this.curve.a, o = this.curve.tinv, u = this.x, h = this.y, p = this.z, x = p.redSqr().redSqr(), l = h.redAdd(h);
  for (n = 0; n < e; n++) {
    var b = u.redSqr(), E = l.redSqr(), C = E.redSqr(), q = b.redAdd(b).redIAdd(b).redIAdd(c.redMul(x)), F = u.redMul(E), z = q.redSqr().redISub(F.redAdd(F)), H = F.redISub(z), U = q.redMul(H);
    U = U.redIAdd(U).redISub(C);
    var Y = l.redMul(p);
    n + 1 < e && (x = x.redMul(C)), u = z, p = Y, l = U;
  }
  return this.curve.jpoint(u, l.redMul(o), p);
};
JPoint.prototype.dbl = function() {
  return this.isInfinity() ? this : this.curve.zeroA ? this._zeroDbl() : this.curve.threeA ? this._threeDbl() : this._dbl();
};
JPoint.prototype._zeroDbl = function() {
  var e, n, a;
  if (this.zOne) {
    var c = this.x.redSqr(), o = this.y.redSqr(), u = o.redSqr(), h = this.x.redAdd(o).redSqr().redISub(c).redISub(u);
    h = h.redIAdd(h);
    var p = c.redAdd(c).redIAdd(c), x = p.redSqr().redISub(h).redISub(h), l = u.redIAdd(u);
    l = l.redIAdd(l), l = l.redIAdd(l), e = x, n = p.redMul(h.redISub(x)).redISub(l), a = this.y.redAdd(this.y);
  } else {
    var b = this.x.redSqr(), E = this.y.redSqr(), C = E.redSqr(), q = this.x.redAdd(E).redSqr().redISub(b).redISub(C);
    q = q.redIAdd(q);
    var F = b.redAdd(b).redIAdd(b), z = F.redSqr(), H = C.redIAdd(C);
    H = H.redIAdd(H), H = H.redIAdd(H), e = z.redISub(q).redISub(q), n = F.redMul(q.redISub(e)).redISub(H), a = this.y.redMul(this.z), a = a.redIAdd(a);
  }
  return this.curve.jpoint(e, n, a);
};
JPoint.prototype._threeDbl = function() {
  var e, n, a;
  if (this.zOne) {
    var c = this.x.redSqr(), o = this.y.redSqr(), u = o.redSqr(), h = this.x.redAdd(o).redSqr().redISub(c).redISub(u);
    h = h.redIAdd(h);
    var p = c.redAdd(c).redIAdd(c).redIAdd(this.curve.a), x = p.redSqr().redISub(h).redISub(h);
    e = x;
    var l = u.redIAdd(u);
    l = l.redIAdd(l), l = l.redIAdd(l), n = p.redMul(h.redISub(x)).redISub(l), a = this.y.redAdd(this.y);
  } else {
    var b = this.z.redSqr(), E = this.y.redSqr(), C = this.x.redMul(E), q = this.x.redSub(b).redMul(this.x.redAdd(b));
    q = q.redAdd(q).redIAdd(q);
    var F = C.redIAdd(C);
    F = F.redIAdd(F);
    var z = F.redAdd(F);
    e = q.redSqr().redISub(z), a = this.y.redAdd(this.z).redSqr().redISub(E).redISub(b);
    var H = E.redSqr();
    H = H.redIAdd(H), H = H.redIAdd(H), H = H.redIAdd(H), n = q.redMul(F.redISub(e)).redISub(H);
  }
  return this.curve.jpoint(e, n, a);
};
JPoint.prototype._dbl = function() {
  var e = this.curve.a, n = this.x, a = this.y, c = this.z, o = c.redSqr().redSqr(), u = n.redSqr(), h = a.redSqr(), p = u.redAdd(u).redIAdd(u).redIAdd(e.redMul(o)), x = n.redAdd(n);
  x = x.redIAdd(x);
  var l = x.redMul(h), b = p.redSqr().redISub(l.redAdd(l)), E = l.redISub(b), C = h.redSqr();
  C = C.redIAdd(C), C = C.redIAdd(C), C = C.redIAdd(C);
  var q = p.redMul(E).redISub(C), F = a.redAdd(a).redMul(c);
  return this.curve.jpoint(b, q, F);
};
JPoint.prototype.trpl = function() {
  if (!this.curve.zeroA)
    return this.dbl().add(this);
  var e = this.x.redSqr(), n = this.y.redSqr(), a = this.z.redSqr(), c = n.redSqr(), o = e.redAdd(e).redIAdd(e), u = o.redSqr(), h = this.x.redAdd(n).redSqr().redISub(e).redISub(c);
  h = h.redIAdd(h), h = h.redAdd(h).redIAdd(h), h = h.redISub(u);
  var p = h.redSqr(), x = c.redIAdd(c);
  x = x.redIAdd(x), x = x.redIAdd(x), x = x.redIAdd(x);
  var l = o.redIAdd(h).redSqr().redISub(u).redISub(p).redISub(x), b = n.redMul(l);
  b = b.redIAdd(b), b = b.redIAdd(b);
  var E = this.x.redMul(p).redISub(b);
  E = E.redIAdd(E), E = E.redIAdd(E);
  var C = this.y.redMul(l.redMul(x.redISub(l)).redISub(h.redMul(p)));
  C = C.redIAdd(C), C = C.redIAdd(C), C = C.redIAdd(C);
  var q = this.z.redAdd(h).redSqr().redISub(a).redISub(p);
  return this.curve.jpoint(E, C, q);
};
JPoint.prototype.mul = function(e, n) {
  return e = new BN$8(e, n), this.curve._wnafMul(this, e);
};
JPoint.prototype.eq = function(e) {
  if (e.type === "affine")
    return this.eq(e.toJ());
  if (this === e)
    return !0;
  var n = this.z.redSqr(), a = e.z.redSqr();
  if (this.x.redMul(a).redISub(e.x.redMul(n)).cmpn(0) !== 0)
    return !1;
  var c = n.redMul(this.z), o = a.redMul(e.z);
  return this.y.redMul(o).redISub(e.y.redMul(c)).cmpn(0) === 0;
};
JPoint.prototype.eqXToP = function(e) {
  var n = this.z.redSqr(), a = e.toRed(this.curve.red).redMul(n);
  if (this.x.cmp(a) === 0)
    return !0;
  for (var c = e.clone(), o = this.curve.redN.redMul(n); ; ) {
    if (c.iadd(this.curve.n), c.cmp(this.curve.p) >= 0)
      return !1;
    if (a.redIAdd(o), this.x.cmp(a) === 0)
      return !0;
  }
};
JPoint.prototype.inspect = function() {
  return this.isInfinity() ? "<EC JPoint Infinity>" : "<EC JPoint x: " + this.x.toString(16, 2) + " y: " + this.y.toString(16, 2) + " z: " + this.z.toString(16, 2) + ">";
};
JPoint.prototype.isInfinity = function() {
  return this.z.cmpn(0) === 0;
};
var BN$7 = bnExports$1, inherits$3 = inherits_browserExports, Base$1 = base$1, utils$h = utils$l;
function MontCurve(t) {
  Base$1.call(this, "mont", t), this.a = new BN$7(t.a, 16).toRed(this.red), this.b = new BN$7(t.b, 16).toRed(this.red), this.i4 = new BN$7(4).toRed(this.red).redInvm(), this.two = new BN$7(2).toRed(this.red), this.a24 = this.i4.redMul(this.a.redAdd(this.two));
}
inherits$3(MontCurve, Base$1);
var mont = MontCurve;
MontCurve.prototype.validate = function(e) {
  var n = e.normalize().x, a = n.redSqr(), c = a.redMul(n).redAdd(a.redMul(this.a)).redAdd(n), o = c.redSqrt();
  return o.redSqr().cmp(c) === 0;
};
function Point$1(t, e, n) {
  Base$1.BasePoint.call(this, t, "projective"), e === null && n === null ? (this.x = this.curve.one, this.z = this.curve.zero) : (this.x = new BN$7(e, 16), this.z = new BN$7(n, 16), this.x.red || (this.x = this.x.toRed(this.curve.red)), this.z.red || (this.z = this.z.toRed(this.curve.red)));
}
inherits$3(Point$1, Base$1.BasePoint);
MontCurve.prototype.decodePoint = function(e, n) {
  return this.point(utils$h.toArray(e, n), 1);
};
MontCurve.prototype.point = function(e, n) {
  return new Point$1(this, e, n);
};
MontCurve.prototype.pointFromJSON = function(e) {
  return Point$1.fromJSON(this, e);
};
Point$1.prototype.precompute = function() {
};
Point$1.prototype._encode = function() {
  return this.getX().toArray("be", this.curve.p.byteLength());
};
Point$1.fromJSON = function(e, n) {
  return new Point$1(e, n[0], n[1] || e.one);
};
Point$1.prototype.inspect = function() {
  return this.isInfinity() ? "<EC Point Infinity>" : "<EC Point x: " + this.x.fromRed().toString(16, 2) + " z: " + this.z.fromRed().toString(16, 2) + ">";
};
Point$1.prototype.isInfinity = function() {
  return this.z.cmpn(0) === 0;
};
Point$1.prototype.dbl = function() {
  var e = this.x.redAdd(this.z), n = e.redSqr(), a = this.x.redSub(this.z), c = a.redSqr(), o = n.redSub(c), u = n.redMul(c), h = o.redMul(c.redAdd(this.curve.a24.redMul(o)));
  return this.curve.point(u, h);
};
Point$1.prototype.add = function() {
  throw new Error("Not supported on Montgomery curve");
};
Point$1.prototype.diffAdd = function(e, n) {
  var a = this.x.redAdd(this.z), c = this.x.redSub(this.z), o = e.x.redAdd(e.z), u = e.x.redSub(e.z), h = u.redMul(a), p = o.redMul(c), x = n.z.redMul(h.redAdd(p).redSqr()), l = n.x.redMul(h.redISub(p).redSqr());
  return this.curve.point(x, l);
};
Point$1.prototype.mul = function(e) {
  for (var n = e.clone(), a = this, c = this.curve.point(null, null), o = this, u = []; n.cmpn(0) !== 0; n.iushrn(1))
    u.push(n.andln(1));
  for (var h = u.length - 1; h >= 0; h--)
    u[h] === 0 ? (a = a.diffAdd(c, o), c = c.dbl()) : (c = a.diffAdd(c, o), a = a.dbl());
  return c;
};
Point$1.prototype.mulAdd = function() {
  throw new Error("Not supported on Montgomery curve");
};
Point$1.prototype.jumlAdd = function() {
  throw new Error("Not supported on Montgomery curve");
};
Point$1.prototype.eq = function(e) {
  return this.getX().cmp(e.getX()) === 0;
};
Point$1.prototype.normalize = function() {
  return this.x = this.x.redMul(this.z.redInvm()), this.z = this.curve.one, this;
};
Point$1.prototype.getX = function() {
  return this.normalize(), this.x.fromRed();
};
var utils$g = utils$l, BN$6 = bnExports$1, inherits$2 = inherits_browserExports, Base = base$1, assert$b = utils$g.assert;
function EdwardsCurve(t) {
  this.twisted = (t.a | 0) !== 1, this.mOneA = this.twisted && (t.a | 0) === -1, this.extended = this.mOneA, Base.call(this, "edwards", t), this.a = new BN$6(t.a, 16).umod(this.red.m), this.a = this.a.toRed(this.red), this.c = new BN$6(t.c, 16).toRed(this.red), this.c2 = this.c.redSqr(), this.d = new BN$6(t.d, 16).toRed(this.red), this.dd = this.d.redAdd(this.d), assert$b(!this.twisted || this.c.fromRed().cmpn(1) === 0), this.oneC = (t.c | 0) === 1;
}
inherits$2(EdwardsCurve, Base);
var edwards = EdwardsCurve;
EdwardsCurve.prototype._mulA = function(e) {
  return this.mOneA ? e.redNeg() : this.a.redMul(e);
};
EdwardsCurve.prototype._mulC = function(e) {
  return this.oneC ? e : this.c.redMul(e);
};
EdwardsCurve.prototype.jpoint = function(e, n, a, c) {
  return this.point(e, n, a, c);
};
EdwardsCurve.prototype.pointFromX = function(e, n) {
  e = new BN$6(e, 16), e.red || (e = e.toRed(this.red));
  var a = e.redSqr(), c = this.c2.redSub(this.a.redMul(a)), o = this.one.redSub(this.c2.redMul(this.d).redMul(a)), u = c.redMul(o.redInvm()), h = u.redSqrt();
  if (h.redSqr().redSub(u).cmp(this.zero) !== 0)
    throw new Error("invalid point");
  var p = h.fromRed().isOdd();
  return (n && !p || !n && p) && (h = h.redNeg()), this.point(e, h);
};
EdwardsCurve.prototype.pointFromY = function(e, n) {
  e = new BN$6(e, 16), e.red || (e = e.toRed(this.red));
  var a = e.redSqr(), c = a.redSub(this.c2), o = a.redMul(this.d).redMul(this.c2).redSub(this.a), u = c.redMul(o.redInvm());
  if (u.cmp(this.zero) === 0) {
    if (n)
      throw new Error("invalid point");
    return this.point(this.zero, e);
  }
  var h = u.redSqrt();
  if (h.redSqr().redSub(u).cmp(this.zero) !== 0)
    throw new Error("invalid point");
  return h.fromRed().isOdd() !== n && (h = h.redNeg()), this.point(h, e);
};
EdwardsCurve.prototype.validate = function(e) {
  if (e.isInfinity())
    return !0;
  e.normalize();
  var n = e.x.redSqr(), a = e.y.redSqr(), c = n.redMul(this.a).redAdd(a), o = this.c2.redMul(this.one.redAdd(this.d.redMul(n).redMul(a)));
  return c.cmp(o) === 0;
};
function Point(t, e, n, a, c) {
  Base.BasePoint.call(this, t, "projective"), e === null && n === null && a === null ? (this.x = this.curve.zero, this.y = this.curve.one, this.z = this.curve.one, this.t = this.curve.zero, this.zOne = !0) : (this.x = new BN$6(e, 16), this.y = new BN$6(n, 16), this.z = a ? new BN$6(a, 16) : this.curve.one, this.t = c && new BN$6(c, 16), this.x.red || (this.x = this.x.toRed(this.curve.red)), this.y.red || (this.y = this.y.toRed(this.curve.red)), this.z.red || (this.z = this.z.toRed(this.curve.red)), this.t && !this.t.red && (this.t = this.t.toRed(this.curve.red)), this.zOne = this.z === this.curve.one, this.curve.extended && !this.t && (this.t = this.x.redMul(this.y), this.zOne || (this.t = this.t.redMul(this.z.redInvm()))));
}
inherits$2(Point, Base.BasePoint);
EdwardsCurve.prototype.pointFromJSON = function(e) {
  return Point.fromJSON(this, e);
};
EdwardsCurve.prototype.point = function(e, n, a, c) {
  return new Point(this, e, n, a, c);
};
Point.fromJSON = function(e, n) {
  return new Point(e, n[0], n[1], n[2]);
};
Point.prototype.inspect = function() {
  return this.isInfinity() ? "<EC Point Infinity>" : "<EC Point x: " + this.x.fromRed().toString(16, 2) + " y: " + this.y.fromRed().toString(16, 2) + " z: " + this.z.fromRed().toString(16, 2) + ">";
};
Point.prototype.isInfinity = function() {
  return this.x.cmpn(0) === 0 && (this.y.cmp(this.z) === 0 || this.zOne && this.y.cmp(this.curve.c) === 0);
};
Point.prototype._extDbl = function() {
  var e = this.x.redSqr(), n = this.y.redSqr(), a = this.z.redSqr();
  a = a.redIAdd(a);
  var c = this.curve._mulA(e), o = this.x.redAdd(this.y).redSqr().redISub(e).redISub(n), u = c.redAdd(n), h = u.redSub(a), p = c.redSub(n), x = o.redMul(h), l = u.redMul(p), b = o.redMul(p), E = h.redMul(u);
  return this.curve.point(x, l, E, b);
};
Point.prototype._projDbl = function() {
  var e = this.x.redAdd(this.y).redSqr(), n = this.x.redSqr(), a = this.y.redSqr(), c, o, u, h, p, x;
  if (this.curve.twisted) {
    h = this.curve._mulA(n);
    var l = h.redAdd(a);
    this.zOne ? (c = e.redSub(n).redSub(a).redMul(l.redSub(this.curve.two)), o = l.redMul(h.redSub(a)), u = l.redSqr().redSub(l).redSub(l)) : (p = this.z.redSqr(), x = l.redSub(p).redISub(p), c = e.redSub(n).redISub(a).redMul(x), o = l.redMul(h.redSub(a)), u = l.redMul(x));
  } else
    h = n.redAdd(a), p = this.curve._mulC(this.z).redSqr(), x = h.redSub(p).redSub(p), c = this.curve._mulC(e.redISub(h)).redMul(x), o = this.curve._mulC(h).redMul(n.redISub(a)), u = h.redMul(x);
  return this.curve.point(c, o, u);
};
Point.prototype.dbl = function() {
  return this.isInfinity() ? this : this.curve.extended ? this._extDbl() : this._projDbl();
};
Point.prototype._extAdd = function(e) {
  var n = this.y.redSub(this.x).redMul(e.y.redSub(e.x)), a = this.y.redAdd(this.x).redMul(e.y.redAdd(e.x)), c = this.t.redMul(this.curve.dd).redMul(e.t), o = this.z.redMul(e.z.redAdd(e.z)), u = a.redSub(n), h = o.redSub(c), p = o.redAdd(c), x = a.redAdd(n), l = u.redMul(h), b = p.redMul(x), E = u.redMul(x), C = h.redMul(p);
  return this.curve.point(l, b, C, E);
};
Point.prototype._projAdd = function(e) {
  var n = this.z.redMul(e.z), a = n.redSqr(), c = this.x.redMul(e.x), o = this.y.redMul(e.y), u = this.curve.d.redMul(c).redMul(o), h = a.redSub(u), p = a.redAdd(u), x = this.x.redAdd(this.y).redMul(e.x.redAdd(e.y)).redISub(c).redISub(o), l = n.redMul(h).redMul(x), b, E;
  return this.curve.twisted ? (b = n.redMul(p).redMul(o.redSub(this.curve._mulA(c))), E = h.redMul(p)) : (b = n.redMul(p).redMul(o.redSub(c)), E = this.curve._mulC(h).redMul(p)), this.curve.point(l, b, E);
};
Point.prototype.add = function(e) {
  return this.isInfinity() ? e : e.isInfinity() ? this : this.curve.extended ? this._extAdd(e) : this._projAdd(e);
};
Point.prototype.mul = function(e) {
  return this._hasDoubles(e) ? this.curve._fixedNafMul(this, e) : this.curve._wnafMul(this, e);
};
Point.prototype.mulAdd = function(e, n, a) {
  return this.curve._wnafMulAdd(1, [this, n], [e, a], 2, !1);
};
Point.prototype.jmulAdd = function(e, n, a) {
  return this.curve._wnafMulAdd(1, [this, n], [e, a], 2, !0);
};
Point.prototype.normalize = function() {
  if (this.zOne)
    return this;
  var e = this.z.redInvm();
  return this.x = this.x.redMul(e), this.y = this.y.redMul(e), this.t && (this.t = this.t.redMul(e)), this.z = this.curve.one, this.zOne = !0, this;
};
Point.prototype.neg = function() {
  return this.curve.point(
    this.x.redNeg(),
    this.y,
    this.z,
    this.t && this.t.redNeg()
  );
};
Point.prototype.getX = function() {
  return this.normalize(), this.x.fromRed();
};
Point.prototype.getY = function() {
  return this.normalize(), this.y.fromRed();
};
Point.prototype.eq = function(e) {
  return this === e || this.getX().cmp(e.getX()) === 0 && this.getY().cmp(e.getY()) === 0;
};
Point.prototype.eqXToP = function(e) {
  var n = e.toRed(this.curve.red).redMul(this.z);
  if (this.x.cmp(n) === 0)
    return !0;
  for (var a = e.clone(), c = this.curve.redN.redMul(this.z); ; ) {
    if (a.iadd(this.curve.n), a.cmp(this.curve.p) >= 0)
      return !1;
    if (n.redIAdd(c), this.x.cmp(n) === 0)
      return !0;
  }
};
Point.prototype.toP = Point.prototype.normalize;
Point.prototype.mixedAdd = Point.prototype.add;
(function(t) {
  var e = t;
  e.base = base$1, e.short = short, e.mont = mont, e.edwards = edwards;
})(curve);
var curves$1 = {}, hash$2 = {}, utils$f = {}, assert$a = minimalisticAssert, inherits$1 = inherits_browserExports;
utils$f.inherits = inherits$1;
function isSurrogatePair(t, e) {
  return (t.charCodeAt(e) & 64512) !== 55296 || e < 0 || e + 1 >= t.length ? !1 : (t.charCodeAt(e + 1) & 64512) === 56320;
}
function toArray(t, e) {
  if (Array.isArray(t))
    return t.slice();
  if (!t)
    return [];
  var n = [];
  if (typeof t == "string")
    if (e) {
      if (e === "hex")
        for (t = t.replace(/[^a-z0-9]+/ig, ""), t.length % 2 !== 0 && (t = "0" + t), c = 0; c < t.length; c += 2)
          n.push(parseInt(t[c] + t[c + 1], 16));
    } else
      for (var a = 0, c = 0; c < t.length; c++) {
        var o = t.charCodeAt(c);
        o < 128 ? n[a++] = o : o < 2048 ? (n[a++] = o >> 6 | 192, n[a++] = o & 63 | 128) : isSurrogatePair(t, c) ? (o = 65536 + ((o & 1023) << 10) + (t.charCodeAt(++c) & 1023), n[a++] = o >> 18 | 240, n[a++] = o >> 12 & 63 | 128, n[a++] = o >> 6 & 63 | 128, n[a++] = o & 63 | 128) : (n[a++] = o >> 12 | 224, n[a++] = o >> 6 & 63 | 128, n[a++] = o & 63 | 128);
      }
  else
    for (c = 0; c < t.length; c++)
      n[c] = t[c] | 0;
  return n;
}
utils$f.toArray = toArray;
function toHex(t) {
  for (var e = "", n = 0; n < t.length; n++)
    e += zero2(t[n].toString(16));
  return e;
}
utils$f.toHex = toHex;
function htonl(t) {
  var e = t >>> 24 | t >>> 8 & 65280 | t << 8 & 16711680 | (t & 255) << 24;
  return e >>> 0;
}
utils$f.htonl = htonl;
function toHex32(t, e) {
  for (var n = "", a = 0; a < t.length; a++) {
    var c = t[a];
    e === "little" && (c = htonl(c)), n += zero8(c.toString(16));
  }
  return n;
}
utils$f.toHex32 = toHex32;
function zero2(t) {
  return t.length === 1 ? "0" + t : t;
}
utils$f.zero2 = zero2;
function zero8(t) {
  return t.length === 7 ? "0" + t : t.length === 6 ? "00" + t : t.length === 5 ? "000" + t : t.length === 4 ? "0000" + t : t.length === 3 ? "00000" + t : t.length === 2 ? "000000" + t : t.length === 1 ? "0000000" + t : t;
}
utils$f.zero8 = zero8;
function join32(t, e, n, a) {
  var c = n - e;
  assert$a(c % 4 === 0);
  for (var o = new Array(c / 4), u = 0, h = e; u < o.length; u++, h += 4) {
    var p;
    a === "big" ? p = t[h] << 24 | t[h + 1] << 16 | t[h + 2] << 8 | t[h + 3] : p = t[h + 3] << 24 | t[h + 2] << 16 | t[h + 1] << 8 | t[h], o[u] = p >>> 0;
  }
  return o;
}
utils$f.join32 = join32;
function split32(t, e) {
  for (var n = new Array(t.length * 4), a = 0, c = 0; a < t.length; a++, c += 4) {
    var o = t[a];
    e === "big" ? (n[c] = o >>> 24, n[c + 1] = o >>> 16 & 255, n[c + 2] = o >>> 8 & 255, n[c + 3] = o & 255) : (n[c + 3] = o >>> 24, n[c + 2] = o >>> 16 & 255, n[c + 1] = o >>> 8 & 255, n[c] = o & 255);
  }
  return n;
}
utils$f.split32 = split32;
function rotr32$1(t, e) {
  return t >>> e | t << 32 - e;
}
utils$f.rotr32 = rotr32$1;
function rotl32$2(t, e) {
  return t << e | t >>> 32 - e;
}
utils$f.rotl32 = rotl32$2;
function sum32$3(t, e) {
  return t + e >>> 0;
}
utils$f.sum32 = sum32$3;
function sum32_3$1(t, e, n) {
  return t + e + n >>> 0;
}
utils$f.sum32_3 = sum32_3$1;
function sum32_4$2(t, e, n, a) {
  return t + e + n + a >>> 0;
}
utils$f.sum32_4 = sum32_4$2;
function sum32_5$2(t, e, n, a, c) {
  return t + e + n + a + c >>> 0;
}
utils$f.sum32_5 = sum32_5$2;
function sum64$1(t, e, n, a) {
  var c = t[e], o = t[e + 1], u = a + o >>> 0, h = (u < a ? 1 : 0) + n + c;
  t[e] = h >>> 0, t[e + 1] = u;
}
utils$f.sum64 = sum64$1;
function sum64_hi$1(t, e, n, a) {
  var c = e + a >>> 0, o = (c < e ? 1 : 0) + t + n;
  return o >>> 0;
}
utils$f.sum64_hi = sum64_hi$1;
function sum64_lo$1(t, e, n, a) {
  var c = e + a;
  return c >>> 0;
}
utils$f.sum64_lo = sum64_lo$1;
function sum64_4_hi$1(t, e, n, a, c, o, u, h) {
  var p = 0, x = e;
  x = x + a >>> 0, p += x < e ? 1 : 0, x = x + o >>> 0, p += x < o ? 1 : 0, x = x + h >>> 0, p += x < h ? 1 : 0;
  var l = t + n + c + u + p;
  return l >>> 0;
}
utils$f.sum64_4_hi = sum64_4_hi$1;
function sum64_4_lo$1(t, e, n, a, c, o, u, h) {
  var p = e + a + o + h;
  return p >>> 0;
}
utils$f.sum64_4_lo = sum64_4_lo$1;
function sum64_5_hi$1(t, e, n, a, c, o, u, h, p, x) {
  var l = 0, b = e;
  b = b + a >>> 0, l += b < e ? 1 : 0, b = b + o >>> 0, l += b < o ? 1 : 0, b = b + h >>> 0, l += b < h ? 1 : 0, b = b + x >>> 0, l += b < x ? 1 : 0;
  var E = t + n + c + u + p + l;
  return E >>> 0;
}
utils$f.sum64_5_hi = sum64_5_hi$1;
function sum64_5_lo$1(t, e, n, a, c, o, u, h, p, x) {
  var l = e + a + o + h + x;
  return l >>> 0;
}
utils$f.sum64_5_lo = sum64_5_lo$1;
function rotr64_hi$1(t, e, n) {
  var a = e << 32 - n | t >>> n;
  return a >>> 0;
}
utils$f.rotr64_hi = rotr64_hi$1;
function rotr64_lo$1(t, e, n) {
  var a = t << 32 - n | e >>> n;
  return a >>> 0;
}
utils$f.rotr64_lo = rotr64_lo$1;
function shr64_hi$1(t, e, n) {
  return t >>> n;
}
utils$f.shr64_hi = shr64_hi$1;
function shr64_lo$1(t, e, n) {
  var a = t << 32 - n | e >>> n;
  return a >>> 0;
}
utils$f.shr64_lo = shr64_lo$1;
var common$5 = {}, utils$e = utils$f, assert$9 = minimalisticAssert;
function BlockHash$4() {
  this.pending = null, this.pendingTotal = 0, this.blockSize = this.constructor.blockSize, this.outSize = this.constructor.outSize, this.hmacStrength = this.constructor.hmacStrength, this.padLength = this.constructor.padLength / 8, this.endian = "big", this._delta8 = this.blockSize / 8, this._delta32 = this.blockSize / 32;
}
common$5.BlockHash = BlockHash$4;
BlockHash$4.prototype.update = function(e, n) {
  if (e = utils$e.toArray(e, n), this.pending ? this.pending = this.pending.concat(e) : this.pending = e, this.pendingTotal += e.length, this.pending.length >= this._delta8) {
    e = this.pending;
    var a = e.length % this._delta8;
    this.pending = e.slice(e.length - a, e.length), this.pending.length === 0 && (this.pending = null), e = utils$e.join32(e, 0, e.length - a, this.endian);
    for (var c = 0; c < e.length; c += this._delta32)
      this._update(e, c, c + this._delta32);
  }
  return this;
};
BlockHash$4.prototype.digest = function(e) {
  return this.update(this._pad()), assert$9(this.pending === null), this._digest(e);
};
BlockHash$4.prototype._pad = function() {
  var e = this.pendingTotal, n = this._delta8, a = n - (e + this.padLength) % n, c = new Array(a + this.padLength);
  c[0] = 128;
  for (var o = 1; o < a; o++)
    c[o] = 0;
  if (e <<= 3, this.endian === "big") {
    for (var u = 8; u < this.padLength; u++)
      c[o++] = 0;
    c[o++] = 0, c[o++] = 0, c[o++] = 0, c[o++] = 0, c[o++] = e >>> 24 & 255, c[o++] = e >>> 16 & 255, c[o++] = e >>> 8 & 255, c[o++] = e & 255;
  } else
    for (c[o++] = e & 255, c[o++] = e >>> 8 & 255, c[o++] = e >>> 16 & 255, c[o++] = e >>> 24 & 255, c[o++] = 0, c[o++] = 0, c[o++] = 0, c[o++] = 0, u = 8; u < this.padLength; u++)
      c[o++] = 0;
  return c;
};
var sha = {}, common$4 = {}, utils$d = utils$f, rotr32 = utils$d.rotr32;
function ft_1$1(t, e, n, a) {
  if (t === 0)
    return ch32$1(e, n, a);
  if (t === 1 || t === 3)
    return p32(e, n, a);
  if (t === 2)
    return maj32$1(e, n, a);
}
common$4.ft_1 = ft_1$1;
function ch32$1(t, e, n) {
  return t & e ^ ~t & n;
}
common$4.ch32 = ch32$1;
function maj32$1(t, e, n) {
  return t & e ^ t & n ^ e & n;
}
common$4.maj32 = maj32$1;
function p32(t, e, n) {
  return t ^ e ^ n;
}
common$4.p32 = p32;
function s0_256$1(t) {
  return rotr32(t, 2) ^ rotr32(t, 13) ^ rotr32(t, 22);
}
common$4.s0_256 = s0_256$1;
function s1_256$1(t) {
  return rotr32(t, 6) ^ rotr32(t, 11) ^ rotr32(t, 25);
}
common$4.s1_256 = s1_256$1;
function g0_256$1(t) {
  return rotr32(t, 7) ^ rotr32(t, 18) ^ t >>> 3;
}
common$4.g0_256 = g0_256$1;
function g1_256$1(t) {
  return rotr32(t, 17) ^ rotr32(t, 19) ^ t >>> 10;
}
common$4.g1_256 = g1_256$1;
var utils$c = utils$f, common$3 = common$5, shaCommon$1 = common$4, rotl32$1 = utils$c.rotl32, sum32$2 = utils$c.sum32, sum32_5$1 = utils$c.sum32_5, ft_1 = shaCommon$1.ft_1, BlockHash$3 = common$3.BlockHash, sha1_K = [
  1518500249,
  1859775393,
  2400959708,
  3395469782
];
function SHA1() {
  if (!(this instanceof SHA1))
    return new SHA1();
  BlockHash$3.call(this), this.h = [
    1732584193,
    4023233417,
    2562383102,
    271733878,
    3285377520
  ], this.W = new Array(80);
}
utils$c.inherits(SHA1, BlockHash$3);
var _1 = SHA1;
SHA1.blockSize = 512;
SHA1.outSize = 160;
SHA1.hmacStrength = 80;
SHA1.padLength = 64;
SHA1.prototype._update = function(e, n) {
  for (var a = this.W, c = 0; c < 16; c++)
    a[c] = e[n + c];
  for (; c < a.length; c++)
    a[c] = rotl32$1(a[c - 3] ^ a[c - 8] ^ a[c - 14] ^ a[c - 16], 1);
  var o = this.h[0], u = this.h[1], h = this.h[2], p = this.h[3], x = this.h[4];
  for (c = 0; c < a.length; c++) {
    var l = ~~(c / 20), b = sum32_5$1(rotl32$1(o, 5), ft_1(l, u, h, p), x, a[c], sha1_K[l]);
    x = p, p = h, h = rotl32$1(u, 30), u = o, o = b;
  }
  this.h[0] = sum32$2(this.h[0], o), this.h[1] = sum32$2(this.h[1], u), this.h[2] = sum32$2(this.h[2], h), this.h[3] = sum32$2(this.h[3], p), this.h[4] = sum32$2(this.h[4], x);
};
SHA1.prototype._digest = function(e) {
  return e === "hex" ? utils$c.toHex32(this.h, "big") : utils$c.split32(this.h, "big");
};
var utils$b = utils$f, common$2 = common$5, shaCommon = common$4, assert$8 = minimalisticAssert, sum32$1 = utils$b.sum32, sum32_4$1 = utils$b.sum32_4, sum32_5 = utils$b.sum32_5, ch32 = shaCommon.ch32, maj32 = shaCommon.maj32, s0_256 = shaCommon.s0_256, s1_256 = shaCommon.s1_256, g0_256 = shaCommon.g0_256, g1_256 = shaCommon.g1_256, BlockHash$2 = common$2.BlockHash, sha256_K = [
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
];
function SHA256$1() {
  if (!(this instanceof SHA256$1))
    return new SHA256$1();
  BlockHash$2.call(this), this.h = [
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ], this.k = sha256_K, this.W = new Array(64);
}
utils$b.inherits(SHA256$1, BlockHash$2);
var _256 = SHA256$1;
SHA256$1.blockSize = 512;
SHA256$1.outSize = 256;
SHA256$1.hmacStrength = 192;
SHA256$1.padLength = 64;
SHA256$1.prototype._update = function(e, n) {
  for (var a = this.W, c = 0; c < 16; c++)
    a[c] = e[n + c];
  for (; c < a.length; c++)
    a[c] = sum32_4$1(g1_256(a[c - 2]), a[c - 7], g0_256(a[c - 15]), a[c - 16]);
  var o = this.h[0], u = this.h[1], h = this.h[2], p = this.h[3], x = this.h[4], l = this.h[5], b = this.h[6], E = this.h[7];
  for (assert$8(this.k.length === a.length), c = 0; c < a.length; c++) {
    var C = sum32_5(E, s1_256(x), ch32(x, l, b), this.k[c], a[c]), q = sum32$1(s0_256(o), maj32(o, u, h));
    E = b, b = l, l = x, x = sum32$1(p, C), p = h, h = u, u = o, o = sum32$1(C, q);
  }
  this.h[0] = sum32$1(this.h[0], o), this.h[1] = sum32$1(this.h[1], u), this.h[2] = sum32$1(this.h[2], h), this.h[3] = sum32$1(this.h[3], p), this.h[4] = sum32$1(this.h[4], x), this.h[5] = sum32$1(this.h[5], l), this.h[6] = sum32$1(this.h[6], b), this.h[7] = sum32$1(this.h[7], E);
};
SHA256$1.prototype._digest = function(e) {
  return e === "hex" ? utils$b.toHex32(this.h, "big") : utils$b.split32(this.h, "big");
};
var utils$a = utils$f, SHA256 = _256;
function SHA224() {
  if (!(this instanceof SHA224))
    return new SHA224();
  SHA256.call(this), this.h = [
    3238371032,
    914150663,
    812702999,
    4144912697,
    4290775857,
    1750603025,
    1694076839,
    3204075428
  ];
}
utils$a.inherits(SHA224, SHA256);
var _224 = SHA224;
SHA224.blockSize = 512;
SHA224.outSize = 224;
SHA224.hmacStrength = 192;
SHA224.padLength = 64;
SHA224.prototype._digest = function(e) {
  return e === "hex" ? utils$a.toHex32(this.h.slice(0, 7), "big") : utils$a.split32(this.h.slice(0, 7), "big");
};
var utils$9 = utils$f, common$1 = common$5, assert$7 = minimalisticAssert, rotr64_hi = utils$9.rotr64_hi, rotr64_lo = utils$9.rotr64_lo, shr64_hi = utils$9.shr64_hi, shr64_lo = utils$9.shr64_lo, sum64 = utils$9.sum64, sum64_hi = utils$9.sum64_hi, sum64_lo = utils$9.sum64_lo, sum64_4_hi = utils$9.sum64_4_hi, sum64_4_lo = utils$9.sum64_4_lo, sum64_5_hi = utils$9.sum64_5_hi, sum64_5_lo = utils$9.sum64_5_lo, BlockHash$1 = common$1.BlockHash, sha512_K = [
  1116352408,
  3609767458,
  1899447441,
  602891725,
  3049323471,
  3964484399,
  3921009573,
  2173295548,
  961987163,
  4081628472,
  1508970993,
  3053834265,
  2453635748,
  2937671579,
  2870763221,
  3664609560,
  3624381080,
  2734883394,
  310598401,
  1164996542,
  607225278,
  1323610764,
  1426881987,
  3590304994,
  1925078388,
  4068182383,
  2162078206,
  991336113,
  2614888103,
  633803317,
  3248222580,
  3479774868,
  3835390401,
  2666613458,
  4022224774,
  944711139,
  264347078,
  2341262773,
  604807628,
  2007800933,
  770255983,
  1495990901,
  1249150122,
  1856431235,
  1555081692,
  3175218132,
  1996064986,
  2198950837,
  2554220882,
  3999719339,
  2821834349,
  766784016,
  2952996808,
  2566594879,
  3210313671,
  3203337956,
  3336571891,
  1034457026,
  3584528711,
  2466948901,
  113926993,
  3758326383,
  338241895,
  168717936,
  666307205,
  1188179964,
  773529912,
  1546045734,
  1294757372,
  1522805485,
  1396182291,
  2643833823,
  1695183700,
  2343527390,
  1986661051,
  1014477480,
  2177026350,
  1206759142,
  2456956037,
  344077627,
  2730485921,
  1290863460,
  2820302411,
  3158454273,
  3259730800,
  3505952657,
  3345764771,
  106217008,
  3516065817,
  3606008344,
  3600352804,
  1432725776,
  4094571909,
  1467031594,
  275423344,
  851169720,
  430227734,
  3100823752,
  506948616,
  1363258195,
  659060556,
  3750685593,
  883997877,
  3785050280,
  958139571,
  3318307427,
  1322822218,
  3812723403,
  1537002063,
  2003034995,
  1747873779,
  3602036899,
  1955562222,
  1575990012,
  2024104815,
  1125592928,
  2227730452,
  2716904306,
  2361852424,
  442776044,
  2428436474,
  593698344,
  2756734187,
  3733110249,
  3204031479,
  2999351573,
  3329325298,
  3815920427,
  3391569614,
  3928383900,
  3515267271,
  566280711,
  3940187606,
  3454069534,
  4118630271,
  4000239992,
  116418474,
  1914138554,
  174292421,
  2731055270,
  289380356,
  3203993006,
  460393269,
  320620315,
  685471733,
  587496836,
  852142971,
  1086792851,
  1017036298,
  365543100,
  1126000580,
  2618297676,
  1288033470,
  3409855158,
  1501505948,
  4234509866,
  1607167915,
  987167468,
  1816402316,
  1246189591
];
function SHA512$1() {
  if (!(this instanceof SHA512$1))
    return new SHA512$1();
  BlockHash$1.call(this), this.h = [
    1779033703,
    4089235720,
    3144134277,
    2227873595,
    1013904242,
    4271175723,
    2773480762,
    1595750129,
    1359893119,
    2917565137,
    2600822924,
    725511199,
    528734635,
    4215389547,
    1541459225,
    327033209
  ], this.k = sha512_K, this.W = new Array(160);
}
utils$9.inherits(SHA512$1, BlockHash$1);
var _512 = SHA512$1;
SHA512$1.blockSize = 1024;
SHA512$1.outSize = 512;
SHA512$1.hmacStrength = 192;
SHA512$1.padLength = 128;
SHA512$1.prototype._prepareBlock = function(e, n) {
  for (var a = this.W, c = 0; c < 32; c++)
    a[c] = e[n + c];
  for (; c < a.length; c += 2) {
    var o = g1_512_hi(a[c - 4], a[c - 3]), u = g1_512_lo(a[c - 4], a[c - 3]), h = a[c - 14], p = a[c - 13], x = g0_512_hi(a[c - 30], a[c - 29]), l = g0_512_lo(a[c - 30], a[c - 29]), b = a[c - 32], E = a[c - 31];
    a[c] = sum64_4_hi(
      o,
      u,
      h,
      p,
      x,
      l,
      b,
      E
    ), a[c + 1] = sum64_4_lo(
      o,
      u,
      h,
      p,
      x,
      l,
      b,
      E
    );
  }
};
SHA512$1.prototype._update = function(e, n) {
  this._prepareBlock(e, n);
  var a = this.W, c = this.h[0], o = this.h[1], u = this.h[2], h = this.h[3], p = this.h[4], x = this.h[5], l = this.h[6], b = this.h[7], E = this.h[8], C = this.h[9], q = this.h[10], F = this.h[11], z = this.h[12], H = this.h[13], U = this.h[14], Y = this.h[15];
  assert$7(this.k.length === a.length);
  for (var ee = 0; ee < a.length; ee += 2) {
    var se = U, fe = Y, pe = s1_512_hi(E, C), ue = s1_512_lo(E, C), ce = ch64_hi(E, C, q, F, z), $e = ch64_lo(E, C, q, F, z, H), V = this.k[ee], _ = this.k[ee + 1], w = a[ee], d = a[ee + 1], m = sum64_5_hi(
      se,
      fe,
      pe,
      ue,
      ce,
      $e,
      V,
      _,
      w,
      d
    ), B = sum64_5_lo(
      se,
      fe,
      pe,
      ue,
      ce,
      $e,
      V,
      _,
      w,
      d
    );
    se = s0_512_hi(c, o), fe = s0_512_lo(c, o), pe = maj64_hi(c, o, u, h, p), ue = maj64_lo(c, o, u, h, p, x);
    var $ = sum64_hi(se, fe, pe, ue), P = sum64_lo(se, fe, pe, ue);
    U = z, Y = H, z = q, H = F, q = E, F = C, E = sum64_hi(l, b, m, B), C = sum64_lo(b, b, m, B), l = p, b = x, p = u, x = h, u = c, h = o, c = sum64_hi(m, B, $, P), o = sum64_lo(m, B, $, P);
  }
  sum64(this.h, 0, c, o), sum64(this.h, 2, u, h), sum64(this.h, 4, p, x), sum64(this.h, 6, l, b), sum64(this.h, 8, E, C), sum64(this.h, 10, q, F), sum64(this.h, 12, z, H), sum64(this.h, 14, U, Y);
};
SHA512$1.prototype._digest = function(e) {
  return e === "hex" ? utils$9.toHex32(this.h, "big") : utils$9.split32(this.h, "big");
};
function ch64_hi(t, e, n, a, c) {
  var o = t & n ^ ~t & c;
  return o < 0 && (o += 4294967296), o;
}
function ch64_lo(t, e, n, a, c, o) {
  var u = e & a ^ ~e & o;
  return u < 0 && (u += 4294967296), u;
}
function maj64_hi(t, e, n, a, c) {
  var o = t & n ^ t & c ^ n & c;
  return o < 0 && (o += 4294967296), o;
}
function maj64_lo(t, e, n, a, c, o) {
  var u = e & a ^ e & o ^ a & o;
  return u < 0 && (u += 4294967296), u;
}
function s0_512_hi(t, e) {
  var n = rotr64_hi(t, e, 28), a = rotr64_hi(e, t, 2), c = rotr64_hi(e, t, 7), o = n ^ a ^ c;
  return o < 0 && (o += 4294967296), o;
}
function s0_512_lo(t, e) {
  var n = rotr64_lo(t, e, 28), a = rotr64_lo(e, t, 2), c = rotr64_lo(e, t, 7), o = n ^ a ^ c;
  return o < 0 && (o += 4294967296), o;
}
function s1_512_hi(t, e) {
  var n = rotr64_hi(t, e, 14), a = rotr64_hi(t, e, 18), c = rotr64_hi(e, t, 9), o = n ^ a ^ c;
  return o < 0 && (o += 4294967296), o;
}
function s1_512_lo(t, e) {
  var n = rotr64_lo(t, e, 14), a = rotr64_lo(t, e, 18), c = rotr64_lo(e, t, 9), o = n ^ a ^ c;
  return o < 0 && (o += 4294967296), o;
}
function g0_512_hi(t, e) {
  var n = rotr64_hi(t, e, 1), a = rotr64_hi(t, e, 8), c = shr64_hi(t, e, 7), o = n ^ a ^ c;
  return o < 0 && (o += 4294967296), o;
}
function g0_512_lo(t, e) {
  var n = rotr64_lo(t, e, 1), a = rotr64_lo(t, e, 8), c = shr64_lo(t, e, 7), o = n ^ a ^ c;
  return o < 0 && (o += 4294967296), o;
}
function g1_512_hi(t, e) {
  var n = rotr64_hi(t, e, 19), a = rotr64_hi(e, t, 29), c = shr64_hi(t, e, 6), o = n ^ a ^ c;
  return o < 0 && (o += 4294967296), o;
}
function g1_512_lo(t, e) {
  var n = rotr64_lo(t, e, 19), a = rotr64_lo(e, t, 29), c = shr64_lo(t, e, 6), o = n ^ a ^ c;
  return o < 0 && (o += 4294967296), o;
}
var utils$8 = utils$f, SHA512 = _512;
function SHA384() {
  if (!(this instanceof SHA384))
    return new SHA384();
  SHA512.call(this), this.h = [
    3418070365,
    3238371032,
    1654270250,
    914150663,
    2438529370,
    812702999,
    355462360,
    4144912697,
    1731405415,
    4290775857,
    2394180231,
    1750603025,
    3675008525,
    1694076839,
    1203062813,
    3204075428
  ];
}
utils$8.inherits(SHA384, SHA512);
var _384 = SHA384;
SHA384.blockSize = 1024;
SHA384.outSize = 384;
SHA384.hmacStrength = 192;
SHA384.padLength = 128;
SHA384.prototype._digest = function(e) {
  return e === "hex" ? utils$8.toHex32(this.h.slice(0, 12), "big") : utils$8.split32(this.h.slice(0, 12), "big");
};
sha.sha1 = _1;
sha.sha224 = _224;
sha.sha256 = _256;
sha.sha384 = _384;
sha.sha512 = _512;
var ripemd = {}, utils$7 = utils$f, common = common$5, rotl32 = utils$7.rotl32, sum32 = utils$7.sum32, sum32_3 = utils$7.sum32_3, sum32_4 = utils$7.sum32_4, BlockHash = common.BlockHash;
function RIPEMD160() {
  if (!(this instanceof RIPEMD160))
    return new RIPEMD160();
  BlockHash.call(this), this.h = [1732584193, 4023233417, 2562383102, 271733878, 3285377520], this.endian = "little";
}
utils$7.inherits(RIPEMD160, BlockHash);
ripemd.ripemd160 = RIPEMD160;
RIPEMD160.blockSize = 512;
RIPEMD160.outSize = 160;
RIPEMD160.hmacStrength = 192;
RIPEMD160.padLength = 64;
RIPEMD160.prototype._update = function(e, n) {
  for (var a = this.h[0], c = this.h[1], o = this.h[2], u = this.h[3], h = this.h[4], p = a, x = c, l = o, b = u, E = h, C = 0; C < 80; C++) {
    var q = sum32(
      rotl32(
        sum32_4(a, f(C, c, o, u), e[r[C] + n], K(C)),
        s[C]
      ),
      h
    );
    a = h, h = u, u = rotl32(o, 10), o = c, c = q, q = sum32(
      rotl32(
        sum32_4(p, f(79 - C, x, l, b), e[rh[C] + n], Kh(C)),
        sh[C]
      ),
      E
    ), p = E, E = b, b = rotl32(l, 10), l = x, x = q;
  }
  q = sum32_3(this.h[1], o, b), this.h[1] = sum32_3(this.h[2], u, E), this.h[2] = sum32_3(this.h[3], h, p), this.h[3] = sum32_3(this.h[4], a, x), this.h[4] = sum32_3(this.h[0], c, l), this.h[0] = q;
};
RIPEMD160.prototype._digest = function(e) {
  return e === "hex" ? utils$7.toHex32(this.h, "little") : utils$7.split32(this.h, "little");
};
function f(t, e, n, a) {
  return t <= 15 ? e ^ n ^ a : t <= 31 ? e & n | ~e & a : t <= 47 ? (e | ~n) ^ a : t <= 63 ? e & a | n & ~a : e ^ (n | ~a);
}
function K(t) {
  return t <= 15 ? 0 : t <= 31 ? 1518500249 : t <= 47 ? 1859775393 : t <= 63 ? 2400959708 : 2840853838;
}
function Kh(t) {
  return t <= 15 ? 1352829926 : t <= 31 ? 1548603684 : t <= 47 ? 1836072691 : t <= 63 ? 2053994217 : 0;
}
var r = [
  0,
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  14,
  15,
  7,
  4,
  13,
  1,
  10,
  6,
  15,
  3,
  12,
  0,
  9,
  5,
  2,
  14,
  11,
  8,
  3,
  10,
  14,
  4,
  9,
  15,
  8,
  1,
  2,
  7,
  0,
  6,
  13,
  11,
  5,
  12,
  1,
  9,
  11,
  10,
  0,
  8,
  12,
  4,
  13,
  3,
  7,
  15,
  14,
  5,
  6,
  2,
  4,
  0,
  5,
  9,
  7,
  12,
  2,
  10,
  14,
  1,
  3,
  8,
  11,
  6,
  15,
  13
], rh = [
  5,
  14,
  7,
  0,
  9,
  2,
  11,
  4,
  13,
  6,
  15,
  8,
  1,
  10,
  3,
  12,
  6,
  11,
  3,
  7,
  0,
  13,
  5,
  10,
  14,
  15,
  8,
  12,
  4,
  9,
  1,
  2,
  15,
  5,
  1,
  3,
  7,
  14,
  6,
  9,
  11,
  8,
  12,
  2,
  10,
  0,
  4,
  13,
  8,
  6,
  4,
  1,
  3,
  11,
  15,
  0,
  5,
  12,
  2,
  13,
  9,
  7,
  10,
  14,
  12,
  15,
  10,
  4,
  1,
  5,
  8,
  7,
  6,
  2,
  13,
  14,
  0,
  3,
  9,
  11
], s = [
  11,
  14,
  15,
  12,
  5,
  8,
  7,
  9,
  11,
  13,
  14,
  15,
  6,
  7,
  9,
  8,
  7,
  6,
  8,
  13,
  11,
  9,
  7,
  15,
  7,
  12,
  15,
  9,
  11,
  7,
  13,
  12,
  11,
  13,
  6,
  7,
  14,
  9,
  13,
  15,
  14,
  8,
  13,
  6,
  5,
  12,
  7,
  5,
  11,
  12,
  14,
  15,
  14,
  15,
  9,
  8,
  9,
  14,
  5,
  6,
  8,
  6,
  5,
  12,
  9,
  15,
  5,
  11,
  6,
  8,
  13,
  12,
  5,
  12,
  13,
  14,
  11,
  8,
  5,
  6
], sh = [
  8,
  9,
  9,
  11,
  13,
  15,
  15,
  5,
  7,
  7,
  8,
  11,
  14,
  14,
  12,
  6,
  9,
  13,
  15,
  7,
  12,
  8,
  9,
  11,
  7,
  7,
  12,
  7,
  6,
  15,
  13,
  11,
  9,
  7,
  15,
  11,
  8,
  6,
  6,
  14,
  12,
  13,
  5,
  14,
  13,
  13,
  7,
  5,
  15,
  5,
  8,
  11,
  14,
  14,
  6,
  14,
  6,
  9,
  12,
  9,
  12,
  5,
  15,
  8,
  8,
  5,
  12,
  9,
  12,
  5,
  14,
  6,
  8,
  13,
  6,
  5,
  15,
  13,
  11,
  11
], utils$6 = utils$f, assert$6 = minimalisticAssert;
function Hmac(t, e, n) {
  if (!(this instanceof Hmac))
    return new Hmac(t, e, n);
  this.Hash = t, this.blockSize = t.blockSize / 8, this.outSize = t.outSize / 8, this.inner = null, this.outer = null, this._init(utils$6.toArray(e, n));
}
var hmac = Hmac;
Hmac.prototype._init = function(e) {
  e.length > this.blockSize && (e = new this.Hash().update(e).digest()), assert$6(e.length <= this.blockSize);
  for (var n = e.length; n < this.blockSize; n++)
    e.push(0);
  for (n = 0; n < e.length; n++)
    e[n] ^= 54;
  for (this.inner = new this.Hash().update(e), n = 0; n < e.length; n++)
    e[n] ^= 106;
  this.outer = new this.Hash().update(e);
};
Hmac.prototype.update = function(e, n) {
  return this.inner.update(e, n), this;
};
Hmac.prototype.digest = function(e) {
  return this.outer.update(this.inner.digest()), this.outer.digest(e);
};
(function(t) {
  var e = t;
  e.utils = utils$f, e.common = common$5, e.sha = sha, e.ripemd = ripemd, e.hmac = hmac, e.sha1 = e.sha.sha1, e.sha256 = e.sha.sha256, e.sha224 = e.sha.sha224, e.sha384 = e.sha.sha384, e.sha512 = e.sha.sha512, e.ripemd160 = e.ripemd.ripemd160;
})(hash$2);
var secp256k1, hasRequiredSecp256k1;
function requireSecp256k1() {
  return hasRequiredSecp256k1 || (hasRequiredSecp256k1 = 1, secp256k1 = {
    doubles: {
      step: 4,
      points: [
        [
          "e60fce93b59e9ec53011aabc21c23e97b2a31369b87a5ae9c44ee89e2a6dec0a",
          "f7e3507399e595929db99f34f57937101296891e44d23f0be1f32cce69616821"
        ],
        [
          "8282263212c609d9ea2a6e3e172de238d8c39cabd5ac1ca10646e23fd5f51508",
          "11f8a8098557dfe45e8256e830b60ace62d613ac2f7b17bed31b6eaff6e26caf"
        ],
        [
          "175e159f728b865a72f99cc6c6fc846de0b93833fd2222ed73fce5b551e5b739",
          "d3506e0d9e3c79eba4ef97a51ff71f5eacb5955add24345c6efa6ffee9fed695"
        ],
        [
          "363d90d447b00c9c99ceac05b6262ee053441c7e55552ffe526bad8f83ff4640",
          "4e273adfc732221953b445397f3363145b9a89008199ecb62003c7f3bee9de9"
        ],
        [
          "8b4b5f165df3c2be8c6244b5b745638843e4a781a15bcd1b69f79a55dffdf80c",
          "4aad0a6f68d308b4b3fbd7813ab0da04f9e336546162ee56b3eff0c65fd4fd36"
        ],
        [
          "723cbaa6e5db996d6bf771c00bd548c7b700dbffa6c0e77bcb6115925232fcda",
          "96e867b5595cc498a921137488824d6e2660a0653779494801dc069d9eb39f5f"
        ],
        [
          "eebfa4d493bebf98ba5feec812c2d3b50947961237a919839a533eca0e7dd7fa",
          "5d9a8ca3970ef0f269ee7edaf178089d9ae4cdc3a711f712ddfd4fdae1de8999"
        ],
        [
          "100f44da696e71672791d0a09b7bde459f1215a29b3c03bfefd7835b39a48db0",
          "cdd9e13192a00b772ec8f3300c090666b7ff4a18ff5195ac0fbd5cd62bc65a09"
        ],
        [
          "e1031be262c7ed1b1dc9227a4a04c017a77f8d4464f3b3852c8acde6e534fd2d",
          "9d7061928940405e6bb6a4176597535af292dd419e1ced79a44f18f29456a00d"
        ],
        [
          "feea6cae46d55b530ac2839f143bd7ec5cf8b266a41d6af52d5e688d9094696d",
          "e57c6b6c97dce1bab06e4e12bf3ecd5c981c8957cc41442d3155debf18090088"
        ],
        [
          "da67a91d91049cdcb367be4be6ffca3cfeed657d808583de33fa978bc1ec6cb1",
          "9bacaa35481642bc41f463f7ec9780e5dec7adc508f740a17e9ea8e27a68be1d"
        ],
        [
          "53904faa0b334cdda6e000935ef22151ec08d0f7bb11069f57545ccc1a37b7c0",
          "5bc087d0bc80106d88c9eccac20d3c1c13999981e14434699dcb096b022771c8"
        ],
        [
          "8e7bcd0bd35983a7719cca7764ca906779b53a043a9b8bcaeff959f43ad86047",
          "10b7770b2a3da4b3940310420ca9514579e88e2e47fd68b3ea10047e8460372a"
        ],
        [
          "385eed34c1cdff21e6d0818689b81bde71a7f4f18397e6690a841e1599c43862",
          "283bebc3e8ea23f56701de19e9ebf4576b304eec2086dc8cc0458fe5542e5453"
        ],
        [
          "6f9d9b803ecf191637c73a4413dfa180fddf84a5947fbc9c606ed86c3fac3a7",
          "7c80c68e603059ba69b8e2a30e45c4d47ea4dd2f5c281002d86890603a842160"
        ],
        [
          "3322d401243c4e2582a2147c104d6ecbf774d163db0f5e5313b7e0e742d0e6bd",
          "56e70797e9664ef5bfb019bc4ddaf9b72805f63ea2873af624f3a2e96c28b2a0"
        ],
        [
          "85672c7d2de0b7da2bd1770d89665868741b3f9af7643397721d74d28134ab83",
          "7c481b9b5b43b2eb6374049bfa62c2e5e77f17fcc5298f44c8e3094f790313a6"
        ],
        [
          "948bf809b1988a46b06c9f1919413b10f9226c60f668832ffd959af60c82a0a",
          "53a562856dcb6646dc6b74c5d1c3418c6d4dff08c97cd2bed4cb7f88d8c8e589"
        ],
        [
          "6260ce7f461801c34f067ce0f02873a8f1b0e44dfc69752accecd819f38fd8e8",
          "bc2da82b6fa5b571a7f09049776a1ef7ecd292238051c198c1a84e95b2b4ae17"
        ],
        [
          "e5037de0afc1d8d43d8348414bbf4103043ec8f575bfdc432953cc8d2037fa2d",
          "4571534baa94d3b5f9f98d09fb990bddbd5f5b03ec481f10e0e5dc841d755bda"
        ],
        [
          "e06372b0f4a207adf5ea905e8f1771b4e7e8dbd1c6a6c5b725866a0ae4fce725",
          "7a908974bce18cfe12a27bb2ad5a488cd7484a7787104870b27034f94eee31dd"
        ],
        [
          "213c7a715cd5d45358d0bbf9dc0ce02204b10bdde2a3f58540ad6908d0559754",
          "4b6dad0b5ae462507013ad06245ba190bb4850f5f36a7eeddff2c27534b458f2"
        ],
        [
          "4e7c272a7af4b34e8dbb9352a5419a87e2838c70adc62cddf0cc3a3b08fbd53c",
          "17749c766c9d0b18e16fd09f6def681b530b9614bff7dd33e0b3941817dcaae6"
        ],
        [
          "fea74e3dbe778b1b10f238ad61686aa5c76e3db2be43057632427e2840fb27b6",
          "6e0568db9b0b13297cf674deccb6af93126b596b973f7b77701d3db7f23cb96f"
        ],
        [
          "76e64113f677cf0e10a2570d599968d31544e179b760432952c02a4417bdde39",
          "c90ddf8dee4e95cf577066d70681f0d35e2a33d2b56d2032b4b1752d1901ac01"
        ],
        [
          "c738c56b03b2abe1e8281baa743f8f9a8f7cc643df26cbee3ab150242bcbb891",
          "893fb578951ad2537f718f2eacbfbbbb82314eef7880cfe917e735d9699a84c3"
        ],
        [
          "d895626548b65b81e264c7637c972877d1d72e5f3a925014372e9f6588f6c14b",
          "febfaa38f2bc7eae728ec60818c340eb03428d632bb067e179363ed75d7d991f"
        ],
        [
          "b8da94032a957518eb0f6433571e8761ceffc73693e84edd49150a564f676e03",
          "2804dfa44805a1e4d7c99cc9762808b092cc584d95ff3b511488e4e74efdf6e7"
        ],
        [
          "e80fea14441fb33a7d8adab9475d7fab2019effb5156a792f1a11778e3c0df5d",
          "eed1de7f638e00771e89768ca3ca94472d155e80af322ea9fcb4291b6ac9ec78"
        ],
        [
          "a301697bdfcd704313ba48e51d567543f2a182031efd6915ddc07bbcc4e16070",
          "7370f91cfb67e4f5081809fa25d40f9b1735dbf7c0a11a130c0d1a041e177ea1"
        ],
        [
          "90ad85b389d6b936463f9d0512678de208cc330b11307fffab7ac63e3fb04ed4",
          "e507a3620a38261affdcbd9427222b839aefabe1582894d991d4d48cb6ef150"
        ],
        [
          "8f68b9d2f63b5f339239c1ad981f162ee88c5678723ea3351b7b444c9ec4c0da",
          "662a9f2dba063986de1d90c2b6be215dbbea2cfe95510bfdf23cbf79501fff82"
        ],
        [
          "e4f3fb0176af85d65ff99ff9198c36091f48e86503681e3e6686fd5053231e11",
          "1e63633ad0ef4f1c1661a6d0ea02b7286cc7e74ec951d1c9822c38576feb73bc"
        ],
        [
          "8c00fa9b18ebf331eb961537a45a4266c7034f2f0d4e1d0716fb6eae20eae29e",
          "efa47267fea521a1a9dc343a3736c974c2fadafa81e36c54e7d2a4c66702414b"
        ],
        [
          "e7a26ce69dd4829f3e10cec0a9e98ed3143d084f308b92c0997fddfc60cb3e41",
          "2a758e300fa7984b471b006a1aafbb18d0a6b2c0420e83e20e8a9421cf2cfd51"
        ],
        [
          "b6459e0ee3662ec8d23540c223bcbdc571cbcb967d79424f3cf29eb3de6b80ef",
          "67c876d06f3e06de1dadf16e5661db3c4b3ae6d48e35b2ff30bf0b61a71ba45"
        ],
        [
          "d68a80c8280bb840793234aa118f06231d6f1fc67e73c5a5deda0f5b496943e8",
          "db8ba9fff4b586d00c4b1f9177b0e28b5b0e7b8f7845295a294c84266b133120"
        ],
        [
          "324aed7df65c804252dc0270907a30b09612aeb973449cea4095980fc28d3d5d",
          "648a365774b61f2ff130c0c35aec1f4f19213b0c7e332843967224af96ab7c84"
        ],
        [
          "4df9c14919cde61f6d51dfdbe5fee5dceec4143ba8d1ca888e8bd373fd054c96",
          "35ec51092d8728050974c23a1d85d4b5d506cdc288490192ebac06cad10d5d"
        ],
        [
          "9c3919a84a474870faed8a9c1cc66021523489054d7f0308cbfc99c8ac1f98cd",
          "ddb84f0f4a4ddd57584f044bf260e641905326f76c64c8e6be7e5e03d4fc599d"
        ],
        [
          "6057170b1dd12fdf8de05f281d8e06bb91e1493a8b91d4cc5a21382120a959e5",
          "9a1af0b26a6a4807add9a2daf71df262465152bc3ee24c65e899be932385a2a8"
        ],
        [
          "a576df8e23a08411421439a4518da31880cef0fba7d4df12b1a6973eecb94266",
          "40a6bf20e76640b2c92b97afe58cd82c432e10a7f514d9f3ee8be11ae1b28ec8"
        ],
        [
          "7778a78c28dec3e30a05fe9629de8c38bb30d1f5cf9a3a208f763889be58ad71",
          "34626d9ab5a5b22ff7098e12f2ff580087b38411ff24ac563b513fc1fd9f43ac"
        ],
        [
          "928955ee637a84463729fd30e7afd2ed5f96274e5ad7e5cb09eda9c06d903ac",
          "c25621003d3f42a827b78a13093a95eeac3d26efa8a8d83fc5180e935bcd091f"
        ],
        [
          "85d0fef3ec6db109399064f3a0e3b2855645b4a907ad354527aae75163d82751",
          "1f03648413a38c0be29d496e582cf5663e8751e96877331582c237a24eb1f962"
        ],
        [
          "ff2b0dce97eece97c1c9b6041798b85dfdfb6d8882da20308f5404824526087e",
          "493d13fef524ba188af4c4dc54d07936c7b7ed6fb90e2ceb2c951e01f0c29907"
        ],
        [
          "827fbbe4b1e880ea9ed2b2e6301b212b57f1ee148cd6dd28780e5e2cf856e241",
          "c60f9c923c727b0b71bef2c67d1d12687ff7a63186903166d605b68baec293ec"
        ],
        [
          "eaa649f21f51bdbae7be4ae34ce6e5217a58fdce7f47f9aa7f3b58fa2120e2b3",
          "be3279ed5bbbb03ac69a80f89879aa5a01a6b965f13f7e59d47a5305ba5ad93d"
        ],
        [
          "e4a42d43c5cf169d9391df6decf42ee541b6d8f0c9a137401e23632dda34d24f",
          "4d9f92e716d1c73526fc99ccfb8ad34ce886eedfa8d8e4f13a7f7131deba9414"
        ],
        [
          "1ec80fef360cbdd954160fadab352b6b92b53576a88fea4947173b9d4300bf19",
          "aeefe93756b5340d2f3a4958a7abbf5e0146e77f6295a07b671cdc1cc107cefd"
        ],
        [
          "146a778c04670c2f91b00af4680dfa8bce3490717d58ba889ddb5928366642be",
          "b318e0ec3354028add669827f9d4b2870aaa971d2f7e5ed1d0b297483d83efd0"
        ],
        [
          "fa50c0f61d22e5f07e3acebb1aa07b128d0012209a28b9776d76a8793180eef9",
          "6b84c6922397eba9b72cd2872281a68a5e683293a57a213b38cd8d7d3f4f2811"
        ],
        [
          "da1d61d0ca721a11b1a5bf6b7d88e8421a288ab5d5bba5220e53d32b5f067ec2",
          "8157f55a7c99306c79c0766161c91e2966a73899d279b48a655fba0f1ad836f1"
        ],
        [
          "a8e282ff0c9706907215ff98e8fd416615311de0446f1e062a73b0610d064e13",
          "7f97355b8db81c09abfb7f3c5b2515888b679a3e50dd6bd6cef7c73111f4cc0c"
        ],
        [
          "174a53b9c9a285872d39e56e6913cab15d59b1fa512508c022f382de8319497c",
          "ccc9dc37abfc9c1657b4155f2c47f9e6646b3a1d8cb9854383da13ac079afa73"
        ],
        [
          "959396981943785c3d3e57edf5018cdbe039e730e4918b3d884fdff09475b7ba",
          "2e7e552888c331dd8ba0386a4b9cd6849c653f64c8709385e9b8abf87524f2fd"
        ],
        [
          "d2a63a50ae401e56d645a1153b109a8fcca0a43d561fba2dbb51340c9d82b151",
          "e82d86fb6443fcb7565aee58b2948220a70f750af484ca52d4142174dcf89405"
        ],
        [
          "64587e2335471eb890ee7896d7cfdc866bacbdbd3839317b3436f9b45617e073",
          "d99fcdd5bf6902e2ae96dd6447c299a185b90a39133aeab358299e5e9faf6589"
        ],
        [
          "8481bde0e4e4d885b3a546d3e549de042f0aa6cea250e7fd358d6c86dd45e458",
          "38ee7b8cba5404dd84a25bf39cecb2ca900a79c42b262e556d64b1b59779057e"
        ],
        [
          "13464a57a78102aa62b6979ae817f4637ffcfed3c4b1ce30bcd6303f6caf666b",
          "69be159004614580ef7e433453ccb0ca48f300a81d0942e13f495a907f6ecc27"
        ],
        [
          "bc4a9df5b713fe2e9aef430bcc1dc97a0cd9ccede2f28588cada3a0d2d83f366",
          "d3a81ca6e785c06383937adf4b798caa6e8a9fbfa547b16d758d666581f33c1"
        ],
        [
          "8c28a97bf8298bc0d23d8c749452a32e694b65e30a9472a3954ab30fe5324caa",
          "40a30463a3305193378fedf31f7cc0eb7ae784f0451cb9459e71dc73cbef9482"
        ],
        [
          "8ea9666139527a8c1dd94ce4f071fd23c8b350c5a4bb33748c4ba111faccae0",
          "620efabbc8ee2782e24e7c0cfb95c5d735b783be9cf0f8e955af34a30e62b945"
        ],
        [
          "dd3625faef5ba06074669716bbd3788d89bdde815959968092f76cc4eb9a9787",
          "7a188fa3520e30d461da2501045731ca941461982883395937f68d00c644a573"
        ],
        [
          "f710d79d9eb962297e4f6232b40e8f7feb2bc63814614d692c12de752408221e",
          "ea98e67232d3b3295d3b535532115ccac8612c721851617526ae47a9c77bfc82"
        ]
      ]
    },
    naf: {
      wnd: 7,
      points: [
        [
          "f9308a019258c31049344f85f89d5229b531c845836f99b08601f113bce036f9",
          "388f7b0f632de8140fe337e62a37f3566500a99934c2231b6cb9fd7584b8e672"
        ],
        [
          "2f8bde4d1a07209355b4a7250a5c5128e88b84bddc619ab7cba8d569b240efe4",
          "d8ac222636e5e3d6d4dba9dda6c9c426f788271bab0d6840dca87d3aa6ac62d6"
        ],
        [
          "5cbdf0646e5db4eaa398f365f2ea7a0e3d419b7e0330e39ce92bddedcac4f9bc",
          "6aebca40ba255960a3178d6d861a54dba813d0b813fde7b5a5082628087264da"
        ],
        [
          "acd484e2f0c7f65309ad178a9f559abde09796974c57e714c35f110dfc27ccbe",
          "cc338921b0a7d9fd64380971763b61e9add888a4375f8e0f05cc262ac64f9c37"
        ],
        [
          "774ae7f858a9411e5ef4246b70c65aac5649980be5c17891bbec17895da008cb",
          "d984a032eb6b5e190243dd56d7b7b365372db1e2dff9d6a8301d74c9c953c61b"
        ],
        [
          "f28773c2d975288bc7d1d205c3748651b075fbc6610e58cddeeddf8f19405aa8",
          "ab0902e8d880a89758212eb65cdaf473a1a06da521fa91f29b5cb52db03ed81"
        ],
        [
          "d7924d4f7d43ea965a465ae3095ff41131e5946f3c85f79e44adbcf8e27e080e",
          "581e2872a86c72a683842ec228cc6defea40af2bd896d3a5c504dc9ff6a26b58"
        ],
        [
          "defdea4cdb677750a420fee807eacf21eb9898ae79b9768766e4faa04a2d4a34",
          "4211ab0694635168e997b0ead2a93daeced1f4a04a95c0f6cfb199f69e56eb77"
        ],
        [
          "2b4ea0a797a443d293ef5cff444f4979f06acfebd7e86d277475656138385b6c",
          "85e89bc037945d93b343083b5a1c86131a01f60c50269763b570c854e5c09b7a"
        ],
        [
          "352bbf4a4cdd12564f93fa332ce333301d9ad40271f8107181340aef25be59d5",
          "321eb4075348f534d59c18259dda3e1f4a1b3b2e71b1039c67bd3d8bcf81998c"
        ],
        [
          "2fa2104d6b38d11b0230010559879124e42ab8dfeff5ff29dc9cdadd4ecacc3f",
          "2de1068295dd865b64569335bd5dd80181d70ecfc882648423ba76b532b7d67"
        ],
        [
          "9248279b09b4d68dab21a9b066edda83263c3d84e09572e269ca0cd7f5453714",
          "73016f7bf234aade5d1aa71bdea2b1ff3fc0de2a887912ffe54a32ce97cb3402"
        ],
        [
          "daed4f2be3a8bf278e70132fb0beb7522f570e144bf615c07e996d443dee8729",
          "a69dce4a7d6c98e8d4a1aca87ef8d7003f83c230f3afa726ab40e52290be1c55"
        ],
        [
          "c44d12c7065d812e8acf28d7cbb19f9011ecd9e9fdf281b0e6a3b5e87d22e7db",
          "2119a460ce326cdc76c45926c982fdac0e106e861edf61c5a039063f0e0e6482"
        ],
        [
          "6a245bf6dc698504c89a20cfded60853152b695336c28063b61c65cbd269e6b4",
          "e022cf42c2bd4a708b3f5126f16a24ad8b33ba48d0423b6efd5e6348100d8a82"
        ],
        [
          "1697ffa6fd9de627c077e3d2fe541084ce13300b0bec1146f95ae57f0d0bd6a5",
          "b9c398f186806f5d27561506e4557433a2cf15009e498ae7adee9d63d01b2396"
        ],
        [
          "605bdb019981718b986d0f07e834cb0d9deb8360ffb7f61df982345ef27a7479",
          "2972d2de4f8d20681a78d93ec96fe23c26bfae84fb14db43b01e1e9056b8c49"
        ],
        [
          "62d14dab4150bf497402fdc45a215e10dcb01c354959b10cfe31c7e9d87ff33d",
          "80fc06bd8cc5b01098088a1950eed0db01aa132967ab472235f5642483b25eaf"
        ],
        [
          "80c60ad0040f27dade5b4b06c408e56b2c50e9f56b9b8b425e555c2f86308b6f",
          "1c38303f1cc5c30f26e66bad7fe72f70a65eed4cbe7024eb1aa01f56430bd57a"
        ],
        [
          "7a9375ad6167ad54aa74c6348cc54d344cc5dc9487d847049d5eabb0fa03c8fb",
          "d0e3fa9eca8726909559e0d79269046bdc59ea10c70ce2b02d499ec224dc7f7"
        ],
        [
          "d528ecd9b696b54c907a9ed045447a79bb408ec39b68df504bb51f459bc3ffc9",
          "eecf41253136e5f99966f21881fd656ebc4345405c520dbc063465b521409933"
        ],
        [
          "49370a4b5f43412ea25f514e8ecdad05266115e4a7ecb1387231808f8b45963",
          "758f3f41afd6ed428b3081b0512fd62a54c3f3afbb5b6764b653052a12949c9a"
        ],
        [
          "77f230936ee88cbbd73df930d64702ef881d811e0e1498e2f1c13eb1fc345d74",
          "958ef42a7886b6400a08266e9ba1b37896c95330d97077cbbe8eb3c7671c60d6"
        ],
        [
          "f2dac991cc4ce4b9ea44887e5c7c0bce58c80074ab9d4dbaeb28531b7739f530",
          "e0dedc9b3b2f8dad4da1f32dec2531df9eb5fbeb0598e4fd1a117dba703a3c37"
        ],
        [
          "463b3d9f662621fb1b4be8fbbe2520125a216cdfc9dae3debcba4850c690d45b",
          "5ed430d78c296c3543114306dd8622d7c622e27c970a1de31cb377b01af7307e"
        ],
        [
          "f16f804244e46e2a09232d4aff3b59976b98fac14328a2d1a32496b49998f247",
          "cedabd9b82203f7e13d206fcdf4e33d92a6c53c26e5cce26d6579962c4e31df6"
        ],
        [
          "caf754272dc84563b0352b7a14311af55d245315ace27c65369e15f7151d41d1",
          "cb474660ef35f5f2a41b643fa5e460575f4fa9b7962232a5c32f908318a04476"
        ],
        [
          "2600ca4b282cb986f85d0f1709979d8b44a09c07cb86d7c124497bc86f082120",
          "4119b88753c15bd6a693b03fcddbb45d5ac6be74ab5f0ef44b0be9475a7e4b40"
        ],
        [
          "7635ca72d7e8432c338ec53cd12220bc01c48685e24f7dc8c602a7746998e435",
          "91b649609489d613d1d5e590f78e6d74ecfc061d57048bad9e76f302c5b9c61"
        ],
        [
          "754e3239f325570cdbbf4a87deee8a66b7f2b33479d468fbc1a50743bf56cc18",
          "673fb86e5bda30fb3cd0ed304ea49a023ee33d0197a695d0c5d98093c536683"
        ],
        [
          "e3e6bd1071a1e96aff57859c82d570f0330800661d1c952f9fe2694691d9b9e8",
          "59c9e0bba394e76f40c0aa58379a3cb6a5a2283993e90c4167002af4920e37f5"
        ],
        [
          "186b483d056a033826ae73d88f732985c4ccb1f32ba35f4b4cc47fdcf04aa6eb",
          "3b952d32c67cf77e2e17446e204180ab21fb8090895138b4a4a797f86e80888b"
        ],
        [
          "df9d70a6b9876ce544c98561f4be4f725442e6d2b737d9c91a8321724ce0963f",
          "55eb2dafd84d6ccd5f862b785dc39d4ab157222720ef9da217b8c45cf2ba2417"
        ],
        [
          "5edd5cc23c51e87a497ca815d5dce0f8ab52554f849ed8995de64c5f34ce7143",
          "efae9c8dbc14130661e8cec030c89ad0c13c66c0d17a2905cdc706ab7399a868"
        ],
        [
          "290798c2b6476830da12fe02287e9e777aa3fba1c355b17a722d362f84614fba",
          "e38da76dcd440621988d00bcf79af25d5b29c094db2a23146d003afd41943e7a"
        ],
        [
          "af3c423a95d9f5b3054754efa150ac39cd29552fe360257362dfdecef4053b45",
          "f98a3fd831eb2b749a93b0e6f35cfb40c8cd5aa667a15581bc2feded498fd9c6"
        ],
        [
          "766dbb24d134e745cccaa28c99bf274906bb66b26dcf98df8d2fed50d884249a",
          "744b1152eacbe5e38dcc887980da38b897584a65fa06cedd2c924f97cbac5996"
        ],
        [
          "59dbf46f8c94759ba21277c33784f41645f7b44f6c596a58ce92e666191abe3e",
          "c534ad44175fbc300f4ea6ce648309a042ce739a7919798cd85e216c4a307f6e"
        ],
        [
          "f13ada95103c4537305e691e74e9a4a8dd647e711a95e73cb62dc6018cfd87b8",
          "e13817b44ee14de663bf4bc808341f326949e21a6a75c2570778419bdaf5733d"
        ],
        [
          "7754b4fa0e8aced06d4167a2c59cca4cda1869c06ebadfb6488550015a88522c",
          "30e93e864e669d82224b967c3020b8fa8d1e4e350b6cbcc537a48b57841163a2"
        ],
        [
          "948dcadf5990e048aa3874d46abef9d701858f95de8041d2a6828c99e2262519",
          "e491a42537f6e597d5d28a3224b1bc25df9154efbd2ef1d2cbba2cae5347d57e"
        ],
        [
          "7962414450c76c1689c7b48f8202ec37fb224cf5ac0bfa1570328a8a3d7c77ab",
          "100b610ec4ffb4760d5c1fc133ef6f6b12507a051f04ac5760afa5b29db83437"
        ],
        [
          "3514087834964b54b15b160644d915485a16977225b8847bb0dd085137ec47ca",
          "ef0afbb2056205448e1652c48e8127fc6039e77c15c2378b7e7d15a0de293311"
        ],
        [
          "d3cc30ad6b483e4bc79ce2c9dd8bc54993e947eb8df787b442943d3f7b527eaf",
          "8b378a22d827278d89c5e9be8f9508ae3c2ad46290358630afb34db04eede0a4"
        ],
        [
          "1624d84780732860ce1c78fcbfefe08b2b29823db913f6493975ba0ff4847610",
          "68651cf9b6da903e0914448c6cd9d4ca896878f5282be4c8cc06e2a404078575"
        ],
        [
          "733ce80da955a8a26902c95633e62a985192474b5af207da6df7b4fd5fc61cd4",
          "f5435a2bd2badf7d485a4d8b8db9fcce3e1ef8e0201e4578c54673bc1dc5ea1d"
        ],
        [
          "15d9441254945064cf1a1c33bbd3b49f8966c5092171e699ef258dfab81c045c",
          "d56eb30b69463e7234f5137b73b84177434800bacebfc685fc37bbe9efe4070d"
        ],
        [
          "a1d0fcf2ec9de675b612136e5ce70d271c21417c9d2b8aaaac138599d0717940",
          "edd77f50bcb5a3cab2e90737309667f2641462a54070f3d519212d39c197a629"
        ],
        [
          "e22fbe15c0af8ccc5780c0735f84dbe9a790badee8245c06c7ca37331cb36980",
          "a855babad5cd60c88b430a69f53a1a7a38289154964799be43d06d77d31da06"
        ],
        [
          "311091dd9860e8e20ee13473c1155f5f69635e394704eaa74009452246cfa9b3",
          "66db656f87d1f04fffd1f04788c06830871ec5a64feee685bd80f0b1286d8374"
        ],
        [
          "34c1fd04d301be89b31c0442d3e6ac24883928b45a9340781867d4232ec2dbdf",
          "9414685e97b1b5954bd46f730174136d57f1ceeb487443dc5321857ba73abee"
        ],
        [
          "f219ea5d6b54701c1c14de5b557eb42a8d13f3abbcd08affcc2a5e6b049b8d63",
          "4cb95957e83d40b0f73af4544cccf6b1f4b08d3c07b27fb8d8c2962a400766d1"
        ],
        [
          "d7b8740f74a8fbaab1f683db8f45de26543a5490bca627087236912469a0b448",
          "fa77968128d9c92ee1010f337ad4717eff15db5ed3c049b3411e0315eaa4593b"
        ],
        [
          "32d31c222f8f6f0ef86f7c98d3a3335ead5bcd32abdd94289fe4d3091aa824bf",
          "5f3032f5892156e39ccd3d7915b9e1da2e6dac9e6f26e961118d14b8462e1661"
        ],
        [
          "7461f371914ab32671045a155d9831ea8793d77cd59592c4340f86cbc18347b5",
          "8ec0ba238b96bec0cbdddcae0aa442542eee1ff50c986ea6b39847b3cc092ff6"
        ],
        [
          "ee079adb1df1860074356a25aa38206a6d716b2c3e67453d287698bad7b2b2d6",
          "8dc2412aafe3be5c4c5f37e0ecc5f9f6a446989af04c4e25ebaac479ec1c8c1e"
        ],
        [
          "16ec93e447ec83f0467b18302ee620f7e65de331874c9dc72bfd8616ba9da6b5",
          "5e4631150e62fb40d0e8c2a7ca5804a39d58186a50e497139626778e25b0674d"
        ],
        [
          "eaa5f980c245f6f038978290afa70b6bd8855897f98b6aa485b96065d537bd99",
          "f65f5d3e292c2e0819a528391c994624d784869d7e6ea67fb18041024edc07dc"
        ],
        [
          "78c9407544ac132692ee1910a02439958ae04877151342ea96c4b6b35a49f51",
          "f3e0319169eb9b85d5404795539a5e68fa1fbd583c064d2462b675f194a3ddb4"
        ],
        [
          "494f4be219a1a77016dcd838431aea0001cdc8ae7a6fc688726578d9702857a5",
          "42242a969283a5f339ba7f075e36ba2af925ce30d767ed6e55f4b031880d562c"
        ],
        [
          "a598a8030da6d86c6bc7f2f5144ea549d28211ea58faa70ebf4c1e665c1fe9b5",
          "204b5d6f84822c307e4b4a7140737aec23fc63b65b35f86a10026dbd2d864e6b"
        ],
        [
          "c41916365abb2b5d09192f5f2dbeafec208f020f12570a184dbadc3e58595997",
          "4f14351d0087efa49d245b328984989d5caf9450f34bfc0ed16e96b58fa9913"
        ],
        [
          "841d6063a586fa475a724604da03bc5b92a2e0d2e0a36acfe4c73a5514742881",
          "73867f59c0659e81904f9a1c7543698e62562d6744c169ce7a36de01a8d6154"
        ],
        [
          "5e95bb399a6971d376026947f89bde2f282b33810928be4ded112ac4d70e20d5",
          "39f23f366809085beebfc71181313775a99c9aed7d8ba38b161384c746012865"
        ],
        [
          "36e4641a53948fd476c39f8a99fd974e5ec07564b5315d8bf99471bca0ef2f66",
          "d2424b1b1abe4eb8164227b085c9aa9456ea13493fd563e06fd51cf5694c78fc"
        ],
        [
          "336581ea7bfbbb290c191a2f507a41cf5643842170e914faeab27c2c579f726",
          "ead12168595fe1be99252129b6e56b3391f7ab1410cd1e0ef3dcdcabd2fda224"
        ],
        [
          "8ab89816dadfd6b6a1f2634fcf00ec8403781025ed6890c4849742706bd43ede",
          "6fdcef09f2f6d0a044e654aef624136f503d459c3e89845858a47a9129cdd24e"
        ],
        [
          "1e33f1a746c9c5778133344d9299fcaa20b0938e8acff2544bb40284b8c5fb94",
          "60660257dd11b3aa9c8ed618d24edff2306d320f1d03010e33a7d2057f3b3b6"
        ],
        [
          "85b7c1dcb3cec1b7ee7f30ded79dd20a0ed1f4cc18cbcfcfa410361fd8f08f31",
          "3d98a9cdd026dd43f39048f25a8847f4fcafad1895d7a633c6fed3c35e999511"
        ],
        [
          "29df9fbd8d9e46509275f4b125d6d45d7fbe9a3b878a7af872a2800661ac5f51",
          "b4c4fe99c775a606e2d8862179139ffda61dc861c019e55cd2876eb2a27d84b"
        ],
        [
          "a0b1cae06b0a847a3fea6e671aaf8adfdfe58ca2f768105c8082b2e449fce252",
          "ae434102edde0958ec4b19d917a6a28e6b72da1834aff0e650f049503a296cf2"
        ],
        [
          "4e8ceafb9b3e9a136dc7ff67e840295b499dfb3b2133e4ba113f2e4c0e121e5",
          "cf2174118c8b6d7a4b48f6d534ce5c79422c086a63460502b827ce62a326683c"
        ],
        [
          "d24a44e047e19b6f5afb81c7ca2f69080a5076689a010919f42725c2b789a33b",
          "6fb8d5591b466f8fc63db50f1c0f1c69013f996887b8244d2cdec417afea8fa3"
        ],
        [
          "ea01606a7a6c9cdd249fdfcfacb99584001edd28abbab77b5104e98e8e3b35d4",
          "322af4908c7312b0cfbfe369f7a7b3cdb7d4494bc2823700cfd652188a3ea98d"
        ],
        [
          "af8addbf2b661c8a6c6328655eb96651252007d8c5ea31be4ad196de8ce2131f",
          "6749e67c029b85f52a034eafd096836b2520818680e26ac8f3dfbcdb71749700"
        ],
        [
          "e3ae1974566ca06cc516d47e0fb165a674a3dabcfca15e722f0e3450f45889",
          "2aeabe7e4531510116217f07bf4d07300de97e4874f81f533420a72eeb0bd6a4"
        ],
        [
          "591ee355313d99721cf6993ffed1e3e301993ff3ed258802075ea8ced397e246",
          "b0ea558a113c30bea60fc4775460c7901ff0b053d25ca2bdeee98f1a4be5d196"
        ],
        [
          "11396d55fda54c49f19aa97318d8da61fa8584e47b084945077cf03255b52984",
          "998c74a8cd45ac01289d5833a7beb4744ff536b01b257be4c5767bea93ea57a4"
        ],
        [
          "3c5d2a1ba39c5a1790000738c9e0c40b8dcdfd5468754b6405540157e017aa7a",
          "b2284279995a34e2f9d4de7396fc18b80f9b8b9fdd270f6661f79ca4c81bd257"
        ],
        [
          "cc8704b8a60a0defa3a99a7299f2e9c3fbc395afb04ac078425ef8a1793cc030",
          "bdd46039feed17881d1e0862db347f8cf395b74fc4bcdc4e940b74e3ac1f1b13"
        ],
        [
          "c533e4f7ea8555aacd9777ac5cad29b97dd4defccc53ee7ea204119b2889b197",
          "6f0a256bc5efdf429a2fb6242f1a43a2d9b925bb4a4b3a26bb8e0f45eb596096"
        ],
        [
          "c14f8f2ccb27d6f109f6d08d03cc96a69ba8c34eec07bbcf566d48e33da6593",
          "c359d6923bb398f7fd4473e16fe1c28475b740dd098075e6c0e8649113dc3a38"
        ],
        [
          "a6cbc3046bc6a450bac24789fa17115a4c9739ed75f8f21ce441f72e0b90e6ef",
          "21ae7f4680e889bb130619e2c0f95a360ceb573c70603139862afd617fa9b9f"
        ],
        [
          "347d6d9a02c48927ebfb86c1359b1caf130a3c0267d11ce6344b39f99d43cc38",
          "60ea7f61a353524d1c987f6ecec92f086d565ab687870cb12689ff1e31c74448"
        ],
        [
          "da6545d2181db8d983f7dcb375ef5866d47c67b1bf31c8cf855ef7437b72656a",
          "49b96715ab6878a79e78f07ce5680c5d6673051b4935bd897fea824b77dc208a"
        ],
        [
          "c40747cc9d012cb1a13b8148309c6de7ec25d6945d657146b9d5994b8feb1111",
          "5ca560753be2a12fc6de6caf2cb489565db936156b9514e1bb5e83037e0fa2d4"
        ],
        [
          "4e42c8ec82c99798ccf3a610be870e78338c7f713348bd34c8203ef4037f3502",
          "7571d74ee5e0fb92a7a8b33a07783341a5492144cc54bcc40a94473693606437"
        ],
        [
          "3775ab7089bc6af823aba2e1af70b236d251cadb0c86743287522a1b3b0dedea",
          "be52d107bcfa09d8bcb9736a828cfa7fac8db17bf7a76a2c42ad961409018cf7"
        ],
        [
          "cee31cbf7e34ec379d94fb814d3d775ad954595d1314ba8846959e3e82f74e26",
          "8fd64a14c06b589c26b947ae2bcf6bfa0149ef0be14ed4d80f448a01c43b1c6d"
        ],
        [
          "b4f9eaea09b6917619f6ea6a4eb5464efddb58fd45b1ebefcdc1a01d08b47986",
          "39e5c9925b5a54b07433a4f18c61726f8bb131c012ca542eb24a8ac07200682a"
        ],
        [
          "d4263dfc3d2df923a0179a48966d30ce84e2515afc3dccc1b77907792ebcc60e",
          "62dfaf07a0f78feb30e30d6295853ce189e127760ad6cf7fae164e122a208d54"
        ],
        [
          "48457524820fa65a4f8d35eb6930857c0032acc0a4a2de422233eeda897612c4",
          "25a748ab367979d98733c38a1fa1c2e7dc6cc07db2d60a9ae7a76aaa49bd0f77"
        ],
        [
          "dfeeef1881101f2cb11644f3a2afdfc2045e19919152923f367a1767c11cceda",
          "ecfb7056cf1de042f9420bab396793c0c390bde74b4bbdff16a83ae09a9a7517"
        ],
        [
          "6d7ef6b17543f8373c573f44e1f389835d89bcbc6062ced36c82df83b8fae859",
          "cd450ec335438986dfefa10c57fea9bcc521a0959b2d80bbf74b190dca712d10"
        ],
        [
          "e75605d59102a5a2684500d3b991f2e3f3c88b93225547035af25af66e04541f",
          "f5c54754a8f71ee540b9b48728473e314f729ac5308b06938360990e2bfad125"
        ],
        [
          "eb98660f4c4dfaa06a2be453d5020bc99a0c2e60abe388457dd43fefb1ed620c",
          "6cb9a8876d9cb8520609af3add26cd20a0a7cd8a9411131ce85f44100099223e"
        ],
        [
          "13e87b027d8514d35939f2e6892b19922154596941888336dc3563e3b8dba942",
          "fef5a3c68059a6dec5d624114bf1e91aac2b9da568d6abeb2570d55646b8adf1"
        ],
        [
          "ee163026e9fd6fe017c38f06a5be6fc125424b371ce2708e7bf4491691e5764a",
          "1acb250f255dd61c43d94ccc670d0f58f49ae3fa15b96623e5430da0ad6c62b2"
        ],
        [
          "b268f5ef9ad51e4d78de3a750c2dc89b1e626d43505867999932e5db33af3d80",
          "5f310d4b3c99b9ebb19f77d41c1dee018cf0d34fd4191614003e945a1216e423"
        ],
        [
          "ff07f3118a9df035e9fad85eb6c7bfe42b02f01ca99ceea3bf7ffdba93c4750d",
          "438136d603e858a3a5c440c38eccbaddc1d2942114e2eddd4740d098ced1f0d8"
        ],
        [
          "8d8b9855c7c052a34146fd20ffb658bea4b9f69e0d825ebec16e8c3ce2b526a1",
          "cdb559eedc2d79f926baf44fb84ea4d44bcf50fee51d7ceb30e2e7f463036758"
        ],
        [
          "52db0b5384dfbf05bfa9d472d7ae26dfe4b851ceca91b1eba54263180da32b63",
          "c3b997d050ee5d423ebaf66a6db9f57b3180c902875679de924b69d84a7b375"
        ],
        [
          "e62f9490d3d51da6395efd24e80919cc7d0f29c3f3fa48c6fff543becbd43352",
          "6d89ad7ba4876b0b22c2ca280c682862f342c8591f1daf5170e07bfd9ccafa7d"
        ],
        [
          "7f30ea2476b399b4957509c88f77d0191afa2ff5cb7b14fd6d8e7d65aaab1193",
          "ca5ef7d4b231c94c3b15389a5f6311e9daff7bb67b103e9880ef4bff637acaec"
        ],
        [
          "5098ff1e1d9f14fb46a210fada6c903fef0fb7b4a1dd1d9ac60a0361800b7a00",
          "9731141d81fc8f8084d37c6e7542006b3ee1b40d60dfe5362a5b132fd17ddc0"
        ],
        [
          "32b78c7de9ee512a72895be6b9cbefa6e2f3c4ccce445c96b9f2c81e2778ad58",
          "ee1849f513df71e32efc3896ee28260c73bb80547ae2275ba497237794c8753c"
        ],
        [
          "e2cb74fddc8e9fbcd076eef2a7c72b0ce37d50f08269dfc074b581550547a4f7",
          "d3aa2ed71c9dd2247a62df062736eb0baddea9e36122d2be8641abcb005cc4a4"
        ],
        [
          "8438447566d4d7bedadc299496ab357426009a35f235cb141be0d99cd10ae3a8",
          "c4e1020916980a4da5d01ac5e6ad330734ef0d7906631c4f2390426b2edd791f"
        ],
        [
          "4162d488b89402039b584c6fc6c308870587d9c46f660b878ab65c82c711d67e",
          "67163e903236289f776f22c25fb8a3afc1732f2b84b4e95dbda47ae5a0852649"
        ],
        [
          "3fad3fa84caf0f34f0f89bfd2dcf54fc175d767aec3e50684f3ba4a4bf5f683d",
          "cd1bc7cb6cc407bb2f0ca647c718a730cf71872e7d0d2a53fa20efcdfe61826"
        ],
        [
          "674f2600a3007a00568c1a7ce05d0816c1fb84bf1370798f1c69532faeb1a86b",
          "299d21f9413f33b3edf43b257004580b70db57da0b182259e09eecc69e0d38a5"
        ],
        [
          "d32f4da54ade74abb81b815ad1fb3b263d82d6c692714bcff87d29bd5ee9f08f",
          "f9429e738b8e53b968e99016c059707782e14f4535359d582fc416910b3eea87"
        ],
        [
          "30e4e670435385556e593657135845d36fbb6931f72b08cb1ed954f1e3ce3ff6",
          "462f9bce619898638499350113bbc9b10a878d35da70740dc695a559eb88db7b"
        ],
        [
          "be2062003c51cc3004682904330e4dee7f3dcd10b01e580bf1971b04d4cad297",
          "62188bc49d61e5428573d48a74e1c655b1c61090905682a0d5558ed72dccb9bc"
        ],
        [
          "93144423ace3451ed29e0fb9ac2af211cb6e84a601df5993c419859fff5df04a",
          "7c10dfb164c3425f5c71a3f9d7992038f1065224f72bb9d1d902a6d13037b47c"
        ],
        [
          "b015f8044f5fcbdcf21ca26d6c34fb8197829205c7b7d2a7cb66418c157b112c",
          "ab8c1e086d04e813744a655b2df8d5f83b3cdc6faa3088c1d3aea1454e3a1d5f"
        ],
        [
          "d5e9e1da649d97d89e4868117a465a3a4f8a18de57a140d36b3f2af341a21b52",
          "4cb04437f391ed73111a13cc1d4dd0db1693465c2240480d8955e8592f27447a"
        ],
        [
          "d3ae41047dd7ca065dbf8ed77b992439983005cd72e16d6f996a5316d36966bb",
          "bd1aeb21ad22ebb22a10f0303417c6d964f8cdd7df0aca614b10dc14d125ac46"
        ],
        [
          "463e2763d885f958fc66cdd22800f0a487197d0a82e377b49f80af87c897b065",
          "bfefacdb0e5d0fd7df3a311a94de062b26b80c61fbc97508b79992671ef7ca7f"
        ],
        [
          "7985fdfd127c0567c6f53ec1bb63ec3158e597c40bfe747c83cddfc910641917",
          "603c12daf3d9862ef2b25fe1de289aed24ed291e0ec6708703a5bd567f32ed03"
        ],
        [
          "74a1ad6b5f76e39db2dd249410eac7f99e74c59cb83d2d0ed5ff1543da7703e9",
          "cc6157ef18c9c63cd6193d83631bbea0093e0968942e8c33d5737fd790e0db08"
        ],
        [
          "30682a50703375f602d416664ba19b7fc9bab42c72747463a71d0896b22f6da3",
          "553e04f6b018b4fa6c8f39e7f311d3176290d0e0f19ca73f17714d9977a22ff8"
        ],
        [
          "9e2158f0d7c0d5f26c3791efefa79597654e7a2b2464f52b1ee6c1347769ef57",
          "712fcdd1b9053f09003a3481fa7762e9ffd7c8ef35a38509e2fbf2629008373"
        ],
        [
          "176e26989a43c9cfeba4029c202538c28172e566e3c4fce7322857f3be327d66",
          "ed8cc9d04b29eb877d270b4878dc43c19aefd31f4eee09ee7b47834c1fa4b1c3"
        ],
        [
          "75d46efea3771e6e68abb89a13ad747ecf1892393dfc4f1b7004788c50374da8",
          "9852390a99507679fd0b86fd2b39a868d7efc22151346e1a3ca4726586a6bed8"
        ],
        [
          "809a20c67d64900ffb698c4c825f6d5f2310fb0451c869345b7319f645605721",
          "9e994980d9917e22b76b061927fa04143d096ccc54963e6a5ebfa5f3f8e286c1"
        ],
        [
          "1b38903a43f7f114ed4500b4eac7083fdefece1cf29c63528d563446f972c180",
          "4036edc931a60ae889353f77fd53de4a2708b26b6f5da72ad3394119daf408f9"
        ]
      ]
    }
  }), secp256k1;
}
(function(t) {
  var e = t, n = hash$2, a = curve, c = utils$l, o = c.assert;
  function u(x) {
    x.type === "short" ? this.curve = new a.short(x) : x.type === "edwards" ? this.curve = new a.edwards(x) : this.curve = new a.mont(x), this.g = this.curve.g, this.n = this.curve.n, this.hash = x.hash, o(this.g.validate(), "Invalid curve"), o(this.g.mul(this.n).isInfinity(), "Invalid curve, G*N != O");
  }
  e.PresetCurve = u;
  function h(x, l) {
    Object.defineProperty(e, x, {
      configurable: !0,
      enumerable: !0,
      get: function() {
        var b = new u(l);
        return Object.defineProperty(e, x, {
          configurable: !0,
          enumerable: !0,
          value: b
        }), b;
      }
    });
  }
  h("p192", {
    type: "short",
    prime: "p192",
    p: "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff",
    a: "ffffffff ffffffff ffffffff fffffffe ffffffff fffffffc",
    b: "64210519 e59c80e7 0fa7e9ab 72243049 feb8deec c146b9b1",
    n: "ffffffff ffffffff ffffffff 99def836 146bc9b1 b4d22831",
    hash: n.sha256,
    gRed: !1,
    g: [
      "188da80e b03090f6 7cbf20eb 43a18800 f4ff0afd 82ff1012",
      "07192b95 ffc8da78 631011ed 6b24cdd5 73f977a1 1e794811"
    ]
  }), h("p224", {
    type: "short",
    prime: "p224",
    p: "ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001",
    a: "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff fffffffe",
    b: "b4050a85 0c04b3ab f5413256 5044b0b7 d7bfd8ba 270b3943 2355ffb4",
    n: "ffffffff ffffffff ffffffff ffff16a2 e0b8f03e 13dd2945 5c5c2a3d",
    hash: n.sha256,
    gRed: !1,
    g: [
      "b70e0cbd 6bb4bf7f 321390b9 4a03c1d3 56c21122 343280d6 115c1d21",
      "bd376388 b5f723fb 4c22dfe6 cd4375a0 5a074764 44d58199 85007e34"
    ]
  }), h("p256", {
    type: "short",
    prime: null,
    p: "ffffffff 00000001 00000000 00000000 00000000 ffffffff ffffffff ffffffff",
    a: "ffffffff 00000001 00000000 00000000 00000000 ffffffff ffffffff fffffffc",
    b: "5ac635d8 aa3a93e7 b3ebbd55 769886bc 651d06b0 cc53b0f6 3bce3c3e 27d2604b",
    n: "ffffffff 00000000 ffffffff ffffffff bce6faad a7179e84 f3b9cac2 fc632551",
    hash: n.sha256,
    gRed: !1,
    g: [
      "6b17d1f2 e12c4247 f8bce6e5 63a440f2 77037d81 2deb33a0 f4a13945 d898c296",
      "4fe342e2 fe1a7f9b 8ee7eb4a 7c0f9e16 2bce3357 6b315ece cbb64068 37bf51f5"
    ]
  }), h("p384", {
    type: "short",
    prime: null,
    p: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe ffffffff 00000000 00000000 ffffffff",
    a: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe ffffffff 00000000 00000000 fffffffc",
    b: "b3312fa7 e23ee7e4 988e056b e3f82d19 181d9c6e fe814112 0314088f 5013875a c656398d 8a2ed19d 2a85c8ed d3ec2aef",
    n: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff c7634d81 f4372ddf 581a0db2 48b0a77a ecec196a ccc52973",
    hash: n.sha384,
    gRed: !1,
    g: [
      "aa87ca22 be8b0537 8eb1c71e f320ad74 6e1d3b62 8ba79b98 59f741e0 82542a38 5502f25d bf55296c 3a545e38 72760ab7",
      "3617de4a 96262c6f 5d9e98bf 9292dc29 f8f41dbd 289a147c e9da3113 b5f0b8c0 0a60b1ce 1d7e819d 7a431d7c 90ea0e5f"
    ]
  }), h("p521", {
    type: "short",
    prime: null,
    p: "000001ff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff",
    a: "000001ff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffc",
    b: "00000051 953eb961 8e1c9a1f 929a21a0 b68540ee a2da725b 99b315f3 b8b48991 8ef109e1 56193951 ec7e937b 1652c0bd 3bb1bf07 3573df88 3d2c34f1 ef451fd4 6b503f00",
    n: "000001ff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffa 51868783 bf2f966b 7fcc0148 f709a5d0 3bb5c9b8 899c47ae bb6fb71e 91386409",
    hash: n.sha512,
    gRed: !1,
    g: [
      "000000c6 858e06b7 0404e9cd 9e3ecb66 2395b442 9c648139 053fb521 f828af60 6b4d3dba a14b5e77 efe75928 fe1dc127 a2ffa8de 3348b3c1 856a429b f97e7e31 c2e5bd66",
      "00000118 39296a78 9a3bc004 5c8a5fb4 2c7d1bd9 98f54449 579b4468 17afbd17 273e662c 97ee7299 5ef42640 c550b901 3fad0761 353c7086 a272c240 88be9476 9fd16650"
    ]
  }), h("curve25519", {
    type: "mont",
    prime: "p25519",
    p: "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed",
    a: "76d06",
    b: "1",
    n: "1000000000000000 0000000000000000 14def9dea2f79cd6 5812631a5cf5d3ed",
    hash: n.sha256,
    gRed: !1,
    g: [
      "9"
    ]
  }), h("ed25519", {
    type: "edwards",
    prime: "p25519",
    p: "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed",
    a: "-1",
    c: "1",
    // -121665 * (121666^(-1)) (mod P)
    d: "52036cee2b6ffe73 8cc740797779e898 00700a4d4141d8ab 75eb4dca135978a3",
    n: "1000000000000000 0000000000000000 14def9dea2f79cd6 5812631a5cf5d3ed",
    hash: n.sha256,
    gRed: !1,
    g: [
      "216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51a",
      // 4/5
      "6666666666666666666666666666666666666666666666666666666666666658"
    ]
  });
  var p;
  try {
    p = requireSecp256k1();
  } catch {
    p = void 0;
  }
  h("secp256k1", {
    type: "short",
    prime: "k256",
    p: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f",
    a: "0",
    b: "7",
    n: "ffffffff ffffffff ffffffff fffffffe baaedce6 af48a03b bfd25e8c d0364141",
    h: "1",
    hash: n.sha256,
    // Precomputed endomorphism
    beta: "7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee",
    lambda: "5363ad4cc05c30e0a5261c028812645a122e22ea20816678df02967c1b23bd72",
    basis: [
      {
        a: "3086d221a7d46bcde86c90e49284eb15",
        b: "-e4437ed6010e88286f547fa90abfe4c3"
      },
      {
        a: "114ca50f7a8e2f3f657c1108d9d44cfd8",
        b: "3086d221a7d46bcde86c90e49284eb15"
      }
    ],
    gRed: !1,
    g: [
      "79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798",
      "483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8",
      p
    ]
  });
})(curves$1);
var hash$1 = hash$2, utils$5 = utils$k, assert$5 = minimalisticAssert;
function HmacDRBG(t) {
  if (!(this instanceof HmacDRBG))
    return new HmacDRBG(t);
  this.hash = t.hash, this.predResist = !!t.predResist, this.outLen = this.hash.outSize, this.minEntropy = t.minEntropy || this.hash.hmacStrength, this._reseed = null, this.reseedInterval = null, this.K = null, this.V = null;
  var e = utils$5.toArray(t.entropy, t.entropyEnc || "hex"), n = utils$5.toArray(t.nonce, t.nonceEnc || "hex"), a = utils$5.toArray(t.pers, t.persEnc || "hex");
  assert$5(
    e.length >= this.minEntropy / 8,
    "Not enough entropy. Minimum is: " + this.minEntropy + " bits"
  ), this._init(e, n, a);
}
var hmacDrbg = HmacDRBG;
HmacDRBG.prototype._init = function(e, n, a) {
  var c = e.concat(n).concat(a);
  this.K = new Array(this.outLen / 8), this.V = new Array(this.outLen / 8);
  for (var o = 0; o < this.V.length; o++)
    this.K[o] = 0, this.V[o] = 1;
  this._update(c), this._reseed = 1, this.reseedInterval = 281474976710656;
};
HmacDRBG.prototype._hmac = function() {
  return new hash$1.hmac(this.hash, this.K);
};
HmacDRBG.prototype._update = function(e) {
  var n = this._hmac().update(this.V).update([0]);
  e && (n = n.update(e)), this.K = n.digest(), this.V = this._hmac().update(this.V).digest(), e && (this.K = this._hmac().update(this.V).update([1]).update(e).digest(), this.V = this._hmac().update(this.V).digest());
};
HmacDRBG.prototype.reseed = function(e, n, a, c) {
  typeof n != "string" && (c = a, a = n, n = null), e = utils$5.toArray(e, n), a = utils$5.toArray(a, c), assert$5(
    e.length >= this.minEntropy / 8,
    "Not enough entropy. Minimum is: " + this.minEntropy + " bits"
  ), this._update(e.concat(a || [])), this._reseed = 1;
};
HmacDRBG.prototype.generate = function(e, n, a, c) {
  if (this._reseed > this.reseedInterval)
    throw new Error("Reseed is required");
  typeof n != "string" && (c = a, a = n, n = null), a && (a = utils$5.toArray(a, c || "hex"), this._update(a));
  for (var o = []; o.length < e; )
    this.V = this._hmac().update(this.V).digest(), o = o.concat(this.V);
  var u = o.slice(0, e);
  return this._update(a), this._reseed++, utils$5.encode(u, n);
};
var BN$5 = bnExports$1, utils$4 = utils$l, assert$4 = utils$4.assert;
function KeyPair$2(t, e) {
  this.ec = t, this.priv = null, this.pub = null, e.priv && this._importPrivate(e.priv, e.privEnc), e.pub && this._importPublic(e.pub, e.pubEnc);
}
var key$1 = KeyPair$2;
KeyPair$2.fromPublic = function(e, n, a) {
  return n instanceof KeyPair$2 ? n : new KeyPair$2(e, {
    pub: n,
    pubEnc: a
  });
};
KeyPair$2.fromPrivate = function(e, n, a) {
  return n instanceof KeyPair$2 ? n : new KeyPair$2(e, {
    priv: n,
    privEnc: a
  });
};
KeyPair$2.prototype.validate = function() {
  var e = this.getPublic();
  return e.isInfinity() ? { result: !1, reason: "Invalid public key" } : e.validate() ? e.mul(this.ec.curve.n).isInfinity() ? { result: !0, reason: null } : { result: !1, reason: "Public key * N != O" } : { result: !1, reason: "Public key is not a point" };
};
KeyPair$2.prototype.getPublic = function(e, n) {
  return typeof e == "string" && (n = e, e = null), this.pub || (this.pub = this.ec.g.mul(this.priv)), n ? this.pub.encode(n, e) : this.pub;
};
KeyPair$2.prototype.getPrivate = function(e) {
  return e === "hex" ? this.priv.toString(16, 2) : this.priv;
};
KeyPair$2.prototype._importPrivate = function(e, n) {
  this.priv = new BN$5(e, n || 16), this.priv = this.priv.umod(this.ec.curve.n);
};
KeyPair$2.prototype._importPublic = function(e, n) {
  if (e.x || e.y) {
    this.ec.curve.type === "mont" ? assert$4(e.x, "Need x coordinate") : (this.ec.curve.type === "short" || this.ec.curve.type === "edwards") && assert$4(e.x && e.y, "Need both x and y coordinate"), this.pub = this.ec.curve.point(e.x, e.y);
    return;
  }
  this.pub = this.ec.curve.decodePoint(e, n);
};
KeyPair$2.prototype.derive = function(e) {
  return e.validate() || assert$4(e.validate(), "public point not validated"), e.mul(this.priv).getX();
};
KeyPair$2.prototype.sign = function(e, n, a) {
  return this.ec.sign(e, this, n, a);
};
KeyPair$2.prototype.verify = function(e, n) {
  return this.ec.verify(e, n, this);
};
KeyPair$2.prototype.inspect = function() {
  return "<Key priv: " + (this.priv && this.priv.toString(16, 2)) + " pub: " + (this.pub && this.pub.inspect()) + " >";
};
var BN$4 = bnExports$1, utils$3 = utils$l, assert$3 = utils$3.assert;
function Signature$2(t, e) {
  if (t instanceof Signature$2)
    return t;
  this._importDER(t, e) || (assert$3(t.r && t.s, "Signature without r or s"), this.r = new BN$4(t.r, 16), this.s = new BN$4(t.s, 16), t.recoveryParam === void 0 ? this.recoveryParam = null : this.recoveryParam = t.recoveryParam);
}
var signature$1 = Signature$2;
function Position() {
  this.place = 0;
}
function getLength(t, e) {
  var n = t[e.place++];
  if (!(n & 128))
    return n;
  var a = n & 15;
  if (a === 0 || a > 4)
    return !1;
  for (var c = 0, o = 0, u = e.place; o < a; o++, u++)
    c <<= 8, c |= t[u], c >>>= 0;
  return c <= 127 ? !1 : (e.place = u, c);
}
function rmPadding(t) {
  for (var e = 0, n = t.length - 1; !t[e] && !(t[e + 1] & 128) && e < n; )
    e++;
  return e === 0 ? t : t.slice(e);
}
Signature$2.prototype._importDER = function(e, n) {
  e = utils$3.toArray(e, n);
  var a = new Position();
  if (e[a.place++] !== 48)
    return !1;
  var c = getLength(e, a);
  if (c === !1 || c + a.place !== e.length || e[a.place++] !== 2)
    return !1;
  var o = getLength(e, a);
  if (o === !1)
    return !1;
  var u = e.slice(a.place, o + a.place);
  if (a.place += o, e[a.place++] !== 2)
    return !1;
  var h = getLength(e, a);
  if (h === !1 || e.length !== h + a.place)
    return !1;
  var p = e.slice(a.place, h + a.place);
  if (u[0] === 0)
    if (u[1] & 128)
      u = u.slice(1);
    else
      return !1;
  if (p[0] === 0)
    if (p[1] & 128)
      p = p.slice(1);
    else
      return !1;
  return this.r = new BN$4(u), this.s = new BN$4(p), this.recoveryParam = null, !0;
};
function constructLength(t, e) {
  if (e < 128) {
    t.push(e);
    return;
  }
  var n = 1 + (Math.log(e) / Math.LN2 >>> 3);
  for (t.push(n | 128); --n; )
    t.push(e >>> (n << 3) & 255);
  t.push(e);
}
Signature$2.prototype.toDER = function(e) {
  var n = this.r.toArray(), a = this.s.toArray();
  for (n[0] & 128 && (n = [0].concat(n)), a[0] & 128 && (a = [0].concat(a)), n = rmPadding(n), a = rmPadding(a); !a[0] && !(a[1] & 128); )
    a = a.slice(1);
  var c = [2];
  constructLength(c, n.length), c = c.concat(n), c.push(2), constructLength(c, a.length);
  var o = c.concat(a), u = [48];
  return constructLength(u, o.length), u = u.concat(o), utils$3.encode(u, e);
};
var ec, hasRequiredEc;
function requireEc() {
  if (hasRequiredEc)
    return ec;
  hasRequiredEc = 1;
  var t = bnExports$1, e = hmacDrbg, n = utils$l, a = curves$1, c = requireBrorand(), o = n.assert, u = key$1, h = signature$1;
  function p(x) {
    if (!(this instanceof p))
      return new p(x);
    typeof x == "string" && (o(
      Object.prototype.hasOwnProperty.call(a, x),
      "Unknown curve " + x
    ), x = a[x]), x instanceof a.PresetCurve && (x = { curve: x }), this.curve = x.curve.curve, this.n = this.curve.n, this.nh = this.n.ushrn(1), this.g = this.curve.g, this.g = x.curve.g, this.g.precompute(x.curve.n.bitLength() + 1), this.hash = x.hash || x.curve.hash;
  }
  return ec = p, p.prototype.keyPair = function(l) {
    return new u(this, l);
  }, p.prototype.keyFromPrivate = function(l, b) {
    return u.fromPrivate(this, l, b);
  }, p.prototype.keyFromPublic = function(l, b) {
    return u.fromPublic(this, l, b);
  }, p.prototype.genKeyPair = function(l) {
    l || (l = {});
    for (var b = new e({
      hash: this.hash,
      pers: l.pers,
      persEnc: l.persEnc || "utf8",
      entropy: l.entropy || c(this.hash.hmacStrength),
      entropyEnc: l.entropy && l.entropyEnc || "utf8",
      nonce: this.n.toArray()
    }), E = this.n.byteLength(), C = this.n.sub(new t(2)); ; ) {
      var q = new t(b.generate(E));
      if (!(q.cmp(C) > 0))
        return q.iaddn(1), this.keyFromPrivate(q);
    }
  }, p.prototype._truncateToN = function(l, b) {
    var E = l.byteLength() * 8 - this.n.bitLength();
    return E > 0 && (l = l.ushrn(E)), !b && l.cmp(this.n) >= 0 ? l.sub(this.n) : l;
  }, p.prototype.sign = function(l, b, E, C) {
    typeof E == "object" && (C = E, E = null), C || (C = {}), b = this.keyFromPrivate(b, E), l = this._truncateToN(new t(l, 16));
    for (var q = this.n.byteLength(), F = b.getPrivate().toArray("be", q), z = l.toArray("be", q), H = new e({
      hash: this.hash,
      entropy: F,
      nonce: z,
      pers: C.pers,
      persEnc: C.persEnc || "utf8"
    }), U = this.n.sub(new t(1)), Y = 0; ; Y++) {
      var ee = C.k ? C.k(Y) : new t(H.generate(this.n.byteLength()));
      if (ee = this._truncateToN(ee, !0), !(ee.cmpn(1) <= 0 || ee.cmp(U) >= 0)) {
        var se = this.g.mul(ee);
        if (!se.isInfinity()) {
          var fe = se.getX(), pe = fe.umod(this.n);
          if (pe.cmpn(0) !== 0) {
            var ue = ee.invm(this.n).mul(pe.mul(b.getPrivate()).iadd(l));
            if (ue = ue.umod(this.n), ue.cmpn(0) !== 0) {
              var ce = (se.getY().isOdd() ? 1 : 0) | (fe.cmp(pe) !== 0 ? 2 : 0);
              return C.canonical && ue.cmp(this.nh) > 0 && (ue = this.n.sub(ue), ce ^= 1), new h({ r: pe, s: ue, recoveryParam: ce });
            }
          }
        }
      }
    }
  }, p.prototype.verify = function(l, b, E, C) {
    l = this._truncateToN(new t(l, 16)), E = this.keyFromPublic(E, C), b = new h(b, "hex");
    var q = b.r, F = b.s;
    if (q.cmpn(1) < 0 || q.cmp(this.n) >= 0 || F.cmpn(1) < 0 || F.cmp(this.n) >= 0)
      return !1;
    var z = F.invm(this.n), H = z.mul(l).umod(this.n), U = z.mul(q).umod(this.n), Y;
    return this.curve._maxwellTrick ? (Y = this.g.jmulAdd(H, E.getPublic(), U), Y.isInfinity() ? !1 : Y.eqXToP(q)) : (Y = this.g.mulAdd(H, E.getPublic(), U), Y.isInfinity() ? !1 : Y.getX().umod(this.n).cmp(q) === 0);
  }, p.prototype.recoverPubKey = function(x, l, b, E) {
    o((3 & b) === b, "The recovery param is more than two bits"), l = new h(l, E);
    var C = this.n, q = new t(x), F = l.r, z = l.s, H = b & 1, U = b >> 1;
    if (F.cmp(this.curve.p.umod(this.curve.n)) >= 0 && U)
      throw new Error("Unable to find sencond key candinate");
    U ? F = this.curve.pointFromX(F.add(this.curve.n), H) : F = this.curve.pointFromX(F, H);
    var Y = l.r.invm(C), ee = C.sub(q).mul(Y).umod(C), se = z.mul(Y).umod(C);
    return this.g.mulAdd(ee, F, se);
  }, p.prototype.getKeyRecoveryParam = function(x, l, b, E) {
    if (l = new h(l, E), l.recoveryParam !== null)
      return l.recoveryParam;
    for (var C = 0; C < 4; C++) {
      var q;
      try {
        q = this.recoverPubKey(x, l, C);
      } catch {
        continue;
      }
      if (q.eq(b))
        return C;
    }
    throw new Error("Unable to find valid recovery factor");
  }, ec;
}
var utils$2 = utils$l, assert$2 = utils$2.assert, parseBytes$2 = utils$2.parseBytes, cachedProperty$1 = utils$2.cachedProperty;
function KeyPair$1(t, e) {
  this.eddsa = t, this._secret = parseBytes$2(e.secret), t.isPoint(e.pub) ? this._pub = e.pub : this._pubBytes = parseBytes$2(e.pub);
}
KeyPair$1.fromPublic = function(e, n) {
  return n instanceof KeyPair$1 ? n : new KeyPair$1(e, { pub: n });
};
KeyPair$1.fromSecret = function(e, n) {
  return n instanceof KeyPair$1 ? n : new KeyPair$1(e, { secret: n });
};
KeyPair$1.prototype.secret = function() {
  return this._secret;
};
cachedProperty$1(KeyPair$1, "pubBytes", function() {
  return this.eddsa.encodePoint(this.pub());
});
cachedProperty$1(KeyPair$1, "pub", function() {
  return this._pubBytes ? this.eddsa.decodePoint(this._pubBytes) : this.eddsa.g.mul(this.priv());
});
cachedProperty$1(KeyPair$1, "privBytes", function() {
  var e = this.eddsa, n = this.hash(), a = e.encodingLength - 1, c = n.slice(0, e.encodingLength);
  return c[0] &= 248, c[a] &= 127, c[a] |= 64, c;
});
cachedProperty$1(KeyPair$1, "priv", function() {
  return this.eddsa.decodeInt(this.privBytes());
});
cachedProperty$1(KeyPair$1, "hash", function() {
  return this.eddsa.hash().update(this.secret()).digest();
});
cachedProperty$1(KeyPair$1, "messagePrefix", function() {
  return this.hash().slice(this.eddsa.encodingLength);
});
KeyPair$1.prototype.sign = function(e) {
  return assert$2(this._secret, "KeyPair can only verify"), this.eddsa.sign(e, this);
};
KeyPair$1.prototype.verify = function(e, n) {
  return this.eddsa.verify(e, n, this);
};
KeyPair$1.prototype.getSecret = function(e) {
  return assert$2(this._secret, "KeyPair is public only"), utils$2.encode(this.secret(), e);
};
KeyPair$1.prototype.getPublic = function(e) {
  return utils$2.encode(this.pubBytes(), e);
};
var key = KeyPair$1, BN$3 = bnExports$1, utils$1 = utils$l, assert$1 = utils$1.assert, cachedProperty = utils$1.cachedProperty, parseBytes$1 = utils$1.parseBytes;
function Signature$1(t, e) {
  this.eddsa = t, typeof e != "object" && (e = parseBytes$1(e)), Array.isArray(e) && (e = {
    R: e.slice(0, t.encodingLength),
    S: e.slice(t.encodingLength)
  }), assert$1(e.R && e.S, "Signature without R or S"), t.isPoint(e.R) && (this._R = e.R), e.S instanceof BN$3 && (this._S = e.S), this._Rencoded = Array.isArray(e.R) ? e.R : e.Rencoded, this._Sencoded = Array.isArray(e.S) ? e.S : e.Sencoded;
}
cachedProperty(Signature$1, "S", function() {
  return this.eddsa.decodeInt(this.Sencoded());
});
cachedProperty(Signature$1, "R", function() {
  return this.eddsa.decodePoint(this.Rencoded());
});
cachedProperty(Signature$1, "Rencoded", function() {
  return this.eddsa.encodePoint(this.R());
});
cachedProperty(Signature$1, "Sencoded", function() {
  return this.eddsa.encodeInt(this.S());
});
Signature$1.prototype.toBytes = function() {
  return this.Rencoded().concat(this.Sencoded());
};
Signature$1.prototype.toHex = function() {
  return utils$1.encode(this.toBytes(), "hex").toUpperCase();
};
var signature = Signature$1, hash = hash$2, curves = curves$1, utils = utils$l, assert = utils.assert, parseBytes = utils.parseBytes, KeyPair = key, Signature = signature;
function EDDSA(t) {
  if (assert(t === "ed25519", "only tested with ed25519 so far"), !(this instanceof EDDSA))
    return new EDDSA(t);
  t = curves[t].curve, this.curve = t, this.g = t.g, this.g.precompute(t.n.bitLength() + 1), this.pointClass = t.point().constructor, this.encodingLength = Math.ceil(t.n.bitLength() / 8), this.hash = hash.sha512;
}
var eddsa = EDDSA;
EDDSA.prototype.sign = function(e, n) {
  e = parseBytes(e);
  var a = this.keyFromSecret(n), c = this.hashInt(a.messagePrefix(), e), o = this.g.mul(c), u = this.encodePoint(o), h = this.hashInt(u, a.pubBytes(), e).mul(a.priv()), p = c.add(h).umod(this.curve.n);
  return this.makeSignature({ R: o, S: p, Rencoded: u });
};
EDDSA.prototype.verify = function(e, n, a) {
  e = parseBytes(e), n = this.makeSignature(n);
  var c = this.keyFromPublic(a), o = this.hashInt(n.Rencoded(), c.pubBytes(), e), u = this.g.mul(n.S()), h = n.R().add(c.pub().mul(o));
  return h.eq(u);
};
EDDSA.prototype.hashInt = function() {
  for (var e = this.hash(), n = 0; n < arguments.length; n++)
    e.update(arguments[n]);
  return utils.intFromLE(e.digest()).umod(this.curve.n);
};
EDDSA.prototype.keyFromPublic = function(e) {
  return KeyPair.fromPublic(this, e);
};
EDDSA.prototype.keyFromSecret = function(e) {
  return KeyPair.fromSecret(this, e);
};
EDDSA.prototype.makeSignature = function(e) {
  return e instanceof Signature ? e : new Signature(this, e);
};
EDDSA.prototype.encodePoint = function(e) {
  var n = e.getY().toArray("le", this.encodingLength);
  return n[this.encodingLength - 1] |= e.getX().isOdd() ? 128 : 0, n;
};
EDDSA.prototype.decodePoint = function(e) {
  e = utils.parseBytes(e);
  var n = e.length - 1, a = e.slice(0, n).concat(e[n] & -129), c = (e[n] & 128) !== 0, o = utils.intFromLE(a);
  return this.curve.pointFromY(o, c);
};
EDDSA.prototype.encodeInt = function(e) {
  return e.toArray("le", this.encodingLength);
};
EDDSA.prototype.decodeInt = function(e) {
  return utils.intFromLE(e);
};
EDDSA.prototype.isPoint = function(e) {
  return e instanceof this.pointClass;
};
var hasRequiredElliptic;
function requireElliptic() {
  return hasRequiredElliptic || (hasRequiredElliptic = 1, function(t) {
    var e = t;
    e.version = require$$0.version, e.utils = utils$l, e.rand = requireBrorand(), e.curve = curve, e.curves = curves$1, e.ec = requireEc(), e.eddsa = eddsa;
  }(elliptic)), elliptic;
}
var asn1$3 = {}, asn1$2 = {}, api = {}, vmBrowserify = {}, hasRequiredVmBrowserify;
function requireVmBrowserify() {
  return hasRequiredVmBrowserify || (hasRequiredVmBrowserify = 1, function(exports) {
    var indexOf = function(t, e) {
      if (t.indexOf)
        return t.indexOf(e);
      for (var n = 0; n < t.length; n++)
        if (t[n] === e)
          return n;
      return -1;
    }, Object_keys = function(t) {
      if (Object.keys)
        return Object.keys(t);
      var e = [];
      for (var n in t)
        e.push(n);
      return e;
    }, forEach = function(t, e) {
      if (t.forEach)
        return t.forEach(e);
      for (var n = 0; n < t.length; n++)
        e(t[n], n, t);
    }, defineProp = function() {
      try {
        return Object.defineProperty({}, "_", {}), function(t, e, n) {
          Object.defineProperty(t, e, {
            writable: !0,
            enumerable: !1,
            configurable: !0,
            value: n
          });
        };
      } catch {
        return function(e, n, a) {
          e[n] = a;
        };
      }
    }(), globals = [
      "Array",
      "Boolean",
      "Date",
      "Error",
      "EvalError",
      "Function",
      "Infinity",
      "JSON",
      "Math",
      "NaN",
      "Number",
      "Object",
      "RangeError",
      "ReferenceError",
      "RegExp",
      "String",
      "SyntaxError",
      "TypeError",
      "URIError",
      "decodeURI",
      "decodeURIComponent",
      "encodeURI",
      "encodeURIComponent",
      "escape",
      "eval",
      "isFinite",
      "isNaN",
      "parseFloat",
      "parseInt",
      "undefined",
      "unescape"
    ];
    function Context() {
    }
    Context.prototype = {};
    var Script = exports.Script = function(e) {
      if (!(this instanceof Script))
        return new Script(e);
      this.code = e;
    };
    Script.prototype.runInContext = function(t) {
      if (!(t instanceof Context))
        throw new TypeError("needs a 'context' argument.");
      var e = document.createElement("iframe");
      e.style || (e.style = {}), e.style.display = "none", document.body.appendChild(e);
      var n = e.contentWindow, a = n.eval, c = n.execScript;
      !a && c && (c.call(n, "null"), a = n.eval), forEach(Object_keys(t), function(h) {
        n[h] = t[h];
      }), forEach(globals, function(h) {
        t[h] && (n[h] = t[h]);
      });
      var o = Object_keys(n), u = a.call(n, this.code);
      return forEach(Object_keys(n), function(h) {
        (h in t || indexOf(o, h) === -1) && (t[h] = n[h]);
      }), forEach(globals, function(h) {
        h in t || defineProp(t, h, n[h]);
      }), document.body.removeChild(e), u;
    }, Script.prototype.runInThisContext = function() {
      return eval(this.code);
    }, Script.prototype.runInNewContext = function(t) {
      var e = Script.createContext(t), n = this.runInContext(e);
      return t && forEach(Object_keys(e), function(a) {
        t[a] = e[a];
      }), n;
    }, forEach(Object_keys(Script.prototype), function(t) {
      exports[t] = Script[t] = function(e) {
        var n = Script(e);
        return n[t].apply(n, [].slice.call(arguments, 1));
      };
    }), exports.isContext = function(t) {
      return t instanceof Context;
    }, exports.createScript = function(t) {
      return exports.Script(t);
    }, exports.createContext = Script.createContext = function(t) {
      var e = new Context();
      return typeof t == "object" && forEach(Object_keys(t), function(n) {
        e[n] = t[n];
      }), e;
    };
  }(vmBrowserify)), vmBrowserify;
}
var hasRequiredApi;
function requireApi() {
  return hasRequiredApi || (hasRequiredApi = 1, function(t) {
    var e = requireAsn1(), n = inherits_browserExports, a = t;
    a.define = function(u, h) {
      return new c(u, h);
    };
    function c(o, u) {
      this.name = o, this.body = u, this.decoders = {}, this.encoders = {};
    }
    c.prototype._createNamed = function(u) {
      var h;
      try {
        h = requireVmBrowserify().runInThisContext(
          "(function " + this.name + `(entity) {
  this._initNamed(entity);
})`
        );
      } catch {
        h = function(x) {
          this._initNamed(x);
        };
      }
      return n(h, u), h.prototype._initNamed = function(x) {
        u.call(this, x);
      }, new h(this);
    }, c.prototype._getDecoder = function(u) {
      return u = u || "der", this.decoders.hasOwnProperty(u) || (this.decoders[u] = this._createNamed(e.decoders[u])), this.decoders[u];
    }, c.prototype.decode = function(u, h, p) {
      return this._getDecoder(h).decode(u, p);
    }, c.prototype._getEncoder = function(u) {
      return u = u || "der", this.encoders.hasOwnProperty(u) || (this.encoders[u] = this._createNamed(e.encoders[u])), this.encoders[u];
    }, c.prototype.encode = function(u, h, p) {
      return this._getEncoder(h).encode(u, p);
    };
  }(api)), api;
}
var base = {}, reporter = {}, inherits = inherits_browserExports;
function Reporter(t) {
  this._reporterState = {
    obj: null,
    path: [],
    options: t || {},
    errors: []
  };
}
reporter.Reporter = Reporter;
Reporter.prototype.isError = function t(e) {
  return e instanceof ReporterError;
};
Reporter.prototype.save = function t() {
  var e = this._reporterState;
  return { obj: e.obj, pathLen: e.path.length };
};
Reporter.prototype.restore = function t(e) {
  var n = this._reporterState;
  n.obj = e.obj, n.path = n.path.slice(0, e.pathLen);
};
Reporter.prototype.enterKey = function t(e) {
  return this._reporterState.path.push(e);
};
Reporter.prototype.exitKey = function t(e) {
  var n = this._reporterState;
  n.path = n.path.slice(0, e - 1);
};
Reporter.prototype.leaveKey = function t(e, n, a) {
  var c = this._reporterState;
  this.exitKey(e), c.obj !== null && (c.obj[n] = a);
};
Reporter.prototype.path = function t() {
  return this._reporterState.path.join("/");
};
Reporter.prototype.enterObject = function t() {
  var e = this._reporterState, n = e.obj;
  return e.obj = {}, n;
};
Reporter.prototype.leaveObject = function t(e) {
  var n = this._reporterState, a = n.obj;
  return n.obj = e, a;
};
Reporter.prototype.error = function t(e) {
  var n, a = this._reporterState, c = e instanceof ReporterError;
  if (c ? n = e : n = new ReporterError(a.path.map(function(o) {
    return "[" + JSON.stringify(o) + "]";
  }).join(""), e.message || e, e.stack), !a.options.partial)
    throw n;
  return c || a.errors.push(n), n;
};
Reporter.prototype.wrapResult = function t(e) {
  var n = this._reporterState;
  return n.options.partial ? {
    result: this.isError(e) ? null : e,
    errors: n.errors
  } : e;
};
function ReporterError(t, e) {
  this.path = t, this.rethrow(e);
}
inherits(ReporterError, Error);
ReporterError.prototype.rethrow = function t(e) {
  if (this.message = e + " at: " + (this.path || "(shallow)"), Error.captureStackTrace && Error.captureStackTrace(this, ReporterError), !this.stack)
    try {
      throw new Error(this.message);
    } catch (n) {
      this.stack = n.stack;
    }
  return this;
};
var buffer = {}, hasRequiredBuffer;
function requireBuffer() {
  if (hasRequiredBuffer)
    return buffer;
  hasRequiredBuffer = 1;
  var t = inherits_browserExports, e = requireBase().Reporter, n = require$$1$2.Buffer;
  function a(o, u) {
    if (e.call(this, u), !n.isBuffer(o)) {
      this.error("Input not Buffer");
      return;
    }
    this.base = o, this.offset = 0, this.length = o.length;
  }
  t(a, e), buffer.DecoderBuffer = a, a.prototype.save = function() {
    return { offset: this.offset, reporter: e.prototype.save.call(this) };
  }, a.prototype.restore = function(u) {
    var h = new a(this.base);
    return h.offset = u.offset, h.length = this.offset, this.offset = u.offset, e.prototype.restore.call(this, u.reporter), h;
  }, a.prototype.isEmpty = function() {
    return this.offset === this.length;
  }, a.prototype.readUInt8 = function(u) {
    return this.offset + 1 <= this.length ? this.base.readUInt8(this.offset++, !0) : this.error(u || "DecoderBuffer overrun");
  }, a.prototype.skip = function(u, h) {
    if (!(this.offset + u <= this.length))
      return this.error(h || "DecoderBuffer overrun");
    var p = new a(this.base);
    return p._reporterState = this._reporterState, p.offset = this.offset, p.length = this.offset + u, this.offset += u, p;
  }, a.prototype.raw = function(u) {
    return this.base.slice(u ? u.offset : this.offset, this.length);
  };
  function c(o, u) {
    if (Array.isArray(o))
      this.length = 0, this.value = o.map(function(h) {
        return h instanceof c || (h = new c(h, u)), this.length += h.length, h;
      }, this);
    else if (typeof o == "number") {
      if (!(0 <= o && o <= 255))
        return u.error("non-byte EncoderBuffer value");
      this.value = o, this.length = 1;
    } else if (typeof o == "string")
      this.value = o, this.length = n.byteLength(o);
    else if (n.isBuffer(o))
      this.value = o, this.length = o.length;
    else
      return u.error("Unsupported type: " + typeof o);
  }
  return buffer.EncoderBuffer = c, c.prototype.join = function(u, h) {
    return u || (u = new n(this.length)), h || (h = 0), this.length === 0 || (Array.isArray(this.value) ? this.value.forEach(function(p) {
      p.join(u, h), h += p.length;
    }) : (typeof this.value == "number" ? u[h] = this.value : typeof this.value == "string" ? u.write(this.value, h) : n.isBuffer(this.value) && this.value.copy(u, h), h += this.length)), u;
  }, buffer;
}
var node, hasRequiredNode;
function requireNode() {
  if (hasRequiredNode)
    return node;
  hasRequiredNode = 1;
  var t = requireBase().Reporter, e = requireBase().EncoderBuffer, n = requireBase().DecoderBuffer, a = minimalisticAssert, c = [
    "seq",
    "seqof",
    "set",
    "setof",
    "objid",
    "bool",
    "gentime",
    "utctime",
    "null_",
    "enum",
    "int",
    "objDesc",
    "bitstr",
    "bmpstr",
    "charstr",
    "genstr",
    "graphstr",
    "ia5str",
    "iso646str",
    "numstr",
    "octstr",
    "printstr",
    "t61str",
    "unistr",
    "utf8str",
    "videostr"
  ], o = [
    "key",
    "obj",
    "use",
    "optional",
    "explicit",
    "implicit",
    "def",
    "choice",
    "any",
    "contains"
  ].concat(c), u = [
    "_peekTag",
    "_decodeTag",
    "_use",
    "_decodeStr",
    "_decodeObjid",
    "_decodeTime",
    "_decodeNull",
    "_decodeInt",
    "_decodeBool",
    "_decodeList",
    "_encodeComposite",
    "_encodeStr",
    "_encodeObjid",
    "_encodeTime",
    "_encodeNull",
    "_encodeInt",
    "_encodeBool"
  ];
  function h(x, l) {
    var b = {};
    this._baseState = b, b.enc = x, b.parent = l || null, b.children = null, b.tag = null, b.args = null, b.reverseArgs = null, b.choice = null, b.optional = !1, b.any = !1, b.obj = !1, b.use = null, b.useDecoder = null, b.key = null, b.default = null, b.explicit = null, b.implicit = null, b.contains = null, b.parent || (b.children = [], this._wrap());
  }
  node = h;
  var p = [
    "enc",
    "parent",
    "children",
    "tag",
    "args",
    "reverseArgs",
    "choice",
    "optional",
    "any",
    "obj",
    "use",
    "alteredUse",
    "key",
    "default",
    "explicit",
    "implicit",
    "contains"
  ];
  return h.prototype.clone = function() {
    var l = this._baseState, b = {};
    p.forEach(function(C) {
      b[C] = l[C];
    });
    var E = new this.constructor(b.parent);
    return E._baseState = b, E;
  }, h.prototype._wrap = function() {
    var l = this._baseState;
    o.forEach(function(b) {
      this[b] = function() {
        var C = new this.constructor(this);
        return l.children.push(C), C[b].apply(C, arguments);
      };
    }, this);
  }, h.prototype._init = function(l) {
    var b = this._baseState;
    a(b.parent === null), l.call(this), b.children = b.children.filter(function(E) {
      return E._baseState.parent === this;
    }, this), a.equal(b.children.length, 1, "Root node can have only one child");
  }, h.prototype._useArgs = function(l) {
    var b = this._baseState, E = l.filter(function(C) {
      return C instanceof this.constructor;
    }, this);
    l = l.filter(function(C) {
      return !(C instanceof this.constructor);
    }, this), E.length !== 0 && (a(b.children === null), b.children = E, E.forEach(function(C) {
      C._baseState.parent = this;
    }, this)), l.length !== 0 && (a(b.args === null), b.args = l, b.reverseArgs = l.map(function(C) {
      if (typeof C != "object" || C.constructor !== Object)
        return C;
      var q = {};
      return Object.keys(C).forEach(function(F) {
        F == (F | 0) && (F |= 0);
        var z = C[F];
        q[z] = F;
      }), q;
    }));
  }, u.forEach(function(x) {
    h.prototype[x] = function() {
      var b = this._baseState;
      throw new Error(x + " not implemented for encoding: " + b.enc);
    };
  }), c.forEach(function(x) {
    h.prototype[x] = function() {
      var b = this._baseState, E = Array.prototype.slice.call(arguments);
      return a(b.tag === null), b.tag = x, this._useArgs(E), this;
    };
  }), h.prototype.use = function(l) {
    a(l);
    var b = this._baseState;
    return a(b.use === null), b.use = l, this;
  }, h.prototype.optional = function() {
    var l = this._baseState;
    return l.optional = !0, this;
  }, h.prototype.def = function(l) {
    var b = this._baseState;
    return a(b.default === null), b.default = l, b.optional = !0, this;
  }, h.prototype.explicit = function(l) {
    var b = this._baseState;
    return a(b.explicit === null && b.implicit === null), b.explicit = l, this;
  }, h.prototype.implicit = function(l) {
    var b = this._baseState;
    return a(b.explicit === null && b.implicit === null), b.implicit = l, this;
  }, h.prototype.obj = function() {
    var l = this._baseState, b = Array.prototype.slice.call(arguments);
    return l.obj = !0, b.length !== 0 && this._useArgs(b), this;
  }, h.prototype.key = function(l) {
    var b = this._baseState;
    return a(b.key === null), b.key = l, this;
  }, h.prototype.any = function() {
    var l = this._baseState;
    return l.any = !0, this;
  }, h.prototype.choice = function(l) {
    var b = this._baseState;
    return a(b.choice === null), b.choice = l, this._useArgs(Object.keys(l).map(function(E) {
      return l[E];
    })), this;
  }, h.prototype.contains = function(l) {
    var b = this._baseState;
    return a(b.use === null), b.contains = l, this;
  }, h.prototype._decode = function(l, b) {
    var E = this._baseState;
    if (E.parent === null)
      return l.wrapResult(E.children[0]._decode(l, b));
    var C = E.default, q = !0, F = null;
    if (E.key !== null && (F = l.enterKey(E.key)), E.optional) {
      var z = null;
      if (E.explicit !== null ? z = E.explicit : E.implicit !== null ? z = E.implicit : E.tag !== null && (z = E.tag), z === null && !E.any) {
        var H = l.save();
        try {
          E.choice === null ? this._decodeGeneric(E.tag, l, b) : this._decodeChoice(l, b), q = !0;
        } catch {
          q = !1;
        }
        l.restore(H);
      } else if (q = this._peekTag(l, z, E.any), l.isError(q))
        return q;
    }
    var U;
    if (E.obj && q && (U = l.enterObject()), q) {
      if (E.explicit !== null) {
        var Y = this._decodeTag(l, E.explicit);
        if (l.isError(Y))
          return Y;
        l = Y;
      }
      var ee = l.offset;
      if (E.use === null && E.choice === null) {
        if (E.any)
          var H = l.save();
        var se = this._decodeTag(
          l,
          E.implicit !== null ? E.implicit : E.tag,
          E.any
        );
        if (l.isError(se))
          return se;
        E.any ? C = l.raw(H) : l = se;
      }
      if (b && b.track && E.tag !== null && b.track(l.path(), ee, l.length, "tagged"), b && b.track && E.tag !== null && b.track(l.path(), l.offset, l.length, "content"), E.any ? C = C : E.choice === null ? C = this._decodeGeneric(E.tag, l, b) : C = this._decodeChoice(l, b), l.isError(C))
        return C;
      if (!E.any && E.choice === null && E.children !== null && E.children.forEach(function(ue) {
        ue._decode(l, b);
      }), E.contains && (E.tag === "octstr" || E.tag === "bitstr")) {
        var fe = new n(C);
        C = this._getUse(E.contains, l._reporterState.obj)._decode(fe, b);
      }
    }
    return E.obj && q && (C = l.leaveObject(U)), E.key !== null && (C !== null || q === !0) ? l.leaveKey(F, E.key, C) : F !== null && l.exitKey(F), C;
  }, h.prototype._decodeGeneric = function(l, b, E) {
    var C = this._baseState;
    return l === "seq" || l === "set" ? null : l === "seqof" || l === "setof" ? this._decodeList(b, l, C.args[0], E) : /str$/.test(l) ? this._decodeStr(b, l, E) : l === "objid" && C.args ? this._decodeObjid(b, C.args[0], C.args[1], E) : l === "objid" ? this._decodeObjid(b, null, null, E) : l === "gentime" || l === "utctime" ? this._decodeTime(b, l, E) : l === "null_" ? this._decodeNull(b, E) : l === "bool" ? this._decodeBool(b, E) : l === "objDesc" ? this._decodeStr(b, l, E) : l === "int" || l === "enum" ? this._decodeInt(b, C.args && C.args[0], E) : C.use !== null ? this._getUse(C.use, b._reporterState.obj)._decode(b, E) : b.error("unknown tag: " + l);
  }, h.prototype._getUse = function(l, b) {
    var E = this._baseState;
    return E.useDecoder = this._use(l, b), a(E.useDecoder._baseState.parent === null), E.useDecoder = E.useDecoder._baseState.children[0], E.implicit !== E.useDecoder._baseState.implicit && (E.useDecoder = E.useDecoder.clone(), E.useDecoder._baseState.implicit = E.implicit), E.useDecoder;
  }, h.prototype._decodeChoice = function(l, b) {
    var E = this._baseState, C = null, q = !1;
    return Object.keys(E.choice).some(function(F) {
      var z = l.save(), H = E.choice[F];
      try {
        var U = H._decode(l, b);
        if (l.isError(U))
          return !1;
        C = { type: F, value: U }, q = !0;
      } catch {
        return l.restore(z), !1;
      }
      return !0;
    }, this), q ? C : l.error("Choice not matched");
  }, h.prototype._createEncoderBuffer = function(l) {
    return new e(l, this.reporter);
  }, h.prototype._encode = function(l, b, E) {
    var C = this._baseState;
    if (!(C.default !== null && C.default === l)) {
      var q = this._encodeValue(l, b, E);
      if (q !== void 0 && !this._skipDefault(q, b, E))
        return q;
    }
  }, h.prototype._encodeValue = function(l, b, E) {
    var C = this._baseState;
    if (C.parent === null)
      return C.children[0]._encode(l, b || new t());
    var H = null;
    if (this.reporter = b, C.optional && l === void 0)
      if (C.default !== null)
        l = C.default;
      else
        return;
    var q = null, F = !1;
    if (C.any)
      H = this._createEncoderBuffer(l);
    else if (C.choice)
      H = this._encodeChoice(l, b);
    else if (C.contains)
      q = this._getUse(C.contains, E)._encode(l, b), F = !0;
    else if (C.children)
      q = C.children.map(function(ee) {
        if (ee._baseState.tag === "null_")
          return ee._encode(null, b, l);
        if (ee._baseState.key === null)
          return b.error("Child should have a key");
        var se = b.enterKey(ee._baseState.key);
        if (typeof l != "object")
          return b.error("Child expected, but input is not object");
        var fe = ee._encode(l[ee._baseState.key], b, l);
        return b.leaveKey(se), fe;
      }, this).filter(function(ee) {
        return ee;
      }), q = this._createEncoderBuffer(q);
    else if (C.tag === "seqof" || C.tag === "setof") {
      if (!(C.args && C.args.length === 1))
        return b.error("Too many args for : " + C.tag);
      if (!Array.isArray(l))
        return b.error("seqof/setof, but data is not Array");
      var z = this.clone();
      z._baseState.implicit = null, q = this._createEncoderBuffer(l.map(function(ee) {
        var se = this._baseState;
        return this._getUse(se.args[0], l)._encode(ee, b);
      }, z));
    } else
      C.use !== null ? H = this._getUse(C.use, E)._encode(l, b) : (q = this._encodePrimitive(C.tag, l), F = !0);
    var H;
    if (!C.any && C.choice === null) {
      var U = C.implicit !== null ? C.implicit : C.tag, Y = C.implicit === null ? "universal" : "context";
      U === null ? C.use === null && b.error("Tag could be omitted only for .use()") : C.use === null && (H = this._encodeComposite(U, F, Y, q));
    }
    return C.explicit !== null && (H = this._encodeComposite(C.explicit, !1, "context", H)), H;
  }, h.prototype._encodeChoice = function(l, b) {
    var E = this._baseState, C = E.choice[l.type];
    return C || a(
      !1,
      l.type + " not found in " + JSON.stringify(Object.keys(E.choice))
    ), C._encode(l.value, b);
  }, h.prototype._encodePrimitive = function(l, b) {
    var E = this._baseState;
    if (/str$/.test(l))
      return this._encodeStr(b, l);
    if (l === "objid" && E.args)
      return this._encodeObjid(b, E.reverseArgs[0], E.args[1]);
    if (l === "objid")
      return this._encodeObjid(b, null, null);
    if (l === "gentime" || l === "utctime")
      return this._encodeTime(b, l);
    if (l === "null_")
      return this._encodeNull();
    if (l === "int" || l === "enum")
      return this._encodeInt(b, E.args && E.reverseArgs[0]);
    if (l === "bool")
      return this._encodeBool(b);
    if (l === "objDesc")
      return this._encodeStr(b, l);
    throw new Error("Unsupported tag: " + l);
  }, h.prototype._isNumstr = function(l) {
    return /^[0-9 ]*$/.test(l);
  }, h.prototype._isPrintstr = function(l) {
    return /^[A-Za-z0-9 '\(\)\+,\-\.\/:=\?]*$/.test(l);
  }, node;
}
var hasRequiredBase;
function requireBase() {
  return hasRequiredBase || (hasRequiredBase = 1, function(t) {
    var e = t;
    e.Reporter = reporter.Reporter, e.DecoderBuffer = requireBuffer().DecoderBuffer, e.EncoderBuffer = requireBuffer().EncoderBuffer, e.Node = requireNode();
  }(base)), base;
}
var constants = {}, der = {}, hasRequiredDer$2;
function requireDer$2() {
  return hasRequiredDer$2 || (hasRequiredDer$2 = 1, function(t) {
    var e = requireConstants();
    t.tagClass = {
      0: "universal",
      1: "application",
      2: "context",
      3: "private"
    }, t.tagClassByName = e._reverse(t.tagClass), t.tag = {
      0: "end",
      1: "bool",
      2: "int",
      3: "bitstr",
      4: "octstr",
      5: "null_",
      6: "objid",
      7: "objDesc",
      8: "external",
      9: "real",
      10: "enum",
      11: "embed",
      12: "utf8str",
      13: "relativeOid",
      16: "seq",
      17: "set",
      18: "numstr",
      19: "printstr",
      20: "t61str",
      21: "videostr",
      22: "ia5str",
      23: "utctime",
      24: "gentime",
      25: "graphstr",
      26: "iso646str",
      27: "genstr",
      28: "unistr",
      29: "charstr",
      30: "bmpstr"
    }, t.tagByName = e._reverse(t.tag);
  }(der)), der;
}
var hasRequiredConstants;
function requireConstants() {
  return hasRequiredConstants || (hasRequiredConstants = 1, function(t) {
    var e = t;
    e._reverse = function(a) {
      var c = {};
      return Object.keys(a).forEach(function(o) {
        (o | 0) == o && (o = o | 0);
        var u = a[o];
        c[u] = o;
      }), c;
    }, e.der = requireDer$2();
  }(constants)), constants;
}
var decoders = {}, der_1$1, hasRequiredDer$1;
function requireDer$1() {
  if (hasRequiredDer$1)
    return der_1$1;
  hasRequiredDer$1 = 1;
  var t = inherits_browserExports, e = requireAsn1(), n = e.base, a = e.bignum, c = e.constants.der;
  function o(x) {
    this.enc = "der", this.name = x.name, this.entity = x, this.tree = new u(), this.tree._init(x.body);
  }
  der_1$1 = o, o.prototype.decode = function(l, b) {
    return l instanceof n.DecoderBuffer || (l = new n.DecoderBuffer(l, b)), this.tree._decode(l, b);
  };
  function u(x) {
    n.Node.call(this, "der", x);
  }
  t(u, n.Node), u.prototype._peekTag = function(l, b, E) {
    if (l.isEmpty())
      return !1;
    var C = l.save(), q = h(l, 'Failed to peek tag: "' + b + '"');
    return l.isError(q) ? q : (l.restore(C), q.tag === b || q.tagStr === b || q.tagStr + "of" === b || E);
  }, u.prototype._decodeTag = function(l, b, E) {
    var C = h(
      l,
      'Failed to decode tag of "' + b + '"'
    );
    if (l.isError(C))
      return C;
    var q = p(
      l,
      C.primitive,
      'Failed to get length of "' + b + '"'
    );
    if (l.isError(q))
      return q;
    if (!E && C.tag !== b && C.tagStr !== b && C.tagStr + "of" !== b)
      return l.error('Failed to match tag: "' + b + '"');
    if (C.primitive || q !== null)
      return l.skip(q, 'Failed to match body of: "' + b + '"');
    var F = l.save(), z = this._skipUntilEnd(
      l,
      'Failed to skip indefinite length body: "' + this.tag + '"'
    );
    return l.isError(z) ? z : (q = l.offset - F.offset, l.restore(F), l.skip(q, 'Failed to match body of: "' + b + '"'));
  }, u.prototype._skipUntilEnd = function(l, b) {
    for (; ; ) {
      var E = h(l, b);
      if (l.isError(E))
        return E;
      var C = p(l, E.primitive, b);
      if (l.isError(C))
        return C;
      var q;
      if (E.primitive || C !== null ? q = l.skip(C) : q = this._skipUntilEnd(l, b), l.isError(q))
        return q;
      if (E.tagStr === "end")
        break;
    }
  }, u.prototype._decodeList = function(l, b, E, C) {
    for (var q = []; !l.isEmpty(); ) {
      var F = this._peekTag(l, "end");
      if (l.isError(F))
        return F;
      var z = E.decode(l, "der", C);
      if (l.isError(z) && F)
        break;
      q.push(z);
    }
    return q;
  }, u.prototype._decodeStr = function(l, b) {
    if (b === "bitstr") {
      var E = l.readUInt8();
      return l.isError(E) ? E : { unused: E, data: l.raw() };
    } else if (b === "bmpstr") {
      var C = l.raw();
      if (C.length % 2 === 1)
        return l.error("Decoding of string type: bmpstr length mismatch");
      for (var q = "", F = 0; F < C.length / 2; F++)
        q += String.fromCharCode(C.readUInt16BE(F * 2));
      return q;
    } else if (b === "numstr") {
      var z = l.raw().toString("ascii");
      return this._isNumstr(z) ? z : l.error("Decoding of string type: numstr unsupported characters");
    } else {
      if (b === "octstr")
        return l.raw();
      if (b === "objDesc")
        return l.raw();
      if (b === "printstr") {
        var H = l.raw().toString("ascii");
        return this._isPrintstr(H) ? H : l.error("Decoding of string type: printstr unsupported characters");
      } else
        return /str$/.test(b) ? l.raw().toString() : l.error("Decoding of string type: " + b + " unsupported");
    }
  }, u.prototype._decodeObjid = function(l, b, E) {
    for (var C, q = [], F = 0; !l.isEmpty(); ) {
      var z = l.readUInt8();
      F <<= 7, F |= z & 127, z & 128 || (q.push(F), F = 0);
    }
    z & 128 && q.push(F);
    var H = q[0] / 40 | 0, U = q[0] % 40;
    if (E ? C = q : C = [H, U].concat(q.slice(1)), b) {
      var Y = b[C.join(" ")];
      Y === void 0 && (Y = b[C.join(".")]), Y !== void 0 && (C = Y);
    }
    return C;
  }, u.prototype._decodeTime = function(l, b) {
    var E = l.raw().toString();
    if (b === "gentime")
      var C = E.slice(0, 4) | 0, q = E.slice(4, 6) | 0, F = E.slice(6, 8) | 0, z = E.slice(8, 10) | 0, H = E.slice(10, 12) | 0, U = E.slice(12, 14) | 0;
    else if (b === "utctime") {
      var C = E.slice(0, 2) | 0, q = E.slice(2, 4) | 0, F = E.slice(4, 6) | 0, z = E.slice(6, 8) | 0, H = E.slice(8, 10) | 0, U = E.slice(10, 12) | 0;
      C < 70 ? C = 2e3 + C : C = 1900 + C;
    } else
      return l.error("Decoding " + b + " time is not supported yet");
    return Date.UTC(C, q - 1, F, z, H, U, 0);
  }, u.prototype._decodeNull = function(l) {
    return null;
  }, u.prototype._decodeBool = function(l) {
    var b = l.readUInt8();
    return l.isError(b) ? b : b !== 0;
  }, u.prototype._decodeInt = function(l, b) {
    var E = l.raw(), C = new a(E);
    return b && (C = b[C.toString(10)] || C), C;
  }, u.prototype._use = function(l, b) {
    return typeof l == "function" && (l = l(b)), l._getDecoder("der").tree;
  };
  function h(x, l) {
    var b = x.readUInt8(l);
    if (x.isError(b))
      return b;
    var E = c.tagClass[b >> 6], C = (b & 32) === 0;
    if ((b & 31) === 31) {
      var q = b;
      for (b = 0; (q & 128) === 128; ) {
        if (q = x.readUInt8(l), x.isError(q))
          return q;
        b <<= 7, b |= q & 127;
      }
    } else
      b &= 31;
    var F = c.tag[b];
    return {
      cls: E,
      primitive: C,
      tag: b,
      tagStr: F
    };
  }
  function p(x, l, b) {
    var E = x.readUInt8(b);
    if (x.isError(E))
      return E;
    if (!l && E === 128)
      return null;
    if (!(E & 128))
      return E;
    var C = E & 127;
    if (C > 4)
      return x.error("length octect is too long");
    E = 0;
    for (var q = 0; q < C; q++) {
      E <<= 8;
      var F = x.readUInt8(b);
      if (x.isError(F))
        return F;
      E |= F;
    }
    return E;
  }
  return der_1$1;
}
var pem$1, hasRequiredPem$1;
function requirePem$1() {
  if (hasRequiredPem$1)
    return pem$1;
  hasRequiredPem$1 = 1;
  var t = inherits_browserExports, e = require$$1$2.Buffer, n = requireDer$1();
  function a(c) {
    n.call(this, c), this.enc = "pem";
  }
  return t(a, n), pem$1 = a, a.prototype.decode = function(o, u) {
    for (var h = o.toString().split(/[\r\n]+/g), p = u.label.toUpperCase(), x = /^-----(BEGIN|END) ([^-]+)-----$/, l = -1, b = -1, E = 0; E < h.length; E++) {
      var C = h[E].match(x);
      if (C !== null && C[2] === p)
        if (l === -1) {
          if (C[1] !== "BEGIN")
            break;
          l = E;
        } else {
          if (C[1] !== "END")
            break;
          b = E;
          break;
        }
    }
    if (l === -1 || b === -1)
      throw new Error("PEM section not found for: " + p);
    var q = h.slice(l + 1, b).join("");
    q.replace(/[^a-z0-9\+\/=]+/gi, "");
    var F = new e(q, "base64");
    return n.prototype.decode.call(this, F, u);
  }, pem$1;
}
var hasRequiredDecoders;
function requireDecoders() {
  return hasRequiredDecoders || (hasRequiredDecoders = 1, function(t) {
    var e = t;
    e.der = requireDer$1(), e.pem = requirePem$1();
  }(decoders)), decoders;
}
var encoders = {}, der_1, hasRequiredDer;
function requireDer() {
  if (hasRequiredDer)
    return der_1;
  hasRequiredDer = 1;
  var t = inherits_browserExports, e = require$$1$2.Buffer, n = requireAsn1(), a = n.base, c = n.constants.der;
  function o(x) {
    this.enc = "der", this.name = x.name, this.entity = x, this.tree = new u(), this.tree._init(x.body);
  }
  der_1 = o, o.prototype.encode = function(l, b) {
    return this.tree._encode(l, b).join();
  };
  function u(x) {
    a.Node.call(this, "der", x);
  }
  t(u, a.Node), u.prototype._encodeComposite = function(l, b, E, C) {
    var q = p(l, b, E, this.reporter);
    if (C.length < 128) {
      var H = new e(2);
      return H[0] = q, H[1] = C.length, this._createEncoderBuffer([H, C]);
    }
    for (var F = 1, z = C.length; z >= 256; z >>= 8)
      F++;
    var H = new e(2 + F);
    H[0] = q, H[1] = 128 | F;
    for (var z = 1 + F, U = C.length; U > 0; z--, U >>= 8)
      H[z] = U & 255;
    return this._createEncoderBuffer([H, C]);
  }, u.prototype._encodeStr = function(l, b) {
    if (b === "bitstr")
      return this._createEncoderBuffer([l.unused | 0, l.data]);
    if (b === "bmpstr") {
      for (var E = new e(l.length * 2), C = 0; C < l.length; C++)
        E.writeUInt16BE(l.charCodeAt(C), C * 2);
      return this._createEncoderBuffer(E);
    } else
      return b === "numstr" ? this._isNumstr(l) ? this._createEncoderBuffer(l) : this.reporter.error("Encoding of string type: numstr supports only digits and space") : b === "printstr" ? this._isPrintstr(l) ? this._createEncoderBuffer(l) : this.reporter.error("Encoding of string type: printstr supports only latin upper and lower case letters, digits, space, apostrophe, left and rigth parenthesis, plus sign, comma, hyphen, dot, slash, colon, equal sign, question mark") : /str$/.test(b) ? this._createEncoderBuffer(l) : b === "objDesc" ? this._createEncoderBuffer(l) : this.reporter.error("Encoding of string type: " + b + " unsupported");
  }, u.prototype._encodeObjid = function(l, b, E) {
    if (typeof l == "string") {
      if (!b)
        return this.reporter.error("string objid given, but no values map found");
      if (!b.hasOwnProperty(l))
        return this.reporter.error("objid not found in values map");
      l = b[l].split(/[\s\.]+/g);
      for (var C = 0; C < l.length; C++)
        l[C] |= 0;
    } else if (Array.isArray(l)) {
      l = l.slice();
      for (var C = 0; C < l.length; C++)
        l[C] |= 0;
    }
    if (!Array.isArray(l))
      return this.reporter.error("objid() should be either array or string, got: " + JSON.stringify(l));
    if (!E) {
      if (l[1] >= 40)
        return this.reporter.error("Second objid identifier OOB");
      l.splice(0, 2, l[0] * 40 + l[1]);
    }
    for (var q = 0, C = 0; C < l.length; C++) {
      var F = l[C];
      for (q++; F >= 128; F >>= 7)
        q++;
    }
    for (var z = new e(q), H = z.length - 1, C = l.length - 1; C >= 0; C--) {
      var F = l[C];
      for (z[H--] = F & 127; (F >>= 7) > 0; )
        z[H--] = 128 | F & 127;
    }
    return this._createEncoderBuffer(z);
  };
  function h(x) {
    return x < 10 ? "0" + x : x;
  }
  u.prototype._encodeTime = function(l, b) {
    var E, C = new Date(l);
    return b === "gentime" ? E = [
      h(C.getFullYear()),
      h(C.getUTCMonth() + 1),
      h(C.getUTCDate()),
      h(C.getUTCHours()),
      h(C.getUTCMinutes()),
      h(C.getUTCSeconds()),
      "Z"
    ].join("") : b === "utctime" ? E = [
      h(C.getFullYear() % 100),
      h(C.getUTCMonth() + 1),
      h(C.getUTCDate()),
      h(C.getUTCHours()),
      h(C.getUTCMinutes()),
      h(C.getUTCSeconds()),
      "Z"
    ].join("") : this.reporter.error("Encoding " + b + " time is not supported yet"), this._encodeStr(E, "octstr");
  }, u.prototype._encodeNull = function() {
    return this._createEncoderBuffer("");
  }, u.prototype._encodeInt = function(l, b) {
    if (typeof l == "string") {
      if (!b)
        return this.reporter.error("String int or enum given, but no values map");
      if (!b.hasOwnProperty(l))
        return this.reporter.error("Values map doesn't contain: " + JSON.stringify(l));
      l = b[l];
    }
    if (typeof l != "number" && !e.isBuffer(l)) {
      var E = l.toArray();
      !l.sign && E[0] & 128 && E.unshift(0), l = new e(E);
    }
    if (e.isBuffer(l)) {
      var C = l.length;
      l.length === 0 && C++;
      var F = new e(C);
      return l.copy(F), l.length === 0 && (F[0] = 0), this._createEncoderBuffer(F);
    }
    if (l < 128)
      return this._createEncoderBuffer(l);
    if (l < 256)
      return this._createEncoderBuffer([0, l]);
    for (var C = 1, q = l; q >= 256; q >>= 8)
      C++;
    for (var F = new Array(C), q = F.length - 1; q >= 0; q--)
      F[q] = l & 255, l >>= 8;
    return F[0] & 128 && F.unshift(0), this._createEncoderBuffer(new e(F));
  }, u.prototype._encodeBool = function(l) {
    return this._createEncoderBuffer(l ? 255 : 0);
  }, u.prototype._use = function(l, b) {
    return typeof l == "function" && (l = l(b)), l._getEncoder("der").tree;
  }, u.prototype._skipDefault = function(l, b, E) {
    var C = this._baseState, q;
    if (C.default === null)
      return !1;
    var F = l.join();
    if (C.defaultBuffer === void 0 && (C.defaultBuffer = this._encodeValue(C.default, b, E).join()), F.length !== C.defaultBuffer.length)
      return !1;
    for (q = 0; q < F.length; q++)
      if (F[q] !== C.defaultBuffer[q])
        return !1;
    return !0;
  };
  function p(x, l, b, E) {
    var C;
    if (x === "seqof" ? x = "seq" : x === "setof" && (x = "set"), c.tagByName.hasOwnProperty(x))
      C = c.tagByName[x];
    else if (typeof x == "number" && (x | 0) === x)
      C = x;
    else
      return E.error("Unknown tag: " + x);
    return C >= 31 ? E.error("Multi-octet tag encoding unsupported") : (l || (C |= 32), C |= c.tagClassByName[b || "universal"] << 6, C);
  }
  return der_1;
}
var pem, hasRequiredPem;
function requirePem() {
  if (hasRequiredPem)
    return pem;
  hasRequiredPem = 1;
  var t = inherits_browserExports, e = requireDer();
  function n(a) {
    e.call(this, a), this.enc = "pem";
  }
  return t(n, e), pem = n, n.prototype.encode = function(c, o) {
    for (var u = e.prototype.encode.call(this, c), h = u.toString("base64"), p = ["-----BEGIN " + o.label + "-----"], x = 0; x < h.length; x += 64)
      p.push(h.slice(x, x + 64));
    return p.push("-----END " + o.label + "-----"), p.join(`
`);
  }, pem;
}
var hasRequiredEncoders;
function requireEncoders() {
  return hasRequiredEncoders || (hasRequiredEncoders = 1, function(t) {
    var e = t;
    e.der = requireDer(), e.pem = requirePem();
  }(encoders)), encoders;
}
var hasRequiredAsn1;
function requireAsn1() {
  return hasRequiredAsn1 || (hasRequiredAsn1 = 1, function(t) {
    var e = t;
    e.bignum = bnExports$1, e.define = requireApi().define, e.base = requireBase(), e.constants = requireConstants(), e.decoders = requireDecoders(), e.encoders = requireEncoders();
  }(asn1$2)), asn1$2;
}
var asn = requireAsn1(), Time = asn.define("Time", function() {
  this.choice({
    utcTime: this.utctime(),
    generalTime: this.gentime()
  });
}), AttributeTypeValue = asn.define("AttributeTypeValue", function() {
  this.seq().obj(
    this.key("type").objid(),
    this.key("value").any()
  );
}), AlgorithmIdentifier$1 = asn.define("AlgorithmIdentifier", function() {
  this.seq().obj(
    this.key("algorithm").objid(),
    this.key("parameters").optional(),
    this.key("curve").objid().optional()
  );
}), SubjectPublicKeyInfo = asn.define("SubjectPublicKeyInfo", function() {
  this.seq().obj(
    this.key("algorithm").use(AlgorithmIdentifier$1),
    this.key("subjectPublicKey").bitstr()
  );
}), RelativeDistinguishedName = asn.define("RelativeDistinguishedName", function() {
  this.setof(AttributeTypeValue);
}), RDNSequence = asn.define("RDNSequence", function() {
  this.seqof(RelativeDistinguishedName);
}), Name = asn.define("Name", function() {
  this.choice({
    rdnSequence: this.use(RDNSequence)
  });
}), Validity = asn.define("Validity", function() {
  this.seq().obj(
    this.key("notBefore").use(Time),
    this.key("notAfter").use(Time)
  );
}), Extension = asn.define("Extension", function() {
  this.seq().obj(
    this.key("extnID").objid(),
    this.key("critical").bool().def(!1),
    this.key("extnValue").octstr()
  );
}), TBSCertificate = asn.define("TBSCertificate", function() {
  this.seq().obj(
    this.key("version").explicit(0).int().optional(),
    this.key("serialNumber").int(),
    this.key("signature").use(AlgorithmIdentifier$1),
    this.key("issuer").use(Name),
    this.key("validity").use(Validity),
    this.key("subject").use(Name),
    this.key("subjectPublicKeyInfo").use(SubjectPublicKeyInfo),
    this.key("issuerUniqueID").implicit(1).bitstr().optional(),
    this.key("subjectUniqueID").implicit(2).bitstr().optional(),
    this.key("extensions").explicit(3).seqof(Extension).optional()
  );
}), X509Certificate = asn.define("X509Certificate", function() {
  this.seq().obj(
    this.key("tbsCertificate").use(TBSCertificate),
    this.key("signatureAlgorithm").use(AlgorithmIdentifier$1),
    this.key("signatureValue").bitstr()
  );
}), certificate = X509Certificate, asn1$1 = requireAsn1();
asn1$3.certificate = certificate;
var RSAPrivateKey = asn1$1.define("RSAPrivateKey", function() {
  this.seq().obj(
    this.key("version").int(),
    this.key("modulus").int(),
    this.key("publicExponent").int(),
    this.key("privateExponent").int(),
    this.key("prime1").int(),
    this.key("prime2").int(),
    this.key("exponent1").int(),
    this.key("exponent2").int(),
    this.key("coefficient").int()
  );
});
asn1$3.RSAPrivateKey = RSAPrivateKey;
var RSAPublicKey = asn1$1.define("RSAPublicKey", function() {
  this.seq().obj(
    this.key("modulus").int(),
    this.key("publicExponent").int()
  );
});
asn1$3.RSAPublicKey = RSAPublicKey;
var AlgorithmIdentifier = asn1$1.define("AlgorithmIdentifier", function() {
  this.seq().obj(
    this.key("algorithm").objid(),
    this.key("none").null_().optional(),
    this.key("curve").objid().optional(),
    this.key("params").seq().obj(
      this.key("p").int(),
      this.key("q").int(),
      this.key("g").int()
    ).optional()
  );
}), PublicKey = asn1$1.define("SubjectPublicKeyInfo", function() {
  this.seq().obj(
    this.key("algorithm").use(AlgorithmIdentifier),
    this.key("subjectPublicKey").bitstr()
  );
});
asn1$3.PublicKey = PublicKey;
var PrivateKeyInfo = asn1$1.define("PrivateKeyInfo", function() {
  this.seq().obj(
    this.key("version").int(),
    this.key("algorithm").use(AlgorithmIdentifier),
    this.key("subjectPrivateKey").octstr()
  );
});
asn1$3.PrivateKey = PrivateKeyInfo;
var EncryptedPrivateKeyInfo = asn1$1.define("EncryptedPrivateKeyInfo", function() {
  this.seq().obj(
    this.key("algorithm").seq().obj(
      this.key("id").objid(),
      this.key("decrypt").seq().obj(
        this.key("kde").seq().obj(
          this.key("id").objid(),
          this.key("kdeparams").seq().obj(
            this.key("salt").octstr(),
            this.key("iters").int()
          )
        ),
        this.key("cipher").seq().obj(
          this.key("algo").objid(),
          this.key("iv").octstr()
        )
      )
    ),
    this.key("subjectPrivateKey").octstr()
  );
});
asn1$3.EncryptedPrivateKey = EncryptedPrivateKeyInfo;
var DSAPrivateKey = asn1$1.define("DSAPrivateKey", function() {
  this.seq().obj(
    this.key("version").int(),
    this.key("p").int(),
    this.key("q").int(),
    this.key("g").int(),
    this.key("pub_key").int(),
    this.key("priv_key").int()
  );
});
asn1$3.DSAPrivateKey = DSAPrivateKey;
asn1$3.DSAparam = asn1$1.define("DSAparam", function() {
  this.int();
});
var ECParameters = asn1$1.define("ECParameters", function() {
  this.choice({
    namedCurve: this.objid()
  });
}), ECPrivateKey = asn1$1.define("ECPrivateKey", function() {
  this.seq().obj(
    this.key("version").int(),
    this.key("privateKey").octstr(),
    this.key("parameters").optional().explicit(0).use(ECParameters),
    this.key("publicKey").optional().explicit(1).bitstr()
  );
});
asn1$3.ECPrivateKey = ECPrivateKey;
asn1$3.signature = asn1$1.define("signature", function() {
  this.seq().obj(
    this.key("r").int(),
    this.key("s").int()
  );
});
const require$$1 = {
  "2.16.840.1.101.3.4.1.1": "aes-128-ecb",
  "2.16.840.1.101.3.4.1.2": "aes-128-cbc",
  "2.16.840.1.101.3.4.1.3": "aes-128-ofb",
  "2.16.840.1.101.3.4.1.4": "aes-128-cfb",
  "2.16.840.1.101.3.4.1.21": "aes-192-ecb",
  "2.16.840.1.101.3.4.1.22": "aes-192-cbc",
  "2.16.840.1.101.3.4.1.23": "aes-192-ofb",
  "2.16.840.1.101.3.4.1.24": "aes-192-cfb",
  "2.16.840.1.101.3.4.1.41": "aes-256-ecb",
  "2.16.840.1.101.3.4.1.42": "aes-256-cbc",
  "2.16.840.1.101.3.4.1.43": "aes-256-ofb",
  "2.16.840.1.101.3.4.1.44": "aes-256-cfb"
};
var findProc = /Proc-Type: 4,ENCRYPTED[\n\r]+DEK-Info: AES-((?:128)|(?:192)|(?:256))-CBC,([0-9A-H]+)[\n\r]+([0-9A-z\n\r+/=]+)[\n\r]+/m, startRegex = /^-----BEGIN ((?:.*? KEY)|CERTIFICATE)-----/m, fullRegex = /^-----BEGIN ((?:.*? KEY)|CERTIFICATE)-----([0-9A-z\n\r+/=]+)-----END \1-----$/m, evp = evp_bytestokey, ciphers$1 = browser$5, Buffer$6 = safeBufferExports.Buffer, fixProc$1 = function(t, e) {
  var n = t.toString(), a = n.match(findProc), c;
  if (a) {
    var u = "aes" + a[1], h = Buffer$6.from(a[2], "hex"), p = Buffer$6.from(a[3].replace(/[\r\n]/g, ""), "base64"), x = evp(e, h.slice(0, 8), parseInt(a[1], 10)).key, l = [], b = ciphers$1.createDecipheriv(u, x, h);
    l.push(b.update(p)), l.push(b.final()), c = Buffer$6.concat(l);
  } else {
    var o = n.match(fullRegex);
    c = Buffer$6.from(o[2].replace(/[\r\n]/g, ""), "base64");
  }
  var E = n.match(startRegex)[1];
  return {
    tag: E,
    data: c
  };
}, asn1 = asn1$3, aesid = require$$1, fixProc = fixProc$1, ciphers = browser$5, compat = browser$7, Buffer$5 = safeBufferExports.Buffer;
function decrypt(t, e) {
  var n = t.algorithm.decrypt.kde.kdeparams.salt, a = parseInt(t.algorithm.decrypt.kde.kdeparams.iters.toString(), 10), c = aesid[t.algorithm.decrypt.cipher.algo.join(".")], o = t.algorithm.decrypt.cipher.iv, u = t.subjectPrivateKey, h = parseInt(c.split("-")[1], 10) / 8, p = compat.pbkdf2Sync(e, n, a, h, "sha1"), x = ciphers.createDecipheriv(c, p, o), l = [];
  return l.push(x.update(u)), l.push(x.final()), Buffer$5.concat(l);
}
function parseKeys$2(t) {
  var e;
  typeof t == "object" && !Buffer$5.isBuffer(t) && (e = t.passphrase, t = t.key), typeof t == "string" && (t = Buffer$5.from(t));
  var n = fixProc(t, e), a = n.tag, c = n.data, o, u;
  switch (a) {
    case "CERTIFICATE":
      u = asn1.certificate.decode(c, "der").tbsCertificate.subjectPublicKeyInfo;
    case "PUBLIC KEY":
      switch (u || (u = asn1.PublicKey.decode(c, "der")), o = u.algorithm.algorithm.join("."), o) {
        case "1.2.840.113549.1.1.1":
          return asn1.RSAPublicKey.decode(u.subjectPublicKey.data, "der");
        case "1.2.840.10045.2.1":
          return u.subjectPrivateKey = u.subjectPublicKey, {
            type: "ec",
            data: u
          };
        case "1.2.840.10040.4.1":
          return u.algorithm.params.pub_key = asn1.DSAparam.decode(u.subjectPublicKey.data, "der"), {
            type: "dsa",
            data: u.algorithm.params
          };
        default:
          throw new Error("unknown key id " + o);
      }
    case "ENCRYPTED PRIVATE KEY":
      c = asn1.EncryptedPrivateKey.decode(c, "der"), c = decrypt(c, e);
    case "PRIVATE KEY":
      switch (u = asn1.PrivateKey.decode(c, "der"), o = u.algorithm.algorithm.join("."), o) {
        case "1.2.840.113549.1.1.1":
          return asn1.RSAPrivateKey.decode(u.subjectPrivateKey, "der");
        case "1.2.840.10045.2.1":
          return {
            curve: u.algorithm.curve,
            privateKey: asn1.ECPrivateKey.decode(u.subjectPrivateKey, "der").privateKey
          };
        case "1.2.840.10040.4.1":
          return u.algorithm.params.priv_key = asn1.DSAparam.decode(u.subjectPrivateKey, "der"), {
            type: "dsa",
            params: u.algorithm.params
          };
        default:
          throw new Error("unknown key id " + o);
      }
    case "RSA PUBLIC KEY":
      return asn1.RSAPublicKey.decode(c, "der");
    case "RSA PRIVATE KEY":
      return asn1.RSAPrivateKey.decode(c, "der");
    case "DSA PRIVATE KEY":
      return {
        type: "dsa",
        params: asn1.DSAPrivateKey.decode(c, "der")
      };
    case "EC PRIVATE KEY":
      return c = asn1.ECPrivateKey.decode(c, "der"), {
        curve: c.parameters.value,
        privateKey: c.privateKey
      };
    default:
      throw new Error("unknown key type " + a);
  }
}
parseKeys$2.signature = asn1.signature;
var parseAsn1 = parseKeys$2;
const require$$4 = {
  "1.3.132.0.10": "secp256k1",
  "1.3.132.0.33": "p224",
  "1.2.840.10045.3.1.1": "p192",
  "1.2.840.10045.3.1.7": "p256",
  "1.3.132.0.34": "p384",
  "1.3.132.0.35": "p521"
};
var hasRequiredSign;
function requireSign() {
  if (hasRequiredSign)
    return sign.exports;
  hasRequiredSign = 1;
  var t = safeBufferExports.Buffer, e = browser$8, n = browserifyRsa, a = requireElliptic().ec, c = bnExports, o = parseAsn1, u = require$$4, h = 1;
  function p(H, U, Y, ee, se) {
    var fe = o(U);
    if (fe.curve) {
      if (ee !== "ecdsa" && ee !== "ecdsa/rsa")
        throw new Error("wrong private key type");
      return x(H, fe);
    } else if (fe.type === "dsa") {
      if (ee !== "dsa")
        throw new Error("wrong private key type");
      return l(H, fe, Y);
    }
    if (ee !== "rsa" && ee !== "ecdsa/rsa")
      throw new Error("wrong private key type");
    if (U.padding !== void 0 && U.padding !== h)
      throw new Error("illegal or unsupported padding mode");
    H = t.concat([se, H]);
    for (var pe = fe.modulus.byteLength(), ue = [0, 1]; H.length + ue.length + 1 < pe; )
      ue.push(255);
    ue.push(0);
    for (var ce = -1; ++ce < H.length; )
      ue.push(H[ce]);
    var $e = n(ue, fe);
    return $e;
  }
  function x(H, U) {
    var Y = u[U.curve.join(".")];
    if (!Y)
      throw new Error("unknown curve " + U.curve.join("."));
    var ee = new a(Y), se = ee.keyFromPrivate(U.privateKey), fe = se.sign(H);
    return t.from(fe.toDER());
  }
  function l(H, U, Y) {
    for (var ee = U.params.priv_key, se = U.params.p, fe = U.params.q, pe = U.params.g, ue = new c(0), ce, $e = C(H, fe).mod(fe), V = !1, _ = E(ee, fe, H, Y); V === !1; )
      ce = F(fe, _, Y), ue = z(pe, ce, se, fe), V = ce.invm(fe).imul($e.add(ee.mul(ue))).mod(fe), V.cmpn(0) === 0 && (V = !1, ue = new c(0));
    return b(ue, V);
  }
  function b(H, U) {
    H = H.toArray(), U = U.toArray(), H[0] & 128 && (H = [0].concat(H)), U[0] & 128 && (U = [0].concat(U));
    var Y = H.length + U.length + 4, ee = [
      48,
      Y,
      2,
      H.length
    ];
    return ee = ee.concat(H, [2, U.length], U), t.from(ee);
  }
  function E(H, U, Y, ee) {
    if (H = t.from(H.toArray()), H.length < U.byteLength()) {
      var se = t.alloc(U.byteLength() - H.length);
      H = t.concat([se, H]);
    }
    var fe = Y.length, pe = q(Y, U), ue = t.alloc(fe);
    ue.fill(1);
    var ce = t.alloc(fe);
    return ce = e(ee, ce).update(ue).update(t.from([0])).update(H).update(pe).digest(), ue = e(ee, ce).update(ue).digest(), ce = e(ee, ce).update(ue).update(t.from([1])).update(H).update(pe).digest(), ue = e(ee, ce).update(ue).digest(), { k: ce, v: ue };
  }
  function C(H, U) {
    var Y = new c(H), ee = (H.length << 3) - U.bitLength();
    return ee > 0 && Y.ishrn(ee), Y;
  }
  function q(H, U) {
    H = C(H, U), H = H.mod(U);
    var Y = t.from(H.toArray());
    if (Y.length < U.byteLength()) {
      var ee = t.alloc(U.byteLength() - Y.length);
      Y = t.concat([ee, Y]);
    }
    return Y;
  }
  function F(H, U, Y) {
    var ee, se;
    do {
      for (ee = t.alloc(0); ee.length * 8 < H.bitLength(); )
        U.v = e(Y, U.k).update(U.v).digest(), ee = t.concat([ee, U.v]);
      se = C(ee, H), U.k = e(Y, U.k).update(U.v).update(t.from([0])).digest(), U.v = e(Y, U.k).update(U.v).digest();
    } while (se.cmp(H) !== -1);
    return se;
  }
  function z(H, U, Y, ee) {
    return H.toRed(c.mont(Y)).redPow(U).fromRed().mod(ee);
  }
  return sign.exports = p, sign.exports.getKey = E, sign.exports.makeKey = F, sign.exports;
}
var verify_1, hasRequiredVerify;
function requireVerify() {
  if (hasRequiredVerify)
    return verify_1;
  hasRequiredVerify = 1;
  var t = safeBufferExports.Buffer, e = bnExports, n = requireElliptic().ec, a = parseAsn1, c = require$$4;
  function o(x, l, b, E, C) {
    var q = a(b);
    if (q.type === "ec") {
      if (E !== "ecdsa" && E !== "ecdsa/rsa")
        throw new Error("wrong public key type");
      return u(x, l, q);
    } else if (q.type === "dsa") {
      if (E !== "dsa")
        throw new Error("wrong public key type");
      return h(x, l, q);
    }
    if (E !== "rsa" && E !== "ecdsa/rsa")
      throw new Error("wrong public key type");
    l = t.concat([C, l]);
    for (var F = q.modulus.byteLength(), z = [1], H = 0; l.length + z.length + 2 < F; )
      z.push(255), H += 1;
    z.push(0);
    for (var U = -1; ++U < l.length; )
      z.push(l[U]);
    z = t.from(z);
    var Y = e.mont(q.modulus);
    x = new e(x).toRed(Y), x = x.redPow(new e(q.publicExponent)), x = t.from(x.fromRed().toArray());
    var ee = H < 8 ? 1 : 0;
    for (F = Math.min(x.length, z.length), x.length !== z.length && (ee = 1), U = -1; ++U < F; )
      ee |= x[U] ^ z[U];
    return ee === 0;
  }
  function u(x, l, b) {
    var E = c[b.data.algorithm.curve.join(".")];
    if (!E)
      throw new Error("unknown curve " + b.data.algorithm.curve.join("."));
    var C = new n(E), q = b.data.subjectPrivateKey.data;
    return C.verify(l, x, q);
  }
  function h(x, l, b) {
    var E = b.data.p, C = b.data.q, q = b.data.g, F = b.data.pub_key, z = a.signature.decode(x, "der"), H = z.s, U = z.r;
    p(H, C), p(U, C);
    var Y = e.mont(E), ee = H.invm(C), se = q.toRed(Y).redPow(new e(l).mul(ee).mod(C)).fromRed().mul(F.toRed(Y).redPow(U.mul(ee).mod(C)).fromRed()).mod(E).mod(C);
    return se.cmp(U) === 0;
  }
  function p(x, l) {
    if (x.cmpn(0) <= 0)
      throw new Error("invalid sig");
    if (x.cmp(l) >= 0)
      throw new Error("invalid sig");
  }
  return verify_1 = o, verify_1;
}
var browser$3, hasRequiredBrowser$1;
function requireBrowser$1() {
  if (hasRequiredBrowser$1)
    return browser$3;
  hasRequiredBrowser$1 = 1;
  var t = safeBufferExports.Buffer, e = browser$9, n = readableBrowserExports, a = inherits_browserExports, c = requireSign(), o = requireVerify(), u = require$$6;
  Object.keys(u).forEach(function(b) {
    u[b].id = t.from(u[b].id, "hex"), u[b.toLowerCase()] = u[b];
  });
  function h(b) {
    n.Writable.call(this);
    var E = u[b];
    if (!E)
      throw new Error("Unknown message digest");
    this._hashType = E.hash, this._hash = e(E.hash), this._tag = E.id, this._signType = E.sign;
  }
  a(h, n.Writable), h.prototype._write = function(E, C, q) {
    this._hash.update(E), q();
  }, h.prototype.update = function(E, C) {
    return this._hash.update(typeof E == "string" ? t.from(E, C) : E), this;
  }, h.prototype.sign = function(E, C) {
    this.end();
    var q = this._hash.digest(), F = c(q, E, this._hashType, this._signType, this._tag);
    return C ? F.toString(C) : F;
  };
  function p(b) {
    n.Writable.call(this);
    var E = u[b];
    if (!E)
      throw new Error("Unknown message digest");
    this._hash = e(E.hash), this._tag = E.id, this._signType = E.sign;
  }
  a(p, n.Writable), p.prototype._write = function(E, C, q) {
    this._hash.update(E), q();
  }, p.prototype.update = function(E, C) {
    return this._hash.update(typeof E == "string" ? t.from(E, C) : E), this;
  }, p.prototype.verify = function(E, C, q) {
    var F = typeof C == "string" ? t.from(C, q) : C;
    this.end();
    var z = this._hash.digest();
    return o(F, z, E, this._signType, this._tag);
  };
  function x(b) {
    return new h(b);
  }
  function l(b) {
    return new p(b);
  }
  return browser$3 = {
    Sign: x,
    Verify: l,
    createSign: x,
    createVerify: l
  }, browser$3;
}
var browser$2, hasRequiredBrowser;
function requireBrowser() {
  if (hasRequiredBrowser)
    return browser$2;
  hasRequiredBrowser = 1;
  var t = requireElliptic(), e = bnExports$1;
  browser$2 = function(u) {
    return new a(u);
  };
  var n = {
    secp256k1: {
      name: "secp256k1",
      byteLength: 32
    },
    secp224r1: {
      name: "p224",
      byteLength: 28
    },
    prime256v1: {
      name: "p256",
      byteLength: 32
    },
    prime192v1: {
      name: "p192",
      byteLength: 24
    },
    ed25519: {
      name: "ed25519",
      byteLength: 32
    },
    secp384r1: {
      name: "p384",
      byteLength: 48
    },
    secp521r1: {
      name: "p521",
      byteLength: 66
    }
  };
  n.p224 = n.secp224r1, n.p256 = n.secp256r1 = n.prime256v1, n.p192 = n.secp192r1 = n.prime192v1, n.p384 = n.secp384r1, n.p521 = n.secp521r1;
  function a(o) {
    this.curveType = n[o], this.curveType || (this.curveType = {
      name: o
    }), this.curve = new t.ec(this.curveType.name), this.keys = void 0;
  }
  a.prototype.generateKeys = function(o, u) {
    return this.keys = this.curve.genKeyPair(), this.getPublicKey(o, u);
  }, a.prototype.computeSecret = function(o, u, h) {
    u = u || "utf8", Buffer$B.isBuffer(o) || (o = new Buffer$B(o, u));
    var p = this.curve.keyFromPublic(o).getPublic(), x = p.mul(this.keys.getPrivate()).getX();
    return c(x, h, this.curveType.byteLength);
  }, a.prototype.getPublicKey = function(o, u) {
    var h = this.keys.getPublic(u === "compressed", !0);
    return u === "hybrid" && (h[h.length - 1] % 2 ? h[0] = 7 : h[0] = 6), c(h, o);
  }, a.prototype.getPrivateKey = function(o) {
    return c(this.keys.getPrivate(), o);
  }, a.prototype.setPublicKey = function(o, u) {
    return u = u || "utf8", Buffer$B.isBuffer(o) || (o = new Buffer$B(o, u)), this.keys._importPublic(o), this;
  }, a.prototype.setPrivateKey = function(o, u) {
    u = u || "utf8", Buffer$B.isBuffer(o) || (o = new Buffer$B(o, u));
    var h = new e(o);
    return h = h.toString(16), this.keys = this.curve.genKeyPair(), this.keys._importPrivate(h), this;
  };
  function c(o, u, h) {
    Array.isArray(o) || (o = o.toArray());
    var p = new Buffer$B(o);
    if (h && p.length < h) {
      var x = new Buffer$B(h - p.length);
      x.fill(0), p = Buffer$B.concat([x, p]);
    }
    return u ? p.toString(u) : p;
  }
  return browser$2;
}
var browser$1 = {}, createHash$2 = browser$9, Buffer$4 = safeBufferExports$1.Buffer, mgf$2 = function(t, e) {
  for (var n = Buffer$4.alloc(0), a = 0, c; n.length < e; )
    c = i2ops(a++), n = Buffer$4.concat([n, createHash$2("sha1").update(t).update(c).digest()]);
  return n.slice(0, e);
};
function i2ops(t) {
  var e = Buffer$4.allocUnsafe(4);
  return e.writeUInt32BE(t, 0), e;
}
var xor$2 = function t(e, n) {
  for (var a = e.length, c = -1; ++c < a; )
    e[c] ^= n[c];
  return e;
}, BN$2 = bnExports$1, Buffer$3 = safeBufferExports$1.Buffer;
function withPublic$2(t, e) {
  return Buffer$3.from(t.toRed(BN$2.mont(e.modulus)).redPow(new BN$2(e.publicExponent)).fromRed().toArray());
}
var withPublic_1 = withPublic$2, parseKeys$1 = parseAsn1, randomBytes = browserExports, createHash$1 = browser$9, mgf$1 = mgf$2, xor$1 = xor$2, BN$1 = bnExports$1, withPublic$1 = withPublic_1, crt$1 = browserifyRsa, Buffer$2 = safeBufferExports$1.Buffer, publicEncrypt = function t(e, n, a) {
  var c;
  e.padding ? c = e.padding : a ? c = 1 : c = 4;
  var o = parseKeys$1(e), u;
  if (c === 4)
    u = oaep$1(o, n);
  else if (c === 1)
    u = pkcs1$1(o, n, a);
  else if (c === 3) {
    if (u = new BN$1(n), u.cmp(o.modulus) >= 0)
      throw new Error("data too long for modulus");
  } else
    throw new Error("unknown padding");
  return a ? crt$1(u, o) : withPublic$1(u, o);
};
function oaep$1(t, e) {
  var n = t.modulus.byteLength(), a = e.length, c = createHash$1("sha1").update(Buffer$2.alloc(0)).digest(), o = c.length, u = 2 * o;
  if (a > n - u - 2)
    throw new Error("message too long");
  var h = Buffer$2.alloc(n - a - u - 2), p = n - o - 1, x = randomBytes(o), l = xor$1(Buffer$2.concat([c, h, Buffer$2.alloc(1, 1), e], p), mgf$1(x, p)), b = xor$1(x, mgf$1(l, o));
  return new BN$1(Buffer$2.concat([Buffer$2.alloc(1), b, l], n));
}
function pkcs1$1(t, e, n) {
  var a = e.length, c = t.modulus.byteLength();
  if (a > c - 11)
    throw new Error("message too long");
  var o;
  return n ? o = Buffer$2.alloc(c - a - 3, 255) : o = nonZero(c - a - 3), new BN$1(Buffer$2.concat([Buffer$2.from([0, n ? 1 : 2]), o, Buffer$2.alloc(1), e], c));
}
function nonZero(t) {
  for (var e = Buffer$2.allocUnsafe(t), n = 0, a = randomBytes(t * 2), c = 0, o; n < t; )
    c === a.length && (a = randomBytes(t * 2), c = 0), o = a[c++], o && (e[n++] = o);
  return e;
}
var parseKeys = parseAsn1, mgf = mgf$2, xor = xor$2, BN = bnExports$1, crt = browserifyRsa, createHash = browser$9, withPublic = withPublic_1, Buffer$1 = safeBufferExports$1.Buffer, privateDecrypt = function t(e, n, a) {
  var c;
  e.padding ? c = e.padding : a ? c = 1 : c = 4;
  var o = parseKeys(e), u = o.modulus.byteLength();
  if (n.length > u || new BN(n).cmp(o.modulus) >= 0)
    throw new Error("decryption error");
  var h;
  a ? h = withPublic(new BN(n), o) : h = crt(n, o);
  var p = Buffer$1.alloc(u - h.length);
  if (h = Buffer$1.concat([p, h], u), c === 4)
    return oaep(o, h);
  if (c === 1)
    return pkcs1(o, h, a);
  if (c === 3)
    return h;
  throw new Error("unknown padding");
};
function oaep(t, e) {
  var n = t.modulus.byteLength(), a = createHash("sha1").update(Buffer$1.alloc(0)).digest(), c = a.length;
  if (e[0] !== 0)
    throw new Error("decryption error");
  var o = e.slice(1, c + 1), u = e.slice(c + 1), h = xor(o, mgf(u, c)), p = xor(u, mgf(h, n - c - 1));
  if (compare(a, p.slice(0, c)))
    throw new Error("decryption error");
  for (var x = c; p[x] === 0; )
    x++;
  if (p[x++] !== 1)
    throw new Error("decryption error");
  return p.slice(x);
}
function pkcs1(t, e, n) {
  for (var a = e.slice(0, 2), c = 2, o = 0; e[c++] !== 0; )
    if (c >= e.length) {
      o++;
      break;
    }
  var u = e.slice(2, c - 1);
  if ((a.toString("hex") !== "0002" && !n || a.toString("hex") !== "0001" && n) && o++, u.length < 8 && o++, o)
    throw new Error("decryption error");
  return e.slice(c);
}
function compare(t, e) {
  t = Buffer$1.from(t), e = Buffer$1.from(e);
  var n = 0, a = t.length;
  t.length !== e.length && (n++, a = Math.min(t.length, e.length));
  for (var c = -1; ++c < a; )
    n += t[c] ^ e[c];
  return n;
}
(function(t) {
  t.publicEncrypt = publicEncrypt, t.privateDecrypt = privateDecrypt, t.privateEncrypt = function(n, a) {
    return t.publicEncrypt(n, a, !0);
  }, t.publicDecrypt = function(n, a) {
    return t.privateDecrypt(n, a, !0);
  };
})(browser$1);
var browser = {};
function oldBrowser() {
  throw new Error(`secure random number generation not supported by this browser
use chrome, FireFox or Internet Explorer 11`);
}
var safeBuffer = safeBufferExports$1, randombytes = browserExports, Buffer = safeBuffer.Buffer, kBufferMaxLength = safeBuffer.kMaxLength, crypto = commonjsGlobal.crypto || commonjsGlobal.msCrypto, kMaxUint32 = Math.pow(2, 32) - 1;
function assertOffset(t, e) {
  if (typeof t != "number" || t !== t)
    throw new TypeError("offset must be a number");
  if (t > kMaxUint32 || t < 0)
    throw new TypeError("offset must be a uint32");
  if (t > kBufferMaxLength || t > e)
    throw new RangeError("offset out of range");
}
function assertSize(t, e, n) {
  if (typeof t != "number" || t !== t)
    throw new TypeError("size must be a number");
  if (t > kMaxUint32 || t < 0)
    throw new TypeError("size must be a uint32");
  if (t + e > n || t > kBufferMaxLength)
    throw new RangeError("buffer too small");
}
crypto && crypto.getRandomValues || !process$1.browser ? (browser.randomFill = randomFill, browser.randomFillSync = randomFillSync) : (browser.randomFill = oldBrowser, browser.randomFillSync = oldBrowser);
function randomFill(t, e, n, a) {
  if (!Buffer.isBuffer(t) && !(t instanceof commonjsGlobal.Uint8Array))
    throw new TypeError('"buf" argument must be a Buffer or Uint8Array');
  if (typeof e == "function")
    a = e, e = 0, n = t.length;
  else if (typeof n == "function")
    a = n, n = t.length - e;
  else if (typeof a != "function")
    throw new TypeError('"cb" argument must be a function');
  return assertOffset(e, t.length), assertSize(n, e, t.length), actualFill(t, e, n, a);
}
function actualFill(t, e, n, a) {
  if (process$1.browser) {
    var c = t.buffer, o = new Uint8Array(c, e, n);
    if (crypto.getRandomValues(o), a) {
      process$1.nextTick(function() {
        a(null, t);
      });
      return;
    }
    return t;
  }
  if (a) {
    randombytes(n, function(h, p) {
      if (h)
        return a(h);
      p.copy(t, e), a(null, t);
    });
    return;
  }
  var u = randombytes(n);
  return u.copy(t, e), t;
}
function randomFillSync(t, e, n) {
  if (typeof e > "u" && (e = 0), !Buffer.isBuffer(t) && !(t instanceof commonjsGlobal.Uint8Array))
    throw new TypeError('"buf" argument must be a Buffer or Uint8Array');
  return assertOffset(e, t.length), n === void 0 && (n = t.length - e), assertSize(n, e, t.length), actualFill(t, e, n);
}
var hasRequiredCryptoBrowserify;
function requireCryptoBrowserify() {
  if (hasRequiredCryptoBrowserify)
    return cryptoBrowserify;
  hasRequiredCryptoBrowserify = 1, cryptoBrowserify.randomBytes = cryptoBrowserify.rng = cryptoBrowserify.pseudoRandomBytes = cryptoBrowserify.prng = browserExports, cryptoBrowserify.createHash = cryptoBrowserify.Hash = browser$9, cryptoBrowserify.createHmac = cryptoBrowserify.Hmac = browser$8;
  var t = algos, e = Object.keys(t), n = ["sha1", "sha224", "sha256", "sha384", "sha512", "md5", "rmd160"].concat(e);
  cryptoBrowserify.getHashes = function() {
    return n;
  };
  var a = browser$7;
  cryptoBrowserify.pbkdf2 = a.pbkdf2, cryptoBrowserify.pbkdf2Sync = a.pbkdf2Sync;
  var c = browser$6;
  cryptoBrowserify.Cipher = c.Cipher, cryptoBrowserify.createCipher = c.createCipher, cryptoBrowserify.Cipheriv = c.Cipheriv, cryptoBrowserify.createCipheriv = c.createCipheriv, cryptoBrowserify.Decipher = c.Decipher, cryptoBrowserify.createDecipher = c.createDecipher, cryptoBrowserify.Decipheriv = c.Decipheriv, cryptoBrowserify.createDecipheriv = c.createDecipheriv, cryptoBrowserify.getCiphers = c.getCiphers, cryptoBrowserify.listCiphers = c.listCiphers;
  var o = requireBrowser$2();
  cryptoBrowserify.DiffieHellmanGroup = o.DiffieHellmanGroup, cryptoBrowserify.createDiffieHellmanGroup = o.createDiffieHellmanGroup, cryptoBrowserify.getDiffieHellman = o.getDiffieHellman, cryptoBrowserify.createDiffieHellman = o.createDiffieHellman, cryptoBrowserify.DiffieHellman = o.DiffieHellman;
  var u = requireBrowser$1();
  cryptoBrowserify.createSign = u.createSign, cryptoBrowserify.Sign = u.Sign, cryptoBrowserify.createVerify = u.createVerify, cryptoBrowserify.Verify = u.Verify, cryptoBrowserify.createECDH = requireBrowser();
  var h = browser$1;
  cryptoBrowserify.publicEncrypt = h.publicEncrypt, cryptoBrowserify.privateEncrypt = h.privateEncrypt, cryptoBrowserify.publicDecrypt = h.publicDecrypt, cryptoBrowserify.privateDecrypt = h.privateDecrypt;
  var p = browser;
  return cryptoBrowserify.randomFill = p.randomFill, cryptoBrowserify.randomFillSync = p.randomFillSync, cryptoBrowserify.createCredentials = function() {
    throw new Error([
      "sorry, createCredentials is not implemented yet",
      "we accept pull requests",
      "https://github.com/crypto-browserify/crypto-browserify"
    ].join(`
`));
  }, cryptoBrowserify.constants = {
    DH_CHECK_P_NOT_SAFE_PRIME: 2,
    DH_CHECK_P_NOT_PRIME: 1,
    DH_UNABLE_TO_CHECK_GENERATOR: 4,
    DH_NOT_SUITABLE_GENERATOR: 8,
    NPN_ENABLED: 1,
    ALPN_ENABLED: 1,
    RSA_PKCS1_PADDING: 1,
    RSA_SSLV23_PADDING: 2,
    RSA_NO_PADDING: 3,
    RSA_PKCS1_OAEP_PADDING: 4,
    RSA_X931_PADDING: 5,
    RSA_PKCS1_PSS_PADDING: 6,
    POINT_CONVERSION_COMPRESSED: 2,
    POINT_CONVERSION_UNCOMPRESSED: 4,
    POINT_CONVERSION_HYBRID: 6
  }, cryptoBrowserify;
}
var cryptoBrowserifyExports = requireCryptoBrowserify();
const index = /* @__PURE__ */ getDefaultExportFromCjs$1(cryptoBrowserifyExports), DEFAULT_HOST = "oast.fun", getHost = () => {
  const t = localStorage.getItem("eb-interactsh-enable"), e = localStorage.getItem("eb-interactsh-host");
  let n = t && t === "true" && e ? e : DEFAULT_HOST;
  return !n.startsWith("http://") && !n.startsWith("https://") && (n = "https://" + n), {
    hostname: new URL(n).hostname,
    url: n
  };
};
class KeyGenerator {
  constructor() {
    gt(this, "publicKey", null);
    gt(this, "privateKey", null);
  }
  async generateKeys() {
    const { publicKey: e, privateKey: n } = await window.crypto.subtle.generateKey(
      {
        name: "RSA-OAEP",
        modulusLength: 2048,
        publicExponent: new Uint8Array([1, 0, 1]),
        hash: { name: "SHA-256" }
      },
      !0,
      ["encrypt", "decrypt"]
    );
    this.publicKey = e, this.privateKey = n;
  }
  async getPublicKey() {
    if (!this.publicKey)
      throw new Error("Public key not generated yet.");
    const e = await window.crypto.subtle.exportKey("spki", this.publicKey), n = String.fromCharCode.apply(
      null,
      Array.from(new Uint8Array(e))
    ), a = btoa(n), c = this.splitStringEveryN(a, 64);
    let o = `-----BEGIN PUBLIC KEY-----
`;
    for (const u of c)
      o += u + `
`;
    return o += `-----END PUBLIC KEY-----
`, o;
  }
  splitStringEveryN(e, n) {
    const a = [];
    for (let c = 0; c < e.length; c += n)
      a.push(e.substr(c, n));
    return a;
  }
}
const xid = (t) => {
  const e = "abcdefghijklmnopqrstuvwxyz0123456789";
  let n = "";
  for (let a = 0; a < t; a++)
    n += e.charAt(Math.floor(Math.random() * e.length));
  return n;
}, register = async () => {
  const t = new KeyGenerator();
  await t.generateKeys();
  const e = await t.getPublicKey(), n = t.privateKey, a = window.crypto.randomUUID(), c = xid(20), o = {
    "public-key": btoa(e),
    "secret-key": a,
    "correlation-id": c
  }, u = getHost(), h = localStorage.getItem("eb-interactsh-token"), p = {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(o)
  }, x = localStorage.getItem("eb-interactsh-enable");
  return h && x && x === "true" && Object.assign(p, {
    headers: {
      ...p.headers,
      Authorization: h
    }
  }), fetch(`${u.url}/register`, p).then((l) => ({
    secretKey: a,
    correlationId: c,
    privateKey: n,
    responseStatusCode: l.status,
    hostname: c + xid(13) + "." + u.hostname
  })).catch((l) => (getEvenBetterAPI().toast.showToast({
    message: "Failed to create interactsh instance",
    type: "error",
    position: "bottom",
    duration: 3e3
  }), Promise.reject(l)));
}, poll = async (t, e, n) => {
  const a = getHost(), c = localStorage.getItem("eb-interactsh-token"), o = localStorage.getItem("eb-interactsh-enable"), u = {};
  return c && o && o === "true" && Object.assign(u, {
    headers: {
      Authorization: c
    }
  }), fetch(
    `${a.url}/poll?id=${e}&secret=${t}`,
    u
  ).then((h) => h.json()).then(async (h) => {
    if (h.data == null)
      return;
    const p = h.aes_key, x = await decryptAesKey(p, n), l = h.data;
    let b = [];
    return l.forEach((E) => {
      const C = JSON.parse(
        processData(E, btoa(x))
      );
      b.push({
        protocol: C.protocol,
        uniqueId: C["unique-id"],
        rawRequest: C["raw-request"],
        timestamp: C.timestamp,
        remoteAddress: C["remote-address"]
      });
    }), {
      decodedData: b
    };
  });
}, decryptAesKey = (t, e) => {
  const n = Uint8Array.from(
    atob(t),
    (a) => a.charCodeAt(0)
  );
  return window.crypto.subtle.decrypt(
    {
      name: "RSA-OAEP"
    },
    e,
    n
  ).then((a) => new TextDecoder().decode(a));
}, processData = (t, e) => {
  const n = Buffer$B.from(t, "base64").slice(0, 16), a = Buffer$B.from(e, "base64"), c = index.createDecipheriv(
    "aes-256-cfb",
    a,
    n
  );
  let o = c.update(Buffer$B.from(t, "base64").slice(16));
  return o += c.final("utf8"), o.toString();
};
var SSRFInstanceType = /* @__PURE__ */ ((t) => (t.CVSSADVISOR = "ssrf.cvssadvisor.com", t.INTERACTSH = "interactsh.com", t))(SSRFInstanceType || {}), SSRFInstanceState = /* @__PURE__ */ ((t) => (t.ACTIVE = "ACTIVE", t.CREATING = "CREATING", t))(SSRFInstanceState || {});
let ssrfInstance = null, addedIDs = [];
const pullSSRFHits = () => {
  if (ssrfInstance)
    switch (ssrfInstance.type) {
      case "ssrf.cvssadvisor.com":
        fetch(CA_SSRF_INSTANCE_API_URL + "/" + ssrfInstance.id).then((e) => e.json()).then((e) => {
          const n = e.requests_history;
          !n || (n == null ? void 0 : n.length) === 0 || n.forEach((a) => {
            addedIDs.includes(a.id) || (a.timestamp = a.timestamp * 1e3, getEvenBetterAPI().eventManager.triggerEvent("onSSRFHit", a), addedIDs.push(a.id));
          });
        }).catch(() => {
          refreshSSRFInstance(
            "ssrf.cvssadvisor.com"
            /* CVSSADVISOR */
          ).then(
            () => refreshInputs()
          );
        });
        break;
      case "interactsh.com":
        if (ssrfInstance.secretKey == null)
          return;
        const t = ssrfInstance.privateKey;
        if (!t)
          return;
        poll(
          ssrfInstance.secretKey,
          ssrfInstance.id,
          t
        ).then((e) => {
          !e || !e.decodedData || e.decodedData.forEach((n) => {
            const a = {
              id: n.uniqueId,
              protocol: n.protocol.toUpperCase(),
              dump: n.rawRequest,
              ip: n.remoteAddress,
              timestamp: new Date(n.timestamp).getTime()
            };
            getEvenBetterAPI().eventManager.triggerEvent("onSSRFHit", a);
          });
        });
        break;
    }
}, refreshSSRFInstance = async (t) => {
  if (!(ssrfInstance && ssrfInstance.state === "CREATING"))
    switch (t) {
      case "ssrf.cvssadvisor.com":
        return fetch(CA_SSRF_INSTANCE_API_URL, {
          method: "POST"
        }).then((e) => e.json()).then((e) => {
          ssrfInstance = {
            id: e,
            url: e + ".c5.rs",
            type: "ssrf.cvssadvisor.com",
            state: "ACTIVE"
            /* ACTIVE */
          }, addedIDs = [], getEvenBetterAPI().toast.showToast({
            message: "Successfully created SSRF instance",
            type: "success",
            position: "bottom",
            duration: 3e3
          }), setSetting$1("ssrfInstanceTool", t), setSetting$1("ssrfInstanceHostname", ssrfInstance.url), getEvenBetterAPI().eventManager.triggerEvent("onSSRFInstanceChange");
        }).catch((e) => {
          console.error(e);
        });
      case "interactsh.com":
        return register().then((e) => {
          if (e.responseStatusCode !== 200) {
            getEvenBetterAPI().modal.openModal({
              title: "Error",
              content: "Failed to create interactsh instance"
            });
            return;
          }
          getEvenBetterAPI().toast.showToast({
            message: "Successfully created SSRF instance",
            type: "success",
            position: "bottom",
            duration: 3e3
          });
          const n = e.privateKey;
          n && (ssrfInstance = {
            id: e.correlationId,
            url: e.hostname,
            secretKey: e.secretKey,
            privateKey: n,
            type: "interactsh.com",
            state: "ACTIVE"
            /* ACTIVE */
          }, setSetting$1("ssrfInstanceTool", t), setSetting$1("ssrfInstanceHostname", ssrfInstance.url), getEvenBetterAPI().eventManager.triggerEvent("onSSRFInstanceChange"));
        }).catch((e) => {
          console.error(e), e.message.includes("crypto.subtle") && window.location.href === "#/evenbetter/quick-ssrf" && getEvenBetterAPI().modal.openModal({
            title: "Error",
            content: "Interactsh.com isn't supported yet on non-local Caido instances :("
          });
        });
    }
};
let selectedInstanceType = SSRFInstanceType.CVSSADVISOR;
const syncData = (t) => {
  const e = t.querySelector("select");
  if (!e)
    return;
  const n = t.querySelector(
    ".ssrf-instance-url"
  );
  ssrfInstance && (n.value = ssrfInstance.url), e.value = selectedInstanceType, updateIcon();
}, navigationBar = () => {
  var o, u;
  const t = getEvenBetterAPI().components.createTextInput(
    "13em",
    "N/A",
    !0
  ), e = getCaidoAPI$1().ui.button({
    label: "Clear Logs",
    variant: "primary",
    leadingIcon: "fas fa-trash",
    size: "small"
  });
  e.addEventListener("click", () => ssrfHitsTable.clearRows());
  const n = getEvenBetterAPI().components.createNavigationBar({
    title: "Quick SSRF",
    items: [
      {
        title: "Requests History",
        url: "#/evenbetter/quick-ssrf",
        icon: "fa-history",
        onOpen: () => syncData(n)
      },
      {
        title: "Settings",
        url: "#/evenbetter/quick-ssrf/settings",
        icon: "fa-cog",
        onOpen: () => syncData(n)
      }
    ],
    customButtons: [e, switchElement(), t]
  }), a = t.querySelector("input");
  if (!a)
    return n;
  a.disabled = !0, a.classList.add("ssrf-instance-url"), getEvenBetterAPI().eventManager.on("onSSRFInstanceChange", () => {
    ssrfInstance && (a.value = ssrfInstance.url);
  });
  const c = n.querySelector(
    ".evenbetter_quick-ssrf_switch select"
  );
  return (o = n.querySelector("select")) == null || o.addEventListener(
    "change",
    () => selectedInstanceType = c.value
  ), (u = n.querySelector(".evenbetter_quick-ssrf_button")) == null || u.addEventListener("click", refreshInputs), n;
}, refreshInputs = () => {
  refreshSSRFInstance(selectedInstanceType).then(() => {
    ssrfHitsTable.clearRows(), updateIcon();
  });
}, updateIcon = () => {
  const t = document.querySelector(".evenbetter_quick-ssrf_switch i");
  t && (t.className = ssrfInstance ? "fas fa-sync" : "fas fa-plus");
}, switchElement = () => {
  const t = document.createElement("div");
  return t.className = "evenbetter_quick-ssrf_switch", t.innerHTML = `<select>
      <option value="ssrf.cvssadvisor.com">ssrf.cvssadvisor.com</option>
      <option value="interactsh.com">interactsh.com</option>
    </select>
    <div class="evenbetter_quick-ssrf_button">
      <i class="fas fa-plus"></i>
    </div>`, t;
};
let ssrfHitsTable;
const reqHistoryPage = () => {
  const t = document.createElement("div");
  t.className = "c-evenbetter_quick-ssrf";
  const e = document.createElement("div");
  e.className = "c-evenbetter_quick-ssrf__content";
  const n = navigationBar();
  t.appendChild(n);
  const a = [
    { name: "ID", width: "9em" },
    { name: "Time", width: "10em" },
    { name: "Type", width: "4em" },
    { name: "Request", width: "40em" },
    { name: "Source IP", width: "11em" }
  ], c = getEvenBetterAPI().components.createTable({
    columns: a
  });
  return ssrfHitsTable = c, getEvenBetterAPI().eventManager.on("onSSRFHit", (o) => {
    window.location.hash.startsWith("#/evenbetter/quick-ssrf") || incrementHitsCount(), ssrfHitsTable.addRow(
      [
        { columnName: "ID", value: labelElement$1(o.id) },
        {
          columnName: "Time",
          value: labelElement$1(new Date(o.timestamp).toLocaleString())
        },
        { columnName: "Type", value: labelElement$1(o.protocol) },
        { columnName: "Request", value: labelElement$1(o.dump) },
        { columnName: "Source IP", value: labelElement$1(o.ip) }
      ],
      () => {
        getEvenBetterAPI().modal.openModal({
          title: "Request",
          content: requestDumpToHTML(o)
        });
      }
    );
  }), e.appendChild(c.getHTMLElement()), t.appendChild(e), t;
}, incrementHitsCount = () => {
  document.querySelectorAll(".c-sidebar-item__content").forEach((t) => {
    var a;
    if (t.textContent != "Quick SSRF")
      return;
    let e = (a = t.parentNode) == null ? void 0 : a.querySelector(
      ".c-sidebar-item__count"
    );
    if (!e)
      return;
    let n = e.querySelector(
      ".c-sidebar-item__count-label"
    );
    if (n)
      if (n) {
        const c = n.textContent;
        if (!c)
          return;
        const o = parseInt(c);
        if (isNaN(o))
          return;
        n.textContent = String(o + 1);
      } else {
        let c = document.createElement("div");
        c.classList.add("c-sidebar-item__count-label"), c.textContent = "1", e.appendChild(c);
      }
  });
}, labelElement$1 = (t) => {
  const e = document.createElement("div");
  return e.style.overflow = "hidden", e.innerHTML = escapeHTML(t), e;
}, requestDumpToHTML = (t) => {
  const e = escapeHTML(t.dump);
  if (t.protocol !== "HTTP")
    return e.split(`
`).join("<br>");
  const n = e.split(`
`), a = document.createElement("div");
  let c = !0;
  return n.forEach((o, u) => {
    const h = document.createElement("div");
    if (c && o.trim() === "" && (c = !1), u === 0) {
      const p = o.split(" ")[0], x = o.split(" ")[1], l = o.split(" ")[2];
      if (!p || !x || !l)
        return;
      const b = document.createElement("span");
      b.classList.add("http_method"), b.innerHTML = p + " ";
      const E = document.createElement("span");
      E.classList.add("http_url"), E.innerHTML = x + " ";
      const C = document.createElement("span");
      C.classList.add("http_version"), C.innerHTML = l, h.appendChild(b), h.appendChild(E), h.appendChild(C);
    }
    if (c) {
      if (o.includes(":")) {
        const p = o.split(":"), x = p[0], l = p.slice(1).join(":"), b = document.createElement("span");
        b.classList.add("http_header-key"), b.innerHTML = x + ":";
        const E = document.createElement("span");
        E.classList.add("http_header-value"), E.innerHTML = l, h.appendChild(b), h.appendChild(E);
      }
    } else
      h.innerHTML = o.split("\\n").join("<br>"), h.classList.add("http_body"), (h.textContent == "\r" || h.textContent == "" || h.textContent == `
`) && (h.style.margin = "5px");
    a.appendChild(h);
  }), a.outerHTML;
}, isNumeric = (t) => !isNaN(Number(t)), checkHeaderFormat = (t) => {
  const e = t.split(`
`);
  for (const n of e)
    if (!n.includes(":"))
      return !1;
  for (const n of e) {
    const a = n.indexOf(":");
    if (n[a + 1] !== " ")
      return !1;
  }
  return !0;
}, settingsPage = () => {
  const t = document.createElement("div");
  t.className = "c-evenbetter_quick-ssrf";
  const e = document.createElement("div");
  e.className = "c-evenbetter_quick-ssrf__content";
  const n = navigationBar();
  t.appendChild(n);
  const a = SettingsPageBody();
  if (a)
    return e.appendChild(a), t.appendChild(e), t;
};
let settingsPageBody;
const SettingsPageBody = () => {
  var q, F;
  const t = document.createElement("div");
  t.classList.add("eb-quickssrf__settings"), t.innerHTML = `
<div class="eb-quickssrf__settings-header">
  <div style="font-weight: 600; font-size: 17px;">
     EvenBetter: Quick SSRF - Settings
  </div>
  <div style="color: var(--c-fg-subtle); font-size: 15px;">
     Configure EvenBetter: Quick SSRF settings.
  </div>
</div>
<div class="eb-quickssrf__settings-content">
  <div class="eb-quickssrf__settings--group">
     <div class="eb-quickssrf__setting-title">Customize HTTP response</div>
     <div class="eb-quickssrf__setting" data-key="customResponse">
        <div class="eb-quickssrf__setting-warning" style="display:none">
           Custom responses are only supported by <b>ssrf.cvssadvisor.com</b>
        </div>
        <!-- Status Code / Body / Headers inputs -->
        <div id="customhttpresponse_input" class="eb-quickssrf__setting-input" data-placeholder="200" data-key="customStatusCode">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Status Code</div>
              <div class="eb-quickssrf__setting-input-description">
                 This is the HTTP status code of the response. You can try to use the redirect status codes to bypass SSRF protection.
              </div>
           </div>
        </div>
        <div id="customhttpresponse_input" class="eb-quickssrf__setting-input" data-placeholder="Hello, World!" data-key="customBody">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Body</div>
              <div class="eb-quickssrf__setting-input-description">
                 This is the body of the HTTP response.
              </div>
           </div>
        </div>
        <div id="customhttpresponse_input" class="eb-quickssrf__setting-input" data-placeholder="Content-Type: text/html" data-key="customHeaders">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Headers</div>
              <div class="eb-quickssrf__setting-input-description">
                 Headers are in the format of key: value. You can add multiple headers in new lines.
              </div>
           </div>
        </div>
     </div>
  </div>
  <!-- Private Interactsh instance, fields: enable, host, token -->
  <div class="eb-quickssrf__settings--group">
     <div class="eb-quickssrf__setting-title">Self-hosted interactsh instance</div>
     <div class="eb-quickssrf__setting" data-key="interactsh">
        <div class="eb-quickssrf__setting-checkbox" data-key="interactsh-enable">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Enable</div>
              <div class="eb-quickssrf__setting-input-description">
                 Enable the self-hosted interactsh instance.
              </div>
           </div>
        </div>
        <div class="eb-quickssrf__setting-input" data-placeholder="https://interactsh.com" data-key="interactsh-host">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Host</div>
              <div class="eb-quickssrf__setting-input-description">
                 The host of your self-hosted interactsh instance.
              </div>
           </div>
        </div>
        <div class="eb-quickssrf__setting-input" data-placeholder="your-token" data-input-type="password" data-key="interactsh-token">
           <div class="eb-quickssrf__setting-text">
              <div class="eb-quickssrf__setting-input-label">Token</div>
              <div class="eb-quickssrf__setting-input-description">
                 The token of your self-hosted interactsh instance.
              </div>
           </div>
        </div>
     </div>
  </div>
</div>
  `, settingsPageBody = t, t.querySelectorAll(".eb-quickssrf__setting-input").forEach((z) => {
    const H = z.getAttribute("data-placeholder");
    if (!H)
      return;
    const U = getEvenBetterAPI().components.createTextInput(
      "100%",
      H
    ), Y = z.getAttribute("data-input-type");
    if (Y) {
      const ee = U.querySelector("input");
      ee && (ee.type = Y);
    }
    z.appendChild(U);
  }), t.querySelectorAll(".eb-quickssrf__setting-checkbox").forEach((z) => {
    const H = z.getAttribute("data-key"), U = localStorage.getItem(`eb-${H}`) === "true", Y = getEvenBetterAPI().components.createCheckbox(), ee = Y.querySelector(
      'input[type="checkbox"]'
    );
    ee.checked = U, z.appendChild(Y), z.addEventListener("change", () => {
      localStorage.setItem(`eb-${H}`, ee.checked ? "true" : "false");
    });
  });
  const e = t.querySelector(
    "[data-key='interactsh-enable']"
  ), n = t.querySelector(
    "[data-key='interactsh-host']"
  ), a = t.querySelector(
    "[data-key='interactsh-token']"
  );
  if (!e || !n || !a)
    return;
  const c = e.querySelector(
    "input"
  ), o = n.querySelector(
    "input"
  ), u = a.querySelector(
    "input"
  );
  if (!c || !o || !u)
    return;
  e.addEventListener("change", () => {
    localStorage.setItem(
      "eb-interactsh-enable",
      c.checked.toString()
    );
  }), (q = n.querySelector("input")) == null || q.addEventListener("input", (z) => {
    localStorage.setItem(
      "eb-interactsh-host",
      z.target.value
    );
  }), (F = a.querySelector("input")) == null || F.addEventListener("input", (z) => {
    localStorage.setItem(
      "eb-interactsh-token",
      z.target.value
    );
  });
  const h = localStorage.getItem("eb-interactsh-enable"), p = localStorage.getItem("eb-interactsh-host"), x = localStorage.getItem("eb-interactsh-token");
  h && (c.checked = h === "true"), p && (o.value = p), x && (u.value = x);
  let l = t.querySelector(
    "[data-key='customHeaders'] input"
  );
  l.outerHTML = l.outerHTML.replace(
    "<input",
    "<textarea"
  ), l = t.querySelector(
    "[data-key='customHeaders'] textarea"
  ), l.style.height = "100px";
  let b = t.querySelector(
    "[data-key='customBody'] input"
  );
  b.outerHTML = b.outerHTML.replace("<input", "<textarea"), b = t.querySelector(
    "[data-key='customBody'] textarea"
  ), b.style.height = "100px";
  const E = t.querySelector(
    "[data-key='customResponse']"
  );
  if (!E)
    return;
  const C = getCaidoAPI$1().ui.button({
    label: "Save",
    variant: "primary",
    size: "small",
    leadingIcon: "fas fa-save"
  });
  return C.addEventListener("click", async () => {
    if (C.ariaDisabled === "true")
      return;
    const z = document.querySelector(
      "[data-key='customStatusCode'] input"
    );
    if (!isNumeric(z.value)) {
      getEvenBetterAPI().toast.showToast({
        message: "Status code must be a number.",
        type: "error",
        duration: 2e3,
        position: "bottom"
      });
      return;
    }
    const H = document.querySelector(
      "[data-key='customBody'] textarea"
    ), U = document.querySelector(
      "[data-key='customHeaders'] textarea"
    );
    if (!checkHeaderFormat(U.value)) {
      getEvenBetterAPI().toast.showToast({
        message: "Headers must be in the format of `key: value`. Make sure you have a space after the colon.",
        type: "error",
        duration: 2e3,
        position: "bottom"
      });
      return;
    }
    ssrfInstance && customizeHTTPResponse(
      ssrfInstance.id,
      parseInt(z.value),
      H.value,
      U.value
    ).then((Y) => {
      getEvenBetterAPI().toast.showToast({
        message: "HTTP response customized successfully!",
        type: "success",
        duration: 2e3,
        position: "bottom"
      });
    }).catch((Y) => {
      getEvenBetterAPI().toast.showToast({
        message: "Failed to customize HTTP response.",
        type: "error",
        duration: 2e3,
        position: "bottom"
      }), console.error(Y);
    });
  }), C.id = "eb-quickssrf-save-button", C.ariaDisabled = "true", E.appendChild(C), getEvenBetterAPI().eventManager.on("onSSRFInstanceChange", () => {
    C.ariaDisabled = "false";
    const z = t.querySelector(
      ".eb-quickssrf__setting-warning"
    ), H = t.querySelectorAll("#customhttpresponse_input");
    (ssrfInstance == null ? void 0 : ssrfInstance.type) === SSRFInstanceType.CVSSADVISOR ? (z.style.display = "none", H.forEach((U) => {
      const Y = U;
      Y.style.display = "flex";
    }), C.style.display = "block", refreshHTTPResponseInputs()) : (z.style.display = "block", H.forEach((U) => {
      const Y = U;
      Y.style.display = "none";
    }), C.style.display = "none");
  }), t;
}, refreshHTTPResponseInputs = async () => {
  if (!ssrfInstance || ssrfInstance.type !== SSRFInstanceType.CVSSADVISOR || !settingsPageBody)
    return;
  const t = await getCASSRFInstance(ssrfInstance.id), e = settingsPageBody.querySelector(
    "[data-key='customStatusCode'] input"
  ), n = settingsPageBody.querySelector(
    "[data-key='customBody'] textarea"
  ), a = settingsPageBody.querySelector(
    "[data-key='customHeaders'] textarea"
  );
  e.value = t.response_data.status_code.toString(), n.value = t.response_data.body, a.value = Object.entries(t.response_data.headers).map(([c, o]) => `${c}: ${o}`).join(`
`);
}, setActiveSidebarItem = (t, e) => {
  const n = Array.from(
    document.querySelectorAll(".c-sidebar-item")
  ).filter((c) => c.textContent == t);
  if (n.length == 0)
    return;
  n[0].setAttribute("data-is-active", e);
}, quickSSRFFunctionality = () => {
  getEvenBetterAPI().eventManager.on("onPageOpen", (n) => {
    n.newUrl == "#/replay" && getSetting$1("ssrfInstanceFunctionality") === "true" && setTimeout(() => observeReplayInput(), 1e3);
  });
  const t = reqHistoryPage(), e = settingsPage();
  !t || !e || (getCaidoAPI$1().navigation.addPage("/evenbetter/quick-ssrf", {
    body: t
  }), getCaidoAPI$1().navigation.addPage("/evenbetter/quick-ssrf/settings", {
    body: e
  }), getCaidoAPI$1().sidebar.registerItem("Quick SSRF", "/evenbetter/quick-ssrf", {
    icon: "fas fa-compass",
    group: "EvenBetter"
  }), getEvenBetterAPI().eventManager.on("onPageOpen", (n) => {
    setActiveSidebarItem(
      "Quick SSRF",
      n.newUrl.startsWith("#/evenbetter/quick-ssrf") ? "true" : "false"
    );
  }), pullInterval());
}, pullInterval = () => {
  const t = window.location.hash === "#/evenbetter/quick-ssrf" ? 1250 : 8e3;
  ssrfInstance && ssrfInstance.state === SSRFInstanceState.ACTIVE && pullSSRFHits(), setTimeout(() => {
    pullInterval();
  }, t);
};
let replayInputObserver = null;
const observeReplayInput = () => {
  const t = document.querySelector(".c-replay-entry .cm-content");
  if (!t)
    return;
  replayInputObserver && (replayInputObserver.disconnect(), replayInputObserver = null);
  const e = getSetting$1("ssrfInstancePlaceholder");
  replayInputObserver = new MutationObserver((a) => {
    a.forEach((c) => {
      const o = c.target.textContent;
      if (o && o.includes(e)) {
        if (!ssrfInstance) {
          getEvenBetterAPI().modal.openModal({
            title: "SSRF Instance not found",
            content: "Please create an SSRF instance from the sidebar Quick SSRF page before using this functionality."
          });
          return;
        }
        const u = window.getSelection();
        if (!u)
          return;
        const h = u.focusNode;
        if (!h)
          return;
        const p = u.focusOffset, x = getCursorPosition(c.target, h, p, {
          pos: 0,
          done: !1
        });
        p === 0 && (x.pos += 0.5);
        const l = o.replace(
          getSetting$1("ssrfInstancePlaceholder"),
          ssrfInstance.url
        );
        c.target.textContent = l, u.removeAllRanges();
        const b = setCursorPosition(
          c.target,
          document.createRange(),
          {
            pos: x.pos,
            done: !1
          }
        );
        b.collapse(!0), u.addRange(b);
      }
    });
  });
  const n = {
    characterData: !0,
    subtree: !0
  };
  replayInputObserver.observe(t, n);
};
function getCursorPosition(t, e, n, a) {
  if (a.done)
    return a;
  let c = null;
  if (t.childNodes.length == 0) {
    if (!t.textContent)
      return a;
    a.pos += t.textContent.length;
  } else
    for (let o = 0; o < t.childNodes.length && !a.done; o++)
      if (c = t.childNodes[o], !!c) {
        if (c === e)
          return a.pos += n, a.done = !0, a;
        getCursorPosition(c, e, n, a);
      }
  return a;
}
function setCursorPosition(t, e, n) {
  if (n.done)
    return e;
  if (t.childNodes.length == 0) {
    if (!t.textContent)
      return e;
    t.textContent.length >= n.pos ? (e.setStart(t, n.pos), n.done = !0) : n.pos = n.pos - t.textContent.length;
  } else
    for (let a = 0; a < t.childNodes.length && !n.done; a++) {
      let c = t.childNodes[a];
      c && setCursorPosition(c, e, n);
    }
  return e;
}
const isTauri$1 = () => typeof __TAURI_INVOKE__ < "u", invokeTauri$1 = async (t, e) => await __TAURI_INVOKE__(t, e), downloadFile = async (t, e) => {
  if (isTauri$1())
    return invokeTauri$1("download", { filename: t, data: e });
  {
    const n = new Blob([e], { type: "text/plain" }), a = URL.createObjectURL(n), c = document.createElement("a");
    c.href = a, c.download = t, c.click();
  }
}, onScopeTabOpen = () => {
  getEvenBetterAPI().eventManager.on("onPageOpen", (t) => {
    t.newUrl == "#/scope" ? (addImportButton$1(), observeScopeTab()) : scopeTabObserver && (scopeTabObserver.disconnect(), scopeTabObserver = null);
  });
}, addImportButton$1 = () => {
  var n;
  const t = document.querySelector(".c-header__actions");
  if (!t)
    return;
  (n = document.querySelector("#scope-presents-import")) == null || n.remove();
  const e = getCaidoAPI$1().ui.button({
    label: "Import",
    leadingIcon: "fas fa-file-upload",
    variant: "primary"
  });
  e.id = "scope-presents-import", e.addEventListener("click", () => {
    const a = document.createElement("input");
    a.type = "file", a.accept = ".json", a.style.display = "none", a.addEventListener("change", (c) => {
      const o = c.target;
      if (!o.files || !o.files.length)
        return;
      const u = o.files[0];
      if (!u)
        return;
      const h = new FileReader();
      h.onload = (p) => {
        const x = p.target, l = JSON.parse(x.result);
        getCaidoAPI$1().scopes.createScope({
          name: l.name,
          allowlist: l.allowlist,
          denylist: l.denylist
        });
      }, h.readAsText(u);
    }), document.body.prepend(a), a.click(), a.remove();
  }), t.style.gap = "0.8rem", t.style.display = "flex", t.appendChild(e);
};
let scopeTabObserver = null;
const observeScopeTab = () => {
  var e;
  const t = (e = document.querySelector(
    ".c-preset-form-create"
  )) == null ? void 0 : e.parentElement;
  t && (scopeTabObserver && (scopeTabObserver.disconnect(), scopeTabObserver = null), scopeTabObserver = new MutationObserver((n) => {
    n.some(
      (a) => a.attributeName === "style" || a.target.classList.contains(
        "c-preset-form-create__header"
      )
    ) || attachDownloadButton$1();
  }), scopeTabObserver.observe(t, {
    childList: !0,
    attributes: !0,
    subtree: !0
  }));
}, attachDownloadButton$1 = () => {
  var a;
  (a = document.querySelector("#scope-presents-download")) == null || a.remove();
  const t = document.querySelector(
    ".c-preset-form-create__header"
  ), e = getCaidoAPI$1().ui.button({
    label: "Download",
    leadingIcon: "fas fa-file-arrow-down",
    variant: "tertiary",
    size: "small"
  });
  e.id = "scope-presents-download";
  const n = e.querySelector("button");
  n && (n.addEventListener("click", () => {
    const c = getActiveScopePreset();
    if (!c)
      return;
    const u = getCaidoAPI$1().scopes.getScopes().find((h) => h.id === c);
    u && (downloadFile("scope-" + u.name + ".json", JSON.stringify(u)), getEvenBetterAPI().toast.showToast({
      message: "Scope preset downloaded successfully",
      duration: 3e3,
      position: "bottom",
      type: "success"
    }));
  }), t == null || t.appendChild(e));
}, getActiveScopePreset = () => {
  var t;
  return (t = document.querySelector('.c-preset[data-is-selected="true"]')) == null ? void 0 : t.getAttribute("data-preset-id");
}, addGroupHideFunctionality = () => {
  if (getSetting$1("sidebarHideGroups") !== "true")
    return;
  document.querySelectorAll(
    ".c-sidebar-group__title"
  ).forEach((e) => {
    e.textContent !== "..." && e.addEventListener("click", () => {
      const a = e.parentElement;
      if (!a)
        return;
      const c = a.querySelector(".c-sidebar-group__items"), o = a.getAttribute("data-is-group-collapsed");
      c.style.display = o === "true" ? "block" : "none", a.setAttribute(
        "data-is-group-collapsed",
        o === "true" ? "false" : "true"
      ), storeSidebarGroupCollapsedStates();
    });
  });
}, storeSidebarGroupCollapsedStates = () => {
  document.querySelectorAll(".c-sidebar-group").forEach((e) => {
    var c, o;
    const n = (o = (c = e.children[0]) == null ? void 0 : c.textContent) == null ? void 0 : o.trim();
    if (!n)
      return;
    const a = e.getAttribute("data-is-group-collapsed");
    a !== null && localStorage.setItem(`evenbetter_${n}_isCollapsed`, a);
  });
}, restoreSidebarGroupCollapsedStates = () => {
  if (getSetting$1("sidebarHideGroups") !== "true")
    return;
  document.querySelectorAll(".c-sidebar-group").forEach((e) => {
    var c, o;
    const n = (o = (c = e.children[0]) == null ? void 0 : c.textContent) == null ? void 0 : o.trim();
    if (!n)
      return;
    const a = localStorage.getItem(
      `evenbetter_${n}_isCollapsed`
    );
    if (a) {
      e.setAttribute("data-is-group-collapsed", a);
      const u = e.querySelector(".c-sidebar-group__items");
      u.style.display = a === "true" ? "none" : "block";
    }
  });
}, addMoveButtonsToSidebar = () => {
  if (getSetting$1("sidebarRearrangeGroups") !== "true")
    return;
  document.querySelectorAll(
    ".c-sidebar-group__title"
  ).forEach((n) => {
    const a = n.textContent;
    a && a !== "..." && attachMoveButtonsToGroup(n, a);
  }), document.querySelectorAll(".c-sidebar-group").forEach((n) => {
    const a = n.querySelector(".c-sidebar-group__move-up"), c = n.querySelector(".c-sidebar-group__move-down");
    !a || !c || (a.addEventListener("click", (o) => {
      moveGroup(n, "up"), o.stopPropagation();
    }), c.addEventListener("click", (o) => {
      moveGroup(n, "down"), o.stopPropagation();
    }));
  });
}, attachMoveButtonsToGroup = (t, e) => {
  t.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;">${e}
          <div class="c-sidebar-group__rearrange-arrows">
              <svg class="c-sidebar-group__move-up" width="15px" height="15px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 5V19M12 5L6 11M12 5L18 11" stroke="#424242" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              <svg class="c-sidebar-group__move-down" width="15px" height="15px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 5V19M12 19L6 13M12 19L18 13" stroke="#424242" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
          </div>
        `;
}, moveGroup = (t, e) => {
  const n = t.parentElement;
  if (!n)
    return;
  const a = Array.from(n.children).indexOf(t);
  if (e === "up" && a > 0 || e === "down" && a < n.children.length - 1) {
    const c = e === "up" ? a - 1 : a + 1;
    if (c == 0)
      return;
    const o = n.children[c + (e === "up" ? 0 : 1)];
    if (!o)
      return;
    n.insertBefore(t, o), storeSidebarGroupPositions();
  }
}, storeSidebarGroupPositions = () => {
  document.querySelectorAll(".c-sidebar-group").forEach((e) => {
    var o, u;
    const n = e.parentElement;
    if (!n)
      return;
    const a = (u = (o = e.children[0]) == null ? void 0 : o.textContent) == null ? void 0 : u.trim();
    if (!a)
      return;
    const c = Array.from(n.children).indexOf(e);
    localStorage.setItem(`evenbetter_${a}_position`, String(c));
  });
}, restoreSidebarGroupPositions = () => {
  if (getSetting$1("sidebarRearrangeGroups") !== "true")
    return;
  document.querySelectorAll(".c-sidebar-group").forEach((e) => {
    var u, h;
    const n = e.parentElement;
    if (!n)
      return;
    const a = (h = (u = e.children[0]) == null ? void 0 : u.textContent) == null ? void 0 : h.trim();
    if (!a)
      return;
    const c = localStorage.getItem(`evenbetter_${a}_position`), o = n.children[Number(c)];
    o && n.insertBefore(e, o);
  });
}, sidebarTweaks = () => {
  restoreSidebarGroupCollapsedStates(), restoreSidebarGroupPositions(), addMoveButtonsToSidebar(), addGroupHideFunctionality();
};
window.global = window;
let Logger$1 = class {
  log(e, n) {
    const c = `${(/* @__PURE__ */ new Date()).toString()} [EvenBetter ${CURRENT_VERSION}]`;
    switch (e) {
      case "info":
        console.log(`${c} [INFO] ${n}`);
        break;
      case "error":
        console.error(`${c} [ERROR] ${n}`);
        break;
      case "warn":
        console.warn(`${c} [WARN] ${n}`);
        break;
      case "debug":
        break;
      default:
        console.log(`${c} [UNKNOWN] ${n}`);
    }
  }
  info(e) {
    this.log("info", e);
  }
  error(e) {
    this.log("error", e);
  }
  warn(e) {
    this.log("warn", e);
  }
  debug(e) {
    this.log("debug", e);
  }
};
const log$1 = new Logger$1(), quickMatchAndReplace = () => {
  getEvenBetterAPI().eventManager.on("onContextMenuOpen", (t) => {
    var p, x, l;
    if (!(window.location.hash == "#/replay" || window.location.hash == "#/intercept"))
      return;
    const e = document.getSelection();
    if (!e || e.toString().trim() == "")
      return;
    const n = t.querySelector("ul"), a = n.querySelectorAll(".p-menuitem"), c = a[0];
    if (!c)
      return;
    const o = c.cloneNode(!0);
    let u = a[0];
    for (let b = 0; b < a.length; b++) {
      const E = a[b];
      if (E && ((p = E.querySelector(".c-context-menu__content")) == null ? void 0 : p.textContent) == "Send to Automate") {
        u = E;
        break;
      }
    }
    const h = o.querySelector(".c-context-menu__content");
    h && (h.textContent = "Send to Match & Replace", (x = o.querySelector(".c-context-menu__leading-visual")) == null || x.remove(), (l = o.querySelector(".c-context-menu__trailing-visual")) == null || l.remove(), o.classList.remove("p-focus"), o.addEventListener("mouseenter", () => {
      n.childNodes.forEach((b) => {
        const E = b;
        if (E.nodeName == "#text" || !E.classList || !E.classList.contains("p-focus"))
          return;
        E.classList.remove("p-focus"), E.classList.remove("p-menuitem-active"), E.classList.remove("p-highlight");
        const C = E.querySelector("ul");
        C && (C.style.display = "none", E.addEventListener("mouseenter", () => {
          C.style.display = "block", E.classList.add("p-focus"), E.classList.add("p-menuitem-active"), E.classList.add("p-highlight");
        }, { once: !0 }));
      }), o.classList.add("p-focus");
    }), o.addEventListener("mouseleave", () => {
      o.classList.remove("p-focus");
    }), o.addEventListener("click", () => {
      var C;
      const b = (C = getCaidoAPI$1().window.getActiveEditor()) == null ? void 0 : C.getSelectedText();
      if (!b)
        return;
      window.location.hash = "#/tamper";
      let E = setInterval(() => {
        const q = document.querySelector(
          ".c-tamper textarea"
        );
        q && (q.value = b, clearInterval(E));
      }, 2);
      n.remove();
    }), u && n.insertBefore(o, u.nextSibling));
  });
};
let selectedLineElements = [];
const getLinesContainingSelection = () => {
  let t = window.getSelection();
  if (!t)
    return [];
  if (t.rangeCount === 0)
    return [];
  let e = t.getRangeAt(0), n = e.startContainer, a = e.endContainer;
  for (; n && n.parentElement && !n.parentElement.classList.contains("cm-line"); )
    n = n.parentElement;
  for (; a && a.parentElement && !a.parentElement.classList.contains("cm-line"); )
    a = a.parentElement;
  if (!n || !n.parentElement || !a || !a.parentElement)
    return [];
  let c = [], o = n.parentElement;
  for (; o && o !== a.parentElement.nextSibling; )
    c.push(o), o = o.nextSibling;
  return c;
};
function unicodeEncode(t) {
  for (var e = "", n = 0; n < t.length; n++) {
    for (var a = t.charCodeAt(n).toString(16); a.length < 4; )
      a = "0" + a;
    e += "\\u" + a;
  }
  return e;
}
const attachQuickDecode = () => {
  const t = document.querySelector(".c-session-list-body");
  if (!t || document.querySelector(".evenbetter__qd-body"))
    return;
  const e = document.createElement("div");
  e.classList.add("evenbetter__qd-body"), e.id = "evenbetter__qd-body", e.style.display = "none", e.innerHTML = ` 
  <div class="evenbetter__qd-selected-text">
    <div class="evenbetter__qd-selected-text-top">
      <div class="evenbetter__qd-selected-text-label">
        Decoded text:
      </div>
      <i class="c-icon fas fa-copy"></i>
    </div>
    <div contenteditable="plaintext-only" autocomplete="false" class="evenbetter__qd-selected-text-box"></div>
    <div style="color: var(--c-fg-subtle);margin-top:5px;" class="evenbetter__qd-selected-text-label evenbetter__qd-selected-text-error">
    </div>
  </div>
  `;
  const n = e.querySelector(
    ".evenbetter__qd-selected-text-box"
  ), a = e.querySelector(".fa-copy");
  if (!a)
    return;
  a.addEventListener("click", () => {
    const o = n.textContent;
    o && navigator.clipboard.writeText(o);
  });
  let c = "none";
  n.addEventListener("input", (o) => {
    const u = o.target, h = u.dataset.previousValue || "";
    let p = u.innerText.replace(/[\u2014]/g, "--").replace(/[\u2022]/g, "*").replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').replace(/\u00A0/g, " ");
    if (p === h || p.length <= 1)
      return;
    let x = selectedLineElements.map((E) => E.textContent).join(`\r
`);
    if (x.split(h).length > 2)
      return;
    if (c === "url" ? p = encodeURIComponent(p) : c === "base64" ? p = btoa(p) : c === "url+base64" ? p = encodeURIComponent(btoa(p)) : c === "unicode" && (p = unicodeEncode(p)), isPrettifyEnabled()) {
      let E = !1;
      selectedLineElements.forEach((C) => {
        C.querySelector(".c-insert-widget") && (E = !0);
      }), E && (x = x.replace(
        /\s+(?=(?:(?:[^"]*"){2})*[^"]*$)/g,
        ""
      ));
    }
    for (let E = 1; E < selectedLineElements.length; E++) {
      const C = selectedLineElements[E];
      C && C.remove();
    }
    u.dataset.previousValue = p;
    const l = x;
    x = x.replace(h, p), x.split(p).length > 2 && (x = l, u.dataset.previousValue = h);
    const b = selectedLineElements[0];
    b && (b.textContent = x);
  }), document.addEventListener("selectionchange", (o) => {
    if (window.location.hash !== "#/replay" || !document.activeElement || document.activeElement.classList.contains(
      "evenbetter__qd-selected-text-box"
    ))
      return;
    const u = window.getSelection();
    if (!u)
      return;
    const h = u.toString().replaceAll(`
`, `\r
`);
    setTimeout(() => {
      var l, b;
      if (document.querySelector(".cm-selectionBackground") && h === "")
        return;
      const p = document.querySelector(
        ".evenbetter__qd-selected-text-label"
      );
      if (!p)
        return;
      const x = document.querySelector(
        ".evenbetter__qd-selected-text-error"
      );
      if (x)
        if (h.trim() !== "") {
          const E = tryToDecode(h);
          c = E.encodeMethod, selectedLineElements = [], getLinesContainingSelection().forEach((C) => {
            selectedLineElements.push(C);
          }), n.dataset.previousValue = h, p.textContent = `Decoded text (${E.encodeMethod}):`, n.innerText = E.decodedContent, x.textContent = "", n.setAttribute("contenteditable", "plaintext-only"), selectedLineElements.length > 1 && (x.textContent = "Modyfing multiple lines isn't supported yet", n.setAttribute("contenteditable", "false")), (l = document.activeElement) != null && l.closest(".c-response-body") && n.setAttribute("contenteditable", "false"), e.style.display = "block", (b = document.querySelector(".c-send-request-button")) == null || b.addEventListener("click", () => {
            const C = document.querySelector(
              ".evenbetter__qd-body"
            );
            C && (C.style.display = "none");
          });
        } else
          c = "none", e.style.display = "none";
    }, 8);
  }), t.appendChild(e);
}, isPrettifyEnabled = () => document.querySelector(
  '.c-request-skeleton__footer .c-pretty-button[data-is-pretty="true"]'
) !== null;
function isUrlEncoded(t) {
  return /(%[0-9A-Fa-f]{2})+/g.test(t);
}
const decodeOnHover = () => {
  document.querySelectorAll(".cm-line").forEach((e) => {
    e.getAttribute("evenbetter-hover-tooltip") || (e.setAttribute("evenbetter-hover-tooltip", "true"), e.addEventListener("mouseover", (n) => {
      const c = n.target.textContent;
      if (c && isUrlEncoded(c))
        try {
          const o = decodeURIComponent(c);
          e.setAttribute("title", o);
        } catch {
        }
    }), e.addEventListener("mouseout", () => e.removeAttribute("title")));
  });
}, base64Decode = (t) => {
  let e = t;
  if (t.length % 4 === 1 ? e += "=" : t.length % 4 === 2 && (e += "=="), /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(e))
    try {
      return { encodeMethod: "base64", decodedContent: atob(e) };
    } catch {
      return { encodeMethod: "none", decodedContent: t };
    }
  return { encodeMethod: "none", decodedContent: t };
}, tryToDecode = (t) => {
  const e = base64Decode(t);
  if (e.encodeMethod !== "none")
    return e;
  const n = /\\u([0-9a-fA-F]{4})/g;
  if (n.test(t))
    try {
      return { encodeMethod: "unicode", decodedContent: t.replace(
        n,
        (c, o) => String.fromCharCode(parseInt(o, 16))
      ) };
    } catch {
      return { encodeMethod: "none", decodedContent: t };
    }
  if (isUrlEncoded(t))
    try {
      const a = decodeURIComponent(t), c = base64Decode(a);
      return c.encodeMethod !== "none" && t.length > 8 ? {
        encodeMethod: "url+base64",
        decodedContent: c.decodedContent
      } : { encodeMethod: "url", decodedContent: a };
    } catch {
      return { encodeMethod: "none", decodedContent: t };
    }
  return { encodeMethod: "none", decodedContent: t };
}, quickDecode = () => {
  getSetting$1("quickDecode") === "true" && getEvenBetterAPI().eventManager.on("onPageOpen", (t) => {
    t.newUrl === "#/replay" && (attachQuickDecode(), setTimeout(() => {
      const e = document.querySelector(".cm-editor");
      e && (e.addEventListener("input", decodeOnHover), decodeOnHover());
    }, 500));
  });
}, dropdownTweaks = () => {
  document.addEventListener("keydown", (t) => {
    if (t.key === "Escape") {
      const e = document.querySelector(
        ".c-context-menu__floating > .c-menu"
      );
      e && e.remove();
    }
  });
}, attachToWorkflowsNavigation = () => {
  var a, c, o;
  const t = document.querySelector(".p-menubar-root-list");
  if (!t || t.querySelector("#workflows-library"))
    return;
  const e = (a = t.children[0]) == null ? void 0 : a.cloneNode(!0);
  e.id = "workflows-library";
  const n = e.querySelector("span");
  n && (n.textContent = "Library", (c = e.querySelector("a")) == null || c.setAttribute("href", "#/workflows/library"), (o = e.querySelector(".c-workflows__item")) == null || o.setAttribute("data-is-active", "false"), t.appendChild(e));
}, customLibraryTab = () => {
  const t = evenBetterLibraryTab();
  t && (getCaidoAPI$1().navigation.addPage("workflows/library", {
    body: t
  }), getEvenBetterAPI().eventManager.on("onPageOpen", (e) => {
    e.newUrl.startsWith("#/workflows/") && e.newUrl !== "#/workflows/library" && attachToWorkflowsNavigation();
  }), getEvenBetterAPI().eventManager.on("onPageOpen", (e) => {
    setActiveSidebarItem(
      "Workflows",
      window.location.hash.startsWith("#/workflows/") ? "true" : "false"
    );
  }));
}, evenBetterLibraryTab = () => {
  const t = [
    { name: "Name", width: "20em" },
    { name: "Description", width: "30em" },
    { name: "Version", width: "7em" },
    { name: "Author", width: "11em" },
    { name: "OS", width: "10em" },
    { name: "Actions", width: "10em" }
  ], e = document.createElement("div");
  e.id = "evenbetter-library";
  const n = document.createElement("div");
  n.classList.add("c-workflows__repository-link"), n.style.padding = "0 var(--c-space-4)", n.innerHTML = `
    <a style="font-size: var(--c-font-size-100); display: flex; align-items: center; gap: var(--c-space-2); cursor: pointer;">
      <i class="c-icon fas fa-external-link"></i>Community Workflows
    </a>
  `;
  const a = getEvenBetterAPI().components.createNavigationBar({
    title: "Workflows",
    items: [
      {
        title: "Passive",
        url: "#/workflows/passive"
      },
      {
        title: "Active",
        url: "#/workflows/active"
      },
      {
        title: "Convert",
        url: "#/workflows/convert"
      },
      {
        title: "Library",
        url: "#/workflows/library"
      }
    ],
    customButtons: [n]
  });
  e.appendChild(a);
  const c = document.createElement("div");
  c.classList.add("c-evenbetter_library-body");
  const o = document.createElement("div");
  o.classList.add("c-evenbetter_library-header");
  const u = getCaidoAPI$1().ui.button({
    label: "New workflow",
    leadingIcon: "fas fa-plus",
    variant: "primary"
  });
  u.addEventListener("click", () => {
    getCaidoAPI$1().navigation.goTo("/workflows/convert/new");
  }), o.appendChild(u);
  const h = getEvenBetterAPI().components.createTextInput(
    "fit-content",
    "Search...",
    !1,
    "fa-search"
  ), p = getEvenBetterAPI().components.createTable({
    columns: t
  }), x = h.querySelector("input");
  if (!x)
    return;
  x.addEventListener("input", (E) => {
    const C = E.target.value;
    p.filterRows(C);
  }), o.appendChild(h);
  const l = document.createElement("div");
  l.classList.add("c-evenbetter_library-content");
  const b = document.createElement("div");
  return b.classList.add("c-evenbetter_library"), b.id = "evenbetter-library-content", l.appendChild(b), c.appendChild(o), c.appendChild(l), e.appendChild(c), fetch(
    "https://raw.githubusercontent.com/bebiksior/EvenBetter/main/workflows/workflows.json?cache=" + (/* @__PURE__ */ new Date()).getTime()
  ).then((E) => {
    E.json().then((C) => {
      C.workflows.forEach((q) => {
        const F = document.createElement("div");
        F.innerHTML = `
          <div class="evenbetter-table-actions">
              <div class="evenbetter-table-actions__select">
                  <div class="c-evenbetter_button" data-plugin-url="${escapeHTML(
          q.url
        )}" data-size="small" data-block="true" data-variant="secondary" data-outline="true" data-plain="false" style="--9bad4558: center;">
                      <div class="formkit-outer" data-family="button" data-type="button" data-empty="true">
                          <div class="formkit-wrapper">
                              <button class="formkit-input c-evenbetter_button__input" type="button" name="button_82" id="input_83">
                                  <div class="c-evenbetter_button__label">
                                      Add
                                  </div>
                              </button>
                          </div>
                      </div>
                  </div>
              </div>
          </div>`, F.addEventListener("click", (z) => {
          var Y;
          const U = (Y = z.target.closest(".c-evenbetter_button")) == null ? void 0 : Y.getAttribute("data-plugin-url");
          U && fetch(U).then((ee) => {
            ee.json().then((se) => {
              getCaidoAPI$1().graphql.createWorkflow({
                input: {
                  definition: {
                    ...se
                  },
                  global: !1
                }
              });
              const fe = F.querySelector(
                ".c-evenbetter_button__label"
              );
              fe && (fe.textContent = "Added", getEvenBetterAPI().toast.showToast({
                message: "Workflow added successfully!",
                type: "success",
                duration: 1500,
                position: "bottom"
              }), setTimeout(() => {
                fe.textContent = "Add";
              }, 1e3));
            });
          });
        }), p.addRow([
          { columnName: "Name", value: labelElement(q.name) },
          {
            columnName: "Description",
            value: labelElement(q.description)
          },
          {
            columnName: "Version",
            value: labelElement(q.version)
          },
          {
            columnName: "Author",
            value: labelElement(q.author)
          },
          {
            columnName: "OS",
            value: labelElement(q.os || "All")
          },
          { columnName: "Actions", value: F }
        ]);
      });
    });
  }), b.appendChild(p.getHTMLElement()), e;
}, labelElement = (t) => {
  const e = document.createElement("div");
  return e.textContent = t, e;
};
class OnSSRFHit {
  constructor() {
    gt(this, "handlers", []);
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
  }
  trigger(e) {
    this.handlers.forEach((n) => n(e));
  }
}
const extendedCommands = () => {
  [
    "General",
    "Shortcuts",
    "Network",
    "Rendering",
    "Developer"
  ].forEach((e) => {
    getCaidoAPI$1().commands.register("settings:" + e, {
      name: "Go to Settings: " + e,
      group: "Navigation",
      run: () => {
        getCaidoAPI$1().navigation.goTo("/settings/" + e.toLowerCase());
      }
    }), getCaidoAPI$1().commandPalette.register("settings:" + e);
  });
}, deleteAllFindings = () => {
  getEvenBetterAPI().eventManager.on("onPageOpen", (t) => {
    t.newUrl === "#/findings" && attachClearAllButton();
  });
}, attachClearAllButton = () => {
  var e;
  if (document.querySelector("#clear-all-findings"))
    return;
  const t = getCaidoAPI$1().ui.button({
    label: "Clear All",
    size: "small",
    variant: "primary",
    leadingIcon: "fas fa-trash"
  });
  t.id = "clear-all-findings", t.addEventListener("click", () => {
    getCaidoAPI$1().graphql.getFindingsByOffset({
      limit: 1e5,
      offset: 0,
      filter: {},
      order: { by: "ID", ordering: "DESC" }
    }).then((n) => {
      getCaidoAPI$1().graphql.deleteFindings({
        ids: n.findingsByOffset.edges.map((a) => a.node.id)
      });
    });
  }), (e = document.querySelector(".c-finding-table .c-card__header")) == null || e.appendChild(t);
}, askAI = async (t, e) => {
  const n = getSetting$1("openaiApiKey");
  if (n)
    return log$1.info("Asking AI with OpenAI API key with prompt: " + e), (await (await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${n}`
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: t
          },
          {
            role: "user",
            content: e
          }
        ]
      })
    })).json()).choices[0].message.content;
  {
    log$1.info("Asking AI without OpenAI API key with prompt: " + e);
    const a = await createAssistantSession(t);
    if (!a)
      throw new Error("Failed to create assistant session");
    return await sendAssistantMessage(a, e), await waitForResponse(a);
  }
}, createAssistantSession = async (t) => {
  var n, a;
  const e = await getCaidoAPI$1().graphql.createAssistantSession({
    input: {
      modelId: "gpt-3.5-turbo",
      systemMessage: t
    }
  });
  return (a = (n = e == null ? void 0 : e.createAssistantSession) == null ? void 0 : n.session) == null ? void 0 : a.id;
}, sendAssistantMessage = async (t, e) => {
  await getCaidoAPI$1().graphql.sendAssistantMessage({
    sessionId: t,
    message: e
  });
}, waitForResponse = async (t) => new Promise((e, n) => {
  const a = setInterval(async () => {
    var c;
    try {
      const u = (await getCaidoAPI$1().graphql.assistantSession({ id: t })).assistantSession;
      if (!u)
        return;
      if (u.messages.length >= 3) {
        const h = (c = u.messages[2]) == null ? void 0 : c.content;
        h ? (clearInterval(a), await getCaidoAPI$1().graphql.deleteAssistantSession({ id: t }), e(h)) : n("Failed to get response from AI");
      }
    } catch (o) {
      clearInterval(a), n(o);
    }
  }, 1e3);
}), systemPrompt = `
You are the Caido HTTPQL assistant, an integral part of the EvenBetter AI system. You are here to help users with writing their HTTPQL queries.
Reply only with the HTTPQL query, nothing else. Don't explain the query, don't use markdown.
Example:

User: response contains hello
Expected response: resp.raw.cont:"hello". 

User: response contains email
Expected response: resp.raw.regex:/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,}/ 

User: response contains aws access key
Expected response: resp.raw.regex:/((?:ASIA|AKIA|AROA|AIDA)([A-Z0-7]{16}))/

Be smart, if user asks for a f.e. paypal api key give them a regex that matches paypal api keys, dont just write resp.raw.cont:"paypal api key".

HTTPQL is the query language we use in Caido to let you filtering requests and responses. It is an evolving language that we hope will eventually become an industry standard. Primitives Parts of a filter clause 1. Namespace The first part of a filter clause is the namespace. We currently support 3 namespaces: req: For HTTP requests resp: For HTTP responses preset: For filter presets The preset namespace is a bit different, it doesn't have a field nor an operator. See the filters page to learn more about filter presets. 2. Field The second part of filter clause is the field. Fields differ based on the the namespace. We will add more fields eventually. Let us know which ones you need! req ext: File extension (if we detected one). Extensions in Caido always contain the leading . (like .js). We are liberal in what we accept as an extension. host: Hostname of the target server. method: HTTP Method used for the request in uppercase. If the request is malformed, this will contain the bytes read until the first space. path: Path of the query, including the extension. port: Port of the target server. raw: The full raw data of the request. This allows you to search on things we currently don't index (like headers). resp code: Status code of the reponse. If the response is malformed, this will contain everything after HTTP/1.1 and the following space. raw: The full raw data of the response. This allows you to search on things we currently don't index (like headers). 3. Operator We have two categories of operators depending on the data type. Integers That category of operators work on field that are numbers like code and port. eq: Equal to value gt: Greater than value gte: Greater than or equal to value lt: Less than value lte: Less than or equal to value ne: No equal to value String/Bytes That category of operators work on field that are text (or bytes) like path and raw. cont: Contains value (case insensitive) eq: Equal to value like: Sqlite LIKE operator. The symbol % matches zero or more characters (like %.js to match .map.js) and the symbol _ matches one character (like v_lue to match vAlue). ncont: Doesn't contain value (case insensitive) ne: No equal to value nlike: SQLITE NOT LIKE operator, see like for more details. Regex That category of operators work on field that are text (or bytes) like path and raw. regex: Matches the regex /value.+/ nregex: Doesn't match the regex /value.+/ 4. Value This is the value against which the field will be compared. The value is either an integer (like 1), a string ("value") or a regex (/value/) depending on the field and operator. Preset The preset value is a different. You can reference presets in one of two ways: Name: preset:"Preset name" Alias: preset:preset-alias Head over to the filters page to learn more about filter presets. Standalone We support string standalone values without namespace, field and operator (like "my value"). It is a shortcut to search across both requests and responses, it is replaced at runtime by: (req.raw.cont:"my value" OR resp.raw.cont:"my value") Query A full HTTPQL Query Queries are composed of multiple filter clauses that are combined together using logical operators and logical grouping. Logical operators We offer two logical operators: AND: Both the left and right clauses must be true OR: Either the left or right clause must be true Operators can be written in upper or lower case. Both have the same priority. Logical grouping Caido supports the priority of operations, AND has a higher priority than OR. Here are some examples: clause1 AND clause2 OR clause3 is equivalent to ((clause1 AND clause2) OR clause3) clause1 OR clause2 AND clause3 is equivalent to (clause1 OR (clause2 AND clause3)) clause1 AND clause2 AND clause3 is equivalent to ((clause1 AND clause2) AND clause3) We still recommend that you insert parentheses to make sure the logicial groups represent what you are trying to accomplish
`.replaceAll(`
`, " "), setupSuggestAICommand = () => {
  getEvenBetterAPI().promptCommands.createPromptCommand(
    "Suggest HTTPQL query",
    "Response contains 'hello' and status code is 200",
    suggestHTTPQLQuery
  );
}, suggestHTTPQLQuery = async (t) => {
  askAI(systemPrompt, t).then((e) => {
    setHTTPQLQuery(e);
  }).catch((e) => {
    console.error("Error:", e), getEvenBetterAPI().toast.showToast({
      message: "Failed to suggest HTTPQL query. More details in the console.",
      duration: 3e3,
      position: "bottom",
      type: "error"
    });
  });
}, setHTTPQLQuery = async (t) => {
  try {
    getCaidoAPI$1().navigation.goTo("/intercept");
    const e = setInterval(() => {
      const n = document.querySelector(
        ".c-topbar__filter .cm-editor .cm-line"
      );
      n && (n.textContent = t, clearInterval(e));
    }, 5);
  } catch (e) {
    console.error("Error:", e);
  }
};
class OnSSRFInstanceChange {
  constructor() {
    gt(this, "handlers", []);
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
  }
  trigger() {
    this.handlers.forEach((e) => e());
  }
}
const dropRequests = async () => {
  try {
    getCaidoAPI$1().graphql.interceptRequestMessages({ first: 1e3 }).then((t) => t.interceptMessages.nodes.forEach((e) => {
      getCaidoAPI$1().graphql.dropInterceptMesage({ id: e.id });
    })), setTimeout(refreshInterceptEntries, 25);
  } catch (t) {
    console.error("Error executing drop requests based on fetched IDs:", t);
  }
}, refreshInterceptEntries = () => {
  document.querySelector(".c-global-actions__status button").click(), setTimeout(() => {
    document.querySelector(".c-global-actions__status button").click();
  }, 5);
}, attachNewButton = () => {
  var n;
  (n = document.querySelector("#dropAllButton")) == null || n.remove();
  const t = document.querySelector(".c-topbar__left");
  if (!t)
    return;
  const e = getCaidoAPI$1().ui.button({
    variant: "primary",
    label: "Drop all",
    size: "small"
  });
  e.id = "dropAllButton", e.addEventListener("click", dropRequests), t.appendChild(e);
}, dropAllButtonFeature = () => {
  getEvenBetterAPI().eventManager.on("onPageOpen", (t) => {
    t.newUrl.startsWith("#/forward/") && attachNewButton();
  });
}, getCollectionByID = async (t) => await getCaidoAPI$1().graphql.replaySessionCollections().then((e) => e.replaySessionCollections.edges.find(
  (a) => a.node.id === t
)), createSession = async (t, e) => await getCaidoAPI$1().graphql.createReplaySession({
  input: {
    collectionId: t,
    requestSource: {
      raw: e
    }
  }
}), createCollection = async (t) => await getCaidoAPI$1().graphql.createReplaySessionCollection({
  input: {
    name: t
  }
}), getRequestRawContent = async (t) => await getCaidoAPI$1().graphql.request({
  id: t
}), downloadCollection = async (t) => {
  var c, o;
  const e = await getCollectionByID(t);
  if (!e)
    return new Error("Collection not found");
  const n = e.node.sessions;
  if (n && n.length > 0)
    for (const u of n) {
      const h = (c = u.activeEntry) == null ? void 0 : c.request;
      if (!h)
        return new Error("Request not found");
      const p = h.id, x = await getRequestRawContent(p);
      if (!x)
        return new Error("Request raw content not found");
      Object.assign(h, { raw: (o = x.request) == null ? void 0 : o.raw });
    }
  const a = e.node.name.replaceAll(" ", "_");
  downloadFile("collection_" + a + ".json", JSON.stringify(e)), getEvenBetterAPI().toast.showToast({
    message: "Collection downloaded successfully!",
    duration: 3e3,
    position: "bottom",
    type: "success"
  });
}, importCollection = async (t) => {
  var o, u;
  const e = t.node.name, a = (o = (await createCollection(e)).createReplaySessionCollection.collection) == null ? void 0 : o.id;
  if (!a)
    return;
  const c = t.node.sessions;
  if (c && c.length > 0)
    for (const h of c) {
      const p = h.activeEntry.request, x = {
        connectionInfo: {
          host: p.host,
          port: p.port,
          isTLS: p.isTls
        },
        raw: p.raw
      }, l = await createSession(a, x);
      if (h.activeEntry.id !== e) {
        const b = (u = l.createReplaySession.session) == null ? void 0 : u.id;
        if (!b)
          return;
        await getCaidoAPI$1().graphql.renameReplaySession({
          id: b,
          name: h.name
        });
      }
    }
  return getEvenBetterAPI().toast.showToast({
    message: "Collection imported successfully!",
    duration: 3e3,
    position: "bottom",
    type: "success"
  }), a;
}, attachImportButton = () => {
  const t = document.querySelector(".c-topbar__left");
  if (!t)
    return;
  const e = getCaidoAPI$1().ui.button({
    label: "Import Collection",
    variant: "tertiary",
    size: "small",
    leadingIcon: "fas fa-file-import"
  });
  e.addEventListener("click", async () => {
    const n = document.createElement("input");
    n.type = "file", n.accept = ".json", n.click(), n.addEventListener("change", async () => {
      var o;
      const a = (o = n.files) == null ? void 0 : o[0];
      if (!a)
        return;
      const c = new FileReader();
      c.readAsText(a), c.onload = async () => {
        const u = JSON.parse(c.result);
        await importCollection(u), setTimeout(() => {
          window.location.reload();
        }, 50);
      };
    });
  }), t.prepend(e);
}, attachExportButton = () => {
  const t = document.querySelectorAll(".c-tree-collection");
  !t || t.length === 0 || t.forEach((e) => {
    var o;
    if (e.querySelector("#download-collection"))
      return;
    const n = e.querySelector(".c-tree-collection__actions");
    if (!n)
      return;
    const a = (o = n.childNodes[0]) == null ? void 0 : o.cloneNode(!0);
    if (!a)
      return;
    const c = a.querySelector("i");
    c && (a.id = "download-collection", c.classList.value = "c-icon fas fa-file-arrow-down", a.addEventListener("click", async () => {
      const u = e.getAttribute("data-collection-id");
      if (!u)
        return;
      const h = await downloadCollection(u);
      h && getEvenBetterAPI().toast.showToast({
        message: "Failed to download collection: " + h,
        duration: 3e3,
        position: "bottom",
        type: "error"
      });
    }), n.prepend(a));
  });
};
let mutationObserver;
const collectionsShare = () => {
  getEvenBetterAPI().eventManager.on("onPageOpen", (t) => {
    if (t.newUrl === "#/replay") {
      attachImportButton(), attachExportButton(), mutationObserver && mutationObserver.disconnect(), mutationObserver = new MutationObserver((n) => {
        n.forEach((a) => {
          a.addedNodes.length > 0 && attachExportButton();
        });
      });
      const e = document.querySelector(".c-session-list-body__tree .c-tree");
      if (!e)
        return;
      mutationObserver.observe(e, {
        childList: !0,
        subtree: !0
      });
    }
  });
}, parseHttpResponse = (t) => {
  const [e, ...n] = t.split(`\r
`);
  if (!e)
    throw new Error("Invalid response");
  const [a, c, o] = e.split(" ");
  if (!a || !c || !o)
    throw new Error("Invalid status line");
  const u = n.slice(0, n.indexOf("")), h = n.slice(n.indexOf("") + 1).join(`\r
`);
  return {
    httpVersion: a,
    statusCode: c,
    statusText: o,
    headers: u,
    body: h
  };
}, getCurrentResponse = async () => {
  const t = document.querySelector(".c-response .c-response");
  if (!t)
    return;
  const e = t.getAttribute("data-response-id");
  if (e)
    return await getCaidoAPI$1().graphql.response({ id: e }).then((n) => {
      var a;
      return (a = n.response) == null ? void 0 : a.raw;
    });
}, attachPreviewButton = () => {
  const t = document.querySelector(".c-response-header .c-response-header__right .c-response-header__actions");
  if (!t || t.querySelector("#preview-button"))
    return;
  t.style.display = "flex", t.style.gap = "1em";
  const e = getCaidoAPI$1().ui.button({
    variant: "tertiary",
    size: "small",
    leadingIcon: "fas fa-eye"
  });
  e.id = "preview-button";
  const n = e.querySelector("button");
  n.style.backgroundColor = "var(--c-bg-default)";
  const a = e.querySelector(".c-button__leading-icon");
  a.style.margin = "0", a.style.color = "white", e.addEventListener("click", async () => {
    const c = await getCurrentResponse();
    if (!c) {
      getEvenBetterAPI().toast.showToast({
        message: "Failed to get response",
        type: "error",
        duration: 3e3,
        position: "bottom"
      });
      return;
    }
    const o = parseHttpResponse(c);
    sendToCA(o);
  }), t.appendChild(e);
}, sendToCA = (t) => fetch(CA_SSRF_INSTANCE_API_URL, {
  method: "POST"
}).then((e) => e.json()).then((e) => {
  const n = e;
  console.log(t), customizeHTTPResponse(n, parseInt(t.statusCode), t.body, t.headers.join(`\r
`)).then((a) => {
    setTimeout(() => navigator.clipboard.writeText(`https://${n}.c5.rs/`), 0), getEvenBetterAPI().toast.showToast({
      message: "Navigate to the copied URL to view the response!",
      type: "success",
      duration: 3e3,
      position: "bottom"
    });
  }).catch((a) => {
    getEvenBetterAPI().toast.showToast({
      message: "Failed to send response to CVSSAdvisor!",
      type: "error",
      duration: 3e3,
      position: "bottom"
    }), console.error(a);
  });
});
let interceptObserver;
const observeChangesIntercept = () => {
  interceptObserver == null || interceptObserver.disconnect();
  const t = document.querySelector(".c-intercept .c-grid .c-grid .c-grid-item ~ .c-grid-item");
  if (!t) {
    console.warn("Target node not found.");
    return;
  }
  const e = { attributes: !0, childList: !0, subtree: !0 }, n = (a) => {
    for (const c of a)
      c.type === "childList" && attachPreviewButton();
  };
  interceptObserver = new MutationObserver(n), interceptObserver.observe(t, e);
};
let replayObserver = null;
const observeChangesReplay = () => {
  replayObserver == null || replayObserver.disconnect(), attachPreviewButton();
  const t = document.querySelector(".c-replay__replay-session");
  if (!t) {
    console.warn("Target node not found.");
    return;
  }
  const e = { attributes: !0, childList: !0, subtree: !0 }, n = (a) => {
    for (const c of a)
      for (const o of Array.from(c.addedNodes))
        o instanceof HTMLElement && (o.classList.contains("c-replay-session") || o.classList.contains("c-response")) && attachPreviewButton();
  };
  replayObserver = new MutationObserver(n), replayObserver.observe(t, e);
}, showResponse = () => {
  getEvenBetterAPI().eventManager.on("onPageOpen", (t) => {
    t.newUrl === "#/intercept" ? observeChangesIntercept() : t.newUrl === "#/replay" ? observeChangesReplay() : (interceptObserver == null || interceptObserver.disconnect(), replayObserver == null || replayObserver.disconnect());
  });
};
let numbersContainer;
const numbersPayload = () => {
  getEvenBetterAPI().eventManager.on("onPageOpen", (t) => {
    t.newUrl === "#/automate" && setTimeout(() => {
      observeSelectedSession();
    }, 100);
  }), getCaidoAPI$1().commandPalette.register("evenbetter:numbersPayload");
};
let selectedSessionObserver;
const observeSelectedSession = () => {
  var e;
  selectedSessionObserver && selectedSessionObserver.disconnect();
  const t = (e = document.querySelector(
    ".p-tabview-panels"
  )) == null ? void 0 : e.parentElement;
  t && (selectedSessionObserver = new MutationObserver(() => {
    document.querySelector(".c-empty-state__body-content") || (attachNumbersPayload(), observeDropdown());
  }), selectedSessionObserver.observe(t, {
    attributes: !0,
    subtree: !0
  }));
};
let dropdownObserver;
const observeDropdown = () => {
  var n;
  dropdownObserver && dropdownObserver.disconnect();
  const t = (n = document.querySelector(
    ".c-payload-settings__body .c-kind-dropdown .p-inputtext"
  )) == null ? void 0 : n.textContent;
  t && numbersContainer && (numbersContainer.style.display = t === "Simple List" ? "block" : "none");
  const e = document.querySelector(
    ".c-payload-settings__body .c-kind-dropdown"
  );
  e && (dropdownObserver = new MutationObserver((a) => {
    numbersContainer && a.forEach((c) => {
      var o;
      if (c.attributeName === "aria-label") {
        const u = (o = document.querySelector(
          ".c-payload-settings__body .c-kind-dropdown .p-inputtext"
        )) == null ? void 0 : o.textContent;
        numbersContainer.style.display = u === "Simple List" ? "block" : "none";
      }
    });
  }), dropdownObserver.observe(e, {
    attributes: !0,
    subtree: !0
  }));
}, attachNumbersPayload = () => {
  if (document.getElementById("numbersPayload"))
    return;
  const t = document.querySelector(
    ".c-payload-settings__kind"
  );
  if (!t)
    return;
  numbersContainer = document.createElement("div"), numbersContainer.style.marginBottom = "0.5em", numbersContainer.style.display = "none", numbersContainer.id = "numbersPayload";
  const e = document.createElement("label");
  e.innerText = "Numbers", e.style.fontSize = "var(--c-font-size-100)", numbersContainer.appendChild(e);
  const n = document.createElement("div");
  n.style.display = "flex", n.style.gap = "1em";
  const a = getEvenBetterAPI().components.createTextInput(
    "10em",
    "Min",
    !1
  );
  n.appendChild(a);
  const c = getEvenBetterAPI().components.createTextInput(
    "10em",
    "Max",
    !1
  );
  n.appendChild(c);
  const o = getEvenBetterAPI().components.createTextInput(
    "10em",
    "Step",
    !1
  ), u = a.querySelector("input"), h = c.querySelector("input"), p = o.querySelector("input");
  !u || !h || !p || (p.value = "1", n.appendChild(o), u.addEventListener("input", (x) => {
    if (!h.value)
      return;
    const l = parseInt(x.target.value), b = parseInt(h.value), E = parseInt(p.value), C = getRange(l, b, E);
    updateSimpleList(C.join(`
`));
  }), h.addEventListener("input", (x) => {
    if (!u.value)
      return;
    const l = parseInt(u.value), b = parseInt(x.target.value), E = parseInt(p.value), C = getRange(l, b, E);
    updateSimpleList(C.join(`
`));
  }), p.addEventListener("input", (x) => {
    if (!u.value || !h.value)
      return;
    const l = parseInt(u.value), b = parseInt(h.value), E = parseInt(x.target.value), C = getRange(l, b, E);
    updateSimpleList(C.join(`
`));
  }), numbersContainer.appendChild(n), t.prepend(numbersContainer));
}, updateSimpleList = (t) => {
  const e = document.querySelector(".c-simple-list__list .cm-content");
  e && (e.textContent = t);
}, getRange = (t, e, n) => {
  const a = [];
  for (let c = t; c <= e; c += n)
    a.push(c);
  return a;
}, onMARTabOpen = () => {
  getEvenBetterAPI().eventManager.on("onPageOpen", (t) => {
    t.newUrl == "#/tamper" ? (addImportButton(), observeMARTab()) : marTabObserver && (marTabObserver.disconnect(), marTabObserver = null);
  });
}, addImportButton = () => {
  const t = document.querySelector(
    ".c-rule-list-header__new"
  );
  if (!t || document.querySelector("#scope-presents-import"))
    return;
  t.style.display = "flex", t.style.gap = "0.5em";
  const e = t.parentElement;
  if (!e)
    return;
  e.style.display = "flex", e.style.justifyContent = "space-between", e.style.alignItems = "center", e.style.padding = "var(--c-space-3)";
  const n = document.createElement("div");
  n.textContent = "Rules", n.classList.add("c-header__title"), e.prepend(n);
  const a = getCaidoAPI$1().ui.button({
    label: "Import",
    leadingIcon: "fas fa-file-upload",
    variant: "primary"
  });
  a.id = "scope-presents-import", a.addEventListener("click", () => {
    const c = document.createElement("input");
    c.type = "file", c.accept = ".json", c.style.display = "none", c.addEventListener("change", (o) => {
      const u = o.target;
      if (!u.files || !u.files.length)
        return;
      const h = u.files[0];
      if (!h)
        return;
      const p = new FileReader();
      p.onload = async (x) => {
        const l = x.target, b = JSON.parse(l.result), E = await getFirstCollcetionID();
        E && (getCaidoAPI$1().graphql.createTamperRule({
          input: {
            collectionId: E,
            name: b.name,
            condition: b.condition,
            isEnabled: b.isEnabled,
            isRegex: b.isRegex,
            matchTerm: b.matchTerm,
            replaceTerm: b.replaceTerm,
            strategy: b.strategy
          }
        }), setTimeout(() => {
          window.location.reload();
        }, 20));
      }, p.readAsText(h);
    }), document.body.prepend(c), c.click(), c.remove();
  }), t.appendChild(a);
}, getFirstCollcetionID = () => getCaidoAPI$1().graphql.tamperRuleCollections().then((t) => {
  var e, n;
  return (n = (e = t.tamperRuleCollections) == null ? void 0 : e.nodes[0]) == null ? void 0 : n.id;
});
let marTabObserver = null;
const observeMARTab = () => {
  const t = document.querySelector(".c-tamper");
  t && (marTabObserver && (marTabObserver.disconnect(), marTabObserver = null), marTabObserver = new MutationObserver((e) => {
    e.some((n) => {
      const a = n.target;
      for (let c = 0; c < n.addedNodes.length; c++)
        if (n.addedNodes[c].id == "rules-download")
          return !0;
      return !!a.classList.contains("c-grid-item");
    }) || attachDownloadButton();
  }), marTabObserver.observe(t, {
    childList: !0,
    attributes: !0,
    subtree: !0
  }));
}, attachDownloadButton = () => {
  var n;
  (n = document.querySelector("#rules-download")) == null || n.remove();
  const t = document.querySelector(
    ".c-rule-form-update__header"
  );
  if (!t)
    return;
  const e = getCaidoAPI$1().ui.button({
    label: "Download",
    leadingIcon: "fas fa-file-arrow-down",
    variant: "tertiary",
    size: "small"
  });
  e.id = "rules-download", e.addEventListener("click", () => {
    const a = getActiveRuleID();
    a && getCaidoAPI$1().graphql.tamperRuleCollections().then((c) => {
      c.tamperRuleCollections.nodes.forEach((u) => {
        u.rules.forEach((p) => {
          if (p.id == a) {
            const x = p.name.replace(/[^a-zA-Z0-9]/g, "-");
            downloadFile("rule-" + x + ".json", JSON.stringify(p));
          }
        });
      });
    });
  }), t.appendChild(e);
}, getActiveRuleID = () => {
  var e;
  return (e = document.querySelector('.c-tree-item__subtree [data-is-active="true"]')) == null ? void 0 : e.getAttribute("data-rule-id");
};
class Logger {
  log(e, n) {
  }
  info(e) {
    this.log("info", e);
  }
  error(e) {
    this.log("error", e);
  }
  warn(e) {
    this.log("warn", e);
  }
}
const log = new Logger();
class EventManager {
  constructor() {
    this.events = {};
  }
  registerEvent(e, n) {
    this.events[e] = n;
  }
  triggerEvent(e, n) {
    const a = this.events[e];
    a ? a.trigger(n) : console.error(`Event "${e}" not registered.`);
  }
  on(e, n) {
    const a = this.events[e];
    a ? a.addHandler(n) : console.error(`Event "${e}" not registered.`);
  }
  initEvents() {
    log.info(`Initializing ${Object.keys(this.events).length} custom events`);
    for (const e in this.events)
      this.events[e].init();
  }
}
class OnCaidoLoad {
  constructor() {
    this.handlers = [];
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    const e = setInterval(() => {
      isCaidoLoaded() && (clearInterval(e), this.trigger());
    }, 25);
  }
  trigger() {
    this.handlers.forEach((e) => e());
  }
}
const isCaidoLoaded = () => document.querySelector(".c-content") !== null;
class OnContextMenuOpen {
  constructor() {
    this.handlers = [];
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    new MutationObserver((n) => {
      for (let a of n)
        a.type === "childList" && a.addedNodes.forEach((c) => {
          const o = c;
          c.nodeType === 1 && o.classList.contains("p-contextmenu") && this.trigger(o);
        });
    }).observe(document.body, { childList: !0, subtree: !0 });
  }
  trigger(e) {
    this.handlers.forEach((n) => n(e));
  }
}
class OnPageOpen {
  constructor(e) {
    this.handlers = [], this.eventManager = e;
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    let e = window.location.href;
    const n = new MutationObserver(() => {
      var c;
      if (window.location.href !== e) {
        let o = new URL(window.location.href).hash, u = new URL(e).hash;
        e = window.location.href, o.includes("?custom-path=") && (o = o.split("?custom-path=")[1]), u.includes("?custom-path=") && (u = u.split("?custom-path=")[1]), (c = document.querySelector(".c-content")) == null || c.setAttribute("data-page", o), this.trigger({
          newUrl: o,
          oldUrl: u
        });
      }
    }), a = { subtree: !0, childList: !0 };
    n.observe(document, a);
  }
  trigger(e) {
    log.info(`Page updated: ${e.oldUrl} -> ${e.newUrl}`), e.newUrl.startsWith("#/settings/") && this.eventManager.triggerEvent(
      "onSettingsTabOpen",
      e.newUrl.replace("#/settings/", "")
    ), this.handlers.forEach((n) => n(e));
  }
}
class OnSettingsTabOpen {
  constructor() {
    this.handlers = [];
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
  }
  trigger(e) {
    log.info(`Settings tab opened: ${e}`), this.handlers.forEach((n) => n(e));
  }
}
let PluginData = null;
const setPluginData = (t) => {
  PluginData = t;
}, getPluginData = () => {
  if (!PluginData)
    throw new Error("PluginData is not set yet!");
  return PluginData;
}, setSetting = async (t, e) => {
  const n = getPluginData();
  localStorage.setItem(`ebapi:settings:${n.manifestID}:${t}`, e);
}, getSetting = (t) => {
  const e = getPluginData();
  return localStorage.getItem(`ebapi:settings:${e.manifestID}:${t}`);
}, getWelcomeToast = () => localStorage.getItem("ebapi:welcomeToast"), setWelcomeToast = async (t) => {
  localStorage.setItem("ebapi:welcomeToast", t);
}, toastCSS = `
.v-toast--fade-in {
    animation: fadeIn 0.15s ease-in-out forwards;
}
@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}
.v-toast--fade-out {
    animation: fadeOut 0.15s ease-in-out forwards;
}
@keyframes fadeOut {
    from {
        opacity: 1;
    }
    to {
        opacity: 0;
    }
}`, createToastElement = (t, e, n) => {
  const a = document.createElement("div");
  a.classList.add("v-toast"), a.classList.add(`v-toast--${n}`);
  const c = document.createElement("div");
  c.setAttribute("role", "alert"), c.classList.add("v-toast__item"), c.classList.add(`v-toast__item--${e}`), c.classList.add(`v-toast__item--${n}`), a.appendChild(c);
  const o = document.createElement("div");
  o.classList.add("v-toast__icon"), c.appendChild(o);
  const u = document.createElement("p");
  return u.classList.add("v-toast__text"), u.textContent = t, c.appendChild(u), a.classList.add("v-toast--fade-in"), a;
}, showToast = (t) => {
  let { message: e, type: n, position: a, duration: c } = t;
  a || (a = "bottom"), n || (n = "success"), c || (c = 3e3);
  let o = document.querySelector(
    `.v-toast--${a}`
  );
  o || (o = document.createElement("div"), o.classList.add("v-toast"), o.classList.add(`v-toast--${a}`), document.body.appendChild(o));
  const u = createToastElement(e, n, a);
  o.appendChild(u), setTimeout(() => {
    u.classList.add("v-toast--fade-out"), setTimeout(() => {
      u.remove();
    }, 150);
  }, c - 150);
};
class ToastAPI {
  constructor(e) {
    this.showToast = (n) => {
      showToast(n);
    }, this.setWelcomeMessage = (n) => {
      setWelcomeToast(n);
    }, this.evenBetterAPI = e, this.evenBetterAPI.helpers.loadCSS({ id: "eb-toast", cssText: toastCSS });
  }
}
class OnCommandRun {
  constructor() {
    this.handlers = [], this.commandObserver = null, this.selectedCommand = null;
  }
  addHandler(e) {
    this.handlers.push(e);
  }
  init() {
    const e = (c) => {
      this.commandObserver = new MutationObserver((o) => {
        const u = n();
        u !== this.selectedCommand && (this.selectedCommand = u);
      }), this.commandObserver.observe(c, {
        attributes: !0,
        subtree: !0
      });
    }, n = () => document.querySelector("[command-item][aria-selected='true']");
    new MutationObserver((c) => {
      for (let o of c)
        o.type === "childList" && (o.addedNodes.forEach((u) => {
          const h = u;
          u.nodeType === 1 && h.hasAttribute("command-theme") && e(h);
        }), o.removedNodes.forEach((u) => {
          const h = u;
          if (u.nodeType === 1 && h.hasAttribute("command-theme")) {
            if (!this.selectedCommand)
              return;
            const p = this.selectedCommand.getAttribute("data-value");
            p && this.trigger(p), this.commandObserver && (this.commandObserver.disconnect(), this.commandObserver = null);
          }
        }));
    }).observe(document.body, { childList: !0, subtree: !0 });
  }
  trigger(e) {
    this.handlers.forEach((n) => n(e));
  }
}
const EVENBETTERAPI_VERSION = "1.4.0";
let CaidoAPI = null;
const setCaidoAPI = (t) => {
  CaidoAPI = t;
}, getCaidoAPI = () => {
  if (!CaidoAPI)
    throw new Error("CaidoAPI is not set yet!");
  return CaidoAPI;
}, checkboxCSS = `
.eb-checkbox__input {
    cursor: pointer;
    -webkit-appearance: none;
    appearance: none;
    width: 1.15em;
    height: 1.15em;
    border: .1em solid grey;
    border-radius: 4px;
    display: inline-grid;
    place-content: center;
    margin: 0;
}
.eb-checkbox__input:checked:before {
    transform: scale(1);
}
.eb-checkbox__input:before {
    content: "";
    transform: scale(0);
    width: .65em;
    height: .65em;
    border-radius: 2px;
    box-shadow: inset 1em 1em var(--c-fg-secondary);
}
.eb-button__label {
    display: inline-flex;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
`, createCheckbox = (t) => {
  t.helpers.loadCSS({ id: "checkbox", cssText: checkboxCSS });
  const e = document.createElement("div");
  e.classList.add("eb-button__label");
  const n = document.createElement("div");
  n.classList.add("eb-checkbox");
  const a = document.createElement("div");
  a.classList.add("formkit-outer"), a.dataset.family = "box", a.dataset.type = "checkbox", a.dataset.complete = "true";
  const c = document.createElement("label");
  c.classList.add("formkit-wrapper", "eb-checkbox__wrapper"), c.dataset.checked = "true";
  const o = document.createElement("span");
  o.classList.add("formkit-inner", "eb-checkbox__inner");
  const u = document.createElement("input");
  u.classList.add("formkit-input", "eb-checkbox__input"), u.type = "checkbox";
  const h = document.createElement("span");
  return h.classList.add("formkit-decorator"), h.setAttribute("aria-hidden", "true"), o.appendChild(u), o.appendChild(h), c.appendChild(o), a.appendChild(c), n.appendChild(a), e.appendChild(n), e;
}, cssText$1 = `
.eb-text-input__inner {
    gap: var(--c-space-1); 
    flex: 1; 
    display: flex; 
    align-items: center; 
    padding-left: var(--c-space-2); 
    padding-right: var(--c-space-2); 
    box-sizing: border-box; 
    border: var(--c-border-width-1) solid var(--c-border-default); 
    border-radius: var(--c-border-radius-2); 
    color: var(--c-fg-default); 
    background-color: var(--c-bg-default); 
    min-height: var(--c-space-10);
}
.eb-text-input__inner:focus-within {
    border: var(--c-border-width-2) solid var(--c-border-secondary);
}
.eb-text-input__inner textarea {
  padding-top: var(--c-space-2);
}
`;
function createTextInput(t, e, n, a = !1, c) {
  t.helpers.loadCSS({ id: "eb-text-input", cssText: cssText$1 });
  const o = document.createElement("div");
  o.classList.add("formkit-outer", "c-text-input__outer"), o.setAttribute("style", `width: ${e};`);
  const u = document.createElement("div");
  u.classList.add("formkit-wrapper"), u.style.display = "flex";
  const h = document.createElement("div");
  h.classList.add("formkit-inner", "eb-text-input__inner");
  const p = document.createElement("div");
  p.classList.add("c-text-input__prefix"), p.setAttribute(
    "style",
    "align-self: center; color: var(--c-fg-subtle);"
  );
  const x = document.createElement("i");
  x.classList.add("c-icon", "fas"), c && x.classList.add(c);
  const l = document.createElement("input");
  if (n && n != "" && l.setAttribute("placeholder", n), l.setAttribute("spellcheck", "false"), l.classList.add("formkit-input", "c-text-input__input"), l.setAttribute("type", "text"), l.setAttribute(
    "style",
    "width: 100%; background: transparent; border: 0; outline: 0; color: inherit; box-sizing: border-box; line-height: inherit;"
  ), c && p.appendChild(x), h.appendChild(p), h.appendChild(l), a) {
    const b = document.createElement("button");
    b.innerHTML = '<i class="fas fa-copy"></i>', b.setAttribute(
      "style",
      "background: transparent; border: 0; outline: 0; cursor: pointer; padding: 0; margin-left: 10px;"
    ), b.addEventListener("click", () => {
      navigator.clipboard.writeText(l.value), t.toast.showToast({
        message: "Copied to clipboard",
        position: "bottom",
        type: "info",
        duration: 1e3
      });
    }), h.appendChild(b);
  }
  return u.appendChild(h), o.appendChild(u), o;
}
function createNavigationBar(t, e) {
  const n = document.createElement("div");
  n.classList.add("c-menu-bar"), n.style.width = "100%";
  const a = document.createElement("div");
  a.classList.add("p-menubar", "p-component"), a.setAttribute("data-pc-name", "menubar"), a.setAttribute("data-pc-section", "root");
  const c = document.createElement("div");
  c.classList.add("p-menubar-start"), c.setAttribute("data-pc-section", "start");
  const o = document.createElement("div");
  o.classList.add("c-settings__title"), o.style.padding = "0 var(--c-space-4)", o.style.fontWeight = "700", o.textContent = e.title, c.appendChild(o);
  const u = document.createElement("ul");
  u.classList.add("p-menubar-root-list");
  const h = e.items.map((l) => l.url);
  e.items.forEach((l) => {
    const b = document.createElement("li");
    b.classList.add("p-menuitem"), b.setAttribute("role", "menuitem"), b.style.margin = "0";
    const E = document.createElement("div");
    E.classList.add("p-menuitem-content"), E.setAttribute("data-pc-section", "content");
    const C = document.createElement("div");
    C.classList.add("c-settings__item"), C.setAttribute("data-is-active", "true"), C.addEventListener("click", () => {
      a.classList.remove("p-menubar-mobile-active");
    });
    const q = document.createElement("a");
    q.setAttribute("href", l.url), q.setAttribute("draggable", "false"), q.draggable = !1, q.classList.add("p-menuitem-link"), l.url === location.hash && (q.style.backgroundColor = "rgba(255,255,255,.04)", q.style.borderRadius = "var(--c-border-radius-2)");
    let F = null;
    if (t.eventManager.on("onPageOpen", (H) => {
      if (l.sidebarItemName)
        if (h.includes(H.newUrl)) {
          const U = document.querySelectorAll(".c-sidebar-item");
          if (U) {
            const Y = Array.from(U).filter(
              (ee) => ee.textContent === l.sidebarItemName
            );
            Y.length >= 1 && (F = Y[0], F.setAttribute("data-is-selected", "true"), F.setAttribute("data-is-active", "true"));
          }
        } else
          F && (F.removeAttribute("data-is-selected"), F.removeAttribute("data-is-active"), F = null);
      H.newUrl === l.url ? (l.onOpen && l.onOpen(), q.style.backgroundColor = "rgba(255,255,255,.04)", q.style.borderRadius = "var(--c-border-radius-2)") : (q.style.backgroundColor = "", q.style.borderRadius = "");
    }), l.icon) {
      const H = document.createElement("i");
      H.classList.add("c-icon", "fas", l.icon), H.style.marginRight = "var(--c-space-2)", q.appendChild(H);
    }
    const z = document.createElement("span");
    z.textContent = l.title, q.appendChild(z), C.appendChild(q), E.appendChild(C), b.appendChild(E), u.appendChild(b);
  });
  const p = document.createElement("a");
  p.setAttribute("role", "button"), p.setAttribute("tabindex", "0"), p.classList.add("p-menubar-button"), p.setAttribute("aria-haspopup", "true"), p.setAttribute("aria-expanded", "false"), p.setAttribute("aria-label", "Navigation"), p.setAttribute("data-pc-section", "button"), p.setAttribute("aria-controls", "pv_id_3"), p.innerHTML = '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" class="p-icon" aria-hidden="true" data-pc-section="menubuttonicon"><path fill-rule="evenodd" clip-rule="evenodd" d="M13.3226 3.6129H0.677419C0.497757 3.6129 0.325452 3.54152 0.198411 3.41448C0.0713707 3.28744 0 3.11514 0 2.93548C0 2.75581 0.0713707 2.58351 0.198411 2.45647C0.325452 2.32943 0.497757 2.25806 0.677419 2.25806H13.3226C13.5022 2.25806 13.6745 2.32943 13.8016 2.45647C13.9286 2.58351 14 2.75581 14 2.93548C14 3.11514 13.9286 3.28744 13.8016 3.41448C13.6745 3.54152 13.5022 3.6129 13.3226 3.6129ZM13.3226 7.67741H0.677419C0.497757 7.67741 0.325452 7.60604 0.198411 7.479C0.0713707 7.35196 0 7.17965 0 6.99999C0 6.82033 0.0713707 6.64802 0.198411 6.52098C0.325452 6.39394 0.497757 6.32257 0.677419 6.32257H13.3226C13.5022 6.32257 13.6745 6.39394 13.8016 6.52098C13.9286 6.64802 14 6.82033 14 6.99999C14 7.17965 13.9286 7.35196 13.8016 7.479C13.6745 7.60604 13.5022 7.67741 13.3226 7.67741ZM0.677419 11.7419H13.3226C13.5022 11.7419 13.6745 11.6706 13.8016 11.5435C13.9286 11.4165 14 11.2442 14 11.0645C14 10.8848 13.9286 10.7125 13.8016 10.5855C13.6745 10.4585 13.5022 10.3871 13.3226 10.3871H0.677419C0.497757 10.3871 0.325452 10.4585 0.198411 10.5855C0.0713707 10.7125 0 10.8848 0 11.0645C0 11.2442 0.0713707 11.4165 0.198411 11.5435C0.325452 11.6706 0.497757 11.7419 0.677419 11.7419Z" fill="currentColor"></path></svg>', p.addEventListener("click", () => {
    a.classList.toggle("p-menubar-mobile-active"), u.style.zIndex = a.classList.contains("p-menubar-mobile-active") ? "1200" : "";
  }), window.addEventListener("resize", () => {
    window.innerWidth < 955 ? a.classList.add("p-menubar-mobile") : (a.classList.remove("p-menubar-mobile"), a.classList.remove("p-menubar-mobile-active"));
  }), window.dispatchEvent(new Event("resize"));
  const x = document.createElement("div");
  return x.classList.add("p-menubar-end"), x.setAttribute("data-pc-section", "end"), x.style.display = "flex", x.style.gap = ".5em", x.style.alignItems = "center", e.customButtons && e.customButtons.forEach((l) => {
    x.appendChild(l);
  }), a.appendChild(c), a.appendChild(p), a.appendChild(u), a.appendChild(x), n.appendChild(a), n;
}
const cssText = `
.eb-select {
    background-image: url(data:image/svg+xml;charset=US-ASCII,%3Csvg%20viewBox%3D%220%20-4.5%2020%2020%22%20version%3D%221.1%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%20fill%3D%22%23ffffff%22%3E%3Cg%20id%3D%22SVGRepo_bgCarrier%22%20stroke-width%3D%220%22%3E%3C%2Fg%3E%3Cg%20id%3D%22SVGRepo_tracerCarrier%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%3C%2Fg%3E%3Cg%20id%3D%22SVGRepo_iconCarrier%22%3E%20%3Ctitle%3Earrow_down%20%5B%23ffffff%5D%3C%2Ftitle%3E%20%3Cdesc%3ECreated%20with%20Sketch.%3C%2Fdesc%3E%20%3Cdefs%3E%20%3C%2Fdefs%3E%20%3Cg%20id%3D%22Page-1%22%20stroke%3D%22none%22%20stroke-width%3D%221%22%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%20%3Cg%20id%3D%22Dribbble-Light-Preview%22%20transform%3D%22translate%28-220.000000%2C%20-6684.000000%29%22%20fill%3D%22%23ffffff%22%3E%20%3Cg%20id%3D%22icons%22%20transform%3D%22translate%2856.000000%2C%20160.000000%29%22%3E%20%3Cpath%20d%3D%22M164.292308%2C6524.36583%20L164.292308%2C6524.36583%20C163.902564%2C6524.77071%20163.902564%2C6525.42619%20164.292308%2C6525.83004%20L172.555873%2C6534.39267%20C173.33636%2C6535.20244%20174.602528%2C6535.20244%20175.383014%2C6534.39267%20L183.70754%2C6525.76791%20C184.093286%2C6525.36716%20184.098283%2C6524.71997%20183.717533%2C6524.31405%20C183.328789%2C6523.89985%20182.68821%2C6523.89467%20182.29347%2C6524.30266%20L174.676479%2C6532.19636%20C174.285736%2C6532.60124%20173.653152%2C6532.60124%20173.262409%2C6532.19636%20L165.705379%2C6524.36583%20C165.315635%2C6523.96094%20164.683051%2C6523.96094%20164.292308%2C6524.36583%22%20id%3D%22arrow_down-%5B%23ffffff%5D%22%3E%20%3C%2Fpath%3E%20%3C%2Fg%3E%20%3C%2Fg%3E%20%3C%2Fg%3E%20%3C%2Fg%3E%3C%2Fsvg%3E);
    background-repeat: no-repeat;
    background-position: right 0.7rem top 50%;
    background-size: 0.65rem auto;
    width: 100%;
    height: var(--c-space-10);
    border-radius: var(--c-border-radius-2) 0px 0px var(--c-border-radius-2) !important;
    border: var(--c-border-width-1) solid var(--c-border-default);
    background-color: var(--c-bg-default);
    color: var(--c-fg-default);
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    padding: 0 0.5em;
}
`;
function createSelect(t, e) {
  t.helpers.loadCSS({ id: "eb-select", cssText });
  const n = document.createElement("select");
  return n.classList.add("eb-select"), e.forEach((a) => {
    const c = document.createElement("option");
    c.value = a.value, c.textContent = a.label, n.appendChild(c);
  }), n;
}
function minifyHTML(t, ...e) {
  return t.reduce((n, a, c) => {
    let o = a + (e[c] !== void 0 ? e[c] : "");
    return n + o.replace(/\s+/g, " ").trim();
  }, "");
}
const generateTableHTML = () => minifyHTML`
      <table role="table" class="p-datatable-table" data-pc-section="table">
        <thead class="p-datatable-thead" role="rowgroup" data-pc-section="thead" style="position: sticky;">
          <tr role="row" data-pc-section="headerrow">
          </tr>
        </thead>
        <tbody class="p-datatable-tbody" role="rowgroup" data-pc-section="tbody">
        </tbody>
      </table>
    `.trim(), createTable = (t, e) => new TableAPI(e);
class TableAPI {
  constructor(e) {
    this.config = e, this.rows = [], this.tableElement = document.createElement("div"), this.tableElement.className = "p-datatable p-datatable-responsive-scroll p-datatable-striped p-datatable-sm", this.tableElement.style.overflow = "auto", this.tableElement.style.width = "100%", this.tableElement.innerHTML = generateTableHTML(), this.tableBody = this.tableElement.querySelector(
      ".p-datatable-tbody"
    );
    const n = this.tableElement.querySelector("table");
    n.style.width = "100%", n.style.tableLayout = "fixed";
    const a = this.tableElement.querySelector(
      "[data-pc-section=headerrow]"
    );
    if (!a)
      throw new Error("Column row not found");
    this.config.columns.forEach((c) => {
      const o = document.createElement("th");
      o.className = "p-column-header", o.setAttribute("role", "columnheader"), o.setAttribute("data-pc-section", "headercell"), o.setAttribute("data-p-resizable-column", "false"), o.setAttribute("data-p-filter-column", "false"), o.setAttribute("data-p-reorderable-column", "false"), o.setAttribute("first", "0");
      const u = document.createElement("div");
      u.className = "p-column-header-content", u.setAttribute("data-pc-section", "headercontent");
      const h = document.createElement("span");
      h.className = "p-column-title", h.setAttribute("data-pc-section", "headertitle"), h.textContent = c.name, u.appendChild(h), o.appendChild(u), c.width && (o.style.width = c.width), a.appendChild(o);
    });
  }
  filterRows(e) {
    let n = 0;
    this.rows.forEach((a) => {
      const c = a.htmlElement, o = a.cells;
      let u = !1;
      o.forEach((h) => {
        var p;
        typeof h.value == "string" ? h.value.toLowerCase().includes(e.toLowerCase()) && (u = !0) : (p = h.value.textContent) != null && p.toLowerCase().includes(e.toLowerCase()) && (u = !0);
      }), u ? (c.style.removeProperty("display"), c.classList.remove("p-row-even", "p-row-odd"), c.classList.add(
        n % 2 === 0 ? "p-row-even" : "p-row-odd"
      ), n++) : (c.style.display = "none", c.removeAttribute("data-is-even"));
    });
  }
  clearRows() {
    this.rows.forEach((e) => {
      e.htmlElement.remove();
    }), this.rows = [];
  }
  addRow(e, n) {
    const a = (this.tableBody.children.length + 1) % 2 !== 0, c = document.createElement("tr");
    c.className = `p-row-${a ? "even" : "odd"}`, c.setAttribute("tabindex", "-1"), c.setAttribute("role", "row"), c.setAttribute("data-pc-section", "bodyrow"), c.setAttribute("data-p-index", "0"), c.setAttribute("data-p-selectable-row", "false"), c.setAttribute("draggable", "false"), e.forEach((o) => {
      var p;
      const u = (p = this.config.columns.find(
        (x) => x.name === o.columnName
      )) == null ? void 0 : p.width, h = document.createElement("td");
      h.setAttribute("role", "cell"), h.style.whiteSpace = "nowrap", h.style.overflow = "hidden", h.setAttribute("data-pc-section", "bodycell"), h.setAttribute("data-pc-name", "bodycell"), h.setAttribute("data-p-selection-column", "false"), h.setAttribute("data-p-cell-editing", "false"), u && (h.style.width = u), typeof o.value == "string" ? h.textContent = o.value : h.appendChild(o.value), c.appendChild(h);
    }), n && c.addEventListener("click", n), this.tableBody.appendChild(c), this.rows.push({
      htmlElement: c,
      cells: e
    });
  }
  getHTMLElement() {
    return this.tableElement;
  }
  static createTable(e) {
    return new TableAPI(e);
  }
}
class ComponentsAPI {
  constructor(e) {
    this.apiInstance = e;
  }
  createTable(e) {
    return createTable(this.apiInstance, e);
  }
  createNavigationBar(e) {
    return createNavigationBar(this.apiInstance, e);
  }
  createCheckbox() {
    return createCheckbox(this.apiInstance);
  }
  createTextInput(e, n, a = !1, c) {
    return createTextInput(this.apiInstance, e, n, a, c);
  }
  createSelectInput(e) {
    return createSelect(this.apiInstance, e);
  }
}
let promptCommands = [];
const openPromptMenu = (t, e) => {
  var l;
  const n = document.createElement("div");
  n.classList.add("custom");
  const a = document.createElement("div");
  a.setAttribute("command-root", ""), n.appendChild(a);
  const c = document.createElement("div");
  c.setAttribute("command-dialog", ""), a.appendChild(c);
  const o = document.createElement("div");
  o.setAttribute("command-dialog-mask", ""), o.style.display = "flex", o.style.justifyContent = "center", o.style.alignItems = "center", o.addEventListener("click", () => {
    n.remove();
  }), c.appendChild(o);
  const u = document.createElement("div");
  u.setAttribute("command-dialog-wrapper", ""), u.style.minWidth = "600px", u.style.padding = "1em", u.style.margin = "0", o.appendChild(u);
  const h = document.createElement("div");
  h.setAttribute("command-dialog-body", ""), h.style.display = "flex", h.style.gap = "0.5em", u.addEventListener("click", (b) => {
    b.stopPropagation();
  }), u.appendChild(h);
  const p = t.components.createTextInput(
    "100%",
    e.promptPlaceholder
  );
  p.style.zIndex = "100", p.addEventListener("click", (b) => {
    b.stopPropagation();
  }), h.appendChild(p);
  const x = getCaidoAPI().ui.button({
    label: "Submit",
    variant: "primary"
  });
  x.addEventListener("click", () => {
    const b = p.querySelector("input");
    e.onPrompt(b.value), n.remove();
  }), h.appendChild(x), document.body.appendChild(n), (l = p.querySelector("input")) == null || l.focus(), p.addEventListener("keydown", (b) => {
    b.key === "Enter" && x.click(), b.key === "Escape" && n.remove();
  });
}, createPromptCommand = (t, e, n, a) => {
  promptCommands.push({
    commandName: e,
    promptPlaceholder: n,
    onPrompt: a
  });
};
class PromptCommandAPI {
  constructor(e) {
    this.apiInstance = e, this.apiInstance.eventManager.on("onCommandRun", (n) => {
      const a = promptCommands.find(
        (c) => c.commandName === n
      );
      a && openPromptMenu(this.apiInstance, a);
    });
  }
  createPromptCommand(e, n, a) {
    createPromptCommand(this.apiInstance, e, n, a);
  }
}
const modalCSS = `
  .evenbetter-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 99999;
  }
  
  .evenbetter-modal__content {
    background-color: var(--c-bg-default);
    padding: 1rem;
    border-radius: 5px;
    width: 50%;
    max-width: 500px;
  }
  
  .evenbetter-modal__content-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
  }
  
  .evenbetter-modal__content-header-title {
    font-size: 1.1rem;
    margin: 0;
  }
  
  .evenbetter-modal__content-body {
    margin-bottom: 1rem;
  }
  
  .evenbetter-modal__content-body-text {
    font-size: 0.9rem;
    color: var(--c-fg-subtle);
    word-break: break-word;
    user-select: text !important;
    -webkit-user-select: text !important;
  
    white-space: break-spaces;
    overflow: auto;
    max-height: 40em;
  }
  
  .evenbetter-modal__content-body a {
    color: var(--c-fg-default);
  }
  
  .evenbetter-modal__content-body-close {
    background-color: var(--c-bg-subtle);
    border: 1px solid var(--c-header-cell-border);
    color: #fff;
    padding: 0.5rem;
    width: 100%;
    margin-top: 0.5rem;
    cursor: pointer;
    transition: 0.2s ease background-color;
  }
  
  .evenbetter-modal__content-body-close:hover {
    background-color: var(--c-bg-default);
  }
`, generateModal = ({
  modalAPI: t,
  title: e,
  content: n
}) => {
  const a = document.createElement("div");
  a.classList.add("evenbetter-modal");
  const c = document.createElement("div");
  c.classList.add("evenbetter-modal__content");
  const o = document.createElement("div");
  o.classList.add("evenbetter-modal__content-header");
  const u = document.createElement("h2");
  u.classList.add("evenbetter-modal__content-header-title"), u.textContent = e, o.appendChild(u);
  const h = document.createElement("div");
  h.classList.add("evenbetter-modal__content-body");
  const p = document.createElement("p");
  p.classList.add("evenbetter-modal__content-body-text"), typeof n == "string" ? p.innerHTML = n : n instanceof HTMLElement && p.appendChild(n);
  const x = document.createElement("button");
  return x.classList.add("evenbetter-modal__content-body-close"), x.textContent = "Close", x.addEventListener("click", t.closeModal), h.appendChild(p), h.appendChild(x), c.appendChild(o), c.appendChild(h), a.appendChild(c), a.setAttribute("data-modal-title", e), a;
}, isModalOpen = () => document.querySelector(".evenbetter-modal") !== null;
class ModalAPI {
  constructor(e) {
    this.evenBetterAPI = e, this.evenBetterAPI.helpers.loadCSS({
      id: "evenbetterapi-modal",
      cssText: modalCSS.toString()
    }), document.addEventListener("keydown", (n) => {
      n.key === "Escape" && this.closeModal();
    });
  }
  openModal({
    title: e,
    content: n
  }) {
    isModalOpen() && this.closeModal();
    const a = generateModal({ modalAPI: this, title: e, content: n });
    document.body.appendChild(a);
  }
  closeModal() {
    const e = document.querySelector(".evenbetter-modal");
    e == null || e.remove();
  }
}
const isTauri = () => typeof __TAURI_INVOKE__ < "u", invokeTauri = async (t, e) => await __TAURI_INVOKE__(t, e), loadedCSSModules = /* @__PURE__ */ new Set();
class HelpersAPI {
  constructor() {
    this.downloadFile = async (e, n) => {
      if (isTauri())
        return invokeTauri("download", { filename: e, data: n });
      {
        const a = new Blob([n], { type: "text/plain" }), c = URL.createObjectURL(a), o = document.createElement("a");
        o.href = c, o.download = e, o.click();
      }
    }, this.openInBrowser = (e) => {
      isTauri() ? invokeTauri("open_in_browser", { url: e }) : window.open(e, "_blank");
    }, this.loadCSS = ({ id: e, cssText: n }) => {
      if (loadedCSSModules.has(e) || document.querySelector(`#${e}`))
        return;
      const a = document.createElement("style");
      a.id = e, a.textContent = n, a.classList.add("evenbetterapi-css-module"), document.head.appendChild(a), loadedCSSModules.add(e);
    };
  }
}
var InputType = /* @__PURE__ */ ((t) => (t.TEXT = "text", t.NUMBER = "number", t.CHECKBOX = "checkbox", t.SELECT = "select", t))(InputType || {});
class SettingsPage {
  constructor(e, n) {
    this.evenBetterAPI = e, this.title = n.title, this.description = n.description, this.inputGroups = n.inputGroups, this.initDefaults();
  }
  async initDefaults() {
    for (const [e, n] of this.inputGroups.entries())
      for (const [a, c] of n.inputs.entries())
        c.defaultValue && !getSetting(c.id) && await setSetting(c.id, c.defaultValue);
  }
  className(e) {
    return `eb-settings-page__${e}`;
  }
  render() {
    const e = document.createElement("div");
    e.classList.add(this.className("container"));
    const n = document.createElement("div");
    n.classList.add(this.className("header"));
    const a = document.createElement("h1");
    a.textContent = this.title, a.classList.add(this.className("title")), n.appendChild(a);
    const c = document.createElement("p");
    c.textContent = this.description, c.classList.add(this.className("description")), n.appendChild(c), e.appendChild(n);
    const o = document.createElement("div");
    return o.classList.add(this.className("groups")), this.inputGroups.forEach((u) => {
      const h = document.createElement("div");
      h.classList.add(this.className("group")), u.width && (u.width.toLowerCase() == "fill-space" ? h.style.flex = "1" : h.style.width = u.width);
      const p = document.createElement("div");
      p.classList.add(this.className("group-header"));
      const x = document.createElement("div");
      x.textContent = u.groupName, x.classList.add(this.className("group-name"));
      const l = document.createElement("p");
      l.textContent = u.groupDescription, l.classList.add(this.className("group-description")), p.appendChild(x), p.appendChild(l), h.appendChild(p);
      const b = document.createElement("div");
      b.classList.add(this.className("group-inputs")), u.inputs.forEach((E) => {
        if (u.separateWithLine) {
          const q = document.createElement("hr");
          q.classList.add(this.className("line")), b.appendChild(q);
        }
        const C = this.createInputElement(E, (q) => {
          setSetting(E.id, q);
        });
        b.appendChild(C);
      }), h.appendChild(b), o.appendChild(h);
    }), e.appendChild(o), e;
  }
  createInputElement(e, n) {
    const a = document.createElement("div");
    a.classList.add(this.className("input-wrapper")), e.type == InputType.CHECKBOX && a.classList.add(this.className("checkbox-wrapper"));
    const c = document.createElement("label");
    e.labelAsHTML ? c.innerHTML = e.label : c.textContent = e.label, c.setAttribute("for", e.id), a.appendChild(c);
    let o;
    switch (e.type) {
      case InputType.TEXT:
        o = this.evenBetterAPI.components.createTextInput(
          "100%",
          e.placeholder
        );
        const u = o.querySelector(
          "input"
        ), h = getSetting(e.id);
        h ? u.value = h : u.value = e.defaultValue, n && u.addEventListener("input", (F) => {
          n(u.value);
        });
        break;
      case InputType.NUMBER:
        o = this.evenBetterAPI.components.createTextInput(
          "100%",
          e.placeholder
        ), o.querySelector("input").type = "number";
        const p = o.querySelector(
          "input"
        ), x = getSetting(e.id);
        x ? p.value = x : p.value = e.defaultValue, n && p.addEventListener("input", (F) => {
          n(p.value);
        });
        break;
      case InputType.CHECKBOX:
        o = this.evenBetterAPI.components.createCheckbox();
        const l = o.querySelector(
          "input"
        ), b = getSetting(e.id);
        b ? l.checked = b == "true" : l.checked = e.defaultValue == "true", n && l.addEventListener("change", (F) => {
          n(l.checked.toString());
        });
        break;
      case InputType.SELECT:
        const E = e.options;
        o = this.evenBetterAPI.components.createSelectInput(E);
        const C = o, q = getSetting(e.id);
        q ? C.value = q : C.value = e.defaultValue, n && C.addEventListener("change", (F) => {
          n(C.value);
        });
        break;
      default:
        throw new Error(`Invalid input type: ${e.type}`);
    }
    return a.appendChild(o), a;
  }
}
class TemplatesAPI {
  constructor(e) {
    this.apiInstance = e;
  }
  createSettingsPage(e) {
    return new SettingsPage(this.apiInstance, e);
  }
}
class EvenBetterAPI {
  constructor(e, n) {
    setCaidoAPI(e), setPluginData(n), this.eventManager = new EventManager();
    const a = new OnCaidoLoad(), c = new OnSettingsTabOpen(), o = new OnPageOpen(this.eventManager), u = new OnContextMenuOpen(), h = new OnCommandRun();
    this.eventManager.registerEvent("onCaidoLoad", a), this.eventManager.registerEvent("onSettingsTabOpen", c), this.eventManager.registerEvent("onPageOpen", o), this.eventManager.registerEvent("onContextMenuOpen", u), this.eventManager.registerEvent("onCommandRun", h), this.eventManager.on("onCaidoLoad", () => {
      this.eventManager.triggerEvent("onPageOpen", {
        newUrl: location.hash,
        oldUrl: ""
      });
      const p = getWelcomeToast();
      p && (this.toast.showToast(JSON.parse(p)), setWelcomeToast(void 0));
    }), this.eventManager.initEvents(), this.helpers = new HelpersAPI(), this.promptCommands = new PromptCommandAPI(this), this.modal = new ModalAPI(this), this.toast = new ToastAPI(this), this.components = new ComponentsAPI(this), this.templates = new TemplatesAPI(this), this.version = EVENBETTERAPI_VERSION;
  }
}
const init = (t) => {
  setCaidoAPI$1(t), log$1.info(`EvenBetter ${CURRENT_VERSION} is loading, thanks for using it! 🎉`);
  const e = new EvenBetterAPI(t, {
    manifestID: "evenbetter-extensions",
    name: "EvenBetter: Extensions"
  });
  setEvenBetterAPI(e), setup();
  const n = new OnSSRFHit(), a = new OnSSRFInstanceChange();
  e.eventManager.registerEvent("onSSRFHit", n), e.eventManager.registerEvent(
    "onSSRFInstanceChange",
    a
  ), getCaidoAPI$1().commands.register("evenbetter:suggesthttpql", {
    name: "Suggest HTTPQL query",
    group: "EvenBetter: AI",
    run: () => {
    }
  }), getCaidoAPI$1().commandPalette.register("evenbetter:suggesthttpql"), setupSuggestAICommand(), e.eventManager.on("onPageOpen", () => {
    localStorage.setItem("previousPath", window.location.hash);
    const c = document.querySelector(
      ".c-sidebar-item[data-is-active='true']"
    );
    if (c) {
      let o = c.querySelector(".c-sidebar-item__count");
      o && (o.innerHTML = "");
    }
  }), e.eventManager.on("onSettingsTabOpen", (c) => {
    switch (c) {
      case "developer":
        const o = document.querySelector(".c-custom-js__footer");
        if (!o)
          return;
        o.removeEventListener("click", reloadPage), o.addEventListener("click", reloadPage);
    }
  }), e.eventManager.on("onCaidoLoad", () => {
    loadTheme(getSetting$1("theme")), loadFont(getSetting$1("font")), deleteAllFindings(), customLibraryTab(), quickSSRFFunctionality(), onScopeTabOpen(), onMARTabOpen(), extendedCommands(), quickDecode(), dropdownTweaks(), dropAllButtonFeature(), collectionsShare(), showResponse(), numbersPayload(), setTimeout(() => {
      sidebarTweaks();
    }, 100), quickMatchAndReplace(), setTimeout(
      () => {
        var u;
        const o = window.location.hash;
        (u = document.querySelector(".c-content")) == null || u.setAttribute("data-page", o), e.eventManager.triggerEvent("onPageOpen", {
          newUrl: o,
          oldUrl: ""
        });
      },
      window.location.hash.startsWith("#/settings/") ? 10 : 100
    ), getComputedStyle(document.documentElement).getPropertyValue("--evenbetter-css-version").replace(/['"]+/g, "").trim() !== CURRENT_VERSION && e.modal.openModal({
      title: "Incompatible CSS version",
      content: "EvenBetter Custom CSS isn't compatible with the current JS version of EvenBetter. Please update the EvenBetter CSS to the latest version."
    });
  });
}, reloadPage = () => {
  setTimeout(() => {
    location.reload();
  }, 250);
};
export {
  init
};
